"""
app.py - Lesson Studio: a chat page for asking the training material, and showing it to others.

  uv run app.py            # opens http://localhost:8765 in the browser
  uv run app.py --port 9000 --no-browser

Tabs:
  Ask              one box: a question gets an answer with its sources; a request for a document,
                   slides, a video, a conversation or audio gets that (the request decides, ask.py).
                   Chats are kept (chats.py): the list on the left reopens an earlier one.
  Prices & results what each kind of request costs (costs.py: measured here, else estimated),
                   spend today and in total, every result with its links (videos, documents, slides)

It runs the same pipeline as ask.py (ask.run). One request is made at a time (rendering uses the
whole laptop). The server listens only on this computer (127.0.0.1) and serves only data/output.

Sharing with someone who has no copy of the project (e.g. the product owner):
  1. APP_PASSWORD=<something long> in .env (then the page asks for it; without it a shared link is refused)
  2. uv run app.py (restart it after changing .env): its first line must say "password on"
  3. VS Code > Ports > Forward a Port > 8765, right-click > Port Visibility > Public; send the
     address and the password. It works while this laptop is on and app.py runs.
  Ask the data owner first: the results and the material's excerpts go through Microsoft's tunnel.
  Spending stays under DAILY_BUDGET_USD.
"""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import hmac
import json
import logging
import mimetypes
import os
import re
import socket
import statistics
import threading
import time
import uuid
import webbrowser
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urlparse

import ask
import chats
import compare
import config
import lesson
import llm
import store

log = logging.getLogger("app")
SWITCHED = ("CHAT_MODEL", "CHAT_BACKEND", "TTS_ENGINE", "REVIEW_MODEL", "RENDERER", "TTS_VOICE", "ELEVENLABS_VOICE",
            "PRO_PRESENTER", "PRO_PERSON", "CARTOON_PRESENTER")   # what a job may change for itself
_before_job: dict = {}
JOBS: dict[str, dict] = {}
BUSY = threading.Lock()

# The formats as the person sees them: settings for ask.run, and how to ask for them in words
FORMATS = [
    {"id": "auto", "label": "Auto (from my words)", "settings": {},
     "how": "", "example": ""},
    {"id": "answer", "label": "Answer to a question", "settings": {"format": "answer"}, "kind": "answer",
     "how": "Ask a question: a short answer with the source of every sentence.", "example": "What is a left join?"},
    {"id": "document", "label": "Text lecture", "settings": {"format": "text"}, "kind": "document",
     "how": "Ask for something to read: a document, lecture notes, an explanation, a summary.",
     "example": "Write a document on the three Scrum roles, with a comparison table and a summary"},
    {"id": "slides", "label": "Presentation (PDF + PowerPoint)", "settings": {"format": "slides"}, "kind": "slides",
     "how": "Ask for a presentation or slides you will present yourself (PDF + PowerPoint with speaker notes).",
     "example": "A simple 6-slide presentation on sprint planning that I can present myself"},
    {"id": "silent", "label": "Animated slides (no voice)", "settings": {"format": "video"}, "kind": "video",
     "config": {"TTS_ENGINE": "silent"},
     "how": "Ask for animated slides without a voice (a video to watch at your own pace).",
     "example": "Animated slides on the sprint review, no voice, about 2 minutes"},
    {"id": "video", "label": "Slides with narrator", "settings": {"format": "video"}, "kind": "video",
     "how": "Ask for a video or an animated presentation with a voice. Add 'clean slides' or 'with illustrations' for the look.",
     "example": "A 2-minute video lesson on the daily scrum for beginners, with illustrations"},
    {"id": "dialogue", "label": "Two characters talking", "picker": False, "settings": {"format": "dialogue", "style": "dialogue"},
     "kind": "dialogue", "how": "Ask for two people or characters talking about the topic, a conversation or an interview.",
     "example": "A 3-minute video where two characters talk about the sprint review"},
    {"id": "presenter", "label": "Slides with presenter",
     "settings": {"format": "video", "style": "presenter", "characters": "cartoon"}, "kind": "video",
     "how": "Ask for a cartoon, an animated character or an animal presenting the topic.",
     "example": "A 2-minute cartoon where a bear explains the definition of done"},
    {"id": "audio", "label": "Audio", "picker": False, "settings": {"format": "audio"}, "kind": "audio",
     "how": "Ask for something to listen to: audio, a podcast, for the way to work.",
     "example": "Something to listen to on the way to work: 3 minutes on the product backlog"},
]
LOOKS = [("auto", "Auto"), ("clean", "Clean slides"), ("illustrated", "With illustrations"),
         ("presenter", "Cartoon presenter")]
LEVELS = [("auto", "Auto"), ("beginner", "Beginner"), ("intermediate", "Intermediate"), ("expert", "Expert")]
LENGTHS = [0, 1, 2, 3, 5, 8]   # 0 = auto; 4+ minute videos become courses with chapters


class JobLog(logging.Handler):
    """Collects the log lines while a job runs (shown as progress on the page). One job runs
    at a time, so every line belongs to it, also those of the parallel chapter threads."""

    def __init__(self, job: dict) -> None:
        super().__init__(logging.INFO)
        self.job = job
        self.setFormatter(logging.Formatter("%(asctime)s %(message)s", "%H:%M:%S"))

    def emit(self, record: logging.LogRecord) -> None:
        if record.name in ("httpx", "urllib3"):
            return
        self.job["log"].append(self.format(record)[:300])
        del self.job["log"][:-200]


def file_url(path: str) -> str:
    rel = Path(path).resolve().relative_to(config.OUTPUT_DIR.resolve())
    return "/files/" + quote(rel.as_posix())


# --- what the page offers -------------------------------------------------------------------
def voices() -> list[dict]:
    """The voice engines that work here (Kokoro, plus cloud voices when they are set up)."""
    import tts
    out = []
    for engine, label in (("kokoro", "Kokoro (free, local)"), ("elevenlabs", "ElevenLabs (most natural, paid)"),
                          ("system", "Windows voice (free, robotic)")):
        ok, why = tts.check(engine)
        if ok or engine == defaults()["TTS_ENGINE"]:
            out.append({"id": engine, "label": label, "ok": ok, "detail": why,
                        "usd_per_1k": {"elevenlabs": config.ELEVENLABS_USD_PER_1K_CHARS}.get(engine, 0)})
    return out


def suggestions() -> dict:
    """Topic suggestions: the topic maps of the sources (topics.py), else the source titles."""
    out, analysed = [], False
    rows = store.available_recordings()
    for r in rows:
        m = store.read_json(store.video_dir(r["video_id"]) / "topics.json", {}) or {}
        for t in m.get("topics", []):
            analysed = True
            if t.get("depth") == "brief":   # only mentioned in the source: too thin for a lesson
                continue
            out.append({"title": t["title"], "covers": t.get("covers", ""), "source": r["title"],
                        "level": t.get("level", ""), "minutes": t.get("minutes", 2)})
    across = (store.read_json(config.OUTPUT_DIR / "topics" / "topics.json", {}) or {}).get("across") or {}
    for t in reversed(across.get("shared_topics", [])):
        out.insert(0, {"title": t["title"], "covers": t.get("covers", ""), "source": "several sources",
                       "level": t.get("level", ""), "minutes": t.get("minutes", 3)})
    if not out:
        out = [{"title": r["title"], "covers": r.get("description", ""), "source": "", "level": "", "minutes": 2}
               for r in rows]
    return {"analysed": analysed, "topics": out[:60], "sources": len(rows)}


def models() -> list[dict]:
    """The models to pick from, with their list price (the configured ones, not the one a running job uses)."""
    out = config.model_choices(defaults()["CHAT_MODEL"], defaults()["CHAT_BACKEND"])
    for m in out:
        m["price_in"], m["price_out"] = (round(x, 4) for x in llm.price(m["id"], m["backend"]))
    return out


def running() -> str:
    return next((j["id"] for j in JOBS.values() if j["status"] in ("queued", "running")), "")


def state() -> dict:
    """What the chat page needs on load: a request being made, spend today."""
    job = JOBS.get(running()) or {}
    return {"running": job.get("id", ""), "running_request": job.get("request", ""), "running_chat": job.get("chat", ""),
            "today": round(llm.spent_today(), 3), "daily": config.DAILY_BUDGET_USD}


def options() -> dict:
    return {"formats": FORMATS, "looks": LOOKS, "levels": LEVELS, "lengths": LENGTHS, "models": models(),
            "voices": voices(), "topics": suggestions(), "course_from": course_min(), "labels": ask.LABELS,
            "default_voice": defaults()["TTS_ENGINE"], "running": running(),
            "budget": {"today": round(llm.spent_today(), 3), "daily": config.DAILY_BUDGET_USD},
            "elevenlabs": elevenlabs_left()}


def elevenlabs_left() -> dict | None:
    """ElevenLabs characters used and left (usage.py), or None when it is not set up."""
    import usage
    try:
        return usage.elevenlabs()
    except Exception:   # noqa: BLE001 - information only
        return None


def course_min() -> float:
    import course
    return course.COURSE_MIN_MINUTES


# --- cost estimate and report -----------------------------------------------------------------
BASE = {"document": (0.02, 0.01), "slides": (0.06, 0.04), "video": (0.06, 0.06), "dialogue": (0.08, 0.07),
        "audio": (0.06, 0.06), "course": (0.10, 0.07)}   # rough $ fixed + per minute, default model


def kind_of(fmt_id: str, minutes: float) -> str:
    f = next((f for f in FORMATS if f["id"] == fmt_id), FORMATS[0])
    kind = f.get("kind", "video")
    if kind in ("video", "dialogue") and minutes >= course_min():
        return "course"
    return kind


def estimate(fmt_id: str, minutes: float, model_id: str, voice: str) -> dict:
    """Cost of a lesson before making it: the average of earlier results of the same kind and
    model (per minute), else a rough figure from the model's price; plus a paid voice."""
    minutes = minutes or 2
    kind = kind_of(fmt_id, minutes)
    same = [r for r in compare.rows(kind=kind) if r["writing_model"].startswith(model_id) and r["cost_usd"]
            and r.get("minutes")]
    if same:
        per_min = statistics.median(float(r["cost_usd"]) / max(0.5, float(r["minutes"])) for r in same)
        cost, basis = per_min * minutes, f"median of {len(same)} earlier {kind} result(s) with this model"
    else:
        fixed, per = BASE.get(kind, BASE["video"])
        backend = next((m["backend"] for m in models() if m["id"] == model_id), defaults()["CHAT_BACKEND"])
        p_in, p_out = llm.price(model_id, backend)
        ref_in, ref_out = llm.price(defaults()["CHAT_MODEL"], defaults()["CHAT_BACKEND"])   # BASE is measured with it
        ratio = 0.0 if not (p_in + p_out) else (p_in + p_out) / (ref_in + ref_out) if (ref_in + ref_out) else 1.0
        cost, basis = (fixed + per * minutes) * ratio, "rough estimate from the model's price (no earlier results yet)"
    if voice == "elevenlabs" and kind not in ("document", "slides"):
        rate = config.ELEVENLABS_USD_PER_1K_CHARS
        cost += 900 * minutes / 1000 * rate * (1.15 if kind == "dialogue" else 1)
        basis += f"; voice ~{900 * minutes:,.0f} characters"
    if config.COST_MARGIN_PCT and cost:   # on the high side, to be safe
        cost *= 1 + config.COST_MARGIN_PCT / 100
        basis += f"; +{config.COST_MARGIN_PCT:g}% safety margin"
    return {"usd": round(cost, 3), "basis": basis, "kind": kind}


def report() -> dict:
    """Spend and results per model and per format."""
    rows = compare.rows()
    if rows:
        compare.write(rows)

    def group(key):
        out = {}
        for r in rows:
            g = out.setdefault(r[key] or "-", {"name": r[key] or "-", "count": 0, "cost": [], "time": [], "faithful": [],
                                              "ok": 0})
            g["count"] += 1
            g["cost"].append(float(r["cost_usd"] or 0))
            if r.get("total_s"):
                g["time"].append(float(r["total_s"]))
            if r.get("faithful"):
                g["faithful"].append(float(r["faithful"]))
            g["ok"] += r.get("verdict") in ("OK", "CHECK")
        return [{"name": g["name"], "count": g["count"], "total_usd": round(sum(g["cost"]), 3),
                 "avg_usd": round(statistics.mean(g["cost"]), 3), "avg_s": round(statistics.mean(g["time"])) if g["time"] else None,
                 "avg_faithful": round(statistics.mean(g["faithful"]), 1) if g["faithful"] else None,
                 "usable": g["ok"]} for g in sorted(out.values(), key=lambda g: -g["count"])]
    return {"count": len(rows), "total_usd": round(sum(float(r["cost_usd"] or 0) for r in rows), 3),
            "today_usd": round(llm.spent_today(), 3), "daily_budget": config.DAILY_BUDGET_USD,
            "by_model": group("writing_model"), "by_kind": group("kind"),
            "csv": "/files/comparison.csv" if (config.OUTPUT_DIR / "comparison.csv").exists() else ""}


# what a file in a result's folder is, when it has none of the usual names (ask.FILES)
BY_SUFFIX = {".mp4": "video", ".mp3": "audio", ".html": "document", ".pdf": "pdf", ".pptx": "pptx", ".md": "markdown"}


def result_files(folder: Path) -> dict:
    """Links to a result's files: the usual names, else the files its run card lists, else any video,
    audio, document or slides in its folder (results made by other tools, or by earlier versions)."""
    files = {k: file_url(str(folder / f)) for k, f in ask.FILES.items() if (folder / f).exists()}
    if not set(files) & {"answer", "video", "avatar_video", "audio", "document", "pdf", "pptx"}:
        card = store.read_json(folder / "run_card.json", {}) or {}
        listed = [folder / f for f in card.get("files", []) if isinstance(f, str)]
        found = sorted((p for p in folder.glob("*") if p.suffix in BY_SUFFIX and "_silent" not in p.name),
                       key=lambda p: -p.stat().st_mtime)
        for path in [p for p in listed if p.exists()] + found:
            key = BY_SUFFIX.get(path.suffix)
            if key and key not in files and path.is_file():
                files[key] = file_url(str(path))
    return files


def results(limit: int = 1000) -> list[dict]:
    """Every result made, the newest first (the whole history; a limit only against a runaway list)."""
    rows = compare.rows()[:limit]
    fb = chats.feedback_by_result()
    for r in rows:
        folder = config.OUTPUT_DIR / r["folder"]
        r["files"] = result_files(folder) if folder.is_dir() else {}
        r["feedback"] = fb.get(r["folder"], {})
        if not r.get("topic"):
            r["topic"] = ((store.read_json(folder / "run_card.json", {}) or {}).get("request") or {}).get("text", "") \
                or r.get("title", "")
    return rows


def comparisons() -> list[dict]:
    """The comparisons made by compare_video.py, newest first, with links to their videos and voices."""
    out = []
    for path in sorted(config.OUTPUT_DIR.glob("*-compare-*/comparison.json"), reverse=True)[:40]:
        d = store.read_json(path, {}) or {}
        folder = path.parent
        for x in d.get("voices", []) + d.get("solutions", []):
            f = folder / x.get("file", "-")
            x["url"] = file_url(str(f)) if x.get("file") and f.exists() else ""
            jpg = f.with_suffix(".jpg")   # its still (compare_video.py makes it): shown until play
            x["poster"] = file_url(str(jpg)) if x.get("file") and jpg.exists() else ""
            x["by_voice_url"] = {vid: file_url(str(folder / rel)) for vid, rel in (x.get("by_voice") or {}).items()
                                 if (folder / rel).exists()}   # a presenter's video for each narrator
            x["by_look_url"] = {lid: file_url(str(folder / rel)) for lid, rel in (x.get("by_look") or {}).items()
                                if (folder / rel).exists()}   # the same video in each look
            x["by_look_voice_url"] = {lid: {vid: file_url(str(folder / rel)) for vid, rel in by.items() if (folder / rel).exists()}
                                      for lid, by in (x.get("by_look_voice") or {}).items()}   # a presenter: look x narrator
            x["version_by_url"] = {file_url(str(folder / rel)): {"v": v, "at": (x.get("made_at") or {}).get(rel, "")}
                                   for rel, v in (x.get("versions") or {}).items() if (folder / rel).exists()}
        d["folder"] = folder.name
        try:
            import compare_video
            fixed = {x["id"]: x for x in compare_video.solutions()}   # names, prices and kinds as they are now
            d["solutions"] = [s for s in d.get("solutions", []) if s.get("id") in fixed]   # a solution taken out
            for s in d.get("solutions", []):
                for k in ("talks", "group", "variant", "about", "price", "who"):
                    if k in fixed.get(s["id"], {}):
                        s[k] = fixed[s["id"]][k]
                looks = compare_video.looks_of(fixed[s["id"]]) if s.get("id") in fixed else []
                if len(looks) > 1:   # the looks' names as they are now
                    s["looks"] = [{k: v for k, v in lk.items() if k != "set"} for lk in looks]
            compare_video.video_costs(folder, d)
        except Exception as e:   # noqa: BLE001 - the costs are information only
            log.info("Costs of %s not worked out: %s", folder.name, e)
        d.pop("state", None)
        out.append(d)
    return merged(out)[:10]


def _made(s: dict) -> bool:
    return s.get("status") == "done" and bool(s.get("url"))


def merged(comps: list[dict]) -> list[dict]:
    """Comparisons of the same content (the same source video or topic) as one: the newest, with every video
    made in the older runs that the newest has not (a run with --only makes only some tools; nothing made
    before is lost from the page). Newest first."""
    out: list[dict] = []
    by_key: dict[str, dict] = {}
    for d in comps:   # newest first
        key = str(d.get("source") or d.get("title") or d.get("folder"))
        base = by_key.get(key)
        if base is None:
            by_key[key] = d
            out.append(d)
            continue
        have = {v.get("id") for v in base.get("voices", [])}
        base.setdefault("voices", []).extend(v for v in d.get("voices", []) if v.get("id") not in have and v.get("url"))
        mine = {s.get("id"): k for k, s in enumerate(base.get("solutions", []))}
        for s in d.get("solutions", []):
            if not _made(s):
                continue
            k = mine.get(s.get("id"))
            if k is None:
                base["solutions"].append(s)
                mine[s.get("id")] = len(base["solutions"]) - 1
                continue
            b = base["solutions"][k]
            if not _made(b):
                base["solutions"][k] = s
                continue
            for field in ("by_voice_url", "by_look_url", "version_by_url"):   # made only in the older run
                for x, url in (s.get(field) or {}).items():
                    b.setdefault(field, {}).setdefault(x, url)
            for lid, by in (s.get("by_look_voice_url") or {}).items():
                for vid, url in by.items():
                    b.setdefault("by_look_voice_url", {}).setdefault(lid, {}).setdefault(vid, url)
        base.setdefault("merged_from", []).append(d.get("folder"))
    return out


def decks() -> list[dict]:
    """Silent animated decks (deck_video.py): one video per engine."""
    out = []
    for folder in sorted(config.OUTPUT_DIR.glob("*-deck-*"), reverse=True)[:20]:
        videos = sorted(folder.glob("slides_*.mp4"))
        if videos:
            sb = store.read_json(folder / "storyboard.json", {}) or {}
            out.append({"title": sb.get("title") or folder.name, "created": sb.get("created", ""),
                        "videos": {v.stem.replace("slides_", ""): file_url(str(v)) for v in videos}})
    return out


# What Lesson Studio makes, as the price list shows it: id, name, example, kind of result (run cards),
# minutes, spoken (a narrator), presenter ("" | "cartoon")
OFFER = [
    ("answer", "Answer to a question", "a few sentences with their sources", "answer", 0, False, ""),
    ("document", "Text lecture", "about 5 minutes to read", "document", 5, False, ""),
    ("slides", "Presentation", "about 10 slides: PDF + PowerPoint with speaker notes", "slides", 10, False, ""),
    ("silent", "Animated slides (no voice)", "a 2-minute video", "video", 2, False, ""),
    ("video", "Slides with narrator", "a 2-minute video", "video", 2, True, ""),
    ("presenter", "Slides with presenter (our cartoon)", "a 2-minute video", "video", 2, True, "cartoon"),
]
CHARS_PER_MIN = 900   # spoken characters in a minute of narration

# The cloud around the tools, a month (AWS Frankfurt list prices, estimates). Its own AWS account in both
# cases (not joined to the agent platform: the product owner's decision). Minimum: one production
# environment, kept lean. Optimal: production + test, fuller monitoring and security, AWS support.
# part, what for, minimum (low, high), optimal (low, high)
CLOUD = [
    ("App servers + making the videos", "The chat, the lessons and the videos (videos on demand)", (100, 130), (100, 130)),
    ("Load balancer", "The page's address, HTTPS", (50, 50), (50, 50)),
    ("Network", "NAT gateway, private links to Bedrock and other AWS services", (50, 100), (160, 200)),
    ("Search index", "Searching the recordings (a file in S3 at minimum, OpenSearch at optimal)", (0, 150), (150, 500)),
    ("Storage + database", "Recordings' knowledge, videos, results, chats, feedback", (25, 60), (25, 90)),
    ("Monitoring", "Logs, metrics, alerts, dashboards", (30, 80), (50, 150)),
    ("Security", "Firewall, threat detection, secrets, keys, backups", (30, 80), (50, 130)),
    ("Test environment", "Trying changes before they go live", (0, 0), (200, 500)),
    ("AWS support plan", "Help from AWS when something breaks", (0, 0), (100, 100)),
]
# A typical department month, for the Claude line (not a price per video): up to this many videos and questions
MONTH_VIDEOS, MONTH_QUESTIONS, QUESTION_USD = 100, 500, 0.02
VIDEO_MIN = 2                     # minutes per video, on average


def claude_per_video() -> dict:
    """Claude's cost of one video, measured on the videos made here (the voice left out); a rough figure
    while none is made. Only feeds the monthly Claude line."""
    import costs
    per = []
    for _path, card in costs.run_cards(("video", "course", "dialogue", "avatar video")):
        if card.get("plan_only"):
            continue
        steps = (card.get("cost") or {}).get("by_step", [])
        usd = sum(float(r.get("cost_usd") or 0) for r in steps if r.get("step") != "voice")
        if usd > 0:
            per.append(usd)
    if not per:
        return {"low": 0.10, "high": 0.40, "basis": "estimate"}
    return {"low": min(per), "high": max(per), "basis": f"measured on {len(per)} video(s)"}


def monthly() -> dict:
    """What the whole solution costs a MONTH: minimum (own AWS account, production only, Kokoro voice, HTML slides)
    and optimal (own AWS account, production + test, ElevenLabs Pro, HTML slides). Ranges."""
    margin = 1 + config.COST_MARGIN_PCT / 100
    c = claude_per_video()
    q = MONTH_QUESTIONS * QUESTION_USD
    claude = (round(10 * c["low"] * margin + 0.2 * q), round(MONTH_VIDEOS * c["high"] * margin + q))
    plat = (sum(r[2][0] for r in CLOUD), sum(r[2][1] for r in CLOUD))
    alone = (sum(r[3][0] for r in CLOUD), sum(r[3][1] for r in CLOUD))
    rows = [
        {"part": "Cloud (AWS)", "minimum": plat, "optimal": alone,
         "min_how": "Own AWS account, production only", "opt_how": "Own AWS account, production + test, AWS support"},
        {"part": "Claude (Bedrock)", "minimum": claude, "optimal": claude,
         "min_how": "Grows with use", "opt_how": "Grows with use"},
        {"part": "Voice", "minimum": (0, 0), "optimal": (99, 99),
         "min_how": "Kokoro (free, runs on our server)", "opt_how": "ElevenLabs Pro (600k characters, ~5 h of narration)"},
        {"part": "Video tool", "minimum": (0, 0), "optimal": (0, 0),
         "min_how": "HTML slides (ours)", "opt_how": "HTML slides or HyperFrames (free)"},
    ]
    tot = lambda k: (sum(r[k][0] for r in rows), sum(r[k][1] for r in rows))   # noqa: E731
    return {"rows": rows, "minimum": tot("minimum"), "optimal": tot("optimal"),
            "usage": f"Claude: from a quiet month to about {MONTH_VIDEOS} videos and {MONTH_QUESTIONS} questions "
                     f"({c['basis']}, +{config.COST_MARGIN_PCT:g}% margin)",
            "cloud": [{"part": r[0], "why": r[1], "minimum": r[2], "optimal": r[3]} for r in CLOUD],
            "cloud_min": plat, "cloud_opt": alone}


def price_table(m: dict, p: dict) -> list[dict]:
    """One request of each kind Lesson Studio makes: the cost with a free voice (Kokoro, or none) and with
    ElevenLabs; made of Claude (measured on this project's runs where there are any), the voice, the
    presenter and the server's time; the safety margin included. Licences and plans: see subscriptions."""
    import compare_video
    import costs
    margin = 1 + config.COST_MARGIN_PCT / 100
    server_min = costs.render_per_min(p, m)                      # making one minute of video
    kokoro_min = compare_video.KOKORO_RTF * 60 * compare_video.CLOUD_PER_S
    eleven_min = CHARS_PER_MIN / 1000 * config.ELEVENLABS_USD_PER_1K_CHARS
    rows = []
    for key, what, example, kind, minutes, spoken, presenter in OFFER:
        if kind == "answer":
            ai, basis = m["answer"]
        else:
            per, basis = m[f"per_min_{kind}"]
            ai = per * minutes
        base = ai + (server_min * minutes if kind == "video" else 0.0)
        if presenter == "cartoon":
            base += server_min * minutes * 0.5                    # the presenter takes longer to draw
        free = base + (kokoro_min * minutes if spoken else 0.0)
        eleven = base + eleven_min * minutes if spoken else None
        rows.append({"key": key, "what": what, "example": example, "usd": round(free * margin, 3),
                     "usd_eleven": round(eleven * margin, 3) if eleven is not None else None,
                     "voice": "Kokoro voice (free)" if spoken else "no voice", "basis": basis})
    return rows


def prices() -> dict:
    """The price list, what each step costs, the subscriptions, spend so far, the full cost report."""
    import compare_video
    import costs
    a, p = costs.load_inputs()
    m = costs.measured(costs.library())
    spent = m["_spent_total"][0]   # every logged model call, as "today" is counted
    report_file = config.OUTPUT_DIR / "costs" / "costs.html"
    try:   # the step costs: the newest comparison has every tool's time to make the same video
        folder = compare_video.latest()
        data = store.read_json(folder / "comparison.json", {}) or {}
        compare_video.video_costs(folder, data)
        steps = compare_video.cost_report(folder, data, content_usd_per_min=m["per_min_video"][0])
    except Exception as e:   # noqa: BLE001 - no comparison yet: the steps without the tools' times
        log.info("Step costs without a comparison: %s", e)
        steps = compare_video.cost_report(None, {}, content_usd_per_min=m["per_min_video"][0])
    return {"rows": price_table(m, p), "steps": steps["steps"], "subscriptions": steps["subscriptions"],
            "monthly": monthly(),
            "checked": steps["checked"], "margin_pct": config.COST_MARGIN_PCT,
            "eleven_rate": config.ELEVENLABS_USD_PER_1K_CHARS, "today": round(llm.spent_today(), 3),
            "daily": config.DAILY_BUDGET_USD, "total": round(spent, 2),
            "report": file_url(str(report_file)) if report_file.exists() else "", "lengths": lengths()}


def lengths() -> dict:
    """What one video costs by length (length_costs.py), with links to the videos and the Excel file."""
    import length_costs
    try:
        rep = length_costs.report()
    except Exception as e:   # noqa: BLE001 - information only
        log.info("Costs by length not worked out: %s", e)
        return {"rows": []}
    for r in rep.get("rows", []) + rep.get("scratch", []):
        v = config.OUTPUT_DIR / r["folder"] / "lesson_video.mp4"
        r["url"] = file_url(str(v)) if v.exists() else ""
        m = re.search(r"-v(\d+)-", r["folder"])
        r["version"] = int(m.group(1)) if m else None
    x = length_costs.folder() / "length_costs.xlsx"
    rep["xlsx"] = file_url(str(x)) if x.exists() else ""
    return rep


# --- jobs --------------------------------------------------------------------------------------
def public(result: dict) -> dict:
    """What the page needs from a result (links instead of paths)."""
    card = result.get("card") or {}
    q = result["quality"]
    return {"format": result["format"], "understood": result["understood"], "title": card.get("title", ""),
            "folder": Path(result["folder"]).name, "files": {k: file_url(v) for k, v in result["files"].items()},
            "verdict": q["status"], "fail": q["fail"], "issues": q["issues"][:8], "review": q.get("review"),
            "cost_usd": (card.get("cost") or {}).get("total_usd", result["cost_usd"]), "seconds": result["seconds"],
            "sources": (card.get("input") or {}).get("used", [])[:8], "solution": card.get("solution", {}),
            "cost_lines": (card.get("cost") or {}).get("by_step", [])[:8], "answer": answer_part(result)}


def answer_part(result: dict) -> dict | None:
    """A question's answer for the page: the text with [n] and its numbered sources."""
    a = result.get("answer")
    if not a:
        return None
    return {"question": a.get("question", ""), "text": a.get("text", ""), "not_in_material": bool(a.get("not_in_material")),
            "not_covered": a.get("not_covered", ""),
            "sources": [{"n": x["n"], "title": x.get("title", ""), "kind": x.get("kind", ""), "where": x.get("where", ""),
                         "at": x.get("at", []), "evidence": x.get("evidence", [])[:2]} for x in a.get("sources", [])]}


def defaults() -> dict:
    """The configured model and voice (while a job runs: the ones from before its own choice)."""
    return dict(_before_job) or {k: getattr(config, k) for k in SWITCHED}


@contextlib.contextmanager
def chosen(model: dict | None, voice: str | None, extra: dict | None = None):
    """The model, voice and tool picked on the page, for this job only (one job runs at a time).
    A local model also does the review (the review must use the same backend)."""
    _before_job.update({k: getattr(config, k) for k in SWITCHED})
    try:
        for k, v in (extra or {}).items():
            if k in SWITCHED:
                setattr(config, k, v)
        if model:
            config.CHAT_MODEL, config.CHAT_BACKEND = model["id"], model["backend"]
            if model["backend"] != _before_job["CHAT_BACKEND"]:
                config.REVIEW_MODEL = model["id"]
        if voice:
            config.TTS_ENGINE = voice
        yield
    finally:
        for k, v in _before_job.items():
            setattr(config, k, v)
        _before_job.clear()


def work(job: dict) -> None:
    handler = JobLog(job)
    logging.getLogger().addHandler(handler)
    try:
        with BUSY:
            job["status"] = "running"
            if job["kind"] == "topics":
                import topics
                topics.run()
                job.update(status="done", result={"topics": suggestions()})
                return
            with chosen(job.get("model"), job.get("voice"), job.get("config")):
                result = ask.run(job["request"], review=job["review"], overrides=job["overrides"],
                                 on_understood=lambda s: job.update(understood=s))
            job.update(status="done", result=public(result))
    except ask.RequestRefused as e:
        job.update(status="refused", error=str(e))
    except lesson.NotEnoughMaterial as e:
        job.update(status="not_covered", error=str(e))
    except Exception as e:   # noqa: BLE001 - show any failure on the page instead of crashing the server
        log.exception("Job failed")
        job.update(status="error", error=f"{type(e).__name__}: {e}"[:600])
    finally:
        logging.getLogger().removeHandler(handler)
        job["finished"] = time.time()
        if job.get("chat"):   # kept with the chat, so it is there after a restart
            chats.add_result(job["chat"], job["id"], job["status"], job.get("result"), job.get("error", ""),
                             job["finished"] - job["started"])


# --- tools and narrators to pick in the chat (the same as in the comparison) -----------------------
LEVEL_CHOICES = [("auto", "Auto"), ("beginner", "Beginner"), ("intermediate", "Intermediate"), ("expert", "Expert")]
ELEVEN_PICK = ("lily", "brian", "alice", "daniel", "charlotte", "will")
_choices: dict = {}


def tool_settings(tool: str) -> tuple[dict, dict]:
    """(config values, request overrides) for a tool id from compare_video.solutions() (the company's
    avatars included)."""
    import compare_video
    sol = next((x for x in compare_video.solutions() if x["id"] == tool), None)
    if not sol:
        return {}, {}
    over = {"style": sol["style"]}
    if sol.get("characters"):
        over["characters"] = sol["characters"]
    return {"RENDERER": sol["renderer"], **sol.get("set", {})}, over


def voice_settings(voice: str) -> dict:
    """kokoro:af_heart / elevenlabs:brian -> the config values for that narrator."""
    engine, _, name = (voice or "").partition(":")
    if engine == "kokoro" and name:
        return {"TTS_ENGINE": "kokoro", "TTS_VOICE": name}
    if engine == "elevenlabs" and name:
        return {"TTS_ENGINE": "elevenlabs", "ELEVENLABS_VOICE": name}
    return {}


def _quick_ok(sol: dict) -> tuple[bool, str]:
    """Can this tool run here? Quick checks only (nothing is installed by asking)."""
    import importlib.util
    r = sol.get("renderer", "")
    if r == "html":
        return importlib.util.find_spec("playwright") is not None, "needs playwright"
    if r.startswith("remotion"):
        return (config.ROOT / "remotion" / "node_modules").exists(), "Remotion not installed (remotion folder, npm.cmd install)"
    if r == "manim":
        import manim_render
        return manim_render.available()
    if r == "hyperframes":
        import hyperframes_render
        return hyperframes_render.available()
    import deck_js
    return deck_js.available(r)


def choices() -> dict:
    """What can be picked under the chat box (checked at most once a minute)."""
    if _choices.get("at", 0) > time.time() - 60:
        return _choices["data"]
    import compare_video
    import tts
    tools = []
    for sol in compare_video.solutions():
        ok, why = _quick_ok(sol)
        tools.append({"id": sol["id"], "label": sol["group"] + (f" \u2013 {sol['variant']}" if sol.get("variant") else ""),
                      "ok": bool(ok), "why": "" if ok else why})
    voices = []
    if tts.check("kokoro")[0]:
        voices += [{"id": f"kokoro:{v}", "label": f"Kokoro \u2013 {name} ({who}, {accent})"}
                   for _, v, name, who, accent in compare_video.KOKORO]
    if config.ELEVENLABS_API_KEY:
        voices += [{"id": f"elevenlabs:{n}", "label": f"ElevenLabs \u2013 {n.capitalize()} "
                    f"({compare_video.ELEVEN_WHO.get(n, '')}, paid)"} for n in ELEVEN_PICK]
    renderer = next((t["label"] for t in tools if t["id"] == defaults()["RENDERER"]), defaults()["RENDERER"])
    voice = defaults()["TTS_ENGINE"] + (f" \u2013 {config.TTS_VOICE}" if defaults()["TTS_ENGINE"] == "kokoro" else "")
    data = {"formats": [{"id": f["id"], "label": f["label"].replace(" (from my words)", "")} for f in FORMATS
                        if f.get("picker", True)],
            "tools": tools, "voices": voices, "levels": [{"id": k, "label": v} for k, v in LEVEL_CHOICES],
            "defaults": {"tool": renderer, "voice": voice}}
    _choices.update(at=time.time(), data=data)
    return data


# --- the company's avatars (company_avatar.py): pictures in data/avatars, marked on the Avatars tab ---------
def avatars() -> dict:
    import company_avatar
    rows = company_avatar.listing()
    for a in rows:
        a["url"] = "/avatars/" + quote(a["file"])
    return {"folder": str(company_avatar.folder()), "avatars": rows}


def avatar_post(path: str, body: dict) -> tuple[dict, int]:
    """A new picture ({name, data: a data URL}: marked by AI at once), every unmarked picture marked by AI
    (/api/avatars/auto), one marked again by AI (/api/avatars/<name>/ai), marks moved by hand ({mouth, eyes,
    label, who}) or a deletion (/api/avatars/<name>/delete)."""
    import base64
    import binascii

    import company_avatar
    parts = [p for p in path.split("/") if p][2:]   # after /api/avatars
    try:
        if not parts:
            raw = str(body.get("data", ""))
            raw = raw.split(",", 1)[1] if raw.startswith("data:") else raw
            if len(raw) > 14_000_000:
                return {"error": "The picture is too big (at most about 10 MB)."}, 413
            name = company_avatar.add_picture(str(body.get("name") or "avatar"), base64.b64decode(raw, validate=True))
            company_avatar.mark(name, label=" ".join(str(body.get("name") or "").split())[:40])
            return {"ok": True, "name": name, **avatars()}, 200
        if parts == ["auto"]:
            return {"ok": True, "marked": company_avatar.mark_all(), **avatars()}, 200
        name = parts[0].lower()
        if len(parts) > 1 and parts[1] == "ai":
            if name not in company_avatar.pictures():
                return {"error": "No such avatar."}, 404
            company_avatar.mark(name)
            return {"ok": True, **avatars()}, 200
        if len(parts) > 1 and parts[1] == "delete":
            ok = company_avatar.delete(name)
            return ({"ok": True, **avatars()} if ok else {"error": "No such avatar."}), 200 if ok else 404
        company_avatar.save(name, {**body, "by": "hand"})
        return {"ok": True, **avatars()}, 200
    except FileNotFoundError as e:
        return {"error": str(e)}, 404
    except (ValueError, KeyError, TypeError, binascii.Error) as e:
        return {"error": f"Not saved: {e}"}, 400


def forget_old_jobs(after_s: float = 3600) -> None:
    """Finished jobs leave memory after an hour: their results are kept in their chat and in data/output."""
    now = time.time()
    for jid in [j["id"] for j in JOBS.values() if j.get("finished") and now - j["finished"] > after_s]:
        JOBS.pop(jid, None)


def new_job(body: dict, owner: str = "") -> tuple[dict | None, str, int]:
    """A lesson job from the page's form (request + clicked options), or (None, error, code). It goes into
    the chat body["chat"] (a new chat when there is none), which belongs to `owner` (the browser)."""
    kind = body.get("kind", "lesson")
    if BUSY.locked():
        return None, "Another lesson is being made. Wait until it is finished.", 409
    forget_old_jobs()
    job = {"id": uuid.uuid4().hex[:10], "kind": kind, "status": "queued", "log": [], "started": time.time()}
    if kind == "lesson":
        request = " ".join(str(body.get("request", "")).split())[:1000]
        if not request:
            return None, "Write a topic or what you want to learn.", 400
        fmt = next((f for f in FORMATS if f["id"] == body.get("format", "auto")), FORMATS[0])
        overrides = dict(fmt["settings"])
        if body.get("minutes"):
            overrides["minutes"] = float(body["minutes"])
        if body.get("level") not in (None, "", "auto"):
            overrides["level"] = body["level"]
        if body.get("look") not in (None, "", "auto") and fmt["id"] in ("auto", "video", "audio"):
            overrides["style"] = body["look"]
            if body["look"] == "presenter":
                overrides["characters"] = "cartoon"
        model = next((m for m in models() if m["id"] == body.get("model")), None)
        cfg = {}
        tool = body.get("tool") or "default"
        if tool != "default" and fmt["id"] not in ("answer", "document", "slides"):
            cfg, tool_over = tool_settings(tool)
            if fmt["id"] != "dialogue":
                overrides.update(tool_over)
        voice = body.get("voice") or None
        if voice and ":" in voice:   # a narrator: engine + voice
            cfg.update(voice_settings(voice))
            voice = None
        if fmt.get("config"):   # e.g. animated slides: no voice, whatever narrator is picked
            cfg.update(fmt["config"])
            voice = None
        job.update(request=request, review=bool(body.get("review", True)), overrides=overrides, model=model,
                   voice=voice, config=cfg)
        picks = {k: str(body[k]) for k in ("format", "tool", "voice", "level") if body.get(k)}
        job["chat"] = chats.add_request(str(body.get("chat") or ""), owner, request, picks, job["id"])
    elif kind != "topics":
        return None, "Unknown job.", 400
    JOBS[job["id"]] = job
    threading.Thread(target=work, args=(job,), name=f"job-{job['id']}", daemon=True).start()
    return job, "", 200


# --- web server ----------------------------------------------------------------------------------
LOGIN = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport"
content="width=device-width, initial-scale=1"><title>Lesson Studio</title><style>
body{margin:0;min-height:100vh;display:grid;place-items:center;background:#f5f6f8;color:#16202c;
font:15px/1.5 "Segoe UI",system-ui,-apple-system,Roboto,Arial,sans-serif}
form{background:#fff;border:1px solid #e3e7ec;border-radius:14px;padding:28px;width:min(340px,90vw)}
h1{font-size:18px;margin:0 0 4px}p{margin:0 0 16px;color:#5f6b7a;font-size:13.5px}
input{width:100%;box-sizing:border-box;border:1px solid #d5dbe2;border-radius:9px;padding:10px 12px;font:inherit}
button{margin-top:12px;width:100%;border:0;border-radius:9px;padding:10px;background:#0f5fae;color:#fff;
font:inherit;font-weight:600;cursor:pointer}.err{color:#b42d23;margin:10px 0 0}</style></head><body>
<form method="post" action="/login"><h1>Lesson Studio</h1><p>Enter the password you were given.</p>
<input type="password" name="password" autofocus autocomplete="current-password" aria-label="Password">
<button>Open</button>__ERR__</form></body></html>"""


def _token() -> str:
    return hashlib.sha256(("lesson-studio:" + config.APP_PASSWORD).encode()).hexdigest()[:40]


class Handler(BaseHTTPRequestHandler):
    server_version = "LessonStudio/1.0"

    def _owner(self) -> str:
        """This browser's id (a cookie set with the page): its chats are its own."""
        morsel = SimpleCookie(self.headers.get("Cookie") or "").get("ls_user")
        return morsel.value if morsel and chats.ID.fullmatch(morsel.value) else ""

    def _shared(self) -> bool:
        """The request came through a shared link (VS Code port forwarding, a tunnel), not from this
        computer's own browser: the tunnel adds X-Forwarded-* headers or keeps its own host name."""
        host = (self.headers.get("Host") or "").rsplit(":", 1)[0].strip("[]").lower()
        forwarded = any(self.headers.get(h) for h in ("X-Forwarded-For", "X-Forwarded-Host", "Forwarded"))
        return forwarded or host not in ("localhost", "127.0.0.1", "::1", "")

    def _allowed(self) -> bool:
        """No APP_PASSWORD: open only to this computer's own browser; a shared link is refused. With
        one: the cookie from /login."""
        if not config.APP_PASSWORD:
            return not self._shared()
        morsel = SimpleCookie(self.headers.get("Cookie") or "").get("ls_auth")
        return bool(morsel) and hmac.compare_digest(morsel.value, _token())

    def _login(self, error: str = "", code: int = 200) -> None:
        err = f'<p class="err">{error}</p>' if error else ""
        self._send(LOGIN.replace("__ERR__", err).encode(), "text/html; charset=utf-8", code)

    def log_message(self, fmt, *args):   # quiet: the page shows the progress
        pass

    def log_request(self, code="-", size="-"):
        """Requests through a shared link are written to data/output/app_access.log (time, what, answer), so a
        page that does not open for someone else can be traced. Not to the terminal: on Windows a click in the
        terminal window pauses every program writing to it, and the page would hang for the other person."""
        try:
            if self._shared():
                line = f"{time.strftime('%Y-%m-%d %H:%M:%S')}  {self.command} {urlparse(self.path).path} -> {code}\n"
                config.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
                with ACCESS_LOCK, open(config.OUTPUT_DIR / "app_access.log", "a", encoding="utf-8") as f:
                    f.write(line)
        except Exception:   # noqa: BLE001 - a log line must never stop an answer
            pass

    def _send(self, body: bytes, ctype: str, code: int = 200, extra: dict | None = None) -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, data, code: int = 200) -> None:
        self._send(json.dumps(data).encode(), "application/json", code)

    def do_GET(self):   # noqa: N802 - http.server API
        url = urlparse(self.path)
        path = url.path
        if path == "/status":   # a quick test of a shared link: is the app reached at all (no sign-in, no data)
            text = (f"Lesson Studio is running.\nThis request came {'through a shared link' if self._shared() else 'from this computer'}."
                    f"\nPassword: {'on' if config.APP_PASSWORD else 'OFF (a shared link is refused)'}.\n")
            return self._send(text.encode(), "text/plain; charset=utf-8")
        if not self._allowed():
            if not config.APP_PASSWORD:   # shared without a password: closed, and says why
                return self._login("Shared without a password, so it stays closed. On the laptop: stop app.py (Ctrl+C) "
                                   "and start it with: uv run app.py --password <a long password>", 200) \
                    if path == "/" else self._json({"error": "No password set."}, 403)
            return self._login() if path == "/" else self._json({"error": "Sign in first."}, 401)
        if path == "/":
            extra = {} if self._owner() else {
                "Set-Cookie": f"ls_user={uuid.uuid4().hex[:16]}; Path=/; SameSite=Lax; Max-Age={400 * 86400}"}
            return self._send(page().encode(), "text/html; charset=utf-8", extra=extra)
        if path == "/api/chats":
            return self._json({"chats": chats.listing(self._owner())})
        if path.startswith("/api/chats/"):
            chat = chats.load(path.rsplit("/", 1)[-1], self._owner())
            busy = {j["id"] for j in JOBS.values() if j["status"] in ("queued", "running")}
            return self._json(chats.for_page(chat, busy) if chat else {"error": "No such chat."}, 200 if chat else 404)
        if path == "/api/state":
            return self._json(state())
        if path == "/api/choices":
            return self._json(choices())
        if path == "/api/comparisons":
            return self._json(comparisons())
        if path == "/api/prices":
            return self._json(prices())
        if path == "/api/decks":
            return self._json(decks())
        if path == "/api/options":
            return self._json(options())
        if path == "/api/estimate":
            q = {k: v[0] for k, v in parse_qs(url.query).items()}
            try:
                minutes = float(q.get("minutes") or 0)
            except ValueError:
                minutes = 0
            return self._json(estimate(q.get("format", "auto"), minutes, q.get("model") or defaults()["CHAT_MODEL"],
                                       q.get("voice") or defaults()["TTS_ENGINE"]))
        if path == "/api/results":
            return self._json(results())
        if path == "/api/report":
            return self._json(report())
        if path.startswith("/api/jobs/"):
            job = JOBS.get(path.rsplit("/", 1)[-1])
            return self._json(job or {"status": "unknown"}, 200 if job else 404)
        if path.startswith("/files/"):
            return self._file(unquote(path[len("/files/"):]))
        if path == "/api/avatars":
            return self._json(avatars())
        if path.startswith("/avatars/"):   # a company avatar's picture (data/avatars only)
            import company_avatar
            name = unquote(path[len("/avatars/"):])
            pic = company_avatar.pictures().get(company_avatar.slug(Path(name).stem))
            if not pic or pic.name != name:
                return self._send(b"not found", "text/plain", 404)
            return self._stream(pic, 0, pic.stat().st_size - 1, pic.stat().st_size,
                                mimetypes.guess_type(pic.name)[0] or "image/png", 200)
        if path == "/api/brand":   # the company brand found in data/brand (brand.py)
            import brand
            s = brand.summary()
            s["logo_url"] = "/brand/logo" if s.get("logo") else ""
            s["folder"] = "data/brand"
            return self._json(s)
        if path == "/brand/logo":
            import brand
            lg = brand.logo()
            if not lg:
                return self._send(b"not found", "text/plain", 404)
            return self._stream(lg, 0, lg.stat().st_size - 1, lg.stat().st_size,
                                mimetypes.guess_type(lg.name)[0] or "image/png", 200)
        self._send(b"not found", "text/plain", 404)

    do_HEAD = do_GET

    def do_POST(self):   # noqa: N802
        path = urlparse(self.path).path
        if path == "/login":
            raw = self.rfile.read(min(4096, int(self.headers.get("Content-Length") or 0))).decode("utf-8", "replace")
            given = (parse_qs(raw).get("password") or [""])[0]
            if config.APP_PASSWORD and hmac.compare_digest(given.encode(), config.APP_PASSWORD.encode()):
                cookie = f"ls_auth={_token()}; Path=/; HttpOnly; SameSite=Lax; Max-Age={30 * 86400}"
                return self._send(b"", "text/plain", 303, {"Location": "/", "Set-Cookie": cookie})
            time.sleep(1)   # slows down guessing
            return self._login("Wrong password." if config.APP_PASSWORD else "No password is set.", 401)
        if not self._allowed():
            return self._json({"error": "Sign in first."}, 401)
        if path != "/api/jobs" and not path.startswith(("/api/chats/", "/api/avatars")):
            return self._send(b"not found", "text/plain", 404)
        try:
            body = json.loads(self.rfile.read(int(self.headers.get("Content-Length") or 0)) or b"{}")
        except json.JSONDecodeError:
            return self._json({"error": "Bad request."}, 400)
        if path.startswith("/api/avatars"):   # /api/avatars {name, data}: a new picture; /api/avatars/<name> {marks}; .../delete
            return self._json(*avatar_post(path, body))
        if path.startswith("/api/chats/"):   # /api/chats/<id>/rename {title}, /delete, /feedback {job, rating, comment}
            _, _, _, chat_id, action = (path.split("/") + [""])[:5]
            ok = (chats.rename(chat_id, self._owner(), str(body.get("title", ""))) if action == "rename"
                  else chats.delete(chat_id, self._owner()) if action == "delete"
                  else chats.add_feedback(chat_id, self._owner(), str(body.get("job", "")), str(body.get("rating", "")),
                                          str(body.get("comment", ""))) if action == "feedback" else False)
            return self._json({"ok": ok}, 200 if ok else 404)
        job, error, code = new_job(body, self._owner())
        self._json({"id": job["id"], "chat": job.get("chat", "")} if job else {"error": error}, code)

    def _file(self, rel: str) -> None:
        """A file from data/output only (no other folder), with byte ranges so videos can seek."""
        root = config.OUTPUT_DIR.resolve()
        target = (root / rel).resolve()
        if root not in target.parents or not target.is_file() or chats.folder().resolve() in target.parents:
            return self._send(b"not found", "text/plain", 404)   # chats only through /api/chats (their owner)
        ctype = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        if target.suffix in (".md", ".txt", ".srt"):
            ctype = "text/plain; charset=utf-8"
        size = target.stat().st_size
        rng = self.headers.get("Range")
        start, end, code = 0, size - 1, 200
        if rng and rng.startswith("bytes="):
            a, _, b = rng[6:].partition("-")
            try:
                start = int(a) if a else max(0, size - int(b))
                end = min(size - 1, int(b)) if a and b else size - 1
            except ValueError:
                start, end = 0, size - 1
            if not b:   # "from here on": a piece at a time, so a video starts at once and many can load together
                end = min(end, start + CHUNK_ON_REQUEST - 1)
            code = 206
        self._stream(target, start, end, size, ctype, code)

    def _stream(self, target: Path, start: int, end: int, size: int, ctype: str, code: int) -> None:
        """Send part of a file in small blocks (never the whole video in memory at once)."""
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(max(0, end - start + 1)))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Cache-Control", "no-store")
        if code == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.end_headers()
        if self.command == "HEAD":
            return
        with open(target, "rb") as f:
            f.seek(start)
            left = end - start + 1
            while left > 0:
                block = f.read(min(256 * 1024, left))
                if not block:
                    break
                self.wfile.write(block)
                left -= len(block)


CHUNK_ON_REQUEST = 1024 * 1024   # an open range ("bytes=0-") is answered with this much; the player asks for more


class Server(ThreadingHTTPServer):
    daemon_threads = True

    def handle_error(self, request, client_address):
        """The browser stopping a video it no longer needs (seeking, another video, closing the tab) is
        normal: no error printed for it ("an established connection was aborted")."""
        import sys
        if isinstance(sys.exc_info()[1], (ConnectionError, TimeoutError)):
            return
        super().handle_error(request, client_address)


class Server6(Server):
    address_family = socket.AF_INET6


def also_on_ipv6(port: int) -> Server | None:
    """The same page on ::1 too (still only this computer). "localhost" can mean ::1 first: VS Code's
    port forwarding then reached nothing ("localhost refused to connect") with only 127.0.0.1."""
    try:
        extra = Server6(("::1", port), Handler)
    except OSError as e:   # no IPv6 on this computer, or the port taken there: 127.0.0.1 is enough
        log.info("Not on ::1: %s", e)
        return None
    threading.Thread(target=extra.serve_forever, daemon=True).start()
    return extra


def serve(port: int, open_browser: bool = True) -> ThreadingHTTPServer:
    server = Server(("127.0.0.1", port), Handler)
    server.daemon_threads = True
    server.ipv6 = also_on_ipv6(server.server_address[1])
    url = f"http://localhost:{server.server_address[1]}"
    print(f"Lesson Studio: {url}   (Ctrl+C to stop)"
          + ("   password on" if config.APP_PASSWORD else
             "   NO PASSWORD: a shared link stays closed (uv run app.py --password <a long password>)"))
    if open_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    return server


ACCESS_LOCK = threading.Lock()


def no_pause_on_click() -> None:
    """Windows: a click in the terminal window starts selecting text ("QuickEdit"), and while it is selecting
    every program writing to that window stops, the page with it (for someone on the shared link it loads
    for ever). Turned off for this window while app.py runs (no admin rights needed)."""
    if os.name != "nt":
        return
    try:
        import ctypes
        k32 = ctypes.windll.kernel32
        handle = k32.GetStdHandle(-10)   # the window's input
        mode = ctypes.c_uint32()
        if k32.GetConsoleMode(handle, ctypes.byref(mode)):
            k32.SetConsoleMode(handle, (mode.value & ~0x0040) | 0x0080)   # QuickEdit off, extended flags on
    except Exception as e:   # noqa: BLE001 - only a convenience
        log.info("QuickEdit not turned off: %s", e)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--password", default="", help="the page's password for this run (instead of APP_PASSWORD in .env)")
    args = ap.parse_args()
    config.setup_logging()
    no_pause_on_click()
    if args.password:
        config.APP_PASSWORD = args.password.strip()
    server = serve(args.port, not args.no_browser)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


def page() -> str:
    """The page (app_page.html next to this file; read on every visit, so edits show after a reload)."""
    path = Path(__file__).with_name("app_page.html")
    return path.read_text(encoding="utf-8") if path.exists() else "<h1>app_page.html is missing next to app.py</h1>"


if __name__ == "__main__":
    import sys
    sys.exit(main())
