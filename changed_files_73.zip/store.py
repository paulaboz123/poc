"""
store.py - all reading and writing of the project's data lives here.

No other script opens data files directly. If the platform later wants its own storage
or vector store, this is the only file that changes.

Layout on disk:
  data/manifest.csv                       which video goes with which transcript
  data/processed/<video_id>/meta.json     title, files, duration, speakers
  data/processed/<video_id>/segments.json ~1-minute transcript segments
  data/processed/<video_id>/slides.json   detected slides + OCR text
  data/processed/<video_id>/slides/*.jpg  slide images
  data/index/                             embeddings for search
  data/output/<lesson_id>/                generated lessons
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import re
import tempfile
from pathlib import Path
from typing import Any

import config

MANIFEST_FIELDS = ["video_id", "include", "catalog_id", "title", "description", "media_type", "video_file",
                   "transcript_file", "source_file", "kind", "lang", "words", "pair_method", "video_min",
                   "transcript_min", "crop", "check", "ai"]


# --- Small helpers --------------------------------------------------------------
def slugify(text: str, max_len: int = 50) -> str:
    """'Budget Review – Q3 (final)' -> 'budget-review-q3-final'."""
    s = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return s[:max_len].rstrip("-") or "item"


def stable_id(name: str, label: str = "") -> str:
    """Readable, unique, always the same for the same file: 'budget-review-2024-10-15-3f2a'."""
    return f"{slugify(label or Path(name).stem, 40)}-{hashlib.sha1(name.encode()).hexdigest()[:4]}"


def fmt_ts(seconds: float) -> str:
    """75 -> '01:15', 3725 -> '1:02:05'."""
    s = int(seconds)
    h, m, sec = s // 3600, s % 3600 // 60, s % 60
    return f"{h}:{m:02d}:{sec:02d}" if h else f"{m:02d}:{sec:02d}"


def location(seg: dict) -> str:
    """Where an excerpt is: '12:30-13:20' in a recording, 'slide 4' / 'page 2' in a document."""
    if seg.get("where"):
        return seg["where"]
    return f"{fmt_ts(seg.get('start', 0))}-{fmt_ts(seg.get('end', 0))}"


def source_kind(seg: dict) -> str:
    """'Document' or 'Recording', for the prompts."""
    return "Document" if seg.get("kind") == "document" or seg.get("where") else "Recording"


def write_json(path: Path, obj: Any) -> None:
    """Atomic write: write a temp file, then rename. A crash never leaves half a file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2)
        _replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def _replace(tmp: str | Path, target: Path) -> None:
    """os.replace with a readable error: on Windows it fails while Excel has the file open."""
    try:
        os.replace(tmp, target)
    except PermissionError as e:
        Path(tmp).unlink(missing_ok=True)
        raise PermissionError(f"Can't write {target.name}: close it in Excel/VS Code and run again") from e


def next_version() -> int:
    """The next video version (v1, v2, v3 ...): one number for every video made or made again, so the newest
    is easy to find (in the folder name and on the page). Kept in data/output/versions.json."""
    f = config.OUTPUT_DIR / "versions.json"
    lock = f.with_suffix(".lock")
    f.parent.mkdir(parents=True, exist_ok=True)
    for _ in range(200):   # two programs at once (e.g. length_costs.py and compare_video.py) take turns
        try:
            fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            break
        except FileExistsError:
            import time
            if time.time() - lock.stat().st_mtime > 30:   # left behind by a stopped program
                lock.unlink(missing_ok=True)
            time.sleep(0.05)
    else:
        fd = None
    try:
        n = int((read_json(f, {}) or {}).get("last", 0)) + 1
        write_json(f, {"last": n})
        return n
    finally:
        if fd is not None:
            os.close(fd)
            lock.unlink(missing_ok=True)


def versioned(created: str, rest: str) -> tuple[str, int]:
    """An output folder name with the next version after its time: 20261112-103000-v7-<rest>."""
    n = next_version()
    return f"{created}-v{n}-{rest}", n


def read_json(path: Path, default: Any = None) -> Any:
    """Parsed JSON file, or `default` if the file does not exist."""
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


# --- Manifest --------------------------------------------------------------------
def read_manifest() -> list[dict]:
    """Read manifest.csv. Survives Excel re-saving it (semicolons, non-UTF-8 encoding)."""
    if not config.MANIFEST.exists():
        return []
    raw = config.MANIFEST.read_bytes()
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = raw.decode("cp1252")   # Excel "CSV (comma delimited)" on Windows
    first_line = text.splitlines()[0] if text else ""
    delimiter = ";" if first_line.count(";") > first_line.count(",") else ","
    rows = csv.DictReader(io.StringIO(text), delimiter=delimiter)
    return [{(k or "").strip(): (v or "").strip() for k, v in r.items() if k} for r in rows]


def write_manifest(rows: list[dict]) -> None:
    """Write manifest.csv as UTF-8 with BOM, so Excel shows accents and umlauts correctly."""
    config.MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    extra = [k for r in rows for k in r if k not in MANIFEST_FIELDS]
    fields = MANIFEST_FIELDS + list(dict.fromkeys(extra))
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=fields, extrasaction="ignore")
    w.writeheader()
    w.writerows(rows)
    tmp = config.MANIFEST.with_suffix(".tmp")
    tmp.write_text(buf.getvalue(), encoding="utf-8-sig", newline="")
    _replace(tmp, config.MANIFEST)


def included_rows() -> list[dict]:
    """Manifest rows marked include=yes (your development set)."""
    yes = {"yes", "y", "1", "true", "x"}
    return [r for r in read_manifest() if r.get("include", "").lower() in yes]


# --- Per-video data -----------------------------------------------------------------
def video_dir(video_id: str) -> Path:
    """Folder with everything derived from one recording: data/processed/<video_id>."""
    return config.PROCESSED_DIR / video_id


def generated_transcript(video_id: str) -> Path:
    """Where transcribe.py writes a transcript it made (data/input is never modified)."""
    return video_dir(video_id) / "transcript.vtt"


def transcript_path(row: dict) -> Path | None:
    """The transcript to use for a manifest row: the downloaded one, else a generated one."""
    if row.get("transcript_file"):
        path = config.INPUT_DIR / row["transcript_file"]
        if path.exists():
            return path
    generated = generated_transcript(row["video_id"])
    return generated if generated.exists() else None


def slides_dir(video_id: str) -> Path:
    """Folder with the slide images of one recording."""
    return video_dir(video_id) / "slides"


def save_meta(video_id: str, meta: dict) -> None:
    """Save meta.json (title, files, duration, speakers) of one recording."""
    write_json(video_dir(video_id) / "meta.json", meta)


def load_meta(video_id: str) -> dict:
    """Load meta.json of one recording; raises if it was never ingested."""
    meta = read_json(video_dir(video_id) / "meta.json")
    if meta is None:
        raise FileNotFoundError(f"No meta.json for {video_id}. Run ingest.py first.")
    return meta


def save_segments(video_id: str, segments: list[dict]) -> None:
    """Save the transcript segments of one recording."""
    write_json(video_dir(video_id) / "segments.json", segments)


def load_segments(video_id: str) -> list[dict]:
    """Transcript segments of one recording ([] if not ingested yet)."""
    return read_json(video_dir(video_id) / "segments.json", [])


def has_segments(video_id: str) -> bool:
    """True if the recording has been ingested."""
    return (video_dir(video_id) / "segments.json").exists()


def save_slides(video_id: str, slides: list[dict]) -> None:
    """Save the detected slides (with OCR text) of one recording."""
    write_json(video_dir(video_id) / "slides.json", slides)


def load_slides(video_id: str) -> list[dict]:
    """Detected slides of one recording ([] if none yet)."""
    return read_json(video_dir(video_id) / "slides.json", [])


def has_slides(video_id: str) -> bool:
    """True if slide detection has run for the recording."""
    return (video_dir(video_id) / "slides.json").exists()


def processed_video_ids() -> list[str]:
    """Videos that have been ingested (have segments), restricted to include=yes if a
    manifest exists, so unticking a video in the manifest removes it from search."""
    if not config.PROCESSED_DIR.exists():
        return []
    ids = sorted(p.parent.name for p in config.PROCESSED_DIR.glob("*/segments.json"))
    included = {r["video_id"] for r in included_rows()}
    return [i for i in ids if i in included] if included else ids


# first names that are also common words: masked only as part of the full name
_COMMON = {"will", "may", "mark", "june", "april", "august", "grant", "bill", "rose", "hope", "faith", "joy", "sky",
           "dawn", "summer", "art", "chip", "rich", "frank", "gene", "guy", "hunter", "lane", "page", "ray", "rob",
           "sean", "young", "long", "white", "black", "green", "brown", "king", "price", "case", "best", "hall"}


def speaker_names(segments: list[dict]) -> dict[str, str]:
    """{every way a speaker's name can appear: 'Speaker N'}, numbered by first appearance. 'Doe, Jane
    (Roche)' -> the full string, 'Jane Doe', 'Doe, Jane', 'Jane', 'Doe'."""
    order: list[str] = []
    for seg in segments:
        for sp in seg.get("speakers") or []:
            if sp and sp not in order:
                order.append(sp)
    names: dict[str, str] = {}
    for n, sp in enumerate(order, 1):
        alias = f"Speaker {n}"
        plain = re.sub(r"\s*\([^)]*\)", "", sp).strip()
        parts = [x.strip() for x in plain.split(",")] if "," in plain else [plain]
        full = " ".join(reversed(parts)) if len(parts) == 2 else plain
        words = full.split()
        for v in {sp, plain, full, *([words[0]] if words else []), *(words[-1:] if len(words) > 1 else [])}:
            if v and (" " in v or "," in v or (len(v) >= 3 and v.lower() not in _COMMON)):
                names.setdefault(v, alias)
    return names


def mask_names(text: str, names: dict[str, str]) -> str:
    """The speakers' names in a text replaced by their alias, longest form first, whole words only."""
    for name in sorted(names, key=len, reverse=True):
        text = re.sub(rf"(?<![\w-]){re.escape(name)}(?![\w-])", names[name], text)
    return text


def all_segments() -> dict[str, dict]:
    """Every segment of every processed video, by id, with title and slide text attached."""
    out: dict[str, dict] = {}
    for vid in processed_video_ids():
        meta = load_meta(vid)
        slides = {s["id"]: s for s in load_slides(vid)}
        segments = load_segments(vid)
        names = speaker_names(segments) if config.MASK_SPEAKERS else {}
        for seg in segments:
            seg = dict(seg)
            if names:   # personal data: pseudonyms before anything is searched or sent to a model
                seg["text"] = mask_names(seg["text"], names)
                seg["speakers"] = [names.get(x, x) for x in seg.get("speakers") or []]
                if seg.get("sentences"):
                    seg["sentences"] = [[a, b, mask_names(t, names)] for a, b, t in seg["sentences"]]
            seg["title"] = meta.get("title", vid)
            seg["description"] = meta.get("description", "")   # from description.xlsx, may be empty
            seg["kind"] = meta.get("kind", "recording")
            seg["catalog_id"] = str(meta.get("catalog_id", "") or "")   # the number in description.xlsx
            # slide text = what OCR read, plus the vision model's description when there is one
            seg["slide_text"] = "\n".join(
                "\n".join(x for x in (slides[i]["text"], slides[i].get("visual", "")) if x)
                for i in seg.get("slide_ids", []) if i in slides and slides[i].get("is_slide"))
            out[seg["id"]] = seg
    return out


def available_recordings() -> list[dict]:
    """Included recordings that have been processed (ready for lessons and videos)."""
    return [r for r in included_rows() if has_segments(r["video_id"])]


def resolve_recordings(ref: str) -> list[str]:
    """Recordings for a user reference: Excel id ('13'), video_id, or part of the title or of
    the file name (case does not matter). Several refs separated by commas: '13,joining'."""
    rows = available_recordings()
    if not rows:
        raise ValueError("No processed recordings yet: set include=yes in data/manifest.csv and run pipeline.py.")
    found: list[str] = []
    for part in (x.strip() for x in ref.split(",") if x.strip()):
        low = part.lower()
        match = ([r for r in rows if r.get("catalog_id") == part] or
                 [r for r in rows if r["video_id"] == part] or
                 [r for r in rows if low in r.get("title", "").lower()] or
                 [r for r in rows if low in (r.get("video_file") or r.get("transcript_file")
                                             or r.get("source_file") or "").lower()])
        if not match:
            listing = "\n".join(f"  {r.get('catalog_id') or '-':>4}  {r['title']}" for r in rows)
            raise ValueError(f"No processed recording matches '{part}'. Use the id, or a word from the "
                             f"title or file name. Available recordings (id, title):\n{listing}")
        found += [r["video_id"] for r in match if r["video_id"] not in found]
    return found


# --- Search index ----------------------------------------------------------------
def save_index(vectors, ids: list[str], info: dict) -> None:
    """Save the search index: vectors, the segment id of each row, and build info."""
    import numpy as np
    config.INDEX_DIR.mkdir(parents=True, exist_ok=True)
    np.save(config.INDEX_DIR / "vectors.npy", vectors.astype("float32"))
    write_json(config.INDEX_DIR / "ids.json", ids)
    write_json(config.INDEX_DIR / "info.json", info)


def load_index():
    """Returns (vectors, ids, info) or raises if the index was never built."""
    import numpy as np
    path = config.INDEX_DIR / "vectors.npy"
    if not path.exists():
        raise FileNotFoundError("No search index yet. Run: uv run index.py build")
    return (np.load(path), read_json(config.INDEX_DIR / "ids.json"),
            read_json(config.INDEX_DIR / "info.json", {}))


# --- Skills and lessons ----------------------------------------------------------
def load_skill(name: str) -> str:
    """Body of skills/<name>/<latest version>/SKILL.md, without the YAML front matter."""
    base = config.SKILLS_DIR / name
    versions = sorted((p for p in base.iterdir() if (p / "SKILL.md").exists()),
                      key=lambda p: [int(x) if x.isdigit() else x for x in p.name.split(".")]
                      ) if base.exists() else []
    path = versions[-1] / "SKILL.md" if versions else base / "SKILL.md"
    if not path.exists():
        raise FileNotFoundError(f"Skill not found: {path}")
    text = path.read_text(encoding="utf-8")
    if text.startswith("---"):
        parts = text.split("---", 2)
        text = parts[2] if len(parts) == 3 else text
    return text.strip()


def save_lesson(lesson_id: str, lesson: dict, markdown: str) -> Path:
    """Save a text lesson as lesson.json (all data) and lesson.md (readable). Returns its folder."""
    out = config.OUTPUT_DIR / lesson_id
    write_json(out / "lesson.json", lesson)
    (out / "lesson.md").write_text(markdown, encoding="utf-8")
    return out


def fresh_dir(path: Path) -> Path:
    """An empty folder at `path`; when Windows keeps the old one locked (a browser or a video player still
    holds a file in it), a new one next to it instead (path-2, path-3 ...), so the work goes on."""
    import shutil
    import time
    path = Path(path)
    for attempt in range(3):
        shutil.rmtree(path, ignore_errors=True)
        if not path.exists():
            break
        time.sleep(0.5 * (attempt + 1))
    k = 1
    while path.exists() and any(path.iterdir()):
        k += 1
        path = path.with_name(f"{path.name.split('~')[0]}~{k}")
    path.mkdir(parents=True, exist_ok=True)
    return path
