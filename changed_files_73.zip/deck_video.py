"""
deck_video.py - an animated slide deck without a voice, made by several engines from the SAME content,
so they can be compared side by side: our designer slides (HTML), Remotion, Remotion Pro (motion design),
Remotion AI (Claude writes each scene's animation code), Manim, Revideo and Motion Canvas (free
animation engines, pure code).
No narrator, no characters: clean slides that build up and flow into each other.

  uv run deck_video.py "Snowflake" --slides 7                       # content + every installed engine
  uv run deck_video.py "Snowflake" --slides 7 --engines html,manim  # only these
  uv run deck_video.py "Snowflake" --slides 7 --general             # a topic the recordings don't cover
  uv run deck_video.py --folder "data\\output\\<deck folder>" --engines remotion   # again, no model calls

How it works:
  1. content (once, the only paid step: Claude, a few cents): the slides are planned from the training
     recordings, like the video lessons (each slide's source is kept). With --general, a topic the
     recordings don't cover is written from Claude's general knowledge instead, and labelled so.
     Each slide also gets a short script: it is never spoken, it only sets how long the slide stays
     and when each element appears.
  2. every engine draws the same slides into <deck folder>/slides_<engine>.mp4 (no sound). Re-rendering
     with --folder costs nothing.
  3. engines.md in the deck folder: each engine's file, length, time to make it, size and licence.

Engines and what they need:
  html          our designer slides (Playwright, already used for the videos)       free
  remotion      Remotion, the classic composition (Node.js, remotion folder)       licence for companies of 4+
  remotion-pro  Remotion, motion design: living backdrop, 3D-style transitions     licence for companies of 4+
  remotion-ai   Remotion, Claude writes the animation code of each slide (paid)    licence + a few cents a deck
  manim         Manim (uv tool install manim)                                      free (MIT)
  revideo       Revideo (Node.js; its packages install on first use)               free (MIT)
  motion-canvas Motion Canvas (Node.js; its editor's Render button is pressed      free (MIT)
                automatically by a hidden browser)
"""
from __future__ import annotations

import argparse
import contextlib
import logging
import shutil
import sys
import time
from pathlib import Path

import config
import lesson
import llm
import media
import store
import storyboard
import tts

log = logging.getLogger("deck_video")

ENGINES = {
    "html": "our designer slides (Playwright)",
    "remotion": "Remotion, classic composition",
    "remotion-pro": "Remotion, motion design",
    "remotion-ai": "Remotion, animation code written by Claude per slide",
    "manim": "Manim, free animation engine",
    "revideo": "Revideo, free animation engine (TypeScript)",
    "motion-canvas": "Motion Canvas, free animation engine (TypeScript)",
    "hyperframes": "HyperFrames, free HTML + GSAP video framework (HeyGen, Apache-2.0)",
}
DEFAULT_ENGINES = ("html", "remotion", "remotion-pro", "manim", "revideo", "motion-canvas", "hyperframes")
JS_ENGINES = ("revideo", "motion-canvas")
LICENCE = {"html": "free", "manim": "free (MIT)", "revideo": "free (MIT)", "motion-canvas": "free (MIT)",
           "hyperframes": "free (Apache-2.0), also for companies",
           "remotion": "Remotion licence for companies of 4+",
           "remotion-pro": "Remotion licence for companies of 4+",
           "remotion-ai": "Remotion licence for companies of 4+, plus Claude per deck"}
NOT_ON_SLIDES = ("question", "answer", "slide", "example", "formula", "calculation", "chart")

DECK_WISHES = """This is a SILENT animated slide deck: no voice will be heard. The narration only sets the pace
(how long a slide stays, when each element appears), so keep it short: 20-40 words per scene.
Exactly {n} scenes:
- scene 1: a title scene (heading = the deck title; subheading = one line on what the viewer will learn);
- scenes 2 to {last}: one content slide each, every one with a DIFFERENT visual, chosen from: cards, steps,
  timeline, comparison, stats, hub, cycle, table, callout, concept. The slide text carries the whole message:
  a clear action title, 3-5 elements, each with a short title and one informative detail line;
- scene {n}: 'cards' with heading "Key takeaways" and 3 elements.
Use animation "build" with cues wherever the elements can appear one by one. No question scene, no worked
example, no original slides, no pictures, no calculations or charts."""

GENERAL_PROMPT = """Write a factual briefing on "{topic}" for building a short training slide deck: what it
is, how it works (its main parts), the typical steps or process, how it compares with the usual
alternative, a few concrete numbers that are well established, and best practices. 400-600 words,
plain sentences, no headings, no markdown. Only well-established facts; leave out anything uncertain."""


@contextlib.contextmanager
def settings(**values):
    """Change config values for one engine and put them back afterwards."""
    old = {k: getattr(config, k) for k in values}
    try:
        for k, v in values.items():
            setattr(config, k, v)
        yield
    finally:
        for k, v in old.items():
            setattr(config, k, v)


# --- 1. Content -----------------------------------------------------------------------------------
def general_material(topic: str, model: str | None) -> list[dict]:
    """A topic the recordings don't cover: a briefing from Claude's general knowledge, as one excerpt
    that says where it comes from."""
    text = llm.chat(GENERAL_PROMPT.format(topic=topic), step="deck_general", model=model, max_tokens=1200,
                    temperature=0.2).strip()
    return [{"id": "general#0", "video_id": "general", "idx": 0, "title": "General knowledge (not from the training "
             "material)", "text": text, "start": 0.0, "end": 0.0, "words": len(text.split()), "slide_ids": [],
             "kind": "document", "where": "general knowledge", "slide_text": "", "description": ""}]


def tidy(sb: dict, n: int) -> dict:
    """Slides only: no question, example or original-slide scenes, no pictures, at most n scenes
    (the first and the last kept), the clean look."""
    scenes = [sc for sc in sb["scenes"] if sc.get("visual") not in NOT_ON_SLIDES]
    for sc in scenes:
        sc.pop("illustration", None)
    if len(scenes) > n:
        scenes = scenes[:n - 1] + scenes[-1:]
    sb["scenes"] = scenes
    sb["style"] = "clean"
    sb["characters"] = "none"
    return sb


def plan(topic: str, n: int = 7, general: bool = False, level: str = "beginner", model: str | None = None) -> Path:
    """Plan the deck once (the paid step). Returns its folder."""
    mark = llm.meter_mark()
    minutes = max(1.0, n * 0.25)
    if general:
        segments = general_material(topic, model)
    else:
        try:
            segments, _ = lesson.retrieve(topic, int(round(max(2, minutes))))
        except lesson.NotEnoughMaterial as e:
            raise lesson.NotEnoughMaterial(f"{e}\nFor a topic the recordings don't cover, add --general "
                                           "(the slides are then written from general knowledge).") from None
    sb = storyboard.make(topic, minutes, level, segments, model=model, style="clean",
                         wishes=DECK_WISHES.format(n=n, last=n - 1))
    sb = tidy(sb, n)
    if len(sb["scenes"]) < 2:
        raise RuntimeError("The plan has fewer than 2 slides; try again or another wording")
    sb["deck"] = {"slides": len(sb["scenes"]), "general_knowledge": general}
    sb["request"] = {"topic": topic, "slides": n, "level": level, "general": general, "kind": "deck"}
    sb["plan_calls"] = llm.calls_since(mark)
    sb["plan_cost_usd_est"] = round(sum(c["cost_usd"] for c in sb["plan_calls"]), 4)
    folder = config.OUTPUT_DIR / store.versioned(sb["created"], f"{store.slugify(topic, 40)}-deck-{len(sb['scenes'])}")[0]
    storyboard.save(sb, folder)
    log.info("Deck planned: %s slides%s, $%.3f -> %s", len(sb["scenes"]),
             " (general knowledge)" if general else "", sb["plan_cost_usd_est"], folder / "script.md")
    return folder


# --- 2. Engines ------------------------------------------------------------------------------------
def slide_seconds(sb: dict) -> list[float]:
    """How long each slide stays, the same for every engine: the silent length of its parts."""
    import make_video
    out = []
    with settings(TTS_ENGINE="silent"):
        for sc in sb["scenes"]:
            total = 0.0
            for b in make_video.scene_beats(sc, "clean"):
                samples, rate = tts.synthesize(b["text"])
                total += 0.15 + len(samples) / rate + b["pause"]
            out.append(round(total, 2))
    return out


def strip_sound(video: Path, out: Path) -> Path:
    """The same video without its (silent) sound track."""
    media._run([config.FFMPEG, "-hide_banner", "-loglevel", "error", "-y", "-i", str(video), "-an",
                "-c:v", "copy", "-movflags", "+faststart", str(out)])
    return out


def render(folder: Path, engine: str) -> dict:
    """Draw the deck with one engine into <folder>/slides_<engine>.mp4. No model calls, except
    remotion-ai (Claude writes each slide's animation)."""
    import make_video
    sb = storyboard.load(folder)
    out = folder / f"slides_{engine}.mp4"
    t0 = time.perf_counter()
    if engine == "manim":
        import manim_render
        manim_render.render(folder, sb, slide_seconds(sb), out)
    elif engine == "hyperframes":
        import hyperframes_render
        import manim_render
        hyperframes_render.render(manim_render.deck_data(sb, slide_seconds(sb)), out)
    elif engine in JS_ENGINES:
        import deck_js
        import manim_render
        drawn = deck_js.render(engine, manim_render.deck_data(sb, slide_seconds(sb)),
                               folder / f"{engine}_with_sound.mp4")
        strip_sound(drawn, out)
        drawn.unlink(missing_ok=True)
    else:
        work = store.fresh_dir(folder / engine)
        shutil.copyfile(folder / "storyboard.json", work / "storyboard.json")
        if engine.startswith("remotion"):
            import remotion_render
            remotion_render.ensure_installed()
            ok, why = remotion_render.available()
            if not ok:
                raise RuntimeError(why)
        with settings(TTS_ENGINE="silent", RENDERER=engine, PRO_PRESENTER="none", ANIMATION=True):
            info = make_video.produce(work)
        if info.get("renderer") != engine:   # e.g. Remotion failed and the designer slides were used
            raise RuntimeError(f"{engine} did not render (used {info.get('renderer')}): {info.get('fallback', '')}")
        strip_sound(Path(info["video"]), out)
        shutil.rmtree(work / "audio", ignore_errors=True)
    secs = media.duration_s(out)
    return {"engine": engine, "file": out.name, "seconds": round(secs, 1), "render_s": round(time.perf_counter() - t0),
            "size_mb": round(out.stat().st_size / 1e6, 1), "licence": LICENCE[engine]}


def available(engine: str) -> tuple[bool, str]:
    """Can this engine run here? (checked before anything is made)"""
    if engine == "manim":
        import manim_render
        return manim_render.available()
    if engine == "hyperframes":
        import hyperframes_render
        return hyperframes_render.available()
    if engine in JS_ENGINES:
        import deck_js
        return deck_js.available(engine)
    if engine.startswith("remotion"):
        import remotion_render
        try:
            remotion_render.ensure_installed()
            return remotion_render.available()
        except Exception as e:   # noqa: BLE001 - a broken Remotion only skips this engine
            return False, f"Remotion check failed: {e}"
    if engine == "html":
        import importlib.util
        return (importlib.util.find_spec("playwright") is not None,
                "Playwright" if importlib.util.find_spec("playwright") else "playwright not installed: uv add playwright")
    return False, "unknown engine"


def write_table(folder: Path, rows: list[dict], skipped: dict[str, str]) -> Path:
    sb = storyboard.load(folder)
    lines = [f"# {sb['title']}: one deck, several engines", "",
             f"{len(sb['scenes'])} slides, no voice. Content: "
             + ("general knowledge (not from the training material)" if sb.get("deck", {}).get("general_knowledge")
                else "from the training recordings") + f", planned once for ${sb.get('plan_cost_usd_est', 0):.3f}.", "",
             "| Engine | File | Length (s) | Made in (s) | Size (MB) | Licence |", "|---|---|---|---|---|---|"]
    lines += [f"| {ENGINES[r['engine']]} | {r['file']} | {r['seconds']} | {r['render_s']} | {r['size_mb']} | {r['licence']} |"
              for r in rows]
    if skipped:
        lines += ["", "Not made:"] + [f"- {ENGINES.get(e, e)}: {why}" for e, why in skipped.items()]
    path = folder / "engines.md"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def run(folder: Path, engines: list[str]) -> tuple[list[dict], dict[str, str]]:
    rows, skipped = [], {}
    for engine in engines:
        ok, why = available(engine)
        if not ok:
            skipped[engine] = why
            log.warning("%s skipped: %s", engine, why)
            continue
        log.info("=== %s", ENGINES[engine])
        try:
            rows.append(render(folder, engine))
            log.info("%s -> %s", engine, rows[-1]["file"])
        except llm.BudgetExceeded:
            raise
        except Exception as e:   # noqa: BLE001 - one engine failing must not stop the others
            skipped[engine] = str(e)[:300]
            log.error("%s failed: %s", engine, str(e)[:300])
    return rows, skipped


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("topic", nargs="?", help="what the deck is about")
    ap.add_argument("--slides", type=int, default=7, help="number of slides (default 7)")
    ap.add_argument("--engines", default=",".join(DEFAULT_ENGINES),
                    help=f"comma-separated: {', '.join(ENGINES)} (default: {', '.join(DEFAULT_ENGINES)})")
    ap.add_argument("--general", action="store_true", help="the recordings don't cover the topic: use general knowledge")
    ap.add_argument("--level", choices=list(lesson.LEVELS), default="beginner")
    ap.add_argument("--model", help="override CHAT_MODEL")
    ap.add_argument("--folder", type=Path, help="an existing deck folder: draw it again (no model calls)")
    args = ap.parse_args()
    config.setup_logging()
    engines = [e.strip() for e in args.engines.split(",") if e.strip()]
    unknown = [e for e in engines if e not in ENGINES]
    if unknown:
        ap.error(f"unknown engine(s) {unknown}; use {', '.join(ENGINES)}")
    if not args.folder and not args.topic:
        ap.error("give a topic, or --folder of an existing deck")
    if not 2 <= args.slides <= 15:
        ap.error("--slides must be between 2 and 15")
    ready = [e for e in engines if available(e)[0]]
    if not ready:
        for e in engines:
            log.error("%s: %s", e, available(e)[1])
        log.error("No engine can run here; nothing was planned (nothing paid)")
        return 1
    try:
        folder = args.folder.resolve() if args.folder else plan(args.topic, args.slides, args.general, args.level,
                                                                 args.model)
        rows, skipped = run(folder, engines)
    except (lesson.NotEnoughMaterial, FileNotFoundError, RuntimeError, ValueError, llm.LLMError) as e:
        log.error("%s", e)
        return 1
    table = write_table(folder, rows, skipped)
    print("\n" + table.read_text(encoding="utf-8"))
    print(f"Folder: {folder}\nAgain with other engines, free: uv run deck_video.py --folder \"{folder}\" --engines ...")
    return 0 if rows else 1


if __name__ == "__main__":
    sys.exit(main())
