"""
course.py - a longer video lesson (about 4-15 minutes) on any topic, built from the whole
knowledge base: the person says what, how long and for which level; which recordings the
content comes from is worked out here, not by them.

  uv run course.py "data preparation for reporting" --minutes 8 --level beginner
  uv run course.py "everything in the recordings" --minutes 10          # a course of all of it
  uv run course.py "summary of all recordings" --minutes 5               # an overview
  uv run course.py --redo-chapter 3 data/output/<folder>                 # remake one chapter
  uv run course.py --auto --minutes 15 --free     # the topic chosen for you: one coherent theme of the knowledge
                                                  # base with enough material for 15 minutes (no stretching);
                                                  # --free: Kokoro voice + HTML slides
Normally you don't call it directly: ask.py sends requests of 4 minutes or more here.

How it works (why it is better than one long storyboard):
 1. Map: the topic map of every recording (topics.py; cached, so usually free).
 2. Outline: the chat model picks what in the whole knowledge base serves the request and
    designs 3-7 chapters with a learning arc. Topics from different recordings are merged when
    they belong together; nothing outside the recordings is added. If the knowledge base covers
    the request only partly, it says what is missing (shown in script.md), and if not at all,
    nothing is made.
 3. Chapters: each chapter gets its own storyboard from the exact parts of the recordings the
    outline points to, plus the best search hits for the chapter (scattered mentions). Each
    chapter knows what the earlier ones covered, so nothing is repeated. One small task per call
    keeps the quality up, where one huge storyboard gets vague.
 4. Frame: an intro with learning objectives, a final quiz on the whole course, and a summary.
 5. Video: the usual make_video.py steps, plus chapter marks in the video and chapters.txt.
Cost with Sonnet: roughly $0.05 per minute of video (with self-review).
"""
from __future__ import annotations

import argparse
import contextlib
import inspect
import logging
import re
import sys
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path

import config
import lesson
import llm
import make_video
import store
import storyboard
import topics

log = logging.getLogger("course")

COURSE_MIN_MINUTES = 4      # ask.py: requests this long or longer become a course
INTRO_WORDS, SUMMARY_WORDS, QUIZ_WORDS = 45, 70, 70   # spoken words of the frame (one quiz question)
CHAPTER_EXTRA_HITS = 4      # search hits added to a chapter's material (scattered mentions)
CHAPTER_MAX_WORDS = 3500    # material words per chapter at most

OUTLINE_SCHEMA = {
    "type": "object",
    "properties": {
        "coverage": {"type": "string", "enum": ["full", "partial", "none"],
                     "description": "How well the recordings cover the request"},
        "missing": {"type": "string", "description": "What the request asks for that the recordings don't cover; "
                                                     "empty if nothing"},
        "title": {"type": "string", "description": "Course title, specific"},
        "chapters": {"type": "array", "items": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Chapter title, 2-7 words"},
                "purpose": {"type": "string", "description": "What the learner gets from this chapter, one sentence"},
                "key_points": {"type": "array", "items": {"type": "string"},
                               "description": "2-4 points the chapter teaches"},
                "weight": {"type": "number", "description": "Share of the time, 1 (short) to 3 (long)"},
                "parts": {"type": "array", "items": {
                    "type": "object",
                    "properties": {"recording": {"type": "string", "description": "recording id"},
                                   "start": {"type": "string", "description": "mm:ss"},
                                   "end": {"type": "string", "description": "mm:ss"}},
                    "required": ["recording", "start", "end"]},
                    "description": "Where in the recordings the content of this chapter is"},
            },
            "required": ["title", "purpose", "key_points", "weight", "parts"],
        }},
    },
    "required": ["coverage", "missing", "title", "chapters"],
}
OUTLINE_SYSTEM = """You design a short video course for employees from the topic maps of internal
training material - recordings and documents such as guides, slides, sheets and quizzes (the
knowledge base). Rules:
- Serve the request: pick only what is relevant to it, from any recordings. For a broad request
  ("everything", "a summary", "an overview") use all solid and deep topics.
- Build a learning arc: why it matters -> basics -> how to do it -> pitfalls and checks. Merge
  topics from different recordings into one chapter when they belong together; never one chapter
  per recording just because.
- {n_min}-{n_max} chapters for {minutes:g} minutes. Brief topics only as part of a bigger chapter.
- parts: the recording ids and time ranges where each chapter's content is (from the maps).
- Never add content that is not in the maps. coverage = full / partial / none; in `missing` say
  what the request asks for that the recordings don't cover.
- Learner level: {level}. A summary moves faster and covers more with less depth."""

FRAME_SCHEMA = {
    "type": "object",
    "properties": {
        "goal": {"type": "string", "description": "One sentence: what the learner can do after the course"},
        "objectives": {"type": "array", "items": {"type": "string"},
                       "description": "3 learning objectives starting with a verb, at most 10 words each"},
        "intro_narration": {"type": "string", "description": "30-60 spoken words: why this matters, what's coming"},
        "quiz": {"type": "array", "items": {
            "type": "object",
            "properties": {
                "question": {"type": "string", "description": "at most 20 words"},
                "options": {"type": "array", "items": {"type": "string"}, "description": "3 options, at most 10 words"},
                "correct": {"type": "integer", "description": "1, 2 or 3"},
                "answer_narration": {"type": "string", "description": "20-45 words: the answer and why"},
            },
            "required": ["question", "options", "correct", "answer_narration"]}},
        "summary_items": {"type": "array", "items": {"type": "string"},
                          "description": "3-5 key takeaways of the whole course, at most 8 words each"},
        "summary_narration": {"type": "string", "description": "50-90 spoken words wrapping up the course"},
    },
    "required": ["goal", "objectives", "intro_narration", "quiz", "summary_items", "summary_narration"],
}
FRAME_SYSTEM = """You write the frame of a video course from the narration of its chapters: the
intro, a final quiz and the summary. Use only what the chapters say. The quiz has {n_quiz}
question(s) that test understanding across chapters (not memory of a word), each with 3 plausible
options and exactly one right. Spoken English, short sentences, "you" for the learner.
Learner level: {level}."""


# --- Helpers ---------------------------------------------------------------------------------
def to_seconds(ts: str) -> float | None:
    """'03:15' or '1:02:05' -> seconds; None if it is not a time."""
    parts = re.findall(r"\d+", ts or "")
    if not parts or len(parts) > 3:
        return None
    sec = 0.0
    for p in parts:
        sec = sec * 60 + int(p)
    return sec


def maps_text(maps: list[dict], supports: bool = False) -> str:
    """The topic maps as compact text for the outline prompt (supports: with the video minutes each topic's
    material supports)."""
    blocks = []
    for m in maps:
        lines = [f"- [{t['start']}-{t['end']}] {t['title']} ({t['depth']}, {t['level']}"
                 + (f", supports={t['minutes']:g} min" if supports else "") + f"): {t['covers']}"
                 for t in m["topics"]]
        blocks.append(f"Recording id {m['ref']}: {m['title']}\n{m['summary']}\n" + "\n".join(lines))
    return "\n\n".join(blocks)


def chapter_segments(chapter: dict, refs: dict[str, str], all_segs: list[dict]) -> list[dict]:
    """The material of one chapter: the segments in its time ranges (with 20 s around them),
    plus the best search hits for its title and points. In recording order, at most
    CHAPTER_MAX_WORDS words (the time ranges come first)."""
    chosen: dict[str, dict] = {}
    for part in chapter.get("parts", []):
        vid = refs.get(str(part.get("recording", "")))
        start, end = to_seconds(part.get("start", "")), to_seconds(part.get("end", ""))
        if not vid or start is None:
            continue
        end = end if end is not None and end > start else start + 60
        for s in all_segs:
            if s["video_id"] == vid and s["start"] < end + 20 and s["end"] > start - 20:
                chosen.setdefault(s["id"], s)
    query = f"{chapter['title']}. " + " ".join(chapter.get("key_points", []))
    try:
        import retrieval  # the answers' search (words + meaning + glossary), without the AI check: cheap
        hits = retrieval.fuse(query, mode="hybrid", top_k=CHAPTER_EXTRA_HITS)
    except (FileNotFoundError, RuntimeError, llm.LLMError) as e:
        log.warning("Search for chapter '%s' skipped: %s", chapter["title"], e)
        hits = []
    for h in hits:
        if h.get("meaning", 0.0) >= config.MIN_SCORE:
            chosen.setdefault(h["segment"]["id"], h["segment"])
    segs, words = [], 0
    for s in sorted(chosen.values(), key=lambda s: (s["video_id"], s["start"])):
        if words + s["words"] > CHAPTER_MAX_WORDS and segs:
            break
        segs.append(s)
        words += s["words"]
    return segs


def chapter_instructions(n: int, total: int, chapter: dict, course_title: str, earlier: list[dict]) -> str:
    """Extra prompt text that turns a lesson storyboard into one chapter of the course."""
    before = "\n".join(f"- Chapter {i}: {c['title']}: {'; '.join(c.get('key_points', []))}"
                       for i, c in enumerate(earlier, 1)) or "(this is the first chapter)"
    return (f"This storyboard is chapter {n} of {total} of the video course \"{course_title}\".\n"
            f"Chapter purpose: {chapter.get('purpose', '')}\n"
            f"Teach: {'; '.join(chapter.get('key_points', []))}\n"
            f"Earlier chapters already covered (don't repeat, build on them):\n{before}\n"
            "Chapter rules (they replace the lesson structure): the first scene is a 'title' scene with the "
            "chapter title as heading and 1-2 sentences of narration leading in; no learning objectives; "
            "no question scene (the course has a quiz at the end); include an example scene if the material "
            "has one; the last scene is 'bullets' with heading \"In short\" and 2-3 items.")


def _budget(minutes: float, n_quiz: int) -> float:
    """Minutes left for the chapters after the intro, quiz and summary."""
    frame = (INTRO_WORDS + SUMMARY_WORDS + n_quiz * QUIZ_WORDS) / storyboard.SPOKEN_WPM
    return max(minutes - frame, minutes * 0.6)


# --- Steps -----------------------------------------------------------------------------------
def outline(request: str, minutes: float, level: str, maps: list[dict], wishes: str,
            model: str | None) -> dict:
    """Ask for the course outline and clean it up."""
    n_min, n_max = max(2, round(minutes / 2.5)), max(3, min(7, round(minutes / 1.2)))
    system = OUTLINE_SYSTEM.format(n_min=n_min, n_max=n_max, minutes=minutes,
                                   level=f"{level} ({lesson.LEVELS[level]})")
    prompt = (f"Request: {request}\nLength: {minutes:g} minutes\n"
              + (f"Wishes: {wishes}\n" if wishes else "") + f"\nKNOWLEDGE BASE (topic maps)\n\n{maps_text(maps)}")
    data = llm.chat_json(prompt, OUTLINE_SCHEMA, system=system, step="course_outline", model=model,
                         max_tokens=3000, temperature=0.2)
    known = {m["ref"] for m in maps}
    chapters = []
    for ch in data.get("chapters", []):
        if not isinstance(ch, dict) or not ch.get("title"):
            continue
        ch["parts"] = [p for p in ch.get("parts", []) if isinstance(p, dict) and str(p.get("recording")) in known]
        ch["weight"] = max(1.0, min(3.0, float(ch.get("weight") or 2)))
        ch["key_points"] = [x for x in ch.get("key_points", []) if isinstance(x, str)][:4]
        chapters.append(ch)
    data["chapters"] = chapters[:n_max]
    if data.get("coverage") not in ("full", "partial", "none"):
        data["coverage"] = "partial"
    return data


def make_chapter(n: int, plan: dict, level: str, refs: dict, all_segs: list[dict], model: str | None,
                 wishes: str) -> dict:
    """Storyboard of chapter n (1-based) with its scenes marked and its source labels made unique."""
    chapters = plan["chapters"]
    ch = chapters[n - 1]
    segs = chapter_segments(ch, refs, all_segs)
    if not segs:
        raise lesson.NotEnoughMaterial(f"No material found for chapter {n} '{ch['title']}'")
    log.info("Chapter %s/%s '%s': %.1f min, %s excerpts", n, len(chapters), ch["title"], ch["minutes"], len(segs))
    sb = storyboard.make(ch["title"], ch["minutes"], level, segs, model=model, wishes=wishes,
                         part=chapter_instructions(n, len(chapters), ch, plan["title"], chapters[:n - 1]),
                         style=plan.get("style"))
    section = f"Chapter {n}: {ch['title']}"
    scenes = []
    for sc in sb["scenes"]:
        if sc["visual"] in ("question", "answer"):   # the course has its own quiz at the end
            continue
        sc["sources"] = [f"C{n}{x}" for x in sc["sources"]]
        sc["section"] = section
        scenes.append(sc)
    scenes[0].update(visual="title", label=f"CHAPTER {n} OF {len(chapters)}", heading=ch["title"],
                     items=[], subtitle=ch.get("purpose", ""))
    if plan.get("style") == "dialogue":   # the two people talk the chapter through
        import dialogue
        dialogue.add_lines({"scenes": scenes}, model)
    return {"scenes": scenes, "sources": {f"C{n}{k}": v for k, v in sb["sources"].items()},
            "stats": sb["stats"], "cost_words": sum(s["words"] for s in segs)}


def make_chapters(plan: dict, level: str, refs: dict, all_segs: list[dict], model: str | None,
                  wishes: str) -> list[dict]:
    """All chapters, PARALLEL_CALLS at a time (each chapter only needs the outline, not the other
    chapters' text). A chapter that fails is tried once more; if it still fails it is left out
    with a warning, so one bad answer doesn't throw away the whole course. The spending lock
    always stops everything."""
    chapters = plan["chapters"]

    def one(n: int) -> dict | None:
        for attempt in (1, 2):
            try:
                return make_chapter(n, plan, level, refs, all_segs, model, wishes)
            except llm.BudgetExceeded:
                raise
            except (llm.LLMError, lesson.NotEnoughMaterial) as e:
                log.warning("Chapter %s, attempt %s failed: %s", n, attempt, str(e).splitlines()[0])
        return None

    with ThreadPoolExecutor(max_workers=config.PARALLEL_CALLS) as pool:
        results = list(pool.map(one, range(1, len(chapters) + 1)))
    kept = [(n, r) for n, r in enumerate(results, 1) if r is not None]
    if not kept:
        raise llm.LLMError("No chapter could be made; see the warnings above")
    dropped = [chapters[n - 1]["title"] for n, r in enumerate(results, 1) if r is None]
    if dropped:   # renumber so the video says "chapter 2 of 3", not "3 of 4"
        plan["chapters"] = [chapters[n - 1] for n, _ in kept]
        plan.setdefault("dropped_chapters", []).extend(dropped)
        for new_n, (old_n, r) in enumerate(kept, 1):
            _renumber(r, old_n, new_n, len(kept), chapters[old_n - 1]["title"])
    return [r for _, r in kept]


def _renumber(ch: dict, old: int, new: int, total: int, title: str) -> None:
    """Chapter labels and source labels after a chapter was left out."""
    for sc in ch["scenes"]:
        sc["section"] = f"Chapter {new}: {title}"
        sc["sources"] = [f"C{new}" + x[len(f"C{old}"):] for x in sc["sources"]]
    ch["scenes"][0]["label"] = f"CHAPTER {new} OF {total}"
    ch["sources"] = {f"C{new}" + k[len(f"C{old}"):]: v for k, v in ch["sources"].items()}


def frame(plan: dict, chapter_sbs: list[dict], level: str, minutes: float, model: str | None) -> dict:
    """Intro, quiz and summary from the chapters' narration."""
    n_quiz = 2 if minutes < 7 else 3
    text = "\n\n".join(f"CHAPTER {i}: {plan['chapters'][i - 1]['title']}\n" +
                       "\n".join(s["narration"] for s in c["scenes"]) for i, c in enumerate(chapter_sbs, 1))
    data = llm.chat_json(f"Course: {plan['title']}\n\n{text}", FRAME_SCHEMA,
                         system=FRAME_SYSTEM.format(n_quiz=n_quiz, level=f"{level} ({lesson.LEVELS[level]})"),
                         step="course_frame", model=model, max_tokens=2500, temperature=0.3)
    quiz = []
    for q in data.get("quiz", [])[:n_quiz]:
        opts = [" ".join(str(o).split()) for o in q.get("options", []) if str(o).strip()][:4]
        if isinstance(q, dict) and q.get("question") and len(opts) >= 2 and 1 <= int(q.get("correct") or 0) <= len(opts):
            quiz.append({**q, "options": opts, "correct": int(q["correct"])})
    data["quiz"] = quiz
    data["objectives"] = [x for x in data.get("objectives", []) if isinstance(x, str) and x.strip()][:3]
    data["summary_items"] = [x for x in data.get("summary_items", []) if isinstance(x, str) and x.strip()][:5]
    return data


def assemble(plan: dict, chapter_sbs: list[dict], fr: dict, request: str, minutes: float, level: str,
             model: str | None, wishes: str) -> dict:
    """One storyboard: intro -> chapters -> quiz -> summary, in the usual storyboard format."""
    short = storyboard._short
    scenes = [{"visual": "title", "label": "VIDEO COURSE", "heading": plan["title"],
               "items": [short(x) for x in fr["objectives"]], "narration": " ".join(fr["intro_narration"].split()),
               "sources": [], "section": "Introduction"}]
    if plan.get("style") in ("illustrated", "presenter"):   # a learning situation for the course cover
        scenes[0]["illustration"] = {"scene": "teacher_class", "why": "a training session: the course itself",
                                     "chart": "none", "icons": [], "prompt": f"a trainer teaching a small group about {plan['title']}"}
    sources, warnings, changes = {}, [], []
    ranges = []
    for n, c in enumerate(chapter_sbs, 1):
        ranges.append([len(scenes), len(scenes) + len(c["scenes"])])
        scenes += c["scenes"]
        sources.update(c["sources"])
        warnings += [f"chapter {n}: {w}" for w in c["stats"].get("warnings", [])
                     if not w.startswith("teaching structure")]
        changes += [f"chapter {n}: {x}" for x in c["stats"].get("self_review_changes", [])]
    for q in fr["quiz"]:
        question = " ".join(q["question"].split())
        opts = [short(x) for x in q["options"]]
        scenes.append({"visual": "question", "heading": question, "items": opts,
                       "narration": f"{question} Pause and think.", "sources": [],
                       "pause_after": storyboard.QUESTION_PAUSE_S, "section": "Quiz"})
        scenes.append({"visual": "answer", "heading": question, "items": opts, "correct": q["correct"],
                       "narration": " ".join(q["answer_narration"].split()), "sources": [], "section": "Quiz"})
    scenes.append({"visual": "bullets", "heading": "Key takeaways", "items": [short(x) for x in fr["summary_items"]],
                   "narration": " ".join(fr["summary_narration"].split()), "sources": [], "section": "Summary"})
    if plan.get("coverage") == "partial" and plan.get("missing"):
        warnings.insert(0, f"the recordings cover the request only partly; missing: {plan['missing']}")
    if not fr["quiz"]:
        warnings.append("no usable quiz question")
    if plan.get("dropped_chapters"):
        warnings.insert(0, f"chapter(s) left out after errors: {', '.join(plan['dropped_chapters'])}")
    words = sum(len(s["narration"].split()) for s in scenes)
    target = int(minutes * storyboard.SPOKEN_WPM)
    if abs(words / target - 1) > 0.25:
        warnings.append(f"narration is {words} words, target {target}")
    kinds = [s["visual"] for s in scenes]
    stats = {"scenes": len(scenes), "words": words, "target_words": target,
             "length_ratio": round(words / target, 2), "est_minutes": round(words / storyboard.SPOKEN_WPM, 1),
             "chapters": len(chapter_sbs), "excerpts_given": len(sources),
             "excerpts_cited": len({x for s in scenes for x in s["sources"]}),
             "teaching": {"objectives": bool(fr["objectives"]), "example": "example" in kinds,
                          "question": "question" in kinds, "recap": True},
             "self_review_changes": changes[:20], "warnings": warnings}
    return {"created": datetime.now().strftime("%Y%m%d-%H%M%S"), "topic": request, "minutes": minutes,
            "level": level, "model": model or config.CHAT_MODEL, "title": plan["title"], "goal": fr["goal"],
            "style": plan.get("style") or "clean",
            "objectives": fr["objectives"], "scenes": scenes, "stats": stats, "sources": sources,
            "settings": storyboard.settings(model, extra_prompts=(OUTLINE_SYSTEM, FRAME_SYSTEM,
                                                                  inspect.getsource(chapter_instructions))),
            "course": {"outline": plan, "chapter_scenes": ranges, "wishes": wishes}}


# --- The topic chosen for you: one coherent theme with enough material ------------------------------------
THEME_SCHEMA = {
    "type": "object",
    "properties": {
        "theme": {"type": "string", "description": "What the course teaches, as a learner would ask for it (one sentence)"},
        "why": {"type": "string", "description": "Why these topics belong together (one sentence)"},
        "topics": {"type": "array", "items": {
            "type": "object",
            "properties": {"recording": {"type": "string", "description": "recording id"},
                           "title": {"type": "string", "description": "the topic's exact title in the map"}},
            "required": ["recording", "title"]}},
    },
    "required": ["theme", "why", "topics"],
}
THEME_SYSTEM = """You choose what one {minutes:g}-minute video course should teach, from the topic maps of the internal
training material (the knowledge base). Rules:
- One coherent theme a learner would take as one course: topics that belong together and build on each other
  (why it matters -> basics -> how to do it -> pitfalls and checks).
- Enough material, so nothing is stretched: each topic shows the video minutes its material supports
  (supports=N min); together the chosen topics must support at least {need:g} minutes. Prefer solid and deep
  topics; brief ones only to connect.
- If no single theme has enough, add the closest related topics so the course still flows.
- Only topics that are in the maps; name each by its recording id and its exact title."""


def pick_theme(minutes: float, level: str, maps: list[dict], model: str | None) -> dict:
    """One coherent theme of the knowledge base whose material supports the chapters' minutes (asked once more
    when the first choice is short). The video is made shorter rather than stretched when the whole knowledge
    base has less."""
    n_quiz = 2 if minutes < 7 else 3
    need = round(_budget(minutes, n_quiz), 1)
    by_key = {(m["ref"], t["title"].strip().lower()): t for m in maps for t in m["topics"]}
    everything = sum(t["minutes"] for t in by_key.values())
    system = THEME_SYSTEM.format(minutes=minutes, need=need)
    prompt = f"Learner level: {level}\n\nKNOWLEDGE BASE (topic maps)\n\n{maps_text(maps, supports=True)}"
    chosen, data = [], {}
    for attempt in (1, 2):
        data = llm.chat_json(prompt, THEME_SCHEMA, system=system, step="course_theme", model=model,
                             max_tokens=1500, temperature=0.2)
        chosen = []
        for x in data.get("topics", []):
            t = by_key.get((str(x.get("recording", "")), str(x.get("title", "")).strip().lower()))
            if t is not None and t not in chosen:
                chosen.append({**t, "recording": str(x["recording"])})
        supported = sum(t["minutes"] for t in chosen)
        if supported >= need * 0.95 or attempt == 2:
            break
        prompt += (f"\n\nYour first choice ({data.get('theme', '')}: "
                   + "; ".join(f"{t['recording']}: {t['title']}" for t in chosen)
                   + f") supports only {supported:g} minutes. Add the closest related topics to reach {need:g}.")
    supported = sum(t["minutes"] for t in chosen)
    fits = minutes
    if supported < need * 0.95:   # not enough: a shorter video, not a stretched one
        fits = max(COURSE_MIN_MINUTES, round(minutes * supported / max(need, 0.1)))
        if everything < need * 0.95:
            log.warning("The whole knowledge base supports about %.0f min of chapters: the video is made %g min long",
                        everything, fits)
    return {"theme": str(data.get("theme") or "the most useful topics of the recordings"), "why": str(data.get("why", "")),
            "topics": chosen, "supported": round(supported, 1), "need": need, "minutes": fits}


def auto(minutes: float = 15, level: str = "beginner", model: str | None = None, plan_only: bool = False,
         free: bool = False) -> tuple[Path, dict, dict]:
    """A course on a theme chosen for you (pick_theme), made from scratch. free: Kokoro voice + HTML slides."""
    rows = store.available_recordings()
    if not rows:
        raise ValueError("No processed recordings yet: set include=yes in data/manifest.csv and run pipeline.py.")
    maps = [topics.analyse_recording(r, model=model) for r in rows]
    theme = pick_theme(minutes, level, maps, model)
    log.info("Theme: %s (%s); %s topics supporting %.0f min; the video: %g min", theme["theme"], theme["why"],
             len(theme["topics"]), theme["supported"], theme["minutes"])
    wishes = ("Build the course from these topics of the knowledge base, in a learning order: "
              + "; ".join(f"recording {t['recording']}: {t['title']}" for t in theme["topics"])
              + ". Nothing outside them; no padding.")
    ctx = contextlib.nullcontext()
    if free:
        import length_costs
        ctx = length_costs.free_setup()
    with ctx:
        out_dir, info = make(theme["theme"], theme["minutes"], level, model, plan_only, wishes, style="clean")
    return out_dir, info, theme


# --- Main entries ----------------------------------------------------------------------------------
def plan_course(request: str, minutes: float = 8, level: str = "beginner", *, model: str | None = None,
                wishes: str = "", style: str | None = None, characters: str | None = None) -> Path:
    """Request -> outline -> chapters -> frame -> storyboard.json in a new output folder."""
    if level not in lesson.LEVELS:
        raise ValueError(f"level must be one of {list(lesson.LEVELS)}")
    rows = store.available_recordings()
    if not rows:
        raise ValueError("No processed recordings yet: set include=yes in data/manifest.csv and run pipeline.py.")
    cost0 = llm.spent_this_run()
    mark = llm.meter_mark()
    maps = [topics.analyse_recording(r, model=model) for r in rows]
    refs = {m["ref"]: m["video_id"] for m in maps}
    plan = outline(request, minutes, level, maps, wishes, model)
    if plan["coverage"] == "none" or not plan["chapters"]:
        raise lesson.NotEnoughMaterial(f"The recordings don't cover '{request}'. "
                                       + (plan.get("missing") or "Try other wording or a broader request."))
    n_quiz = 2 if minutes < 7 else 3
    budget, total_w = _budget(minutes, n_quiz), sum(c["weight"] for c in plan["chapters"])
    for ch in plan["chapters"]:
        ch["minutes"] = round(max(0.8, budget * ch["weight"] / total_w), 1)
    log.info("Course '%s': %s chapters (%s), coverage %s", plan["title"], len(plan["chapters"]),
             ", ".join(f"{c['title']} {c['minutes']:g}m" for c in plan["chapters"]), plan["coverage"])
    all_segs = list(store.all_segments().values())
    plan["style"] = style if style in storyboard.STYLES else config.STYLE if config.STYLE in storyboard.STYLES \
        else "illustrated"
    chapter_sbs = make_chapters(plan, level, refs, all_segs, model, wishes)
    fr = frame(plan, chapter_sbs, level, minutes, model)
    sb = assemble(plan, chapter_sbs, fr, request, minutes, level, model, wishes)
    if plan["style"] == "dialogue":   # intro, quiz and summary of the course
        import dialogue
        dialogue.add_lines(sb, model, only_missing=True)
    sb["characters"] = characters if characters in ("cartoon", "people") else config.CHARACTERS
    sb["request"] = {"topic": request, "recording": "", "minutes": minutes, "level": level, "wishes": wishes,
                     "kind": "course", "style": plan["style"], "characters": sb["characters"]}
    sb["plan_cost_usd_est"] = round(llm.spent_this_run() - cost0, 4)
    sb["plan_calls"] = llm.calls_since(mark)
    name, sb["version"] = store.versioned(sb["created"], f"{store.slugify(request, 40)}-course-{minutes:g}m")
    out_dir = config.OUTPUT_DIR / name
    storyboard.save(sb, out_dir)
    log.info("Course storyboard: %s scenes, %s words (target %s) -> %s", sb["stats"]["scenes"],
             sb["stats"]["words"], sb["stats"]["target_words"], out_dir / "script.md")
    return out_dir


def redo_chapter(out_dir: Path, n: int, *, model: str | None = None) -> Path:
    """Make chapter n of an existing course again (e.g. after a weak chapter), keep the rest."""
    sb = storyboard.load(out_dir)
    course = sb.get("course")
    if not course:
        raise ValueError(f"{out_dir} is not a course (made by course.py)")
    plan, ranges = course["outline"], course["chapter_scenes"]
    if not 1 <= n <= len(ranges):
        raise ValueError(f"chapter must be 1-{len(ranges)}")
    cost0 = llm.spent_this_run()
    mark = llm.meter_mark()
    rows = store.available_recordings()
    refs = {topics.recording_ref(r): r["video_id"] for r in rows}
    new = make_chapter(n, plan, sb["level"], refs, list(store.all_segments().values()), model, course["wishes"])
    a, b = ranges[n - 1]
    sb["scenes"][a:b] = new["scenes"]
    shift = len(new["scenes"]) - (b - a)
    ranges[n - 1] = [a, a + len(new["scenes"])]
    for r in ranges[n:]:
        r[0] += shift
        r[1] += shift
    sb["sources"] = {k: v for k, v in sb["sources"].items() if not k.startswith(f"C{n}S")} | new["sources"]
    words = sum(len(s["narration"].split()) for s in sb["scenes"])
    sb["stats"].update(scenes=len(sb["scenes"]), words=words,
                       length_ratio=round(words / sb["stats"]["target_words"], 2),
                       est_minutes=round(words / storyboard.SPOKEN_WPM, 1))
    sb["plan_cost_usd_est"] = round(sb.get("plan_cost_usd_est", 0) + llm.spent_this_run() - cost0, 4)
    sb["plan_calls"] = sb.get("plan_calls", []) + llm.calls_since(mark)
    storyboard.save(sb, out_dir)
    log.info("Chapter %s remade: %s scenes", n, len(new["scenes"]))
    return out_dir


def make(request: str, minutes: float = 8, level: str = "beginner", model: str | None = None,
         plan_only: bool = False, wishes: str = "", style: str | None = None,
         characters: str | None = None, audio_only: bool = False) -> tuple[Path, dict]:
    """The whole course: plan, then voice + pictures + video (unless plan_only; audio_only: no video)."""
    if not plan_only:
        make_video.check_voice_quota(minutes)   # a course plan is many paid calls: check the voice first
    out_dir = plan_course(request, minutes, level, model=model, wishes=wishes, style=style, characters=characters)
    return make_video.make(rerender=out_dir, plan_only=plan_only, audio_only=audio_only)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("request", nargs="?", help="what the course is about, in your own words")
    ap.add_argument("--minutes", type=float, default=8, help="target length (default 8)")
    ap.add_argument("--level", choices=list(lesson.LEVELS), default="beginner")
    ap.add_argument("--wishes", default="", help="e.g. 'more examples, a comparison table'")
    ap.add_argument("--model", help="override CHAT_MODEL from .env")
    ap.add_argument("--plan-only", action="store_true", help="stop after the storyboard (read script.md first)")
    ap.add_argument("--redo-chapter", type=int, metavar="N", help="remake chapter N of the course in FOLDER")
    ap.add_argument("folder", nargs="?", type=Path, help="with --redo-chapter: the course's output folder")
    ap.add_argument("--auto", action="store_true", help="no request: one coherent theme of the knowledge base with "
                                                         "enough material for --minutes is chosen for you")
    ap.add_argument("--free", action="store_true", help="Kokoro voice + HTML slides (free), whatever .env says")
    args = ap.parse_args()
    config.setup_logging()
    try:
        if args.auto:
            out_dir, info, theme = auto(args.minutes, args.level, args.model, args.plan_only, args.free)
            print(f"\nTheme: {theme['theme']}\nWhy: {theme['why']}\nTopics ({theme['supported']:g} min of material "
                  f"for {theme['need']:g} min of chapters):")
            for t in theme["topics"]:
                print(f"  - {t['title']}  (recording {t['recording']}, {t['minutes']:g} min, {t['depth']})")
            if theme["minutes"] < args.minutes:
                print(f"Not enough material for {args.minutes:g} min without stretching: made {theme['minutes']:g} min.")
        elif args.redo_chapter:
            folder = args.folder or (Path(args.request) if args.request else None)
            if not folder:
                ap.error("--redo-chapter needs the course folder")
            redo_chapter(folder, args.redo_chapter, model=args.model)
            out_dir, info = make_video.make(rerender=folder, plan_only=args.plan_only)
        elif args.request:
            ctx = contextlib.nullcontext()
            if args.free:
                import length_costs
                ctx = length_costs.free_setup()
            with ctx:
                out_dir, info = make(args.request, args.minutes, args.level, args.model, args.plan_only, args.wishes)
        else:
            ap.error("give a request, --auto, or --redo-chapter N FOLDER")
    except lesson.NotEnoughMaterial as e:
        log.error("%s", e)
        return 2
    except (RuntimeError, ValueError, OSError) as e:
        log.error("%s", e)
        return 1
    print(f"\nScript: {out_dir / 'script.md'}")
    if args.plan_only:
        print(f"Then make the video: uv run make_video.py --rerender \"{out_dir}\"")
    else:
        m, s = divmod(int(info["duration_s"]), 60)
        print(f"Video:  {info['video']}  ({m}:{s:02d})\nChapters: {out_dir / 'chapters.txt'}")
    print(f"Estimated model cost: ${llm.spent_this_run():.3f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
