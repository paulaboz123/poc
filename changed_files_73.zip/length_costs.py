"""
length_costs.py - what one video costs as it gets longer: the same request made at 1, 3, 5, 10 and 15 minutes
with the free setup the client chose (Kokoro voice + HTML slides). The cost shown is what is paid today: Claude
writing the video (the voice and the slides are free). Also the limits: the longest video, how many a day the
spending lock allows. (The .json keeps more measurements: times, file sizes, tokens.)

  uv run length_costs.py "Snowflake basics"                  # 3, 5, 10 and 15 minutes (Claude: ~$1-2 in total)
  uv run length_costs.py "Snowflake basics" --minutes 3,5    # some lengths only
  uv run length_costs.py "Snowflake basics" --redo 10        # make one length again
  uv run length_costs.py --report                            # only the tables again, from the videos made
  uv run length_costs.py --scratch 15                        # a new 15-min video from nothing: the theme chosen from
                                                             # the knowledge base so its material fills 15 min

Built on an existing video instead (extend.py): the 1-minute video made 5 minutes long, that one 10, that
one 15 - each longer video keeps the shorter one and adds chapters after it (when the topic runs out, the
closest related topics of the knowledge base, so the length is reached):
  uv run length_costs.py --from 1m                           # the newest 1-minute video -> 3, 5, 10, 15
  uv run length_costs.py --from data/output/<folder> --minutes 1,5,10,15
The starting video's own length (1) is measured too: its script made again with the free setup (no Claude).

A length already made is not made again (run the same command after an error: it goes on where it stopped).
4 minutes or more is a course (course.py: chapters), as when a person asks in Lesson Studio.
Result: data/output/length_costs/length_costs.json, .md and .xlsx; shown in Lesson Studio, tab Prices & results.
"""
from __future__ import annotations

import argparse
import contextlib
import logging
import re
import sys
import time
from datetime import datetime
from pathlib import Path

import config
import llm
import store

log = logging.getLogger("length_costs")
LENGTHS = [3, 5, 10, 15]
MAX_MINUTES = 15            # the longest video one request makes (ask.py); longer: several videos
CLOUD_SLOWER = 1.5          # the laptop has 4 cores, the cloud server 2: its time is taken 1.5x
S3_USD_PER_GB_MONTH = 0.0245   # keeping the video (S3 Frankfurt)
MONTH_VIDEOS = 100          # a busy department month, for the "a month" column
RENDERER, VOICE = "html", "kokoro"   # the client's choice: HTML slides, Kokoro voice (both free)


def folder() -> Path:
    return config.OUTPUT_DIR / "length_costs"


def load() -> dict:
    return store.read_json(folder() / "length_costs.json", {}) or {}


@contextlib.contextmanager
def free_setup():
    """The client's choice for the whole run: Kokoro voice, HTML slides, the plain style, the main look."""
    keys = ("RENDERER", "TTS_ENGINE", "TTS_VOICE", "VIDEO_LOOK")
    saved = {k: getattr(config, k) for k in keys}
    config.RENDERER, config.TTS_ENGINE, config.VIDEO_LOOK = RENDERER, VOICE, "main"
    if not re.fullmatch(r"[a-z]{2}_[a-z]+", str(saved["TTS_VOICE"])):   # an ElevenLabs voice set in .env
        config.TTS_VOICE = "af_heart"
    try:
        yield
    finally:
        for k, v in saved.items():
            setattr(config, k, v)


def make_one(topic: str, minutes: float, level: str = "beginner", model: str | None = None,
             base: Path | None = None) -> dict:
    """One video of this length, measured (base: built on that shorter video, extend.py)."""
    import course
    import extend
    import make_video
    mark = llm.meter_mark()
    t0 = time.perf_counter()
    with free_setup():
        if base is not None:
            out_dir, info = extend.make(base, minutes, model=model)
        elif minutes >= course.COURSE_MIN_MINUTES:
            out_dir, info = course.make(topic, minutes, level, model, style="clean")
        else:
            out_dir, info = make_video.make(topic, None, minutes, level, model, style="clean")
    make_s = time.perf_counter() - t0
    calls = [c for c in llm.calls_since(mark) if c.get("step") != "voice"]
    claude_s = sum(float(c.get("seconds") or 0) for c in calls)
    step_usd = round(sum(float(c.get("cost_usd") or 0) for c in calls), 4)
    video = out_dir / "lesson_video.mp4"
    t = info.get("timings", {})
    chain = {}
    if base is not None:   # the whole video's writing: the shorter videos' and this step's
        sb = store.read_json(out_dir / "storyboard.json", {}) or {}
        ext = sb.get("course", {})
        chain = {"built_on": base.name, "claude_step_usd": step_usd,
                 "claude_usd": round(max(step_usd, float(sb.get("plan_cost_total_usd") or 0)), 4),
                 "new_topics": [c["title"] for c in ext.get("new_chapters", []) if c.get("new_topic")],
                 "new_chapters": [c["title"] for c in ext.get("new_chapters", [])]}
    return {"minutes": minutes, "folder": out_dir.name, "title": info.get("title", ""),
            "made": datetime.now().isoformat(timespec="seconds"), "model": info.get("model", ""),
            "length_s": float(info.get("duration_s") or 0), "scenes": info.get("scenes"),
            "claude_usd": round(sum(float(c.get("cost_usd") or 0) for c in calls), 4),
            "claude_calls": len(calls), "in_tokens": sum(int(c.get("in_tokens") or 0) for c in calls),
            "out_tokens": sum(int(c.get("out_tokens") or 0) for c in calls),
            "claude_s": round(claude_s, 1), "make_s": round(make_s, 1),
            "voice_s": t.get("voice_s"), "pictures_s": t.get("pictures_s"), "video_s": t.get("video_s"),
            "size_mb": round(video.stat().st_size / 1e6, 1) if video.exists() else None, **chain}


def costs(row: dict) -> dict:
    """What the video costs: Claude + the server's time (cloud), the margin on top; keeping it a month."""
    import compare_video
    margin = 1 + config.COST_MARGIN_PCT / 100
    server_s = max(0.0, row["make_s"] - row.get("claude_s", 0)) * CLOUD_SLOWER   # waiting for Claude costs no CPU
    server = server_s * compare_video.CLOUD_PER_S
    total = (row["claude_usd"] + server) * margin
    real_min = (row["length_s"] or row["minutes"] * 60) / 60
    return {**row, "server_usd": round(server, 4), "total_usd": round(total, 4),
            "cloud_make_s": round(row.get("claude_s", 0) + server_s, 1),
            "per_min_usd": round(total / max(real_min, 0.1), 4), "real_min": round(real_min, 1),
            "store_usd_month": round((row.get("size_mb") or 0) / 1000 * S3_USD_PER_GB_MONTH, 5),
            "make_per_video_min": round(row["make_s"] / 60 / max(real_min, 0.1), 2)}


def fit(rows: list[dict], key: str) -> tuple[float, float]:
    """key = a + b * minutes (least squares; one row: through zero)."""
    xs, ys = [r["real_min"] for r in rows], [r[key] for r in rows]
    if len(rows) == 1:
        return 0.0, ys[0] / max(xs[0], 0.1)
    mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
    sxx = sum((x - mx) ** 2 for x in xs) or 1e-9
    b = sum((x - mx) * (y - my) for x, y in zip(xs, ys, strict=True)) / sxx
    if my - b * mx < 0:   # a fixed part below zero makes no sense: a line through zero instead
        return 0.0, sum(x * y for x, y in zip(xs, ys, strict=True)) / (sum(x * x for x in xs) or 1e-9)
    return my - b * mx, b


def report(data: dict | None = None) -> dict:
    """The tables: per length, the progression (fitted line, longer videos), the limits."""
    data = data if data is not None else load()
    raw = [dict(r) for r in sorted(data.get("runs", {}).values(), key=lambda r: r["minutes"])]
    start = next((r for r in raw if r.get("claude_unknown")), None)
    if start is not None:   # what writing the starting video cost is not in it: Claude's cost a minute of the steps
        steps, prev = [], start["length_s"] / 60
        for r in raw:
            if r.get("claude_step_usd") is not None and r["length_s"] / 60 > prev:
                steps.append(r["claude_step_usd"] / (r["length_s"] / 60 - prev))
                prev = r["length_s"] / 60
        if steps:
            est = round(sum(steps) / len(steps) * start["length_s"] / 60, 4)
            start["claude_usd"] = est
            for r in raw:
                if r.get("built_on"):
                    r["claude_usd"] = round(r["claude_usd"] + est, 4)
                    r["claude_estimated"] = True
            start["claude_estimated"] = True
    rows = [costs(r) for r in raw]
    scratch = [costs(r) for r in sorted((store.read_json(folder() / "scratch.json", {}) or {}).values(),
                                        key=lambda r: r["minutes"])]
    out = {"scratch": scratch, "topic": data.get("topic", ""),
           "built_from": data.get("from", "") if data.get("mode") == "chain" else "",
           "setup": "Kokoro voice (free) + HTML slides (free), Claude writes the script",
           "rows": rows, "margin_pct": config.COST_MARGIN_PCT, "cloud_slower": CLOUD_SLOWER,
           "month_videos": MONTH_VIDEOS}
    if not rows:
        out["limits"] = []
        return out
    a, b = fit(rows, "total_usd")
    ma, mb = fit(rows, "cloud_make_s")
    out["fit"] = {"fixed_usd": round(a, 4), "per_min_usd": round(b, 4),
                  "make_fixed_s": round(ma, 1), "make_per_min_s": round(mb, 1)}
    out["progression"] = [{"minutes": m, "usd": round(max(a + b * m, 0), 3),
                           "make_min": round(max(ma + mb * m, 0) / 60, 1),
                           "month_usd": round(max(a + b * m, 0) * MONTH_VIDEOS, 2),
                           "measured": any(abs(r["real_min"] - m) < 0.75 for r in rows)}
                          for m in (1, 3, 5, 10, 15, 20, 30, 45, 60)]
    claude_per_min = max(r["claude_usd"] / max(r["real_min"], 0.1) for r in rows)
    longest = rows[-1]
    out["limits"] = [
        {"limit": "Longest video one request makes", "value": f"{MAX_MINUTES} min",
         "why": "Set in the app (ask.py). Longer: a series of videos, or the limit raised (the course is made "
                "chapter by chapter, so length is not a technical wall)."},
        {"limit": "Spending lock a day", "value": f"${config.DAILY_BUDGET_USD:g} (max $100, fixed in code)",
         "why": f"About {int(config.DAILY_BUDGET_USD // max(longest['claude_usd'], 0.001))} videos of "
                f"{longest['real_min']:g} min a day before the app stops calling Claude (only Claude counts: "
                f"the voice and the slides are free)."},
        {"limit": "Spending lock a request", "value": f"${config.RUN_BUDGET_USD:g}",
         "why": f"Claude costs ~${claude_per_min:.3f} a minute of video, so one request could be up to "
                f"~{int(config.RUN_BUDGET_USD / max(claude_per_min, 1e-4))} min before this lock stops it."},
        {"limit": "The material", "value": "What the recordings cover",
         "why": "A video only uses the training material: a long video on a narrow topic repeats itself or is "
                "made shorter, and says what is missing."},
    ]
    return out


def write(rep: dict) -> Path:
    """length_costs.md and .xlsx next to the .json: what each video cost (what is paid today: Claude writing it;
    the voice and the slides are free) and the limits."""
    f = folder()
    f.mkdir(parents=True, exist_ok=True)
    limits = [x for x in rep.get("limits", []) if "server" not in x["limit"].lower()]
    md = ["# What a video costs by length", "",
          "The cost is what is paid today: Claude writing the video (the voice and the slides are free).", "",
          "| Video | Cost | New topics (the topic ran out) |", "|---|---|---|"]
    md += [f"| {r['minutes']:g} min | ${r['claude_usd']:.3f} | {', '.join(r.get('new_topics', [])) or '-'} |"
           for r in rep["rows"]]
    if limits:
        md += ["", "## Limits", ""] + [f"- **{x['limit']}: {x['value']}.** {x['why']}" for x in limits]
    (f / "length_costs.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font
        wb = Workbook()
        ws = wb.active
        ws.title = "Costs"
        ws.append(["Video (min)", "Cost ($)", "New topics (the topic ran out)"])
        for r in rep["rows"]:
            ws.append([r["minutes"], r["claude_usd"], ", ".join(r.get("new_topics", []))])
        ws2 = wb.create_sheet("Limits")
        ws2.append(["Limit", "Value", "Why"])
        for x in limits:
            ws2.append([x["limit"], x["value"], x["why"]])
        for sheet in (ws, ws2):
            for c in sheet[1]:
                c.font = Font(bold=True)
        ws.column_dimensions["C"].width = 50
        wb.save(f / "length_costs.xlsx")
    except ImportError:
        log.info("openpyxl not installed: no .xlsx (the .md is there)")
    return f / "length_costs.md"


def run(topic: str, lengths: list[float], redo: set[float] | None = None, level: str = "beginner",
        model: str | None = None) -> dict:
    data = load()
    if data.get("topic") and data["topic"] != topic:   # another topic: start again (the old file is kept aside)
        old = folder() / "length_costs.json"
        old.rename(old.with_name(f"length_costs_{datetime.now():%Y%m%d-%H%M%S}.json"))
        data = {}
    data["topic"] = topic
    runs = data.setdefault("runs", {})
    for m in lengths:
        key = f"{m:g}"
        if key in runs and m not in (redo or set()) and (config.OUTPUT_DIR / runs[key]["folder"]).exists():
            log.info("%g min: made before (%s)", m, runs[key]["folder"])
            continue
        log.info("=== %g min", m)
        try:
            runs[key] = make_one(topic, m, level, model)
        except Exception as e:   # noqa: BLE001 - one length failing (lock, voice, material) does not stop the rest
            log.error("%g min failed: %s", m, str(e)[:400])
            data.setdefault("errors", {})[key] = str(e)[:300]
            continue
        data.get("errors", {}).pop(key, None)
        folder().mkdir(parents=True, exist_ok=True)
        store.write_json(folder() / "length_costs.json", data)
    store.write_json(folder() / "length_costs.json", data)
    return data


def measure_base(base: Path) -> dict:
    """The video the chain starts from, measured as the others: its script as it is (no Claude now: what writing
    it cost is read from it), made again with the free setup in a new folder (the original stays as it was)."""
    import extend
    import make_video
    import storyboard
    sb = storyboard.load(base)
    name, sb["version"] = store.versioned(f"{datetime.now():%Y%m%d-%H%M%S}",
                                          f"{store.slugify(sb.get('title') or base.name, 40)}-measured-{float(sb.get('minutes') or 1):g}m")
    out_dir = config.OUTPUT_DIR / name
    storyboard.save(sb, out_dir)
    t0 = time.perf_counter()
    with free_setup():
        out_dir, info = make_video.make(rerender=out_dir)
    make_s = time.perf_counter() - t0
    claude = extend.base_cost(sb)
    video = out_dir / "lesson_video.mp4"
    t = info.get("timings", {})
    return {"minutes": float(sb.get("minutes") or 1), "folder": out_dir.name, "title": info.get("title", ""),
            "made": datetime.now().isoformat(timespec="seconds"), "model": sb.get("model", ""),
            "length_s": float(info.get("duration_s") or 0), "scenes": info.get("scenes"),
            "claude_usd": round(claude, 4), "claude_unknown": claude <= 0, "claude_calls": len(sb.get("plan_calls", [])),
            "in_tokens": sum(int(c.get("in_tokens") or 0) for c in sb.get("plan_calls", [])),
            "out_tokens": sum(int(c.get("out_tokens") or 0) for c in sb.get("plan_calls", [])),
            "claude_s": round(sum(float(c.get("seconds") or 0) for c in sb.get("plan_calls", [])), 1),
            "make_s": round(make_s + sum(float(c.get("seconds") or 0) for c in sb.get("plan_calls", [])), 1),
            "voice_s": t.get("voice_s"), "pictures_s": t.get("pictures_s"), "video_s": t.get("video_s"),
            "size_mb": round(video.stat().st_size / 1e6, 1) if video.exists() else None,
            "measured_copy_of": base.name, "new_chapters": [], "new_topics": []}


def make_scratch(minutes: float = 15, level: str = "beginner", model: str | None = None) -> dict:
    """A video made from nothing (course.py --auto): the theme chosen from the knowledge base so its material
    supports the length (shorter rather than stretched), Kokoro + HTML, measured like the others. Kept in
    scratch.json and shown in Lesson Studio, tab Prices & results."""
    import course
    mark = llm.meter_mark()
    t0 = time.perf_counter()
    with free_setup():
        out_dir, info, theme = course.auto(minutes, level, model)
    make_s = time.perf_counter() - t0
    calls = [c for c in llm.calls_since(mark) if c.get("step") != "voice"]
    video = out_dir / "lesson_video.mp4"
    row = {"minutes": theme["minutes"], "asked": minutes, "folder": out_dir.name, "title": info.get("title", ""),
           "made": datetime.now().isoformat(timespec="seconds"), "model": info.get("model", ""),
           "length_s": float(info.get("duration_s") or 0), "scenes": info.get("scenes"),
           "claude_usd": round(sum(float(c.get("cost_usd") or 0) for c in calls), 4), "claude_calls": len(calls),
           "in_tokens": sum(int(c.get("in_tokens") or 0) for c in calls),
           "out_tokens": sum(int(c.get("out_tokens") or 0) for c in calls),
           "claude_s": round(sum(float(c.get("seconds") or 0) for c in calls), 1), "make_s": round(make_s, 1),
           "size_mb": round(video.stat().st_size / 1e6, 1) if video.exists() else None,
           "theme": theme["theme"], "why": theme["why"],
           "topics": [f"{t['title']} (recording {t['recording']})" for t in theme["topics"]],
           "material_min": theme["supported"]}
    data = store.read_json(folder() / "scratch.json", {}) or {}
    data[f"{minutes:g}"] = row
    folder().mkdir(parents=True, exist_ok=True)
    store.write_json(folder() / "scratch.json", data)
    return row


def run_chain(base_spec: str | Path, lengths: list[float], redo: set[float] | None = None,
              model: str | None = None) -> dict:
    """Each length built on the one before it (the first on the given video): 1 -> 3 -> 5 -> 10 -> 15.
    The given video's own length (e.g. 1) is measured too: its script made again with the free setup."""
    import extend
    base = extend.find_base(base_spec)
    data = load()
    if data and (data.get("mode") != "chain" or data.get("from") != base.name):   # another set: start again
        old = folder() / "length_costs.json"
        old.rename(old.with_name(f"length_costs_{datetime.now():%Y%m%d-%H%M%S}.json"))
        data = {}
    sb = store.read_json(base / "storyboard.json", {}) or {}
    data.update(mode="chain", topic=sb.get("title") or sb.get("topic") or base.name, **{"from": base.name})
    runs = data.setdefault("runs", {})
    redo = redo or set()
    log.info("Built on: %s (%s)", base.name, data["topic"])
    first = base
    base_min = float(sb.get("minutes") or 1)
    for m in sorted(lengths):
        key = f"{m:g}"
        done = runs.get(key)
        if abs(m - base_min) < 0.5:   # the starting video itself: measured, not made longer
            if done and m not in redo and (config.OUTPUT_DIR / done["folder"]).exists() \
                    and done.get("measured_copy_of") == first.name:
                log.info("%g min (the starting video): measured before (%s)", m, done["folder"])
                continue
            log.info("=== %g min: the starting video, made again with the free setup to measure it", m)
            try:
                runs[key] = measure_base(first)
            except Exception as e:   # noqa: BLE001 - the longer ones don't need it: go on
                log.error("Measuring the starting video failed: %s", str(e)[:400])
                data.setdefault("errors", {})[key] = str(e)[:300]
                continue
            data.get("errors", {}).pop(key, None)
            folder().mkdir(parents=True, exist_ok=True)
            store.write_json(folder() / "length_costs.json", data)
            continue
        if done and m not in redo and (config.OUTPUT_DIR / done["folder"]).exists() and done.get("built_on") == base.name:
            log.info("%g min: made before (%s)", m, done["folder"])
            base = config.OUTPUT_DIR / done["folder"]
            continue
        redo |= {x for x in lengths if x > m}   # the longer ones are built on this one: they are made again too
        log.info("=== %g min, built on %s", m, base.name)
        try:
            runs[key] = make_one(data["topic"], m, model=model, base=base)
        except extend.AlreadyLong as e:   # the shorter video is already about this long: the next one builds on it
            log.warning("%g min skipped: %s", m, e)
            data.setdefault("errors", {})[key] = str(e)[:300]
            continue
        except Exception as e:   # noqa: BLE001 - the longer ones need this one: stop here
            log.error("%g min failed: %s (run the same command again to go on)", m, str(e)[:400])
            data.setdefault("errors", {})[key] = str(e)[:300]
            break
        data.get("errors", {}).pop(key, None)
        base = config.OUTPUT_DIR / runs[key]["folder"]
        folder().mkdir(parents=True, exist_ok=True)
        store.write_json(folder() / "length_costs.json", data)
    folder().mkdir(parents=True, exist_ok=True)
    store.write_json(folder() / "length_costs.json", data)
    return data


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("topic", nargs="?", help="what the videos are about (the same for every length)")
    ap.add_argument("--minutes", default=",".join(map(str, LENGTHS)), help="lengths, e.g. 3,5,10,15")
    ap.add_argument("--redo", default="", help="lengths to make again, e.g. 10")
    ap.add_argument("--level", default="beginner")
    ap.add_argument("--model", help="override CHAT_MODEL from .env")
    ap.add_argument("--from", dest="base", help="build every length on this video: its folder, or 1m for the "
                                                 "newest 1-minute video (lengths then default to 1,3,5,10,15)")
    ap.add_argument("--scratch", type=float, metavar="MIN", help="a new video of this length from nothing: the theme "
                    "chosen from the knowledge base so its material fills it (e.g. --scratch 15)")
    ap.add_argument("--report", action="store_true", help="only the tables again")
    args = ap.parse_args()
    config.setup_logging()
    if args.scratch:
        r = make_scratch(min(args.scratch, MAX_MINUTES), args.level, args.model)
        print(f"\n{r['minutes']:g}-min video from scratch: {r['title']}\nTheme: {r['theme']} ({r['why']})\n"
              f"Material: {r['material_min']:g} min in: " + "; ".join(r["topics"]) +
              f"\nCost (Claude): ${r['claude_usd']:.3f}\nFolder: {config.OUTPUT_DIR / r['folder']}\n"
              "In Lesson Studio: tab Prices & results.")
        return 0
    if not args.report:
        if not args.topic and not args.base:
            ap.error("give a topic, --from <video> (or --report)")
        minutes = args.minutes if args.minutes != ",".join(map(str, LENGTHS)) or not args.base else "1,3,5,10,15"
        lengths = [min(float(x), MAX_MINUTES) for x in minutes.split(",") if x.strip()]
        redo = {float(x) for x in args.redo.split(",") if x.strip()}
        if args.base:
            try:
                run_chain(args.base, lengths, redo, args.model)
            except FileNotFoundError as e:
                print(e)
                return 1
        else:
            run(args.topic, lengths, redo, args.level, args.model)
    rep = report()
    if not rep["rows"]:
        print("Nothing made yet: uv run length_costs.py \"<topic>\"")
        return 1
    md = write(rep)
    print(md.read_text(encoding="utf-8"))
    print(f"Saved: {md} (+ .xlsx). In Lesson Studio: tab Prices & results.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
