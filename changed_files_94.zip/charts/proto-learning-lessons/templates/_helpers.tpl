{{/* Name of every object: the release name. */}}
{{- define "pll.name" -}}
{{- .Release.Name | trunc 50 | trimSuffix "-" -}}
{{- end -}}

{{- define "pll.labels" -}}
app.kubernetes.io/name: {{ include "pll.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/part-of: lesson-studio
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version }}
{{- end -}}

{{- define "pll.selector" -}}
app.kubernetes.io/name: {{ include "pll.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/* Secrets: the Bifrost key and the optional extra settings. */}}
{{- define "pll.bifrostSecret" -}}
{{- printf "%s-bifrost" (include "pll.name" .) -}}
{{- end -}}

{{- define "pll.extraSecret" -}}
{{- if .Values.extraSecret.existingSecret -}}
{{- .Values.extraSecret.existingSecret -}}
{{- else if .Values.extraSecret.awsSecretName -}}
{{- printf "%s-env" (include "pll.name" .) -}}
{{- end -}}
{{- end -}}

{{- define "pll.oauth2" -}}
{{- $o := index .Values "oauth2-proxy" | default dict -}}
{{- if $o.enabled }}true{{ end -}}
{{- end -}}

{{- define "pll.image" -}}
{{- $img := .Values.app.image -}}
{{- if not $img.repository -}}
{{- fail "app.image.repository is required" -}}
{{- end -}}
{{- if or (not $img.tag) (eq (toString $img.tag) "latest") -}}
{{- fail "app.image.tag is required and must not be latest" -}}
{{- end -}}
{{- printf "%s:%s" $img.repository (toString $img.tag) -}}
{{- end -}}

{{/* Container environment. */}}
{{- define "pll.env" -}}
- {name: APP_HOST, value: "0.0.0.0"}
- {name: APP_PORT, value: {{ .Values.app.port | quote }}}
- {name: LOG_FORMAT, value: {{ .Values.config.logFormat | quote }}}
- {name: LOG_LEVEL, value: {{ .Values.config.logLevel | quote }}}
- {name: SHUTDOWN_WAIT_S, value: {{ .Values.app.shutdownWaitS | quote }}}
- {name: COST_LOG, value: /app/data/cost_log.csv}
- {name: METRICS_PORT, value: {{ .Values.app.metricsPort | quote }}}
- {name: EVAL_SAMPLE, value: {{ .Values.app.evalSample | quote }}}
{{- with .Values.bifrost.baseUrl }}
- {name: BIFROST_BASE_URL, value: {{ . | quote }}}
{{- end }}
{{- with .Values.bifrost.model }}
- {name: CHAT_MODEL, value: {{ . | quote }}}
{{- end }}
{{- with .Values.auth.proxyHeader }}
- {name: AUTH_PROXY_HEADER, value: {{ . | quote }}}
{{- end }}
{{- range $k, $v := .Values.config.env }}
- {name: {{ $k }}, value: {{ $v | quote }}}
{{- end }}
{{- if .Values.bifrost.apiKey.enabled }}
- name: BIFROST_API_KEY
  valueFrom:
    secretKeyRef:
      name: {{ include "pll.bifrostSecret" . }}
      key: BIFROST_API_KEY
{{- end }}
{{- end -}}

{{/* Required values. */}}
{{- define "pll.checks" -}}
{{- if ne (int .Values.app.replicaCount) 1 -}}
{{- fail "app.replicaCount must be 1 (in-memory job queue, ReadWriteOnce volume)" -}}
{{- end -}}
{{- if not .Values.bifrost.baseUrl -}}
{{- fail "bifrost.baseUrl is required" -}}
{{- end -}}
{{- if not .Values.bifrost.model -}}
{{- fail "bifrost.model is required" -}}
{{- end -}}
{{- if and (not .Values.auth.proxyHeader) (not (include "pll.extraSecret" .)) -}}
{{- fail "No sign-in configured: set auth.proxyHeader or provide APP_PASSWORD through extraSecret" -}}
{{- end -}}
{{- end -}}

{{/* Pod and container security context. */}}
{{- define "pll.podSecurity" -}}
runAsNonRoot: true
runAsUser: 1000
runAsGroup: 1000
fsGroup: 1000
fsGroupChangePolicy: OnRootMismatch
seccompProfile:
  type: RuntimeDefault
{{- end -}}

{{- define "pll.containerSecurity" -}}
allowPrivilegeEscalation: false
readOnlyRootFilesystem: true
capabilities:
  drop: ["ALL"]
{{- end -}}

{{/* Common helper names, so templates following the standard Helm layout work unchanged. */}}
{{- define "pll.fullname" -}}
{{- include "pll.name" . -}}
{{- end -}}

{{- define "pll.selectorLabels" -}}
{{- include "pll.selector" . -}}
{{- end -}}

{{- define "pll.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | trunc 63 | trimSuffix "-" -}}
{{- end -}}
