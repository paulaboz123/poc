"""
slides_html.py - designer-grade slides and motion, drawn by a real browser engine (HTML/CSS/SVG),
the way modern presentation and video tools work. Replaces the simple Pillow drawings
(render.py stays as the fallback when no browser is available).

What a slide can show
  - an "action title" (the message of the slide) and a lead line under it
  - elements with an icon, a title, a detail line and optionally a value (a number, a time)
  - layouts: cards, steps, cycle, timeline, hub, comparison, table, stats, concept, example,
    callout, bullets, title (lesson / chapter), question / answer, and original slides
  - 1,500 open-source icons (Lucide, ISC licence, assets/icons.json); the font Inter (OFL)

How it moves (timed to the voice, see animation.py for the cut points)
  - entrance: the title and lead slide in, elements rise and fade in one after another
  - build: an element appears exactly when the voice reaches it
  - highlight: the element being talked about lifts, its icon fills, the others step back
  - connectors and rings draw themselves, timelines grow, numbers count up
  - scenes cross-fade into each other (make_video.py)

How it is rendered
  One HTML page per scene; a small script sets the picture for any moment t (render(t)), so
  every frame is exact and repeatable. Frames are only captured while something moves; still
  stretches are one picture shown longer, which keeps rendering fast.

Browser: Playwright with its own Chromium, or the Microsoft Edge / Chrome already installed
(no download needed on a company laptop):  uv add playwright   (once)
"""
from __future__ import annotations

import html
import json
import logging
import math
import re
from functools import lru_cache
from pathlib import Path

import cartoon
import config

log = logging.getLogger("slides_html")

ASSETS = Path(__file__).resolve().parent / "assets"
W, H = 1280, 720                     # design size; the picture is scaled to VIDEO_WIDTH
FPS = config.VIDEO_FPS
ENTER_S = 0.6                        # how long an element takes to appear
HILITE_S = 0.35                      # how long a highlight takes to switch on or off

ICON_HINTS = {   # first icon that fits common learning topics, when the model gave none
    "goal": "target", "objective": "target", "team": "users", "people": "users", "role": "user-round",
    "owner": "crown", "master": "compass", "coach": "compass", "developer": "code", "plan": "calendar-check",
    "planning": "calendar-check", "daily": "sun", "review": "presentation", "retro": "refresh-ccw",
    "retrospective": "refresh-ccw", "sprint": "timer", "backlog": "list-ordered", "increment": "package-check",
    "time": "clock", "timebox": "hourglass", "quality": "badge-check", "risk": "triangle-alert", "cost": "wallet",
    "money": "banknote", "data": "database", "report": "file-chart-column", "chart": "chart-column", "check": "check-check",
    "test": "flask-conical", "customer": "smile", "value": "gem", "feedback": "messages-square",
    "meeting": "messages-square", "decision": "git-branch", "process": "workflow", "rule": "scale",
    "security": "shield-check", "learn": "graduation-cap", "tip": "lightbulb", "warning": "triangle-alert",
    "idea": "lightbulb", "tool": "wrench", "excel": "sheet", "table": "table", "join": "merge", "key": "key-round",
    "clean": "sparkles", "error": "circle-x", "success": "circle-check", "start": "play", "end": "flag",
    "deliver": "truck", "build": "hammer", "improve": "trending-up", "measure": "gauge", "transparency": "eye",
    "inspection": "search", "adaptation": "shuffle", "commitment": "handshake", "focus": "focus", "respect": "heart-handshake",
    "courage": "shield", "openness": "door-open", "estimate": "ruler", "priority": "arrow-up-wide-narrow",
    "stakeholder": "briefcase", "product": "box", "story": "book-open", "done": "circle-check-big",
}


# --- Assets ----------------------------------------------------------------------------------------
@lru_cache(maxsize=1)
def _icons() -> dict:
    return json.loads((ASSETS / "icons.json").read_text(encoding="utf-8"))


def icon_names() -> list[str]:
    return list(_icons()["icons"])


def find_icon(name: str, hint_text: str = "") -> str:
    """A valid icon name: the one asked for, a close match, one from the words of the text, or ''."""
    import safety
    data = _icons()
    icons = {k: v for k, v in data["icons"].items() if safety.icon_allowed(k)}
    name = (name or "").strip().lower().replace(" ", "-").replace("_", "-")
    if name in safety.BLOCKED_ICONS:   # a blocked concept gets no icon at all, not a look-alike
        return ""
    if name in icons:
        return name
    words = re.findall(r"[a-z]+", f"{name} {hint_text}".lower())
    for w in words:
        if w in ICON_HINTS and ICON_HINTS[w] in icons:
            return ICON_HINTS[w]
        if w.rstrip("s") in ICON_HINTS and ICON_HINTS[w.rstrip("s")] in icons:
            return ICON_HINTS[w.rstrip("s")]
    for w in words:   # an icon whose name or tags contain the word
        if len(w) < 4:
            continue
        if w in icons:
            return w
        for icon, tags in data["tags"].items():
            if w in tags and icon in icons:
                return icon
    return ""


def svg_icon(name: str, cls: str = "ic") -> str:
    import safety
    inner = _icons()["icons"].get(name, "") if safety.icon_allowed(name) else ""
    if not inner:
        return ""
    # width/height 24 matter inside illustrations (a nested svg without them fills the whole picture)
    return (f'<svg class="{cls}" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" '
            f'stroke-linecap="round" stroke-linejoin="round">{inner}</svg>')


def esc(text: str) -> str:
    """HTML-escaped text; **word** becomes an accent-coloured emphasis."""
    t = html.escape(str(text or ""))
    return re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)


# --- Elements ------------------------------------------------------------------------------------
def elements(scene: dict) -> list[dict]:
    """The scene's elements as dicts {title, detail, icon, value}: from `elements` when the
    storyboard has them, else from the plain `items` (older storyboards)."""
    out = []
    raw = scene.get("elements") or [{"title": x} for x in scene.get("items", [])]
    for e in raw:
        e = e if isinstance(e, dict) else {"title": str(e)}
        title, detail = str(e.get("title", "")).strip(), str(e.get("detail", "")).strip()
        if not title and not detail:
            continue
        if ":" in title and not detail and len(title.split(":")[0].split()) <= 3:   # "Situation: late orders"
            title, detail = (x.strip() for x in title.split(":", 1))
        out.append({"title": title, "detail": detail, "value": str(e.get("value", "")).strip(),
                    "expression": str(e.get("expression", "")).strip(),
                    "icon": find_icon(e.get("icon", ""), f"{title} {detail}")})
    return out


# --- Layouts ------------------------------------------------------------------------------------
def _el(i: int, inner: str, cls: str = "", extra: str = "") -> str:
    return f'<div class="el {cls}" data-i="{i}" {extra}>{inner}</div>'


def _tile(icon: str, n: int | None = None, cls: str = "tile") -> str:
    body = svg_icon(icon) if icon else f'<span class="num">{n if n is not None else "•"}</span>'
    return f'<div class="{cls}">{body}</div>'


def _text(e: dict, title_cls: str = "t", detail_cls: str = "d") -> str:
    out = f'<div class="{title_cls}">{esc(e["title"])}</div>' if e["title"] else ""
    if e["detail"]:
        out += f'<div class="{detail_cls}">{esc(e["detail"])}</div>'
    return out


def layout_cards(els: list[dict], max_cols: int = 3) -> str:
    n = len(els)
    cols = min(n if n <= 3 else 2 if n == 4 else 3, max_cols)
    cards = "".join(_el(i, _tile(e["icon"], i + 1) + f'<div class="body">{_text(e)}</div>', "card")
                    for i, e in enumerate(els))
    return f'<div class="grid cards c{cols} n{n}">{cards}</div>'


def layout_bullets(els: list[dict]) -> str:
    rows = "".join(_el(i, _tile(e["icon"], i + 1, "tile sm") + f'<div class="body">{_text(e)}</div>', "row")
                   for i, e in enumerate(els))
    return f'<div class="rows">{rows}</div>'


def layout_steps(els: list[dict]) -> str:
    n = len(els)
    if n > 5:   # many steps: a vertical list, a short connector between two cards
        rows = "".join(_el(i, f'<div class="badge">{i + 1}</div><div class="body">{_text(e)}</div>', "vstep")
                       for i, e in enumerate(els))
        return f'<div class="vsteps">{rows}</div>'
    track = "".join(f'<div class="link draw-h" data-i="{i}"></div>' for i in range(1, n))
    steps = "".join(_el(i, f'<div class="node">{svg_icon(e["icon"]) if e["icon"] else i + 1}'
                           f'<span class="no">{i + 1}</span></div><div class="body">{_text(e)}</div>', "step")
                    for i, e in enumerate(els))
    return f'<div class="steps n{n}"><div class="links">{track}</div>{steps}</div>'


def layout_cycle(els: list[dict]) -> str:
    """A ring with the elements as nodes (left) and a legend with their text (right)."""
    n = len(els)
    r, cx, cy = 165, 215, 215
    arcs, nodes = [], []
    for i in range(n):
        a0 = -math.pi / 2 + 2 * math.pi * i / n
        a1 = a0 + 2 * math.pi / n
        gap = 0.32 if n <= 4 else 0.26
        s, e = a0 + gap, a1 - gap
        x0, y0, x1, y1 = cx + r * math.cos(s), cy + r * math.sin(s), cx + r * math.cos(e), cy + r * math.sin(e)
        length = r * (e - s)
        arcs.append(f'<path class="arc draw" data-i="{(i + 1) % n if i + 1 < n else i}" data-len="{length:.0f}" '
                    f'd="M{x0:.1f},{y0:.1f} A{r},{r} 0 0 1 {x1:.1f},{y1:.1f}" marker-end="url(#arrow)"/>')
        nx, ny = cx + r * math.cos(a0), cy + r * math.sin(a0)
        nodes.append(_el(i, f'{svg_icon(els[i]["icon"]) if els[i]["icon"] else i + 1}<span class="no">{i + 1}</span>',
                         "cnode", f'style="left:{nx - 38:.0f}px;top:{ny - 38:.0f}px"'))
    svg = (f'<svg class="ring" viewBox="0 0 430 430"><defs><marker id="arrow" viewBox="0 0 10 10" refX="6" '
           f'refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" '
           f'class="arrowhead"/></marker></defs><circle class="track" cx="{cx}" cy="{cy}" r="{r}"/>'
           + "".join(arcs) + "</svg>")
    legend = "".join(_el(i, f'<div class="badge">{i + 1}</div><div class="body">{_text(e)}</div>', "legend")
                     for i, e in enumerate(els))
    return f'<div class="cycle n{n}"><div class="wheel">{svg}{"".join(nodes)}</div><div class="legends">{legend}</div></div>'


def layout_timeline(els: list[dict]) -> str:
    n = len(els)
    items = "".join(_el(i, f'<div class="when">{esc(e["value"]) or (i + 1)}</div><div class="dot">'
                           f'{svg_icon(e["icon"]) if e["icon"] else ""}</div><div class="body">{_text(e)}</div>',
                        "mile") for i, e in enumerate(els))
    grow = "".join(f'<div class="seg draw-h" data-i="{i}"></div>' for i in range(1, n))   # dot to dot
    return f'<div class="timeline n{n}"><div class="axis"><div class="segs">{grow}</div></div>{items}</div>'


def layout_hub(els: list[dict], center: str, center_icon: str) -> str:
    n = len(els)
    cx, cy, rx, ry = 560, 235, 405, 175
    angles = {2: [180, 0], 3: [-90, 30, 150], 4: [-150, -30, 30, 150], 5: [-90, -18, 54, 126, 198],
              6: [-150, -90, -30, 30, 90, 150]}.get(n, [360 * k / n - 90 for k in range(n)])
    lines, sats = [], []
    for i, (e, deg) in enumerate(zip(els, angles, strict=False)):
        a = math.radians(deg)
        x, y = cx + rx * math.cos(a), cy + ry * math.sin(a)
        # the spoke runs from the edge of the core to the edge of the card, never under either (a dimmed or
        # see-through card would show a line through its text)
        dx, dy = cx - x, cy - y
        full = math.hypot(dx, dy) or 1.0
        s = min(158 / abs(dx) if abs(dx) > 1e-6 else 9.0, 58 / abs(dy) if abs(dy) > 1e-6 else 9.0)
        x2, y2 = x + dx * s, y + dy * s
        x1, y1 = cx - dx / full * 104, cy - dy / full * 104
        length = max(0.0, math.hypot(x2 - x1, y2 - y1))
        if s < 1 and (x2 - x1) * dx <= 0 and (y2 - y1) * dy <= 0 and length > 8:
            lines.append(f'<line class="spoke draw" data-i="{i}" data-len="{length:.0f}" x1="{x1:.0f}" y1="{y1:.0f}" '
                         f'x2="{x2:.0f}" y2="{y2:.0f}"/>')
        sats.append(_el(i, _tile(e["icon"], i + 1, "tile sm") + f'<div class="body">{_text(e)}</div>', "sat",
                        f'style="left:{x - 150:.0f}px;top:{y - 46:.0f}px"'))
    core = (f'<div class="core">{svg_icon(center_icon, "ic big") if center_icon else ""}'
            f'<div class="label">{esc(center)}</div></div>')
    return (f'<div class="hub n{n}"><svg class="spokes" viewBox="0 0 1120 470">{"".join(lines)}</svg>'
            f'{core}{"".join(sats)}</div>')


def layout_comparison(columns: list[dict]) -> str:
    cols = []
    for i, col in enumerate(columns):
        tone = col.get("tone", "neutral")
        mark = {"positive": "check", "negative": "x"}.get(tone, "")
        items = "".join(f'<li>{svg_icon(mark, "mk") if mark else "<i class=mkdot></i>"}<span>{esc(x)}</span></li>'
                        for x in col.get("items", []))
        icon = find_icon(col.get("icon", ""), col.get("heading", ""))
        head = f'<div class="chead">{svg_icon(icon) if icon else ""}<span>{esc(col.get("heading", ""))}</span></div>'
        cols.append(_el(i, head + f"<ul>{items}</ul>", f"col tone-{tone}"))
    vs = '<div class="vs">vs</div>' if len(columns) == 2 else ""
    return f'<div class="compare n{len(columns)}">{vs.join(cols) if vs else "".join(cols)}</div>'


def layout_table(header: list[str], rows: list[list[str]]) -> str:
    head = "".join(f"<th>{esc(h)}</th>" for h in header)
    body = "".join(f'<tr class="el" data-i="{i}">' + "".join(f"<td>{esc(c)}</td>" for c in r) + "</tr>"
                   for i, r in enumerate(rows))
    return f'<div class="tablewrap"><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>'


def layout_stats(els: list[dict]) -> str:
    cards = []
    for i, e in enumerate(els):
        value = e["value"] or e["title"]
        m = re.match(r"^([^\d-]*)(-?\d+(?:[.,]\d+)?)(.*)$", value)
        num = (f'<span class="pre">{esc(m.group(1))}</span><span class="count" data-to="{m.group(2).replace(",", ".")}" '
               f'data-dec="{len(m.group(2).split(".")[1]) if "." in m.group(2) else 0}">{esc(m.group(2))}</span>'
               f'<span class="post">{esc(m.group(3))}</span>') if m else esc(value)
        label = e["title"] if e["value"] else ""
        cards.append(_el(i, f'<div class="ico">{svg_icon(e["icon"]) if e["icon"] else ""}</div>'
                            f'<div class="big">{num}</div><div class="t">{esc(label)}</div>'
                            f'<div class="d">{esc(e["detail"])}</div>', "stat"))
    return f'<div class="stats n{len(els)}">{"".join(cards)}</div>'


def _num(v: float) -> str:
    return f"{v:,.0f}" if abs(v - round(v)) < 1e-9 else f"{v:,.2f}".rstrip("0").rstrip(".")


def _count(v: float, unit: str = "", svg: bool = False) -> str:
    """A number that counts up as its element appears (tspan inside SVG text, span in HTML)."""
    dec = 0 if abs(v - round(v)) < 1e-9 else 2 if abs(v * 10 - round(v * 10)) > 1e-9 else 1
    tag = "tspan" if svg else "span"
    u = f'<{tag} class="u"> {esc(unit)}</{tag}>' if unit else ""
    return f'<{tag} class="count" data-to="{v}" data-dec="{dec}">{_num(v)}</{tag}>{u}'


def nice_scale(lo: float, hi: float, ticks: int = 5) -> tuple[float, float, float]:
    """Axis from a round number to a round number with round steps (0, 10, 20 ... not 8.5, 17)."""
    span = (hi - lo) or abs(hi) or 1
    raw = span / (ticks - 1)
    mag = 10 ** math.floor(math.log10(raw))
    step = next(m * mag for m in (1, 2, 2.5, 5, 10) if m * mag >= raw)
    return math.floor(lo / step) * step, math.ceil(hi / step) * step, step


def layout_chart(c: dict) -> str:
    """Real data as an SVG chart: bars grow, the line draws itself, slices sweep in - each
    element (bar, point, slice) appears when the voice gets to it; the highlighted one is in
    the second colour. Values are always written on the chart."""
    labels, values, unit, kind = c["labels"], c["values"], c.get("unit", ""), c.get("kind", "bar")
    hl = c.get("highlight", 0) - 1
    n = len(values)
    W, H, left, bottom, top = 1060, 400, 70, 60, 30
    out = []
    vmin, vmax, tick = nice_scale(min(min(values), 0), max(max(values), 0))
    span = vmax - vmin or 1
    y = lambda v: top + (H - top - bottom) * (1 - (v - vmin) / span)   # noqa: E731
    if kind in ("pie", "donut"):
        total = sum(v for v in values if v > 0) or 1
        cx, cy, r = 300, 200, 165
        start = -math.pi / 2
        cols = ["var(--accent)", "var(--accent2)", "#ef8354", "#7c6fd6", "#5aa9e6", "#3fb68b", "#94a3b8", "#0f1b2d"]
        legend = []
        for i, v in enumerate(values):
            frac = max(v, 0) / total
            mid = start + frac * math.pi
            rr = r * (0.72 if kind == "donut" else 0.5)
            circ = 2 * math.pi * rr
            out.append(f'<circle class="draw slice" data-i="{i}" data-len="{circ * frac:.1f}" data-gap="{circ:.1f}" cx="{cx}" cy="{cy}" r="{rr:.1f}" '
                       f'fill="none" stroke="{cols[i % len(cols)]}" stroke-width="{r * (0.56 if kind == "donut" else 1.0):.0f}" '
                       f'transform="rotate({math.degrees(start):.2f} {cx} {cy})" style="--seg:{circ * frac:.1f}"/>')
            if frac > 0.06:
                lx, ly = cx + r * 0.78 * math.cos(mid), cy + r * 0.78 * math.sin(mid)
                out.append(f'<text class="el seg-lbl" data-i="{i}" x="{lx:.0f}" y="{ly + 6:.0f}" text-anchor="middle">{frac * 100:.0f}%</text>')
            legend.append(_el(i, f'<i style="background:{cols[i % len(cols)]}"></i><span class="lt">{esc(labels[i])}</span>'
                                 f'<span class="lv">{_count(values[i], unit)}</span>', "leg" + (" hl" if i == hl else "")))
            start += frac * 2 * math.pi
        svg = f'<svg class="pie" viewBox="0 0 600 400">{"".join(out)}</svg>'
        return f'<div class="chartwrap pie-wrap">{svg}<div class="legend">{"".join(legend)}</div></div>'
    ticks = [vmin + tick * k for k in range(int(round(span / tick)) + 1)]
    grid = "".join(f'<line class="gl" x1="{left}" x2="{W}" y1="{y(v):.0f}" y2="{y(v):.0f}"/>'
                   f'<text class="axis" x="{left - 12}" y="{y(v) + 5:.0f}" text-anchor="end">{_num(v)}</text>' for v in ticks)
    step = (W - left) / n
    xl = "".join(f'<text class="cat{" hl" if i == hl else ""}" x="{left + step * (i + .5):.0f}" y="{H - bottom + 30}" '
                 f'text-anchor="middle">{esc(lab)}</text>' for i, lab in enumerate(labels))
    if kind == "line":
        pts = [(left + step * (i + .5), y(v)) for i, v in enumerate(values)]
        segs = "".join(f'<line class="draw ln" data-i="{i}" data-len="{math.dist(pts[i - 1], pts[i]):.0f}" x1="{pts[i - 1][0]:.0f}" '
                       f'y1="{pts[i - 1][1]:.0f}" x2="{pts[i][0]:.0f}" y2="{pts[i][1]:.0f}"/>' for i in range(1, n))
        dots = "".join(f'<g class="el pt{" hl" if i == hl else ""}" data-i="{i}"><circle cx="{px:.0f}" cy="{py:.0f}" r="9"/>'
                       f'<text class="val" x="{px:.0f}" y="{py - 20:.0f}" text-anchor="middle">{_count(values[i], unit, True)}</text></g>'
                       for i, (px, py) in enumerate(pts))
        body = segs + dots
    else:
        bw = step * 0.56
        body = "".join(f'<g class="el bar{" hl" if i == hl else ""}" data-i="{i}"><rect x="{left + step * (i + .5) - bw / 2:.0f}" '
                       f'y="{min(y(v), y(0)):.0f}" width="{bw:.0f}" height="{abs(y(0) - y(v)):.0f}" rx="8"/>'
                       f'<text class="val" x="{left + step * (i + .5):.0f}" y="{min(y(v), y(0)) - 12:.0f}" text-anchor="middle">'
                       f'{_count(v, unit, True)}</text></g>' for i, v in enumerate(values))
    svg = f'<svg class="bars" viewBox="0 0 {W} {H}">{grid}{body}{xl}</svg>'
    note = f'<div class="takeaway">{svg_icon("trending-up", "mk")}<span>{esc(c["takeaway"])}</span></div>' if c.get("takeaway") else ""
    return f'<div class="chartwrap">{svg}{note}</div>'


def layout_formula(latex: str, els: list[dict]) -> str:
    """A formula typeset like in a textbook (KaTeX), and what each symbol means."""
    legend = "".join(_el(i, f'<div class="sym tex-inline" data-tex="{html.escape(e["title"])}">{esc(e["title"])}</div>'
                            f'<div class="means">{esc(e["detail"])}</div>', "symrow") for i, e in enumerate(els))
    return (f'<div class="formula"><div class="formcard"><div class="tex" data-tex="{html.escape(latex)}">{esc(latex)}</div></div>'
            f'<div class="symbols">{legend}</div></div>')


def layout_calculation(els: list[dict]) -> str:
    """A worked calculation, one step per row: what is calculated, the arithmetic, the result
    (counting up). The last step is the answer, shown large."""
    rows = []
    for i, e in enumerate(els):
        expr = re.sub(r"\d+(?:\.\d+)?", lambda m: _num(float(m.group(0))), e.get("expression", ""))
        expr = esc(expr).replace("*", "×").replace("/", "÷").replace("-", "−")
        last = i == len(els) - 1
        rows.append(_el(i, f'<div class="badge">{i + 1}</div><div class="what">{esc(e["title"])}'
                           f'{"<div class=d>" + esc(e["detail"]) + "</div>" if e["detail"] else ""}</div>'
                           f'<div class="expr">{expr}</div><div class="eq">=</div><div class="res">{esc(e["value"])}</div>',
                        "calc" + (" final" if last else "")))
    return f'<div class="calcs">{"".join(rows)}</div>'


def layout_concept(term: str, els: list[dict], icon: str) -> str:
    definition = els[0] if els else {"title": "", "detail": ""}
    example = els[1] if len(els) > 1 else None
    left = (f'<div class="term"><div class="kicker">Key term</div>{_tile(icon, None, "tile xl")}'
            f'<div class="word">{esc(term)}</div></div>')
    right = _el(0, f'<div class="lbl">What it means</div><div class="def">{esc(definition["title"])} '
                   f'{esc(definition["detail"])}</div>', "defcard")
    if example:
        right += _el(1, f'<div class="lbl">{svg_icon("lightbulb", "mk")} Example</div>'
                        f'<div class="ex">{esc(example["title"])} {esc(example["detail"])}</div>', "excard")
    return f'<div class="concept">{left}<div class="defs">{right}</div></div>'


def layout_example(els: list[dict]) -> str:
    labels = ["Situation", "What to do", "Result", "Next"]
    icons = ["map-pin", "hand", "circle-check-big", "arrow-right"]   # the same symbols in every example
    panels = []
    for i, e in enumerate(els):
        label, text = e["title"], e["detail"]
        if not text:   # "Situation: ..." already split by elements(); else a plain line
            label, text = labels[i] if i < len(labels) else f"Step {i + 1}", e["title"]
        icon = icons[min(i, len(icons) - 1)]
        panels.append(_el(i, f'<div class="phead">{svg_icon(icon)}<span>{esc(label)}</span></div>'
                             f'<div class="ptext">{esc(text)}</div>', "panel"))
    arrows = '<div class="parrow">' + svg_icon("chevron-right") + "</div>"
    return f'<div class="example n{len(els)}">{arrows.join(panels)}</div>'


def layout_callout(els: list[dict], kind_icon: str, label: str) -> str:
    main = els[0] if els else {"title": "", "detail": ""}
    rest = els[1:]
    side = "".join(_el(i + 1, f'{svg_icon(e["icon"] or "chevron-right", "mk")}<span>{esc(e["title"])} '
                              f'{esc(e["detail"])}</span>', "aside") for i, e in enumerate(rest))
    return ('<div class="callout">' + _el(0, f'<div class="qtop"><div class="qicon">{svg_icon(kind_icon)}</div>'
                                              f'<span class="qlabel">{esc(label)}</span></div>'
                                              f'<div class="statement">{esc(main["title"])}</div>'
                                              f'<div class="support">{esc(main["detail"])}</div>', "quote")
            + (f'<div class="asides">{side}</div>' if side else "") + "</div>")


def layout_question(question: str, options: list[str], correct: int) -> str:
    opts = []
    for n, o in enumerate(options, 1):
        state = "" if not correct else " right" if n == correct else " wrong"
        mark = svg_icon("check", "mk") if correct == n else ""
        opts.append(f'<div class="opt{state}"><div class="letter">{chr(64 + n)}</div><div class="otext">{esc(o)}</div>'
                    f"{mark}</div>")
    return f'<div class="quiz">{"".join(opts)}</div>'


def layout_title(scene: dict, goal: str, illustration: str = "") -> str:
    label = scene.get("label") or "VIDEO LESSON"
    objectives = scene.get("items", [])
    m = re.match(r"CHAPTER (\d+)", label)
    big = f'<div class="bignum">{int(m.group(1)):02d}</div>' if m else ""
    obj = "".join(f'<li class="el" data-i="{i}">{svg_icon("circle-check", "mk")}<span>{esc(o)}</span></li>'
                  for i, o in enumerate(objectives))
    sub = scene.get("subtitle", goal) if not objectives else ""
    icon = find_icon(scene.get("icon", ""), scene.get("heading", ""))
    art = (f'<div class="art"><div class="orb o1"></div><div class="orb o2"></div><div class="orb o3"></div>'
           f'<div class="emblem">{svg_icon(icon or "graduation-cap", "ic huge")}</div></div>')
    if illustration:
        art = f'<div class="art ill">{illustration}</div>'
    return (f'<div class="titlewrap">{big}<div class="tleft"><div class="kicker">{esc(label)}</div>'
            f'<h1 class="ttl">{esc(scene.get("heading", ""))}</h1><div class="bar"></div>'
            + (f'<p class="tsub">{esc(sub)}</p>' if sub else "")
            + (f'<div class="objhead">You will be able to</div><ul class="obj">{obj}</ul>' if obj else "")
            + f"</div>{art}</div>")


# --- The page ------------------------------------------------------------------------------------
def illustration_html(scene: dict) -> str:
    """The scene's illustration: an AI picture when one was generated (images.py), else a drawing
    (illustrations.py); '' when the scene has none."""
    ill = scene.get("illustration")
    if not ill:
        return ""
    image = ill.get("image")
    if image and Path(image).exists():
        return f'<img class="ill-img" src="{Path(image).resolve().as_uri()}">'
    import illustrations
    return illustrations.scene_svg(ill.get("scene", ""), seed=scene.get("heading", ""), chart_kind=ill.get("chart", "mixed"),
                                   icons=ill.get("icons", []))


SPLIT = {"cards", "bullets", "callout", "steps", "concept"}   # layouts that can share the slide with a picture


def scene_html(scene: dict, *, lesson_title: str, goal: str, page: str, slide_image: Path | None = None,
               caption: str = "", style: str = "clean", characters: str | None = None) -> tuple[str, int]:
    """The HTML of one scene and the number of its animated elements.
    style: clean (designer slides), illustrated (+ illustrations of people, offices, screens),
    presenter (a character stands next to the slide and points at what the voice talks about)."""
    kind = scene.get("visual", "bullets")
    els = elements(scene)
    head = True
    n = len(els)
    ill = illustration_html(scene) if style in ("illustrated", "presenter", "dialogue") else ""
    split = bool(ill) and style == "illustrated" and kind in SPLIT and n <= (3 if kind in ("steps", "stats") else 4)
    if kind == "title":
        body, head, n = layout_title(scene, goal, ill if style == "illustrated" else ""), False, len(scene.get("items", []))
    elif kind == "slide" and slide_image and slide_image.exists():
        body, n = (f'<figure class="orig"><img src="{slide_image.resolve().as_uri()}"><figcaption>{esc(caption)}'
                   f"</figcaption></figure>"), 0
    elif kind == "steps" and n >= 2:
        body = layout_steps(els)
    elif kind == "cycle" and n >= 3:
        body = layout_cycle(els)
    elif kind == "timeline" and n >= 2:
        body = layout_timeline(els)
    elif kind == "hub" and n >= 2:
        center = scene.get("center") or scene.get("heading", "")
        body = layout_hub(els, center, find_icon(scene.get("center_icon", ""), center))
    elif kind == "comparison" and len(scene.get("columns", [])) >= 2:
        body, n = layout_comparison(scene["columns"]), len(scene["columns"])
    elif kind == "table" and scene.get("table_header") and scene.get("table_rows"):
        body, n = layout_table(scene["table_header"], scene["table_rows"]), len(scene["table_rows"])
    elif kind == "stats" and n >= 1:
        body = layout_stats(els)
    elif kind == "chart" and scene.get("chart"):
        body, n = layout_chart(scene["chart"]), len(scene["chart"]["labels"])
    elif kind == "formula" and scene.get("formula"):
        body = layout_formula(scene["formula"], els)
    elif kind == "calculation" and n >= 1:
        body = layout_calculation(els)
    elif kind == "concept" and n >= 1:
        body, n = layout_concept(scene.get("heading", ""), els, find_icon(scene.get("icon", ""), scene.get("heading", ""))), min(n, 2)
        head = False
    elif kind == "example" and n >= 1:
        body = layout_example(els)
    elif kind == "callout" and n >= 1:
        tone = scene.get("tone", "insight")
        body = layout_callout(els, {"tip": "lightbulb", "warning": "triangle-alert"}.get(tone, "sparkles"),
                              {"tip": "Tip", "warning": "Watch out"}.get(tone, "Key insight"))
        head = bool(scene.get("heading"))
    elif kind in ("question", "answer") and len(scene.get("items", [])) >= 2:
        body = layout_question(scene.get("heading", ""), scene["items"], scene.get("correct", 0) if kind == "answer" else 0)
        n = 0
    elif kind == "cards" or (kind == "bullets" and n and any(e["detail"] for e in els)):
        body = layout_cards(els, 1 if split and n <= 3 else 2 if split else 3)
    elif n:
        body = layout_bullets(els)
    else:   # a heading alone: a statement slide
        body, head = f'<div class="statement-only"><h1>{esc(scene.get("heading", ""))}</h1></div>', False
        n = 0
    eyebrow = {"question": "Check yourself", "answer": "Answer", "example": "Example"}.get(kind, "")
    section = scene.get("section", "")
    footer_left = section if section and section not in ("Introduction", "Summary", "Quiz") else lesson_title
    try:
        done, total = (int(x) for x in page.split("/"))
        progress = 100 * done / max(total, 1)
    except ValueError:
        progress = 0
    header = ""
    if head:
        lead = scene.get("subheading", "")
        header = ('<header class="hd">' + (f'<div class="eyebrow">{esc(eyebrow)}</div>' if eyebrow else "")
                  + f'<h2 class="heading">{esc(scene.get("heading", ""))}</h2>'
                  + (f'<p class="lead">{esc(lead)}</p>' if lead else "") + "</header>")
    footer = "" if kind == "title" else (
        f'<footer><span class="sec">{esc(footer_left)}</span><span class="pg">{esc(page)}</span>'
        f'<div class="prog"><i style="width:{progress:.1f}%"></i></div></footer>')
    if split:
        body = f'<div class="split"><div class="sl">{body}</div><div class="sr">{ill}</div></div>'
    deco = decoration(page + scene.get("heading", "")) if style == "illustrated" else ""
    import brand
    logo = brand.logo_html()   # the company logo in the corner (large on the title slide)
    slide = (f'<div class="slide k-{kind} st-{style}{" has-split" if split else ""}{" has-logo" if logo else ""}">'
             f'<div class="bg"><i class="b1"></i><i class="b2"></i>{deco}</div>{header}<main>{body}</main>{footer}{logo}</div>')
    toons = (characters or config.CHARACTERS) == "cartoon"
    if style == "presenter":
        slide = (toon_presenter_stage(slide) if toons and not lottie_presenter()   # an added Lottie presenter wins
                 else presenter_stage(slide, page + scene.get("heading", "")))
    elif style == "dialogue":
        slide = dialogue_stage(slide, toons)
    katex = katex_head() if 'data-tex="' in slide else ""
    lot = lottie_head() if 'class="lot ' in slide else ""
    page_html = (f"<!doctype html><html><head><meta charset='utf-8'><style>{css(config.VIDEO_LOOK)}</style>{katex}{gsap_head()}{lot}</head>"
                 f'<body>{slide}<script>{RUNTIME}{cartoon.RUNTIME}</script></body></html>')
    return page_html, n


@lru_cache(maxsize=1)
def gsap_head() -> str:
    """GSAP and its plugins (bundled in assets/gsap), or '' when they are not there (then the
    simpler built-in motion is used)."""
    g = ASSETS / "gsap"
    files = ["gsap.min.js", "SplitText.min.js", "DrawSVGPlugin.min.js", "CustomEase.min.js"]
    if not config.GSAP or not all((g / f).exists() for f in files):
        return ""
    js = "\n".join((g / f).read_text(encoding="utf-8") for f in files)
    return f"<script>{js}\ngsap.registerPlugin(SplitText,DrawSVGPlugin,CustomEase);</script>"


LOTTIE_DIR = ASSETS / "lottie"


def lottie_presenter() -> dict:
    """The presenter animations added with tools/add_lottie.py: {'talk': path, 'point': path or
    None, 'faces': 'left'|'right'} or {} when there are none."""
    meta = json.loads((LOTTIE_DIR / "manifest.json").read_text(encoding="utf-8")) if (LOTTIE_DIR / "manifest.json").exists() else {}
    talk = meta.get("presenter_talk")
    if not talk or not (LOTTIE_DIR / talk["file"]).exists():
        return {}
    point = meta.get("presenter_point")
    return {"talk": LOTTIE_DIR / talk["file"], "faces": talk.get("faces", "right"),
            "point": LOTTIE_DIR / point["file"] if point and (LOTTIE_DIR / point["file"]).exists() else None,
            "point_faces": (point or {}).get("faces", "right")}


@lru_cache(maxsize=1)
def lottie_head() -> str:
    """The Lottie player (lottie-web, MIT), the presenter animations, and the code that shows the
    exact frame for any moment (goToAndStop), so the character moves as smoothly as its animator made it."""
    lp = lottie_presenter()
    data = {k: json.loads(Path(lp[k]).read_text(encoding="utf-8")) for k in ("talk", "point") if lp.get(k)}
    return (f"<script>{(LOTTIE_DIR / 'lottie_svg.min.js').read_text(encoding='utf-8')}</script>"
            f"<script>window.LOTTIE={json.dumps(data, separators=(',', ':'))};</script>"
            "<script>document.addEventListener('DOMContentLoaded',()=>{window.LOTS={};"
            "document.querySelectorAll('.lot').forEach(d=>{const k=d.dataset.k; if(!window.LOTTIE[k]) return;"
            "window.LOTS[k]=lottie.loadAnimation({container:d,renderer:'svg',loop:true,autoplay:false,animationData:window.LOTTIE[k],"
            "rendererSettings:{preserveAspectRatio:'xMidYMax meet'}});});"
            "window.lottieFrame=function(t){for(const k in window.LOTS){const a=window.LOTS[k];"
            "a.goToAndStop((t*a.frameRate)%Math.max(1,a.totalFrames-1),true);}};});</script>")


@lru_cache(maxsize=1)
def katex_head() -> str:
    """KaTeX (MIT, bundled in assets/katex) to typeset formulas, run as the page loads."""
    k = ASSETS / "katex"
    css_text = (k / "katex.min.css").read_text(encoding="utf-8").replace("url(fonts/", f"url({(k / 'fonts').resolve().as_uri()}/")
    return (f"<style>{css_text}</style><script>{(k / 'katex.min.js').read_text(encoding='utf-8')}</script>"
            "<script>document.addEventListener('DOMContentLoaded',()=>{document.querySelectorAll('[data-tex]').forEach(e=>{"
            "try{katex.render(e.dataset.tex,e,{throwOnError:false,displayMode:!e.classList.contains('tex-inline')})}catch(x){}})});</script>")


def decoration(seed: str) -> str:
    """Organic shapes, dots and a contour in the corners (illustrated style)."""
    import illustrations as il
    p = il.palette()
    r = il.rng_for(seed)
    return (f'<svg class="deco" viewBox="0 0 1280 720" preserveAspectRatio="none">'
            f'{il.blob(1250, 40, 120, p["soft2"], r, .9)}{il.blob(30, 700, 110, p["soft"], r, .9)}'
            f'{il.dots(1150, 600, 6, 4, p["mid"], 18)}'
            + "".join(f'<circle cx="1220" cy="690" r="{40 + 16 * k}" fill="none" stroke="{p["mid"]}" stroke-width="1.5" opacity=".5"/>'
                      for k in range(4)) + "</svg>")


def presenter_stage(slide: str, seed: str) -> str:
    """The slide on a big screen in a bright room, with a presenter next to it. The presenter's
    pointer arm is moved by the runtime towards the element the voice talks about."""
    import illustrations as il
    p = il.palette()
    lp = lottie_presenter()
    if lp:   # a character animated by a professional animator (Lottie), facing the screen
        flip = lambda faces: ' style="transform:scaleX(-1)"' if faces == "right" else ""   # noqa: E731
        layers = f'<div class="lot lot-talk" data-k="talk"{flip(lp["faces"])}></div>'
        if lp.get("point"):
            layers += f'<div class="lot lot-point" data-k="point"{flip(lp["point_faces"])}></div>'
        room = f'<svg class="room" viewBox="0 0 1280 720">{il.plant(1235, 700, 1.1, p)}</svg>'
        return (f'<div class="stage"><div class="wall"></div><div class="floor"></div>'
                f'<div class="screenframe"><div class="screenin">{slide}</div></div>{room}'
                f'<div class="lot-host">{layers}</div></div>')
    host = il.cast(il.rng_for("presenter"), p, 1)[0]   # the same presenter in every scene of a video
    person = il.presenter_figure(host, 1095, 700, 520)
    room = f'<svg class="room" viewBox="0 0 1280 720">{il.plant(1235, 700, 1.1, p)}{person}</svg>'
    return (f'<div class="stage"><div class="wall"></div><div class="floor"></div>'
            f'<div class="screenframe"><div class="screenin">{slide}</div></div>{room}</div>')


DUO_SCALE = 0.59375   # the slide on the smaller screen between the two people (760 / 1280)


def toon_room(p: dict, shelf: bool = True) -> str:
    """A friendly cartoon room behind the screen: a window, a shelf (where there is room), a plant."""
    import illustrations as il
    window = ('<rect x="1060" y="70" width="170" height="150" rx="10" fill="#dbeafe" stroke="#ffffff" stroke-width="10"/>'
              '<path d="M1145,70 V220 M1060,145 H1230" stroke="#ffffff" stroke-width="6"/>'
              '<circle cx="1100" cy="110" r="16" fill="#fde68a"/>')
    if not shelf:
        return f'<svg class="room back" viewBox="0 0 1280 720">{window}</svg>'
    return ('<svg class="room back" viewBox="0 0 1280 720">' + window
            + '<rect x="40" y="120" width="170" height="12" rx="4" fill="#cbb08a"/>'
            '<rect x="56" y="78" width="22" height="42" rx="3" fill="' + p["a"] + '"/>'
            '<rect x="82" y="88" width="18" height="32" rx="3" fill="' + p["b"] + '"/>'
            '<rect x="104" y="72" width="20" height="48" rx="3" fill="' + p["coral"] + '"/>'
            f'{il.plant(185, 120, 0.45, p)}</svg>')


def toon_presenter_stage(slide: str) -> str:
    """Presenter style with a cartoon presenter (a bear) next to the screen."""
    import illustrations as il
    p = il.palette()
    kind = str(getattr(config, "CARTOON_PRESENTER", "bear"))
    if kind.startswith("company:"):   # the company's own avatar (company_avatar.py), right of the screen
        import company_avatar
        bear = company_avatar.svg(kind.split(":", 1)[1], 1128, 724, 440, 296)
    else:
        bear = cartoon.character(cartoon.presenter_kind(), 1105, 702, 470, cls="toon-presenter", jacket=p["a"],
                                 jacket2=p["deep"], facing="left")
        bear = bear.replace('class="toon toon-presenter"', 'class="toon toon-presenter" data-who="presenter"')
    room = f'<svg class="room" viewBox="0 0 1280 720">{il.plant(1240, 700, 1.0, p)}{bear}</svg>'
    return (f'<div class="stage toonroom"><div class="wall"></div><div class="floor"></div>{toon_room(p, shelf=False)}'
            f'<div class="screenframe"><div class="screenin">{slide}</div></div>{room}</div>')


def dialogue_stage(slide: str, toons: bool = False) -> str:
    """The slide on a screen in the middle, the expert on the left and the host on the right,
    both turned towards the screen (and each other). The same two in every scene; the runtime
    moves the one who is talking (cartoon characters: also their mouth, in time with the voice)."""
    import illustrations as il
    p = il.palette()
    if toons:
        bear = cartoon.character("bear", 128, 702, 440, cls="duo-expert", jacket=p["a"], jacket2=p["deep"])
        fox = cartoon.character("fox", 1152, 702, 420, cls="duo-host", jacket=p["violet"],
                                jacket2="#4c3f8f", facing="left")
        people = (bear.replace('class="toon duo-expert"', 'class="toon duo-expert" data-who="expert"')
                  + fox.replace('class="toon duo-host"', 'class="toon duo-host" data-who="host"'))
        room = f'<svg class="room" viewBox="0 0 1280 720">{people}</svg>'
        return (f'<div class="stage duo toonroom"><div class="wall"></div><div class="floor"></div>{toon_room(p)}'
                f'<div class="screenframe"><div class="screenin">{slide}</div></div>{room}'
                f'<div class="tag tag-expert">Expert</div><div class="tag tag-host">Host</div>'
                f'<script>window.SCREEN_SCALE={DUO_SCALE};</script></div>')
    import dataclasses
    expert, host = il.cast(il.rng_for("dialogue"), p, 2)
    # big characters: heads with a clear outline at this size (light fabrics read as stray lines)
    expert = dataclasses.replace(expert, head="ShortBeard")
    host = dataclasses.replace(host, head="Pony")
    people = (il.presenter_figure(expert, 128, 700, 470, cls="duo-expert", facing="right")
              + il.presenter_figure(host, 1152, 700, 470, cls="duo-host", facing="left"))
    room = f'<svg class="room" viewBox="0 0 1280 720">{il.plant(1262, 700, 0.8, p)}{people}</svg>'
    return (f'<div class="stage duo"><div class="wall"></div><div class="floor"></div>'
            f'<div class="screenframe"><div class="screenin">{slide}</div></div>{room}'
            f'<div class="tag tag-expert">Expert</div><div class="tag tag-host">Host</div>'
            f'<script>window.SCREEN_SCALE={DUO_SCALE};</script></div>')


@lru_cache(maxsize=4)
def css(look: str = "main") -> str:
    fonts = ASSETS / "fonts"
    faces = "".join(f"@font-face{{font-family:'Inter';font-weight:{w};src:url('{(fonts / f).resolve().as_uri()}')}}"
                    for w, f in ((400, "Inter-Regular.otf"), (500, "Inter-Medium.otf"), (600, "Inter-SemiBold.otf"),
                                 (700, "Inter-Bold.otf")) if (fonts / f).exists())
    accent, accent2 = config.THEME_ACCENT, config.THEME_ACCENT_2
    base = faces + STYLE.replace("#0b6e79", accent).replace("#f2a541", accent2)
    import brand  # the company's font, colours and logo (data/brand): colours on the main look, the logo on both
    return base + (SECOND if look == "second" else "") + brand.css(colours=look != "second")


# VIDEO_LOOK=second: "Midnight": deep navy, violet and mint, glowing glass cards, a fine grid, the title in a
# gradient (the same slides and timing as the light look)
SECOND = """
:root{--ink:#eef0ff;--muted:#aab2d0;--faint:#6f7896;--line:rgba(255,255,255,.13);--bg:#0d1030;--card:rgba(255,255,255,.065);
--accent:#8b7bff;--accent2:#34d6b4;--soft:rgba(139,123,255,.2);--soft2:rgba(52,214,180,.18);
--shadow:0 1px 0 rgba(255,255,255,.06) inset,0 14px 34px rgba(0,0,0,.35);
--shadow-hi:0 0 0 1px rgba(139,123,255,.55),0 18px 46px rgba(139,123,255,.38)}
.slide{background:radial-gradient(900px 520px at 88% 6%,rgba(139,123,255,.30),transparent 62%),
 radial-gradient(760px 520px at 0% 100%,rgba(52,214,180,.20),transparent 60%),
 linear-gradient(rgba(255,255,255,.035) 1px,transparent 1px) 0 0/40px 40px,
 linear-gradient(90deg,rgba(255,255,255,.035) 1px,transparent 1px) 0 0/40px 40px,#0d1030}
.slide:before{height:4px;background:linear-gradient(90deg,#8b7bff,#34d6b4,#8b7bff)}
.heading{color:#fff;text-shadow:0 2px 24px rgba(139,123,255,.35)}
.tone-positive .chead{background:rgba(52,214,180,.14);color:#5eead4}
.tone-negative .chead{background:rgba(248,113,113,.13);color:#fca5a5}
.vs{background:#8b7bff;color:#fff}
.opt.right{background:rgba(52,214,180,.12)}
.ill-img{background:rgba(255,255,255,.06)}
.eyebrow{color:#34d6b4}
.card,.row,.step .body{background:linear-gradient(160deg,rgba(255,255,255,.09),rgba(255,255,255,.03));border:1px solid rgba(255,255,255,.12)}
.node,.dot{background:#141844;color:#c9c1ff;border-color:#8b7bff}
.tile{background:rgba(139,123,255,.18);color:#c9c1ff}
footer .sec{color:#34d6b4}
.prog{background:rgba(255,255,255,.08)}
"""


STYLE = """
:root{--ink:#0f1b2d;--muted:#5b6b7f;--faint:#94a3b8;--line:#e2e8f0;--bg:#f6f8fb;--card:#fff;
--accent:#0b6e79;--accent2:#f2a541;--soft:color-mix(in srgb,var(--accent) 11%,white);
--soft2:color-mix(in srgb,var(--accent2) 18%,white);--good:#16a34a;--bad:#dc2626;
--shadow:0 1px 2px rgba(15,27,45,.06),0 8px 24px rgba(15,27,45,.07);
--shadow-hi:0 2px 4px rgba(15,27,45,.08),0 18px 40px color-mix(in srgb,var(--accent) 28%,transparent)}
*{box-sizing:border-box;margin:0;padding:0}
html,body{width:1280px;height:720px;overflow:hidden;background:var(--bg)}
body{font-family:'Inter','Segoe UI',system-ui,sans-serif;color:var(--ink);-webkit-font-smoothing:antialiased}
.slide{position:relative;width:1280px;height:720px;overflow:hidden;
 background:radial-gradient(1200px 600px at 100% 0%,color-mix(in srgb,var(--accent) 7%,transparent),transparent 60%),var(--bg)}
.bg i{position:absolute;border-radius:50%;filter:blur(2px);opacity:.55}
.bg .b1{width:420px;height:420px;right:-140px;top:-170px;background:radial-gradient(circle,var(--soft),transparent 70%)}
.bg .b2{width:300px;height:300px;left:-120px;bottom:-140px;background:radial-gradient(circle,var(--soft2),transparent 70%)}
.slide:before{content:"";position:absolute;left:0;top:0;width:100%;height:6px;background:linear-gradient(90deg,var(--accent),color-mix(in srgb,var(--accent) 55%,var(--accent2)))}
.hd{position:absolute;left:72px;right:72px;top:46px}
.eyebrow{font-size:14px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--accent);margin-bottom:8px}
.heading{font-size:40px;line-height:1.12;font-weight:700;letter-spacing:-.02em;max-width:1050px}
.lead{margin-top:10px;font-size:20px;line-height:1.4;color:var(--muted);max-width:980px}
main{position:absolute;left:72px;right:72px;top:178px;bottom:70px;display:flex;align-items:center;justify-content:center}
.k-title main,.k-concept main{top:0;bottom:0}
footer{position:absolute;left:72px;right:72px;bottom:22px;display:flex;justify-content:space-between;font-size:14px;color:var(--muted)}
footer .sec{font-weight:600;color:var(--accent)}
.prog{position:absolute;left:-72px;right:-72px;bottom:-22px;height:5px;background:var(--line)}
.prog i{display:block;height:100%;background:linear-gradient(90deg,var(--accent),var(--accent2))}
b{color:var(--accent);font-weight:700}
.ic{width:28px;height:28px}.ic.big{width:44px;height:44px}.ic.huge{width:120px;height:120px;stroke-width:1.4}
.mk{width:20px;height:20px;flex:none}
.tile{width:56px;height:56px;border-radius:16px;background:var(--soft);color:var(--accent);display:flex;align-items:center;
 justify-content:center;flex:none;transition:none}
.tile.sm{width:46px;height:46px;border-radius:13px}.tile.sm .ic{width:24px;height:24px}
.tile.xl{width:96px;height:96px;border-radius:26px}.tile.xl .ic{width:48px;height:48px}
.tile .num{font-weight:700;font-size:20px}
.t{font-weight:650;font-size:24px;line-height:1.25;letter-spacing:-.01em}
.d{margin-top:6px;font-size:18px;line-height:1.45;color:var(--muted)}
.el{will-change:transform,opacity}
.el.on .tile,.el.on .node,.el.on .badge,.el.on .dot{background:var(--accent);color:#fff}
/* cards */
.grid.cards{display:grid;gap:22px;width:100%}
.cards.c2{grid-template-columns:repeat(2,1fr)}.cards.c3{grid-template-columns:repeat(3,1fr)}.cards.c1{grid-template-columns:1fr;max-width:760px}
.card{background:var(--card);border-radius:20px;padding:30px 28px 28px;box-shadow:var(--shadow);border:1px solid var(--line);
 display:flex;flex-direction:column;gap:18px;min-height:200px}
.cards.c2 .card{flex-direction:row;align-items:flex-start;gap:20px}
.el.on.card,.el.on.sat,.el.on.stat,.el.on.col,.el.on.panel,.el.on.legend,.el.on.row,.el.on.vstep,.el.on.defcard,.el.on.excard{
 border-color:color-mix(in srgb,var(--accent) 55%,white);box-shadow:var(--shadow-hi)}
/* rows (bullets) */
.rows{display:flex;flex-direction:column;gap:14px;width:100%;max-width:1000px}
.row{display:flex;align-items:center;gap:20px;padding:18px 24px;border-radius:16px;background:var(--card);border:1px solid var(--line);box-shadow:var(--shadow)}
.row .d{margin-top:2px}
/* steps */
.steps{position:relative;display:flex;gap:26px;width:100%;align-items:flex-start}
.steps .step{flex:1;display:flex;flex-direction:column;align-items:center;text-align:center;gap:18px;position:relative;z-index:1}
.steps .links{position:absolute;left:0;right:0;top:52px;height:4px;display:flex;z-index:0}
.steps .link{flex:1;height:4px;background:linear-gradient(90deg,var(--accent),color-mix(in srgb,var(--accent) 50%,white));transform-origin:left;margin:0 64px;border-radius:2px}
.steps.n2 .links{left:25%;right:25%}.steps.n3 .links{left:16.6%;right:16.6%}.steps.n4 .links{left:12.5%;right:12.5%}.steps.n5 .links{left:10%;right:10%}
.node{position:relative;width:108px;height:108px;border-radius:50%;background:#fff;color:var(--accent);border:3px solid var(--accent);
 display:flex;align-items:center;justify-content:center;font-weight:700;font-size:28px;box-shadow:var(--shadow)}
.node .ic{width:46px;height:46px}
.node .no,.cnode .no{position:absolute;right:-6px;top:-6px;width:30px;height:30px;border-radius:50%;background:var(--accent2);color:#fff;
 font-size:15px;font-weight:700;display:flex;align-items:center;justify-content:center;border:3px solid var(--bg)}
.step .body{background:var(--card);border:1px solid var(--line);border-radius:18px;padding:20px 18px;box-shadow:var(--shadow);width:100%;min-height:150px}
.step .t{font-size:23px}.step .d{font-size:18px}
.el.on.step .body{border-color:color-mix(in srgb,var(--accent) 55%,white);box-shadow:var(--shadow-hi)}
.vsteps{position:relative;display:flex;flex-direction:column;gap:12px;width:100%;max-width:980px}
.spine{position:absolute;left:23px;top:20px;bottom:20px;width:4px;background:var(--soft);transform-origin:top}
.vstep{display:flex;gap:18px;align-items:center;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:10px 18px;box-shadow:var(--shadow);margin-left:0;position:relative}
.vstep:not(:last-child)::after{content:"";position:absolute;left:36px;top:100%;width:4px;height:12px;background:color-mix(in srgb,var(--accent) 45%,transparent);border-radius:2px}
.badge{width:40px;height:40px;border-radius:12px;background:var(--soft);color:var(--accent);font-weight:700;font-size:18px;display:flex;align-items:center;justify-content:center;flex:none}
.vstep .t{font-size:19px}.vstep .d{font-size:15px;margin-top:2px}
/* cycle */
.cycle{display:flex;align-items:center;gap:40px;width:100%}
.wheel{position:relative;width:430px;height:430px;flex:none}
.ring{position:absolute;inset:0;overflow:visible}
.ring .track{fill:none;stroke:var(--line);stroke-width:14}
.ring .arc{fill:none;stroke:var(--accent);stroke-width:6;stroke-linecap:round}
.ring .arrowhead{fill:var(--accent)}
.cnode{position:absolute;width:76px;height:76px;border-radius:50%;background:#fff;border:3px solid var(--accent);color:var(--accent);
 display:flex;align-items:center;justify-content:center;font-weight:700;font-size:24px;box-shadow:var(--shadow)}
.cnode .ic{width:32px;height:32px}
.el.on.cnode{background:var(--accent);color:#fff;box-shadow:var(--shadow-hi)}
.legends{flex:1;display:flex;flex-direction:column;gap:12px}
.legend{display:flex;gap:16px;align-items:flex-start;background:var(--card);border:1px solid var(--line);border-radius:16px;padding:14px 18px;box-shadow:var(--shadow)}
.legend .t{font-size:21px}.legend .d{font-size:16px;margin-top:3px}
/* timeline */
.timeline{position:relative;display:grid;grid-auto-flow:column;grid-auto-columns:1fr;width:100%;gap:18px;padding-top:6px}
.axis{position:absolute;left:0;right:0;top:92px;height:4px}
.axis .segs{display:flex;height:100%}.axis .seg{flex:1;background:var(--accent);transform-origin:left;margin:0 38px;border-radius:2px}
.timeline.n2 .axis{left:calc(25% - 4.5px);right:calc(25% - 4.5px)}.timeline.n3 .axis{left:calc(100%/6 - 6px);right:calc(100%/6 - 6px)}
.timeline.n4 .axis{left:calc(12.5% - 6.75px);right:calc(12.5% - 6.75px)}.timeline.n5 .axis{left:calc(10% - 7.2px);right:calc(10% - 7.2px)}
.timeline.n6 .axis{left:calc(100%/12 - 7.5px);right:calc(100%/12 - 7.5px)}
.mile{display:flex;flex-direction:column;align-items:center;text-align:center;gap:12px;position:relative}
.when{font-size:22px;font-weight:700;color:var(--accent);height:44px;display:flex;align-items:flex-end;letter-spacing:-.01em}
.dot{width:58px;height:58px;border-radius:50%;background:#fff;border:3px solid var(--accent);color:var(--accent);display:flex;align-items:center;
 justify-content:center;box-shadow:var(--shadow);z-index:1}
.dot .ic{width:26px;height:26px}
.mile .body{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:18px 14px;min-height:110px;box-shadow:var(--shadow);width:100%}
.mile .t{font-size:20px}.mile .d{font-size:16px}
.el.on.mile .body{border-color:color-mix(in srgb,var(--accent) 55%,white);box-shadow:var(--shadow-hi)}
/* hub */
.hub{position:relative;width:1120px;height:470px}
.spokes{position:absolute;inset:0;width:1120px;height:470px;overflow:visible}
.spoke{stroke:color-mix(in srgb,var(--accent) 45%,white);stroke-width:3;stroke-dasharray:var(--len);}
.core{position:absolute;left:470px;top:145px;width:180px;height:180px;border-radius:50%;
 background:radial-gradient(circle at 30% 25%,color-mix(in srgb,var(--accent) 75%,white),var(--accent));color:#fff;
 display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;text-align:center;
 box-shadow:0 20px 50px color-mix(in srgb,var(--accent) 35%,transparent),0 0 0 14px color-mix(in srgb,var(--accent) 10%,transparent)}
.core .label{font-weight:700;font-size:22px;line-height:1.15;padding:0 14px}
.sat{position:absolute;width:300px;min-height:100px;display:flex;gap:14px;align-items:center;background:var(--card);border:1px solid var(--line);
 border-radius:18px;padding:14px 16px;box-shadow:var(--shadow)}
.sat .t{font-size:19px}.sat .d{font-size:14.5px;margin-top:3px}
/* comparison */
.compare{display:flex;gap:22px;width:100%;align-items:stretch}
.col{flex:1;background:var(--card);border-radius:20px;border:1px solid var(--line);box-shadow:var(--shadow);overflow:hidden}
.chead{display:flex;align-items:center;gap:12px;padding:22px 28px;font-size:24px;font-weight:700;background:var(--soft);color:var(--accent)}
.tone-positive .chead{background:color-mix(in srgb,var(--good) 12%,white);color:var(--good)}
.tone-negative .chead{background:color-mix(in srgb,var(--bad) 10%,white);color:var(--bad)}
.col ul{list-style:none;padding:24px 28px 28px;display:flex;flex-direction:column;gap:16px}
.col li{display:flex;gap:12px;align-items:flex-start;font-size:21px;line-height:1.4}
.tone-positive .mk{color:var(--good)}.tone-negative .mk{color:var(--bad)}
.mkdot{width:9px;height:9px;border-radius:50%;background:var(--accent);margin-top:9px;flex:none}
.vs{align-self:center;width:54px;height:54px;border-radius:50%;background:var(--ink);color:#fff;font-weight:700;display:flex;
 align-items:center;justify-content:center;font-size:17px;flex:none;box-shadow:var(--shadow)}
/* table */
.tablewrap{width:100%;background:var(--card);border-radius:18px;box-shadow:var(--shadow);border:1px solid var(--line);overflow:hidden}
table{width:100%;border-collapse:collapse;font-size:21px}
th{background:var(--accent);color:#fff;text-align:left;padding:18px 26px;font-weight:650;font-size:17px;letter-spacing:.02em}
td{padding:19px 26px;border-top:1px solid var(--line);line-height:1.35}
td:first-child{font-weight:650}
tr.el.on td{background:var(--soft2)}
tr.el.on td:first-child{box-shadow:inset 5px 0 0 var(--accent2)}
/* stats */
.stats{display:flex;gap:22px;width:100%}
.stat{flex:1;background:var(--card);border-radius:20px;border:1px solid var(--line);box-shadow:var(--shadow);padding:32px 26px;min-height:240px;position:relative;overflow:hidden}
.stat:after{content:"";position:absolute;left:0;top:0;bottom:0;width:6px;background:linear-gradient(var(--accent),var(--accent2))}
.stat .ico{color:var(--accent);height:30px}
.stat .big{font-size:66px;font-weight:700;letter-spacing:-.03em;line-height:1.05;margin:10px 0 6px;color:var(--ink)}
.stat .big .post,.stat .big .pre{font-size:30px;font-weight:650;color:var(--muted);margin:0 4px}
/* concept */
.concept{display:flex;gap:56px;align-items:center;width:100%;padding-top:20px}
.term{flex:0 0 400px;display:flex;flex-direction:column;gap:20px}
.kicker{font-size:14px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--accent)}
.word{font-size:56px;font-weight:700;letter-spacing:-.03em;line-height:1.05}
.defs{flex:1;display:flex;flex-direction:column;gap:20px}
.defcard,.excard{background:var(--card);border:1px solid var(--line);border-radius:20px;padding:24px 28px;box-shadow:var(--shadow)}
.excard{background:var(--soft2);border-color:transparent}
.lbl{display:flex;gap:8px;align-items:center;font-size:13px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);margin-bottom:10px}
.def{font-size:26px;line-height:1.4;font-weight:500}.ex{font-size:20px;line-height:1.45}
/* example */
.example{display:flex;align-items:stretch;gap:10px;width:100%}
.panel{flex:1;background:var(--card);border:1px solid var(--line);border-radius:20px;box-shadow:var(--shadow);padding:28px 26px 30px;min-height:220px}
.phead{display:flex;align-items:center;gap:10px;font-size:14px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--accent);margin-bottom:14px}
.phead .ic{width:24px;height:24px}
.ptext{font-size:23px;line-height:1.45}
.parrow{align-self:center;color:var(--accent)}
/* callout */
.callout{display:flex;gap:28px;width:100%;align-items:stretch}
.quote{flex:1.6;background:linear-gradient(135deg,var(--accent),color-mix(in srgb,var(--accent) 70%,#0f1b2d));color:#fff;border-radius:24px;padding:40px 44px;box-shadow:var(--shadow-hi)}
.qtop{display:flex;align-items:center;gap:14px;margin-bottom:22px}
.qicon{width:58px;height:58px;border-radius:16px;background:rgba(255,255,255,.16);display:flex;align-items:center;justify-content:center}
.qlabel{font-size:14px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;opacity:.85}
.statement{font-size:38px;line-height:1.25;font-weight:700;letter-spacing:-.02em}
.support{margin-top:14px;font-size:20px;line-height:1.45;opacity:.85}
.quote b{color:var(--accent2)}
.asides{flex:1;display:flex;flex-direction:column;gap:14px;justify-content:center}
.aside{display:flex;gap:12px;background:var(--card);border:1px solid var(--line);border-radius:16px;padding:16px 18px;font-size:18px;line-height:1.4;box-shadow:var(--shadow)}
.aside .mk{color:var(--accent);margin-top:2px}
/* quiz */
.quiz{display:flex;flex-direction:column;gap:14px;width:100%;max-width:980px}
.opt{display:flex;align-items:center;gap:20px;background:var(--card);border:2px solid var(--line);border-radius:18px;padding:16px 22px;box-shadow:var(--shadow);font-size:22px}
.letter{width:48px;height:48px;border-radius:14px;background:var(--soft);color:var(--accent);font-weight:700;display:flex;align-items:center;justify-content:center;flex:none}
.otext{flex:1}
.opt.right{border-color:var(--good);background:color-mix(in srgb,var(--good) 9%,white)}
.opt.right .letter{background:var(--good);color:#fff}.opt.right .mk{color:var(--good);width:30px;height:30px}
.opt.wrong{opacity:.45}
/* title */
.titlewrap{position:relative;display:flex;align-items:center;width:100%;height:100%;padding:0 10px}
.tleft{flex:1;position:relative;z-index:1;max-width:700px}
.ttl{font-size:60px;line-height:1.05;font-weight:700;letter-spacing:-.035em;margin-top:14px}
.k-title .bar{width:96px;height:6px;border-radius:3px;background:linear-gradient(90deg,var(--accent),var(--accent2));margin:26px 0 22px}
.tsub{font-size:22px;line-height:1.45;color:var(--muted)}
.objhead{font-size:13px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--muted);margin-bottom:12px}
.obj{list-style:none;display:flex;flex-direction:column;gap:10px}
.obj li{display:flex;gap:12px;align-items:center;font-size:21px}
.obj .mk{color:var(--accent);width:24px;height:24px}
.art{position:relative;width:420px;height:420px;flex:none}
.orb{position:absolute;border-radius:50%}
.o1{inset:0;background:radial-gradient(circle at 35% 30%,color-mix(in srgb,var(--accent) 20%,white),color-mix(in srgb,var(--accent) 6%,white))}
.o2{width:150px;height:150px;right:-10px;top:10px;background:radial-gradient(circle,var(--soft2),transparent 70%)}
.o3{width:90px;height:90px;left:20px;bottom:30px;background:var(--accent2);opacity:.25}
.emblem{position:absolute;inset:90px;border-radius:50%;background:#fff;color:var(--accent);display:flex;align-items:center;justify-content:center;
 box-shadow:0 30px 60px color-mix(in srgb,var(--accent) 25%,transparent)}
.bignum{position:absolute;right:30px;bottom:-40px;font-size:300px;font-weight:700;letter-spacing:-.06em;color:color-mix(in srgb,var(--accent) 7%,transparent);z-index:0}
.slide.compact main{zoom:.9}.slide.compact .heading{font-size:36px}
.slide.compact2 main{zoom:.8}.slide.compact2 .heading{font-size:32px}.slide.compact2 .lead{font-size:18px}
.statement-only{max-width:1000px;text-align:center}.statement-only h1{font-size:54px;line-height:1.15;letter-spacing:-.03em}
.orig{display:flex;flex-direction:column;align-items:center;gap:10px}.orig img{max-width:1100px;max-height:440px;border-radius:12px;box-shadow:var(--shadow)}
.orig figcaption{font-size:14px;color:var(--muted)}
/* data: charts, formulas, calculations */
.chartwrap{width:100%;display:flex;flex-direction:column;align-items:center;gap:6px}
.bars{width:100%;height:auto;max-height:420px;overflow:visible}
.gl{stroke:var(--line);stroke-width:1.5}
.axis{font-size:15px;fill:var(--muted)}
.cat{font-size:18px;font-weight:600;fill:var(--ink)}.cat.hl{fill:var(--accent2)}
.bar rect{fill:color-mix(in srgb,var(--accent) 78%,white)}.bar.hl rect,.bar.on rect{fill:var(--accent)}
.bar.hl rect{fill:var(--accent2)}
.val{font-size:20px;font-weight:700;fill:var(--ink)}.val .u,.lv .u{font-size:.75em;font-weight:600;fill:var(--muted);color:var(--muted);margin-left:3px}
.ln{stroke:var(--accent);stroke-width:5;stroke-linecap:round}
.pt circle{fill:#fff;stroke:var(--accent);stroke-width:4}.pt.hl circle,.pt.on circle{fill:var(--accent2);stroke:var(--accent2)}
.takeaway{display:flex;gap:10px;align-items:center;font-size:19px;font-weight:600;color:var(--accent);background:var(--soft);
 padding:10px 18px;border-radius:999px}
.pie-wrap{flex-direction:row;gap:40px;justify-content:center}.pie{width:560px;height:auto}
.seg-lbl{font-size:20px;font-weight:700;fill:#fff}
.legend{display:flex;flex-direction:column;gap:12px;min-width:340px}
.leg{display:flex;align-items:center;gap:14px;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:12px 18px;box-shadow:var(--shadow);font-size:19px}
.leg i{width:18px;height:18px;border-radius:5px;flex:none}.leg .lt{flex:1}.leg .lv{font-weight:700}
.formula{display:flex;flex-direction:column;align-items:center;gap:26px;width:100%}
.formcard{background:var(--card);border:1px solid var(--line);border-radius:24px;box-shadow:var(--shadow);padding:30px 50px;font-size:34px;min-width:640px;text-align:center}
.symbols{display:grid;grid-template-columns:repeat(2,1fr);gap:12px 20px;width:100%;max-width:1000px}
.symrow{display:flex;align-items:center;gap:18px;background:var(--card);border:1px solid var(--line);border-radius:14px;padding:12px 18px;box-shadow:var(--shadow)}
.sym{font-size:24px;min-width:70px;color:var(--accent);font-weight:700}.means{font-size:18px;color:var(--ink)}
.calcs{display:flex;flex-direction:column;gap:12px;width:100%;max-width:1080px}
.calc{display:grid;grid-template-columns:44px 1fr auto 30px minmax(150px,auto);align-items:center;gap:18px;background:var(--card);
 border:1px solid var(--line);border-radius:16px;padding:14px 22px;box-shadow:var(--shadow)}
.calc .what{font-size:20px;font-weight:650}.calc .what .d{font-size:15px;color:var(--muted);font-weight:400;margin-top:2px}
.calc .expr{font-family:'Inter',monospace;font-size:22px;color:var(--muted);font-variant-numeric:tabular-nums}
.calc .eq{font-size:24px;color:var(--faint);text-align:center}
.calc .res{font-size:26px;font-weight:700;color:var(--ink);text-align:right;font-variant-numeric:tabular-nums}
.calc.final{background:linear-gradient(135deg,var(--accent),color-mix(in srgb,var(--accent) 70%,#0f1b2d));color:#fff;border-color:transparent}
.calc.final .what,.calc.final .res{color:#fff}.calc.final .res{font-size:34px;color:var(--accent2)}.calc.final .expr{color:rgba(255,255,255,.75)}
.calc.final .badge{background:rgba(255,255,255,.18);color:#fff}
/* illustrated style */
.deco{position:absolute;inset:0;width:1280px;height:720px}
.split{display:flex;align-items:center;gap:30px;width:100%;height:100%}
.split .sl{flex:1.25;min-width:0;display:flex;align-items:center}
.split .sr{flex:1;display:flex;align-items:center;justify-content:center;max-height:100%}
.split .sr>svg,.split .sr>img{width:100%;height:auto;max-height:470px}
.ill-img{border-radius:22px;object-fit:contain;background:#fff}
.split .cards.c1 .card{flex-direction:row;align-items:flex-start;gap:18px;min-height:0;padding:20px 22px}
.split .cards .card{min-height:0}
.art.ill{width:520px;height:440px;display:flex;align-items:center}.art.ill>svg,.art.ill>img{width:100%;height:auto}
.illustration svg{overflow:visible}
/* presenter style: the slide on a screen in a bright room, a presenter beside it */
.stage{position:relative;width:1280px;height:720px;overflow:hidden;background:linear-gradient(#eef3f8,#e6edf4)}
.stage .wall{position:absolute;inset:0;background:radial-gradient(700px 400px at 35% 30%,#ffffff,transparent 70%)}
.stage .floor{position:absolute;left:0;right:0;bottom:0;height:70px;background:linear-gradient(#d9e2ec,#cfd9e4)}
.screenframe{position:absolute;left:46px;top:56px;width:908px;height:528px;border-radius:18px;background:#1f2937;padding:10px;
 box-shadow:0 30px 60px rgba(15,27,45,.22)}
.screenin{width:888px;height:508px;overflow:hidden;border-radius:10px;position:relative}
.screenin .slide{transform:scale(.69375);transform-origin:0 0}
.room{position:absolute;inset:0;width:1280px;height:720px;overflow:visible}
.lot-host{position:absolute;right:-10px;bottom:20px;width:330px;height:560px}
.lot{position:absolute;inset:0}.lot-point{opacity:0}
/* dialogue style: the screen in the middle, a person on each side */
.duo .screenframe{left:250px;top:62px;width:780px;height:448px}
.duo .screenin{width:760px;height:428px}
.duo .screenin .slide{transform:scale(.59375)}
.duo .wall{background:radial-gradient(640px 380px at 50% 32%,#ffffff,transparent 70%)}
.tag{position:absolute;bottom:14px;padding:5px 14px;border-radius:99px;font:600 15px/1 Inter,sans-serif;letter-spacing:.04em;
 text-transform:uppercase;background:#fff;color:#475569;box-shadow:0 4px 12px rgba(15,27,45,.12);transition:none}
.tag-expert{left:128px;transform:translateX(-50%)}.tag-host{left:1152px;transform:translateX(-50%)}
.tag.talk{background:var(--accent);color:#fff}
/* cartoon room: warmer wall, wooden floor */
.toonroom{background:linear-gradient(#fdf6ec,#f6ead8)}
.toonroom .wall{background:radial-gradient(700px 420px at 50% 30%,#fffaf2,transparent 70%)}
.toonroom .floor{height:74px;background:linear-gradient(#e2c9a4,#d6b88f)}
.room.back{pointer-events:none}
"""

RUNTIME = r"""
const E=(x)=>1-Math.pow(1-Math.min(Math.max(x,0),1),3);            // ease-out cubic
const S=(x)=>{x=Math.min(Math.max(x,0),1);return x*x*(3-2*x)};         // smoothstep
window.TL={appear:[],active:[],dim:0.5,enter:0.6,hi:0.35};
function stateAt(t){
  const T=window.TL, n=T.appear.length, ap=[], hi=[];
  for(let i=0;i<n;i++){ap.push(E((t-T.appear[i])/T.enter));
    const w=T.active[i]; hi.push(w?Math.min(S((t-w[0])/T.hi),1-S((t-w[1])/T.hi)):0);}
  return {ap,hi};
}
// GSAP drives the motion when it is bundled (assets/gsap): one paused timeline per slide, built
// from the timing (window.TL) and moved to any moment with seek(t) - exact and repeatable frames.
function render(t){
  if(window.gsap){ renderGsap(t); } else { renderBasic(t); }
  if(window.lottieFrame) lottieFrame(t);
  duo(t);
  toon(t);
}
// dialogue style: the one who talks nods and moves a little (the expert also gestures to the
// screen when something new appears); the listener stands calmer and nods now and then
function duo(t){
  if(!document.querySelector('.duo')) return;
  const T=window.TL, R=(x)=>S(Math.min(Math.max(x,0),1));
  for(const who of ['expert','host']){
    const g=document.querySelector('.duo-'+who); if(!g) continue;
    let talk=0;
    for(const w of (T.talk||[])) if(w[2]===who){ talk=Math.max(talk, Math.min(R((t-w[0]+0.15)/0.25), 1-R((t-w[1])/0.25))); }
    let point=0;
    if(who==='expert') for(const a of T.appear){ point=Math.max(point, Math.min(R((t-a+0.1)/0.35), 1-R((t-a-2.4)/0.4))*talk); }
    const set=(c,v)=>{const e=g.querySelector(c); if(e) e.style.opacity=v.toFixed(3);};
    set('.p-rest',1-point); set('.p-point',point); set('.p-up',0);
    const ph=who==='host'?1.7:0;
    const nod=talk*(1.2*Math.sin(t*2.3+ph)+0.5*Math.sin(t*3.9+1.3+ph)) + (1-talk)*0.6*Math.max(0,Math.sin(t*0.9+ph))**6*-3;
    const head=g.querySelector('.p-head'), sway=g.querySelector('.p-sway');
    if(head) head.style.transform=`rotate(${nod.toFixed(2)}deg)`;
    const amp=0.6+talk*1.0;
    if(sway) sway.style.transform=`translate(${(amp*Math.sin(t*0.8+ph)).toFixed(2)}px,0) rotate(${(0.3*amp*Math.sin(t*0.6+0.4+ph)).toFixed(2)}deg) scaleY(${(1+0.003*Math.sin(t*1.9+ph)).toFixed(4)})`;
    const tag=document.querySelector('.tag-'+who); if(tag) tag.classList.toggle('talk', talk>0.5);
  }
}
function fmtNum(v,d){return v.toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d});}
function buildTimeline(){
  const T=window.TL, tl=gsap.timeline({paused:true});
  if(window.SplitText) document.querySelectorAll('.hd .heading,.ttl,.statement-only h1,.statement').forEach(h=>{
    const st=new SplitText(h,{type:'words'});
    tl.fromTo(st.words,{y:26,opacity:0},{y:0,opacity:1,duration:.65,ease:'power3.out',stagger:.045},0.05);});
  tl.fromTo('.eyebrow,.lead,.kicker,.k-title .bar,.objhead,.tsub,.qtop,.support',{y:14,opacity:0},
            {y:0,opacity:1,duration:.55,ease:'power2.out',stagger:.07},0.25);
  tl.fromTo('.art,.term,.core,.formcard,.takeaway',{scale:.88,opacity:0},{scale:1,opacity:1,duration:.85,ease:'back.out(1.7)'},0.15);
  tl.fromTo('.illustration .float',{y:18,opacity:0},{y:0,opacity:1,duration:.8,ease:'back.out(2)',stagger:.16},0.55);
  tl.fromTo('.illustration .human:not(.host)',{x:-14,opacity:0},{x:0,opacity:1,duration:.8,ease:'power3.out',stagger:.12},0.3);
  tl.fromTo('.quiz .opt',{y:18,opacity:0},{y:0,opacity:(i,el)=>el.classList.contains('wrong')?0.45:1,duration:.55,ease:'back.out(1.5)',stagger:.12},0.3);
  document.querySelectorAll('.el').forEach(el=>{
    const i=+el.dataset.i, a=T.appear[i]??0.3, w=T.active[i];
    if(el.classList.contains('bar')){ const r=el.querySelector('rect');
      tl.fromTo(r,{scaleY:0,transformOrigin:'50% 100%'},{scaleY:1,duration:.8,ease:'power4.out'},a);
      tl.fromTo(el,{opacity:0},{opacity:1,duration:.25},a); }
    else if(el.classList.contains('pt')) tl.fromTo(el,{scale:0,opacity:0,transformOrigin:'50% 50%'},{scale:1,opacity:1,duration:.5,ease:'back.out(3)'},a);
    else if(el.classList.contains('cnode')) tl.fromTo(el,{scale:.3,opacity:0},{scale:1,opacity:1,duration:.65,ease:'back.out(2.4)'},a);
    else if(el.tagName==='TR'||el.tagName==='text'||el.tagName==='LI') tl.fromTo(el,{y:12,opacity:0},{y:0,opacity:1,duration:.5,ease:'power2.out'},a);
    else { tl.fromTo(el,{y:30,opacity:0},{y:0,opacity:1,duration:.65,ease:'back.out(1.4)'},a);
      if(w){ tl.fromTo(el,{scale:1},{scale:1.035,duration:.4,ease:'power2.out',immediateRender:false},w[0]);
             tl.fromTo(el,{scale:1.035},{scale:1,duration:.4,ease:'power2.inOut',immediateRender:false},w[1]); } }
    el.querySelectorAll('.count').forEach(c=>{const o={v:0}, to=+c.dataset.to, d=+c.dataset.dec; c.textContent=fmtNum(0,d);
      tl.to(o,{v:to,duration:1.0,ease:'power2.out',onUpdate:()=>{c.textContent=fmtNum(o.v,d);}},a);});
  });
  document.querySelectorAll('.draw').forEach(p=>{const a=T.appear[+p.dataset.i]??0.3;
    const end=p.dataset.gap? `0% ${(100*(+p.dataset.len)/(+p.dataset.gap)).toFixed(2)}%` : '100%';
    if(window.DrawSVGPlugin) tl.fromTo(p,{drawSVG:'0%'},{drawSVG:end,duration:.8,ease:'power2.inOut'},a);});
  document.querySelectorAll('.draw-h').forEach(p=>{const a=T.appear[+p.dataset.i]??0.3;
    tl.fromTo(p,{scaleX:0,transformOrigin:'0% 50%'},{scaleX:1,duration:.7,ease:'power3.inOut'},a-0.15);});
  document.querySelectorAll('.draw-v').forEach(p=>{const ts=T.appear.length?T.appear:[0.3];
    tl.fromTo(p,{scaleY:0,transformOrigin:'50% 0%'},{scaleY:1,duration:Math.max(.6,ts[ts.length-1]-ts[0]+.6),ease:'none'},ts[0]);});
  window.MT=tl;
}
function renderGsap(t){
  const T=window.TL, {hi}=stateAt(t), anyHi=Math.max(0,...hi);
  if(!window.MT) buildTimeline();
  window.MT.seek(t,false);
  // the element talked about stands out, the others step back (filter, so it never fights the entrance)
  document.querySelectorAll('.el').forEach(el=>{const i=+el.dataset.i, s=hi[i]??0;
    const dim=(anyHi>0.01 && s<0.5)? (1-T.dim*anyHi*(1-s)) : 1;
    el.style.filter=dim<0.999?`opacity(${dim.toFixed(3)})`:''; el.classList.toggle('on',s>0.5);});
  presenter(t, hi);
}
function renderBasic(t){
  const T=window.TL, {ap,hi}=stateAt(t), anyHi=Math.max(0,...hi);
  // header and decoration enter first
  const h=E(t/0.7);
  document.querySelectorAll('.hd,.k-title .tleft,.statement-only').forEach(el=>{el.style.opacity=h;el.style.transform=`translateY(${(1-h)*18}px)`});
  document.querySelectorAll('.art,.term,.core').forEach(el=>{const k=E((t-0.15)/0.8);el.style.opacity=k;el.style.transform=`scale(${0.92+0.08*k})`});
  document.querySelectorAll('.quiz .opt').forEach((el,i)=>{const k=E((t-0.3-0.12*i)/0.5);el.style.opacity=(el.classList.contains('wrong')?0.45:1)*k;el.style.transform=`translateY(${(1-k)*16}px)`});
  document.querySelectorAll('.el').forEach(el=>{
    const i=+el.dataset.i, a=ap[i]??1, s=hi[i]??0;
    const dim=(anyHi>0.01 && s<0.5)? (1-T.dim*anyHi*(1-s)) : 1;
    el.style.opacity=(a*dim).toFixed(3);
    const lift=-6*s, rise=(1-a)*26;
    if(el.tagName==='TR'){el.style.transform=`translateY(${rise*0.5}px)`;}
    else if(el.classList.contains('bar')){const r=el.querySelector('rect'); r.style.transformBox='fill-box';
      r.style.transformOrigin='50% 100%'; r.style.transform=`scaleY(${a.toFixed(3)})`; el.style.opacity=(Math.min(1,a*3)*dim).toFixed(3);
      el.style.transform=''; el.classList.toggle('on',s>0.5); return;}
    else if(el.tagName==='g'||el.tagName==='text'){el.style.transform='';}
    else if(el.classList.contains('cnode')){el.style.transform=`scale(${(0.6+0.4*a)*(1+0.12*s)})`;}
    else el.style.transform=`translateY(${rise+lift}px) scale(${0.97+0.03*a+0.02*s})`;
    el.classList.toggle('on',s>0.5);
  });
  document.querySelectorAll('.draw').forEach(p=>{const i=+p.dataset.i, a=ap[i]??1, L=+p.dataset.len||300;
    p.style.strokeDasharray=p.dataset.gap?`${L} ${p.dataset.gap}`:L; p.style.strokeDashoffset=(L*(1-a)).toFixed(1); p.style.opacity=a>0.01?1:0;});
  document.querySelectorAll('.draw-h').forEach(p=>{const a=ap[+p.dataset.i]??1;p.style.transform=`scaleX(${a})`});
  document.querySelectorAll('.draw-v').forEach(p=>{const n=ap.length; const k=n?Math.max(...ap.map((x,i)=>x>0.01?(i+x)/n:0)):1;p.style.transform=`scaleY(${k})`});
  document.querySelectorAll('.count').forEach(c=>{const el=c.closest('.el'), a=el?(ap[+el.dataset.i]??1):1;
    const to=+c.dataset.to, d=+c.dataset.dec; c.textContent=(to*E(a*1.2>1?1:a*1.2)).toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d});});
  document.querySelectorAll('.illustration .float').forEach((f,i)=>{const k=E((t-0.5-0.15*i)/0.7);f.style.opacity=k;});
  presenter(t, hi);
}
// layout check: text cut off or overflowing its box, elements overlapping or outside the slide
function layoutIssues(){
  const out=[], slide=document.querySelector('.slide').getBoundingClientRect();
  const sc=document.querySelector('.screenin')?(window.SCREEN_SCALE||0.69375):1;
  document.querySelectorAll('.slide .t,.slide .d,.slide .heading,.slide .lead,.slide td,.slide .otext,.slide .ptext,.slide .statement,.slide .def,.slide .ex,.slide .res,.slide .expr,.slide .what').forEach(e=>{
    if(e.scrollWidth>e.clientWidth+2||e.scrollHeight>e.clientHeight+2) out.push('text overflows: '+e.textContent.trim().slice(0,40));});
  const els=[...document.querySelectorAll('.slide .el')].filter(e=>getComputedStyle(e).position!=='static'||e.closest('.hub,.wheel'));
  document.querySelectorAll('.slide .el, .slide .hd, .slide .split .sr').forEach(e=>{const r=e.getBoundingClientRect();
    if(r.width&&(r.left<slide.left-2||r.right>slide.left+1280*sc+2||r.top<slide.top-2||r.bottom>slide.top+(720-40)*sc+2))
      out.push('outside the slide: '+e.textContent.trim().slice(0,40));});
  for(let i=0;i<els.length;i++)for(let j=i+1;j<els.length;j++){const a=els[i].getBoundingClientRect(),b=els[j].getBoundingClientRect();
    const w=Math.min(a.right,b.right)-Math.max(a.left,b.left), h=Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top);
    if(w>4&&h>4&&w*h>0.08*Math.min(a.width*a.height,b.width*b.height)) out.push('elements overlap: '+els[i].textContent.trim().slice(0,25)+' / '+els[j].textContent.trim().slice(0,25));}
  return [...new Set(out)];
}
// presenter style: poses follow what the voice talks about, the head moves while talking,
// the body sways and breathes - so the presenter looks alive, never frozen
function presenter(t, hi){
  const host=document.querySelector('.host')||document.querySelector('.lot-host'); if(!host) return;
  const T=window.TL, R=(x)=>S(Math.min(Math.max(x,0),1));
  // where each element sits: pointing up for elements high on the screen (measured once)
  if(!window.UPS){ const scr=document.querySelector('.screenin').getBoundingClientRect(); window.UPS={};
    document.querySelectorAll('.screenin .el').forEach(el=>{const r=el.getBoundingClientRect();
      window.UPS[+el.dataset.i]=(r.top+r.height/2) < scr.top+scr.height*0.40 ? 1 : 0;}); }
  // point while an element is talked about; short gaps between elements keep the arm up
  // (no dropping and raising between two sentences), with calm 0.3 s transitions
  const win=T.active.map((w,i)=>w?[w[0]-0.2,w[1]+0.7,i]:null).filter(Boolean);
  let point=0, up=0, cur=null;
  for(const w of win){ const v=Math.min(R((t-w[0])/0.3), 1-R((t-w[1])/0.3)); if(v>point){point=v;} if(t>=w[0]-0.3) cur=w; }
  if(cur){ const prev=win[win.indexOf(cur)-1]; const u1=window.UPS[cur[2]]||0, u0=prev?(window.UPS[prev[2]]||0):u1;
    up=u0+(u1-u0)*R((t-cur[0])/0.3); }
  if(!win.length){ point=Math.min(R((t-0.4)/0.4), 1-R((t-3.0)/0.5)); }   // a still slide: present it, then rest
  const set=(cls,v)=>{const g=document.querySelector(cls); if(g) g.style.opacity=v.toFixed(3);};
  if(document.querySelector('.lot-point')){ set('.lot-point',point); set('.lot-talk',1-point); }
  set('.p-rest',1-point); set('.p-point',point*(1-up)); set('.p-up',point*up);
  // talking: a slow, small head movement; a gentle sway and breathing (no jitter)
  const head=host.querySelector('.p-head'), sway=host.querySelector('.p-sway');
  const nod=1.1*Math.sin(t*2.2)+0.5*Math.sin(t*3.7+1.3);
  if(head) head.style.transform=`rotate(${nod.toFixed(2)}deg)`;
  const dip=point>0.02&&point<0.98 ? 3*Math.sin(Math.PI*point) : 0;      // a small step while changing pose
  if(sway) sway.style.transform=`translate(${(1.6*Math.sin(t*0.8)).toFixed(2)}px,${dip.toFixed(2)}px) rotate(${(0.35*Math.sin(t*0.6+0.4)).toFixed(2)}deg) scaleY(${(1+0.003*Math.sin(t*1.9)).toFixed(4)})`;
}
"""


# --- Timing ----------------------------------------------------------------------------------------
def timeline(scene: dict, beats: list[dict], durations: list[float], n: int) -> dict:
    """When each element appears and is highlighted (seconds from the scene start).
    build: each element appears when its part of the narration starts and stays highlighted
    while it is talked about. highlight: all appear at the start, then one by one is highlighted.
    none: all appear one after another in the first second (a quick, calm entrance)."""
    mode = scene.get("animation", "none") if len(beats) == n + 1 or len(beats) == n else "none"
    if len(beats) <= 1:
        mode = "none"
    starts = [sum(durations[:k]) for k in range(len(beats))]
    total = sum(durations)
    first = len(beats) - n   # 1 when there is a lead-in part before the first element

    def window(i: int) -> list[float]:
        end = starts[first + i + 1] if first + i + 1 < len(beats) else total
        return [starts[first + i] + 0.05, end - 0.08]

    if mode == "build":
        return {"appear": [starts[first + i] + 0.05 for i in range(n)],
                "active": [window(i) for i in range(n)], "dim": 0.25}
    stagger = min(0.18, 1.2 / max(n, 1))
    appear = [0.35 + stagger * i for i in range(n)]
    if mode == "highlight":
        return {"appear": appear, "active": [window(i) for i in range(n)], "dim": 0.5}
    return {"appear": appear, "active": [None] * n, "dim": 0.5}


_STOP = {"the", "a", "an", "and", "or", "of", "to", "in", "on", "for", "with", "is", "are", "be", "by", "it", "its",
         "this", "that", "your", "our", "how", "what", "who", "when", "why", "per", "vs"}


def _key_words(text: str) -> set[str]:
    return {w for w in re.findall(r"[a-z0-9']+", (text or "").lower()) if len(w) > 2 and w not in _STOP}


def dialogue_timeline(beats: list[dict], durations: list[float], n: int, titles: list[str] | None = None) -> dict:
    """Dialogue style: who talks when (TL.talk: [start, end, 'host'|'expert']), and when each of the
    slide's elements appears: on the first line (in order) that names it (its title words), so the
    screen follows what is being discussed; elements no line names are spread over the lines."""
    starts = [sum(durations[:k]) for k in range(len(beats))]
    talk = [[round(s + 0.15, 3), round(s + d - b.get("pause", 0.3), 3), b.get("speaker", "expert")]
            for s, d, b in zip(starts, durations, beats, strict=True)]
    lines = max(1, len(beats))
    line_words = [_key_words(b.get("text", "")) for b in beats]
    appear, used, last = [], {}, 0
    for i in range(n):
        k = min(lines - 1, i * lines // max(n, 1))
        want = _key_words(titles[i]) if titles and i < len(titles) else set()
        named = [j for j in range(last, lines) if want and len(want & line_words[j]) >= min(2, len(want))]
        if named:
            k = named[0]
        k = max(k, last)
        last = k
        appear.append(round(starts[k] + 0.3 + 0.2 * used.get(k, 0), 3) if beats else 0.35 + 0.18 * i)
        used[k] = used.get(k, 0) + 1
    return {"appear": appear, "active": [None] * n, "dim": 0.5, "talk": talk}


def speech_track(beats: list[dict], durations: list[float], who: str = "presenter") -> dict:
    """Who speaks when and how open each speaker's mouth is, frame by frame from the scene start
    (from beat['mouth'], made from the real voice by cartoon.mouth_envelope)."""
    starts = [sum(durations[:k]) for k in range(len(beats))]
    total = int(round(sum(durations) * FPS)) + 1
    mouth: dict[str, list[float]] = {}
    talk = []
    for s, d, b in zip(starts, durations, beats, strict=True):
        w = b.get("speaker", who)
        talk.append([round(s + 0.15, 3), round(s + d - b.get("pause", 0.3), 3), w])
        env = b.get("mouth") or []
        track = mouth.setdefault(w, [0.0] * total)
        k0 = int(round(s * FPS))
        for k, v in enumerate(env):
            if k0 + k < total:
                track[k0 + k] = v
    return {"talk": talk, "mouth": mouth}


def moving_windows(tl: dict) -> list[tuple[float, float]]:
    """Time ranges in which the picture changes (frames are captured only there)."""
    win = [(0.0, 1.0)]
    win += [(a - 0.02, a + ENTER_S + 0.15) for a in tl["appear"]]
    for w in tl["active"]:
        if w:
            win += [(w[0] - 0.02, w[0] + HILITE_S + 0.05), (w[1] - 0.02, w[1] + HILITE_S + 0.05)]
    return win


# --- Browser -------------------------------------------------------------------------------------
class Browser:
    """One headless browser page for all scenes of a video. Tries Playwright's Chromium, then
    the installed Microsoft Edge, then Chrome."""

    def __init__(self) -> None:
        from playwright.sync_api import sync_playwright
        self._pw = sync_playwright().start()
        errors = []
        self.browser = None
        for channel in (None, "msedge", "chrome"):
            try:
                self.browser = self._pw.chromium.launch(channel=channel) if channel else self._pw.chromium.launch()
                break
            except Exception as e:   # noqa: BLE001 - try the next browser
                errors.append(f"{channel or 'chromium'}: {str(e).splitlines()[0]}")
        if self.browser is None:
            self._pw.stop()
            raise RuntimeError("No browser for the slides: " + "; ".join(errors))
        scale = config.VIDEO_WIDTH / W
        self.page = self.browser.new_page(viewport={"width": W, "height": H}, device_scale_factor=scale)

    def close(self) -> None:
        self.browser.close()
        self._pw.stop()

    def scene_frames(self, html_text: str, tl: dict, total: float, work: Path, prefix: str) -> list[tuple[Path, float]]:
        """Pictures of one scene with how long each is shown: a frame every 1/FPS while something
        moves, one picture for each still stretch."""
        page_file = work / f"{prefix}.html"
        page_file.write_text(html_text, encoding="utf-8")
        self.page.goto(page_file.resolve().as_uri())
        self.page.evaluate("tl => { Object.assign(window.TL, tl); }", tl)
        self.page.evaluate("document.fonts.ready")
        self.issues = self.fit(total)
        windows = moving_windows(tl)
        n_frames = max(1, round(total * FPS))
        alive = 'class="stage' in html_text   # the presenter / the two people move all the time
        out: list[tuple[Path, float]] = []
        for k in range(n_frames):
            t = k / FPS
            if k == 0 or any(a <= t <= b for a, b in windows) or (alive and k % config.PRESENTER_STEP == 0):
                self.page.evaluate(f"render({t:.4f})")
                path = work / f"{prefix}_{k:05d}.jpg"
                self.page.screenshot(path=str(path), type="jpeg", quality=92)
                out.append((path, 1 / FPS))
            else:
                prev, d = out[-1]
                out[-1] = (prev, d + 1 / FPS)
        # the exact length: the last picture absorbs the rounding
        out[-1] = (out[-1][0], out[-1][1] + (total - n_frames / FPS))
        page_file.unlink(missing_ok=True)
        return out

    def fit(self, total: float) -> list[str]:
        """Check the finished slide; if text overflows or elements collide, make the content a
        bit smaller (two steps) and check again. Returns what is still wrong."""
        self.page.evaluate(f"render({total + 5:.2f})")   # everything visible
        issues = self.page.evaluate("layoutIssues()")
        for cls in ("compact", "compact2"):
            if not issues:
                break
            self.page.evaluate(f"document.querySelector('.slide').classList.remove('compact');"
                               f"document.querySelector('.slide').classList.add('{cls}')")
            issues = self.page.evaluate("layoutIssues()")
        return issues

    def still(self, html_text: str, tl: dict, t: float, out: Path) -> Path:
        page_file = out.with_suffix(".html")
        page_file.write_text(html_text, encoding="utf-8")
        self.page.goto(page_file.resolve().as_uri())
        self.page.evaluate("tl => { Object.assign(window.TL, tl); }", tl)
        self.page.evaluate(f"render({t:.4f})")
        self.page.screenshot(path=str(out), type="png")
        page_file.unlink(missing_ok=True)
        return out


def available() -> tuple[bool, str]:
    """Can slides be drawn with a browser here? (for doctor.py and the fallback)."""
    if config.RENDERER != "html":
        return False, f"RENDERER={config.RENDERER}"
    try:
        b = Browser()
        name = b.browser.browser_type.name + " " + b.browser.version
        b.close()
        return True, name
    except ImportError:
        return False, "playwright not installed (uv add playwright)"
    except Exception as e:   # noqa: BLE001
        return False, str(e)[:200]
