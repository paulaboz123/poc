"""
compare_video.py - the same video made by every tool, side by side, so people can compare them 1:1:
the same content and the same timing in each, a choice of narrator under every video (Kokoro voices,
the ElevenLabs voice already made, a new ElevenLabs voice), of presenter and of look (a solution can
make the same video in a second look: other colours, another way of showing the content).
The result opens in Lesson Studio (uv run app.py), tab Comparison.

  uv run compare_video.py                          # the newest video made with ElevenLabs: its content and voice
  uv run compare_video.py --from "data\\output\\<video folder>"
  uv run compare_video.py "Snowflake" --general    # new content instead (Claude plans it, a few cents)
  uv run compare_video.py --resume                 # after fixing an error: makes only what is missing or failed
  uv run compare_video.py --resume --add-voice "data\\output\\<the same video, another voice>"   # e.g. Lily
  uv run compare_video.py --only html,manim        # some solutions (ids below); --redo manim: make it again

Solutions (ids): html, remotion, remotion-pro, manim, revideo, motion-canvas, hyperframes (slides, each its own look);
cartoon-bear, cartoon-fox (our cartoon presenter: one video per narrator, so the mouth follows the voice
picked); company-<name> (the company's own avatars, company_avatar.py: a picture in data/avatars made to
talk). Only when asked (--only): pro2d-micah, pro2d-avataaars (Remotion Pro, drawn presenter), pro-woman,
pro-man, pro-robot (Remotion Pro's blocky 3D presenters): drawn people did not look professional.
No real-looking (photographic) presenters: not allowed in this project.

Narrators: the ElevenLabs voice of the source video (its recorded parts are reused: no new credits),
four Kokoro voices (free: a woman and a man, US and UK), and one ElevenLabs voice not used before,
speaking as many parts as the credits left allow (it stops there, no error).

What is paid: nothing for the voices already made; Kokoro is free; the new ElevenLabs voice uses the
credits left; Claude only for new content.
A solution that cannot run here (not installed, no key, an error) is noted and the others go on.
"""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import logging
import shutil
import sys
import time
from datetime import datetime
from pathlib import Path

import numpy as np

import config
import make_video
import media
import store
import storyboard
import tts

log = logging.getLogger("compare_video")
RATE = 44100   # every voice track and the videos' sound
LEAD_S = 0.15  # tts.speak_to_wav puts this much silence before each part

KOKORO = [   # id, Kokoro voice, name, who, accent
    ("kokoro-heart", "af_heart", "Heart", "woman", "US"),
    ("kokoro-michael", "am_michael", "Michael", "man", "US"),
    ("kokoro-emma", "bf_emma", "Emma", "woman", "UK"),
    ("kokoro-george", "bm_george", "George", "man", "UK"),
]
ELEVEN_WHO = {"alice": "woman", "bill": "man", "brian": "man", "callum": "man", "charlie": "man", "charlotte": "woman",
              "chris": "man", "daniel": "man", "eric": "man", "george": "man", "jessica": "woman", "laura": "woman",
              "liam": "man", "lily": "woman", "matilda": "woman", "sarah": "woman", "will": "man"}
ELEVEN_ACCENT = {"alice": "UK", "bill": "US", "brian": "US", "callum": "US", "charlie": "AU", "charlotte": "UK",
                 "chris": "US", "daniel": "UK", "eric": "US", "george": "UK", "jessica": "US", "laura": "US", "liam": "US",
                 "lily": "UK", "matilda": "US", "sarah": "US", "will": "US"}
NEW_VOICE_ORDER = ("brian", "alice", "daniel", "charlotte", "sarah", "chris", "laura", "will", "eric", "callum",
                   "jessica", "liam", "bill", "charlie")   # good narrators first

FREE = "Free (open source)"
REMOTION = "Free for teams of up to 3 people; companies: $0.01 a render, at least $100 a month"
SOLUTIONS = [
    {"id": "html", "group": "Designer slides (HTML)", "renderer": "html", "style": "clean",
     "about": "Our own slides drawn in a browser (Playwright).", "price": "Free"},
    {"id": "remotion", "group": "Remotion", "renderer": "remotion", "style": "clean",
     "about": "React video framework, the classic composition.", "price": REMOTION,
     "looks": [{"id": "classic", "name": "Classic: light cards"},
               {"id": "editorial", "name": "Editorial: paper, ink and coral; a drawn flow, counters, a ring chart",
                "about": "React video framework, a second look: warm paper, ink and coral; the elements are drawn as a "
                         "flow that grows with the voice, numbers count up, charts fill as rings.",
                "set": {"REMOTION_LOOK": "editorial"}}]},
    {"id": "remotion-pro", "group": "Remotion Pro (motion design)", "renderer": "remotion-pro", "style": "clean",
     "set": {"PRO_PRESENTER": "none"}, "about": "Remotion with a living dark backdrop, glass cards, push transitions.",
     "price": REMOTION},
    {"id": "manim", "group": "Manim", "renderer": "manim", "style": "clean",
     "about": "Python animation engine (known from maths videos), its dark look.", "price": FREE + ", MIT"},
    {"id": "revideo", "group": "Revideo", "renderer": "revideo", "style": "clean",
     "about": "TypeScript animation engine made for rendering from code, warm look.", "price": FREE + ", MIT"},
    {"id": "motion-canvas", "group": "Motion Canvas", "renderer": "motion-canvas", "style": "clean",
     "about": "TypeScript animation engine (Revideo's origin), dark look; its editor's Render button is pressed "
              "automatically.", "price": FREE + ", MIT"},
    {"id": "hyperframes", "group": "HyperFrames", "renderer": "hyperframes", "style": "clean",
     "about": "HeyGen's open-source video framework: our slides as HTML animated with GSAP, light violet look. "
              "A free alternative to Remotion (no company licence); needs Node.js 22.",
     "price": FREE + ", Apache-2.0 (also for companies)"},
    {"id": "cartoon-bear", "talks": True, "group": "Cartoon presenter (HTML)", "variant": "Bear", "renderer": "html",
     "style": "presenter", "characters": "cartoon", "set": {"CARTOON_PRESENTER": "bear"},
     "about": "Our cartoon presenter beside the slides; the mouth follows the narrator you pick.", "price": "Free"},
    {"id": "cartoon-fox", "talks": True, "group": "Cartoon presenter (HTML)", "variant": "Fox", "renderer": "html",
     "style": "presenter", "characters": "cartoon", "set": {"CARTOON_PRESENTER": "fox"},
     "about": "Our cartoon presenter beside the slides; the mouth follows the narrator you pick.", "price": "Free"},
    {"id": "pro2d-micah", "talks": True, "who": "woman", "default": False, "group": "Remotion Pro \u2013 2D presenter",
     "variant": "Illustrated",
     "renderer": "remotion-pro", "style": "presenter", "set": {"PRO_PRESENTER": "person-2d", "PRO_AVATAR": "micah"},
     "about": "Remotion Pro's motion design with a smooth drawn presenter: the mouth follows the voice, blinks, "
              "leans toward the slide.", "price": REMOTION + "; drawing by Micah Lanier, CC BY 4.0 (credit needed)"},
    {"id": "pro2d-avataaars", "talks": True, "default": False, "group": "Remotion Pro \u2013 2D presenter",
     "variant": "Cartoon",
     "renderer": "remotion-pro", "style": "presenter", "set": {"PRO_PRESENTER": "person-2d", "PRO_AVATAR": "avataaars"},
     "about": "Remotion Pro's motion design with a smooth drawn presenter: the mouth follows the voice, blinks, "
              "leans toward the slide.", "price": REMOTION + "; Avataaars drawing, free for commercial use"},
    {"id": "pro-woman", "talks": True, "who": "woman", "group": "Remotion Pro presenter (3D)", "default": False, "variant": "Woman", "renderer": "remotion-pro",
     "style": "presenter", "set": {"PRO_PRESENTER": "person-3d", "PRO_PERSON": "woman"},
     "about": "A 3D presenter that talks, waves and points at the screen.", "price": REMOTION + "; 3D models free (CC0)"},
    {"id": "pro-man", "talks": True, "who": "man", "group": "Remotion Pro presenter (3D)", "default": False, "variant": "Man", "renderer": "remotion-pro",
     "style": "presenter", "set": {"PRO_PRESENTER": "person-3d", "PRO_PERSON": "man"},
     "about": "A 3D presenter that talks, waves and points at the screen.", "price": REMOTION + "; 3D models free (CC0)"},
    {"id": "pro-robot", "talks": True, "group": "Remotion Pro presenter (3D)", "default": False, "variant": "Robot", "renderer": "remotion-pro",
     "style": "presenter", "set": {"PRO_PRESENTER": "robot"},
     "about": "A 3D presenter that talks, waves and points at the screen.", "price": REMOTION + "; 3D models free (CC0)"},
]
IDS = [s["id"] for s in SOLUTIONS]
DEFAULT_IDS = [s["id"] for s in SOLUTIONS if s.get("default", True)]   # the blocky 3D people only when asked


def solutions() -> list[dict]:
    """Every solution: the fixed ones and one per company avatar marked in data/avatars (company_avatar.py)."""
    import company_avatar
    return SOLUTIONS + company_avatar.solutions()


def default_ids() -> list[str]:
    return [s["id"] for s in solutions() if s.get("default", True)]


# Every tool's two looks (VIDEO_LOOK): its own, and the same video drawn another way. renderer: (main, second, about)
LOOK_NAMES = {
    "html": ("Light: teal and amber", "Midnight: navy, violet and mint",
             "a second look: deep navy with a fine grid, violet and mint, glowing glass cards, the title in a gradient"),
    "remotion-pro": ("Night sky: grid floor, teal and amber", "Aurora: plum sky, magenta and mint ribbons",
                     "a second look: a plum night sky with slow aurora ribbons and stars, magenta and mint"),
    "manim": ("Charcoal and yellow", "Chalkboard: green board, pink chalk",
              "a second look: a green chalkboard, chalk-white text, pink and yellow chalk, a serif face"),
    "revideo": ("Warm paper and orange", "Plum night and mint",
                "a second look: dark plum with mint, the parts moving in from below"),
    "motion-canvas": ("Navy and sky blue", "Light paper and violet",
                      "a second look: light paper with violet, a serif face, the parts moving in from the side"),
    "hyperframes": ("Light violet", "Dark ink, coral and gold",
                    "a second look: dark ink with coral, the same GSAP motion"),
}


def looks_of(sol: dict) -> list[dict]:
    """A solution's looks: the first is its main video; the others are the same video drawn another way
    (the same content, voice and timing)."""
    if sol.get("looks"):
        return sol["looks"]
    names = LOOK_NAMES.get(sol.get("renderer", ""))
    if not names:
        return [{"id": "main", "name": "Main"}]
    main, second, about = names
    return [{"id": "main", "name": main},
            {"id": "second", "name": second, "about": f"{sol.get('about', '').rstrip('.')}; {about}.",
             "set": {"VIDEO_LOOK": "second"}}]

VOICE_PRICE = {"kokoro": "Free (runs on our own server)",
               "elevenlabs": "About $0.15 a narrated minute (Pro plan: $99 a month for 600,000 characters)"}


def voice_label(v: dict) -> str:
    """What people see in the narrator list: tool, name, woman/man, accent (no 'new' or 'made before')."""
    tool = "Kokoro" if v.get("engine") == "kokoro" else "ElevenLabs"
    accent = v.get("accent") or ELEVEN_ACCENT.get(str(v.get("name", "")).lower(), "")
    about = ", ".join(x for x in (v.get("who", ""), accent) if x)
    part = "" if v.get("parts", 1) == v.get("of", 1) else f"; first {v.get('parts')} of {v.get('of')} parts"
    return f"{tool} \u2013 {v.get('name', '')}" + (f" ({about}{part})" if about or part else "")


class Skipped(RuntimeError):
    """This solution cannot run here (not installed, no key): noted, the others go on."""


@contextlib.contextmanager
def settings(**values):
    old = {k: getattr(config, k) for k in values}
    try:
        for k, v in values.items():
            setattr(config, k, v)
        yield
    finally:
        for k, v in old.items():
            setattr(config, k, v)


# --- 0. the content ---------------------------------------------------------------------------------
def beats(sb: dict, animated: bool = True) -> list[tuple[int, dict]]:
    """Every spoken part, in order (one narrator: the clean style's parts; animated = split for the build-up)."""
    with settings(ANIMATION=animated):
        return [(i, b) for i, sc in enumerate(sb["scenes"]) for b in make_video.scene_beats(sc, "clean")]


def _info(folder: Path) -> dict:
    return store.read_json(folder / "info.json", {}) or {}


def newest_source() -> Path:
    """The newest video whose voice is ElevenLabs (its content and voice are reused)."""
    for folder in sorted(config.OUTPUT_DIR.glob("*-video-*"), reverse=True):
        sb_path = folder / "storyboard.json"
        if not sb_path.exists() or not (folder / "audio").exists():
            continue
        if str(_info(folder).get("tts", "")).startswith("ElevenLabs") and storyboard.load(folder).get("style") != "dialogue":
            return folder
    raise FileNotFoundError("No video made with an ElevenLabs voice in data/output. Give one with --from \"<folder>\", "
                            "or new content: uv run compare_video.py \"Snowflake\" --general")


def new_folder(sb: dict, source: str) -> Path:
    folder = config.OUTPUT_DIR / f"{datetime.now():%Y%m%d-%H%M%S}-compare-{store.slugify(sb.get('title', 'video'), 40)}"
    folder.mkdir(parents=True)
    sb = {**sb, "style": "clean"}
    store.write_json(folder / "storyboard.json", sb)
    store.write_json(folder / "comparison.json", {"title": sb.get("title", ""), "source": source,
                                                  "created": datetime.now().isoformat(timespec="seconds"),
                                                  "voices": [], "solutions": []})
    return folder


# --- 1. the narrators -------------------------------------------------------------------------------
def _resample(samples: np.ndarray, rate: int) -> np.ndarray:
    if rate == RATE or not len(samples):
        return samples.astype(np.float32)
    n = int(round(len(samples) * RATE / rate))
    return np.interp(np.linspace(0, len(samples) - 1, n), np.arange(len(samples)), samples).astype(np.float32)


def _beat_file(folder: Path, voice: str, n: int) -> Path:
    return folder / "voices" / voice / f"part_{n:03d}.wav"


def _matched(audio: Path, plan: list, voice: str) -> dict[int, Path]:
    with settings(TTS_ENGINE="elevenlabs", ELEVENLABS_VOICE=voice):
        fp = make_video.voice_fingerprint()
    found = {}
    for n, (_, b) in enumerate(plan):
        key = hashlib.sha1(f"{fp}|{b.get('voice') or ''}|{b['pause']}|{b['text']}".encode()).hexdigest()[:16]
        if (audio / f"voice_{key}.wav").exists():
            found[n] = audio / f"voice_{key}.wav"
    return found


def source_parts(source: Path, plan: list) -> tuple[dict[int, Path], str, str]:
    """{part number: the source's ElevenLabs file}, how they were found, and the voice's name when the
    files tell it (each file is named by the voice, the settings and the text)."""
    audio = source / "audio"
    best: dict[int, Path] = {}
    voice = ""
    for name in [config.ELEVENLABS_VOICE] + list(tts.ELEVEN_VOICES):
        found = _matched(audio, plan, name)
        if len(found) > len(best):
            best, voice = found, name
        if len(found) == len(plan):
            break
    named = tts.eleven_voice_name(tts.eleven_voice_id(voice)) if best and voice else ""
    if len(best) == len(plan):
        return best, "matched", named
    files = sorted(audio.glob("voice_*.wav"), key=lambda p: p.stat().st_mtime)
    if len(files) == len(plan):
        return dict(enumerate(files)), "taken in order", ""
    return best, "matched", named


def voice_name_of(source: Path) -> str:
    """The ElevenLabs voice a video was made with, from its run card (e.g. 'voice George')."""
    import re
    card = store.read_json(source / "run_card.json", {}) or {}
    said = str((card.get("solution") or {}).get("voice", ""))
    m = re.search(r"voice\s+([A-Za-z][\w-]*)", said)
    return m.group(1).capitalize() if m else ""


def animated_like(source: Path, sb: dict) -> bool:
    """Was the source spoken in build-up parts (ANIMATION=yes) or one part a scene? The one its files fit."""
    for animated in (True, False):
        found, _, _ = source_parts(source, beats(sb, animated))
        if len(found) == len(beats(sb, animated)):
            return animated
    return True


def existing_eleven(folder: Path, source: Path, plan: list, vid: str = "elevenlabs-made") -> dict | None:
    """The ElevenLabs parts of a video already made, copied (never spoken again). Found by the key the
    video used (which also tells the voice); else by their order. Only a video with the same content fits."""
    found, how, name = source_parts(source, plan)
    if not found:
        log.warning("%s: no ElevenLabs parts of this content (only a video with the same storyboard fits: "
                    "the same slides and narration)", source.name)
        return None
    for n, src in found.items():
        dst = _beat_file(folder, vid, n)
        dst.parent.mkdir(parents=True, exist_ok=True)
        if not dst.exists():
            shutil.copyfile(src, dst)
    name = name or voice_name_of(source) or tts.eleven_voice_name(tts.eleven_voice_id(config.ELEVENLABS_VOICE or "lily"))
    who = ELEVEN_WHO.get(name.lower(), "")
    log.info("ElevenLabs %s from %s: %s of %s parts reused (%s), no credits used", name, source.name, len(found),
             len(plan), how)
    v = {"id": vid, "engine": "elevenlabs", "name": name, "who": who, "source": str(source),
         "parts": len(found), "of": len(plan), "note": "" if len(found) == len(plan) else f"{len(found)} of {len(plan)} parts"}
    return {**v, "label": voice_label(v)}


def kokoro_voices(folder: Path, plan: list, only: set[str] | None = None) -> list[dict]:
    ok, why = tts.check("kokoro")
    if not ok:
        log.warning("Kokoro voices skipped: %s", why)
        return []
    out = []
    for vid, voice, name, who, accent in KOKORO:
        if only and vid not in only:
            continue
        made, t0 = 0, time.perf_counter()
        with settings(TTS_ENGINE="kokoro", TTS_VOICE=voice):
            for n, (_, b) in enumerate(plan):
                f = _beat_file(folder, vid, n)
                if not f.exists():
                    f.parent.mkdir(parents=True, exist_ok=True)
                    tts.speak_to_wav(b["text"], f, pause_after_s=b["pause"])
                    made += 1
        log.info("Kokoro %s: %s parts spoken", name, made)
        out.append({"id": vid, "engine": "kokoro", "name": name, "who": who, "accent": accent,
                    "label": f"Kokoro – {name} ({who}, {accent})", "parts": len(plan), "of": len(plan), "note": "",
                    # seconds the server spends speaking the whole narration (for its cost)
                    "make_s": round((time.perf_counter() - t0) * len(plan) / made, 1) if made else None})
    return out


def _used_eleven_voices() -> set[str]:
    """Voice ids already used on the ElevenLabs account (its history; free to read) and in .env."""
    used = {tts.eleven_voice_id(v) for v in (config.ELEVENLABS_VOICE, config.ELEVENLABS_HOST_VOICE,
                                               config.ELEVENLABS_EXPERT_VOICE) if v}
    used |= {tts.eleven_voice_id(n) for n in tts.ELEVEN_DEFAULTS.values()}
    try:
        import llm
        r = llm._http().get(f"{config.ELEVENLABS_BASE_URL}/v1/history", params={"page_size": 1000},
                            headers={"xi-api-key": config.ELEVENLABS_API_KEY}, timeout=30)
        if r.status_code == 200:
            used |= {h.get("voice_id") for h in r.json().get("history", []) if h.get("voice_id")}
    except Exception as e:   # noqa: BLE001 - the history is a help, not a must
        log.info("ElevenLabs history not readable (%s); avoiding the voices in .env", str(e)[:100])
    return used


def new_eleven(folder: Path, plan: list, state: dict) -> dict | None:
    """A voice not used before, as many parts as the credits left allow; stops there without an error."""
    if not config.ELEVENLABS_API_KEY:
        log.info("New ElevenLabs voice skipped: no ELEVENLABS_API_KEY")
        return None
    import usage
    voice = state.get("new_voice")
    if not voice:
        used = _used_eleven_voices()
        voice = next((n for n in NEW_VOICE_ORDER if tts.eleven_voice_id(n) not in used), NEW_VOICE_ORDER[0])
    texts = [tts.clean_for_speech(b["text"]) for _, b in plan]
    q = usage.elevenlabs(refresh=True) or {"left": 0}
    model = state.get("new_model") or ("eleven_multilingual_v2" if q["left"] >= sum(map(len, texts)) * 1.05 + 50
                                       else "eleven_flash_v2_5")   # flash: half the credits a character
    factor = 0.5 if "flash" in model or "turbo" in model else 1.0
    state.update(new_voice=voice, new_model=model)
    done = sum(1 for n in range(len(plan)) if _beat_file(folder, "elevenlabs-new", n).exists())
    stopped = ""
    with settings(TTS_ENGINE="elevenlabs", ELEVENLABS_VOICE=voice, ELEVENLABS_MODEL=model):
        for n, (_, b) in enumerate(plan):
            f = _beat_file(folder, "elevenlabs-new", n)
            if f.exists():
                continue
            left = (usage.elevenlabs(refresh=True) or {"left": 0})["left"]
            need = int(len(texts[n]) * factor) + 1
            if need > left - 10:
                stopped = f"the credits ran out after part {n} ({left} left)"
                break
            f.parent.mkdir(parents=True, exist_ok=True)
            try:
                tts.speak_to_wav(b["text"], f, pause_after_s=b["pause"], context=make_video.neighbours(plan, n))
            except tts.TTSError as e:
                stopped = str(e)[:200]
                f.unlink(missing_ok=True)
                break
            done += 1
            if any(not _beat_file(folder, "elevenlabs-new", k).exists() for k in range(n)):
                break   # only the first parts in a row: a track with gaps would sound broken
    if not done:
        log.warning("New ElevenLabs voice: nothing spoken (%s)", stopped or "no credits left")
        return None
    name = voice.capitalize()
    if stopped:
        log.info("New ElevenLabs voice %s: %s of %s parts, stopped: %s", name, done, len(plan), stopped)
    v = {"id": "elevenlabs-new", "engine": "elevenlabs", "name": name, "who": ELEVEN_WHO.get(voice, ""),
         "parts": done, "of": len(plan), "model": model,
         "note": "" if done == len(plan) else f"first {done} of {len(plan)} parts: {stopped or 'the credits ran out'}"}
    return {**v, "label": voice_label(v)}


def _part_samples(folder: Path, voice: str, n: int) -> np.ndarray | None:
    f = _beat_file(folder, voice, n)
    if not f.exists():
        return None
    samples, rate = tts._read_wav(f)
    return _resample(np.asarray(samples, dtype=np.float32), rate)


def slots(folder: Path, plan: list, voices: list[dict]) -> list[int]:
    """How long each part lasts in every video: the longest voice for it, so every voice fits (samples).
    Fixed once written (slots.json): videos already made keep matching every track."""
    path = folder / "slots.json"
    saved = store.read_json(path, {}) or {}
    if saved.get("parts") == len(plan):
        return saved["samples"]
    out = []
    for n, (_, b) in enumerate(plan):
        lens = [len(s) for v in voices if (s := _part_samples(folder, v["id"], n)) is not None]
        fallback = int((LEAD_S + max(1.0, len(b["text"].split()) * 0.42) + b["pause"]) * RATE)
        out.append(max(lens) if lens else fallback)
    store.write_json(path, {"parts": len(plan), "rate": RATE, "samples": out, "seconds": round(sum(out) / RATE, 2)})
    return out


def fit(samples: np.ndarray, length: int) -> np.ndarray:
    """A part made to last exactly `length` samples: silence added, or (a voice added after the videos
    were made, longer than its place) spoken a little faster, pitch kept (ffmpeg atempo)."""
    if len(samples) <= length:
        return np.concatenate([samples, np.zeros(length - len(samples), dtype=np.float32)])
    loud = np.flatnonzero(np.abs(samples) > 0.01)
    if not len(loud) or loud[-1] + 1 <= length:   # only silence beyond its place: cut it
        return samples[:length]
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        src, dst = Path(tmp) / "a.wav", Path(tmp) / "b.wav"
        tts._write_wav(src, samples, RATE)
        tempo = min(1.35, len(samples) / length + 0.005)
        media._run([config.FFMPEG, "-hide_banner", "-loglevel", "error", "-y", "-i", str(src), "-filter:a",
                    f"atempo={tempo:.4f}", "-ar", str(RATE), str(dst)])
        faster, rate = tts._read_wav(dst)
    faster = _resample(np.asarray(faster, dtype=np.float32), rate)[:length]
    return np.concatenate([faster, np.zeros(length - len(faster), dtype=np.float32)])


def tracks(folder: Path, plan: list, voices: list[dict], slot: list[int]) -> None:
    """One narration track per voice on the common timeline (a part a voice did not speak = silence)."""
    for v in voices:
        mp3 = folder / "voices" / f"{v['id']}.mp3"
        pieces = []
        for n in range(len(plan)):
            s = _part_samples(folder, v["id"], n)
            pieces.append(fit(np.zeros(0, dtype=np.float32) if s is None else s, slot[n]))
        wav = folder / "voices" / f"{v['id']}.wav"
        tts._write_wav(wav, tts.normalize(np.concatenate(pieces), RATE), RATE)
        media.to_mp3(wav, mp3)
        wav.unlink(missing_ok=True)
        v["file"] = f"voices/{v['id']}.mp3"


def fixed_audio(folder: Path, plan: list, reference: str, slot: list[int]) -> dict:
    """What tts gives each part while the videos are drawn: the reference voice fitted to the common
    timeline (speak_to_wav adds the lead and the pause around it again)."""
    out = {}
    for n, (_, b) in enumerate(plan):
        s = _part_samples(folder, reference, n)
        core = slot[n] - int(LEAD_S * RATE) - int(b["pause"] * RATE)
        body = np.zeros(core, dtype=np.float32) if s is None else s[int(LEAD_S * RATE):][:core]
        body = np.concatenate([body, np.zeros(max(0, core - len(body)), dtype=np.float32)])
        if b["text"] in out:   # the same words twice: the longer slot wins
            body = body if len(body) >= len(out[b["text"]][0]) else out[b["text"]][0]
        out[b["text"]] = (body, RATE)
    return out


# --- 2. the solutions ---------------------------------------------------------------------------------
def available(sol: dict) -> tuple[bool, str]:
    r = sol.get("renderer")
    if r == "html":
        import importlib.util
        return (importlib.util.find_spec("playwright") is not None, "playwright not installed: uv add playwright")
    if r.startswith("remotion"):
        import remotion_render
        try:
            remotion_render.ensure_installed()
            return remotion_render.available()
        except Exception as e:   # noqa: BLE001
            return False, f"Remotion check failed: {e}"
    if r == "manim":
        import manim_render
        return manim_render.available()
    if r == "hyperframes":
        import hyperframes_render
        return hyperframes_render.available()
    import deck_js
    return deck_js.available(r)


def render(folder: Path, sol: dict, fixed: dict, animated: bool = True, name: str = "", look: dict | None = None) -> Path:
    """One solution's video into videos/<name or id>.mp4 (a presenter's video with another narrator, or
    another look: a name). look: one of the solution's looks (its settings on top of the solution's)."""
    ok, why = available(sol)
    if not ok:
        raise Skipped(why)
    name = name or sol["id"]
    work = store.fresh_dir(folder / "work" / name)
    sb = storyboard.load(folder)
    out = folder / "videos" / f"{name}.mp4"
    out.parent.mkdir(exist_ok=True)
    store.write_json(work / "storyboard.json", {**sb, "style": sol["style"],
                                                "characters": sol.get("characters") or sb.get("characters")})
    tts.FIXED.clear()
    tts.FIXED.update(fixed)
    with settings(TTS_ENGINE="fixed", RENDERER=sol["renderer"], ANIMATION=animated,
                  **{**sol.get("set", {}), **(look or {}).get("set", {})}):
        info = make_video.produce(work)
    if info.get("renderer") != sol["renderer"]:
        raise RuntimeError(f"{sol['renderer']} did not draw it (used {info.get('renderer')}): {info.get('fallback', '')}")
    shutil.copyfile(info["video"], out)
    shrink(out)
    return out


SHRINK_MB = 12   # videos bigger than this are encoded again (Remotion Pro writes ~50 MB a minute): the page loads
                 # them quickly, also through a shared link, at the same look


def poster(video: Path) -> Path | None:
    """<video>.jpg: a still from the video, shown on the page before it plays (nothing is downloaded until then)."""
    jpg = video.with_suffix(".jpg")
    if jpg.exists() and jpg.stat().st_mtime >= video.stat().st_mtime:
        return jpg
    try:
        media._run([config.FFMPEG, "-hide_banner", "-loglevel", "error", "-y", "-ss", "3", "-i", str(video),
                    "-frames:v", "1", "-vf", "scale=640:-2", "-q:v", "4", str(jpg)])
        return jpg if jpg.exists() else None
    except Exception as e:   # noqa: BLE001 - only a still
        log.info("No still for %s: %s", video.name, e)
        return None


def shrink(video: Path) -> Path:
    """A video above SHRINK_MB encoded again (H.264, CRF 23, the index at the start), and its still made."""
    if video.stat().st_size > SHRINK_MB * 1e6:
        tmp = video.with_name(video.stem + ".small.mp4")
        try:
            media._run([config.FFMPEG, "-hide_banner", "-loglevel", "error", "-y", "-i", str(video), "-c:v", "libx264",
                        "-preset", "veryfast", "-crf", "23", "-pix_fmt", "yuv420p", "-c:a", "copy", "-movflags",
                        "+faststart", str(tmp)])
            if tmp.exists() and 0 < tmp.stat().st_size < video.stat().st_size:
                before = video.stat().st_size
                tmp.replace(video)
                log.info("%s: %.0f MB -> %.0f MB", video.name, before / 1e6, video.stat().st_size / 1e6)
        finally:
            tmp.unlink(missing_ok=True)
    poster(video)
    return video


def shrink_all() -> list[str]:
    """Every comparison's videos: the big ones made smaller, a still for each (uv run compare_video.py --shrink)."""
    done = []
    for folder in sorted(config.OUTPUT_DIR.glob("*-compare-*")):
        for v in sorted((folder / "videos").glob("*.mp4")):
            big = v.stat().st_size > SHRINK_MB * 1e6
            shrink(v)
            if big:
                done.append(f"{folder.name}/{v.name}")
    return done


# --- what each video costs, made from scratch ----------------------------------------------------------
CLOUD_PER_S = (2 * 0.04656 + 4 * 0.00511) / 3600   # a 2 vCPU / 4 GB cloud container (AWS Fargate, costs.py)
KOKORO_RTF = 0.6                                   # server seconds per second of speech, when not measured
MONTHLY = {   # fixed monthly fees that come with a tool: shown in brackets, not in the cost of one video
    "remotion": "with a company licence: from $100 a month, then $0.01 a video",
    "elevenlabs": "plan: Pro $99 a month for 600,000 characters",
}
LICENCE = {"html": "open source", "manim": "open source (MIT)", "revideo": "open source (MIT)",
           "motion-canvas": "open source (MIT)",
           "hyperframes": "open source (Apache-2.0), also for companies"}


def _calls_cost(calls: list[dict], voice: bool = False) -> float:
    return sum(float(c.get("cost_usd") or 0) for c in calls or [] if (c.get("step") == "voice") == voice)


def content_cost(folder: Path, data: dict) -> tuple[float, str]:
    """Claude's part of one video made from scratch: finding the material in the recordings, writing the
    script and the slides, checking them (the planning calls kept with the storyboard), plus the checks
    while the source video was made. The same for every tool."""
    sb = storyboard.load(folder)
    plan = _calls_cost(sb.get("plan_calls", [])) or float(sb.get("plan_cost_usd_est") or 0)
    src = Path(data.get("source", "-")) if data.get("source") else None
    made = 0.0
    if src and (src / "run_card.json").exists():
        card = store.read_json(src / "run_card.json", {}) or {}
        steps = (card.get("cost") or {}).get("by_step", [])
        total = sum(float(r.get("cost_usd") or 0) for r in steps if r.get("step") != "voice")
        made = max(0.0, total - plan)   # the card holds the planning too
    if plan + made <= 0:
        import costs
        minutes = float(data.get("seconds") or 60) / 60
        return round(costs.FALLBACK_PER_MIN["video"] * minutes, 4), "estimate (this content's own cost is not recorded)"
    return round(plan + made, 4), ""


def video_costs(folder: Path, data: dict) -> dict:
    """What each video costs when made from scratch (as a user would), split: the content (Claude), the
    narrator, making the video on a cloud server; the licence and plans per month apart.
    Nothing is counted as free because it was made before for this comparison. Added to `data`."""
    sb = storyboard.load(folder)
    plan = beats(sb, (data.get("state") or {}).get("animated", True))
    texts = [tts.clean_for_speech(b["text"]) for _, b in plan]
    chars = sum(len(t) for t in texts)
    seconds = float(data.get("seconds") or 0)
    minutes = seconds / 60
    rate = config.ELEVENLABS_USD_PER_1K_CHARS / 1000
    data["cost_content"], data["cost_content_note"] = content_cost(folder, data)
    data["minutes"] = round(minutes, 2)
    data["cost_margin_pct"] = config.COST_MARGIN_PCT   # added on top, so the figure errs on the high side
    for v in data.get("voices", []):
        v["label"] = voice_label(v)
        if v["engine"] == "kokoro":
            server_s = float(v.get("make_s") or seconds * KOKORO_RTF)
            v["cost_usd"] = round(server_s * CLOUD_PER_S, 4)
            v["cost_note"] = f"free open-source voice; ~{server_s:.0f} s of server time"
            v["monthly"] = ""
        else:
            factor = 0.5 if "flash" in str(v.get("model", "")) or "turbo" in str(v.get("model", "")) else 1.0
            v["cost_usd"] = round(chars * rate * factor, 4)
            v["cost_note"] = f"{chars:,} characters, the whole narration"
            v["monthly"] = MONTHLY["elevenlabs"]
    for s in data.get("solutions", []):
        if s.get("status") != "done":
            continue
        renderer = str(s.get("renderer", ""))
        s["cost"] = {
            "making": round(float(s.get("render_s") or 0) * CLOUD_PER_S, 4),
            "claude": round(float(s.get("claude_usd") or 0), 4),
            "licence": 0.0,
            "licence_note": "$0 now (Remotion is free for up to 3 people)" if renderer.startswith("remotion")
            else LICENCE.get(renderer, "free"),
            "monthly": [MONTHLY["remotion"]] if renderer.startswith("remotion") else [],
        }
    return data


CHECKED = "5 Nov 2026"   # when the plans below were checked on the providers' pages
SUBSCRIPTIONS = [   # service, plan, price a month, what it allows, what it is for
    ("Claude (AWS Bedrock, EU)", "Pay per use, no subscription", "per request", "No plan limit; our cap: DAILY_BUDGET_USD a day",
     "Content of every video"),
    ("Cloud server (AWS Fargate, 2 CPUs, 4 GB)", "Pay per use", "about $0.11 an hour", "No limit", "Making the videos"),
    ("Kokoro, HTML slides, Manim, Revideo, Motion Canvas, HyperFrames", "Free, open source", "$0", "No limit",
     "Narrator / video tool"),
    ("ElevenLabs", "Starter", "$6", "30,000 characters (about 33 min of narration)", "Narrator"),
    ("ElevenLabs", "Creator", "$22", "121,000 characters (about 2 hours)", "Narrator"),
    ("ElevenLabs", "Pro", "$99", "600,000 characters (about 11 hours)", "Narrator"),
    ("ElevenLabs", "Scale", "$299", "1,800,000 characters (about 33 hours)", "Narrator"),
    ("Remotion", "Free licence", "$0", "Companies of up to 3 people", "Video tool (Remotion, Remotion Pro)"),
    ("Remotion", "Company: Automators", "at least $100", "$0.01 a video (the $100 covers 10,000 videos)", "Videos rendered by code"),
    ("Remotion", "Company: Creators", "$25 a person", "Per person who writes Remotion code", "Building the video templates"),
]


def cost_report(folder: Path | None, data: dict, content_usd_per_min: float | None = None) -> dict:
    """What each step of making a video costs, for one minute of video (not a whole video: content, narrator,
    making, licence each with their options), and the subscriptions the tools need. The safety
    margin (COST_MARGIN_PCT) is included. Without a comparison (folder None) the tools' times are left out.
    content_usd_per_min: Claude's cost a minute measured over every result made (else this comparison's)."""
    if folder and "cost_content" not in data:
        video_costs(folder, data)
    m = 1 + config.COST_MARGIN_PCT / 100
    minutes = max(float(data.get("minutes") or 1), 0.1)
    per = lambda usd: round(usd / minutes * m, 4)   # noqa: E731 - a minute of video, margin in
    content = content_usd_per_min * m if content_usd_per_min is not None else per(float(data.get("cost_content") or 0))
    steps = [{"step": "Content", "option": "Claude (AWS Bedrock)",
              "what": "Finds the material in the recordings, writes the script and the slides, checks them",
              "usd": round(content, 4), "note": "The same whatever tool makes the video"}]
    voices = data.get("voices", [])
    eleven = next((v for v in voices if v["engine"] == "elevenlabs" and v.get("parts") == v.get("of")), None) \
        or next((v for v in voices if v["engine"] == "elevenlabs"), None)
    kokoro = [v for v in voices if v["engine"] == "kokoro"]
    steps.append({"step": "Narrator", "option": "ElevenLabs", "what": "The voice reads the script",
                  "usd": per(float(eleven.get("cost_usd") or 0)) if eleven and eleven.get("parts") == eleven.get("of")
                  else round(900 * config.ELEVENLABS_USD_PER_1K_CHARS / 1000 * m, 4),
                  "note": f"About 900 characters a minute at ${config.ELEVENLABS_USD_PER_1K_CHARS:g} per 1,000 (Pro plan)"})
    steps.append({"step": "Narrator", "option": "Kokoro", "what": "The voice reads the script",
                  "usd": per(max((float(v.get("cost_usd") or 0) for v in kokoro), default=0.0)) if kokoro
                  else round(KOKORO_RTF * 60 * CLOUD_PER_S * m, 4),
                  "note": "Free open-source voice; only the server's time"})
    seen = set()
    for s in data.get("solutions", []):
        if s.get("status") != "done" or s.get("hidden") or s.get("group") in seen:
            continue
        seen.add(s.get("group"))
        render_min = float(s.get("render_s") or 0) / 60 / minutes
        steps.append({"step": "Making the video", "option": s.get("group", s["id"]),
                      "what": "Drawing the slides, adding the voice, putting it together (a cloud server)",
                      "usd": per(float(s.get("render_s") or 0) * CLOUD_PER_S),
                      "note": f"About {render_min:.1f} min of server time a minute of video (measured on this laptop)"})
    if not seen:   # no comparison: one estimate for any tool
        steps.append({"step": "Making the video", "option": "Any tool",
                      "what": "Drawing the slides, adding the voice, putting it together (a cloud server)",
                      "usd": round(90 * CLOUD_PER_S * m, 4), "note": "About 1.5 min of server time a minute of video (estimate)"})
    steps.append({"step": "Licence", "option": "Remotion, Remotion Pro", "what": "Using the video tool",
                  "usd": 0.0, "note": "$0 now (free for up to 3 people); a company pays at least $100 a month (below)"})
    steps.append({"step": "Licence", "option": "Every other tool", "what": "Using the video tool", "usd": 0.0,
                  "note": "Open source: free, no limit"})
    return {"steps": steps, "subscriptions": [dict(zip(("service", "plan", "price", "limit", "for"), r, strict=True))
                                              for r in SUBSCRIPTIONS],
            "checked": CHECKED, "margin_pct": config.COST_MARGIN_PCT, "minutes": round(minutes, 2)}


# --- 3. run ----------------------------------------------------------------------------------------
def _save(folder: Path, data: dict) -> None:
    store.write_json(folder / "comparison.json", data)


def run(folder: Path, only: list[str] | None = None, redo: set[str] | None = None, source: Path | None = None,
        add_voices: list[Path] | None = None, voice: str = "") -> dict:
    data = store.read_json(folder / "comparison.json", {}) or {}
    sb = storyboard.load(folder)
    try:   # the company's pictures not marked yet: marked by Claude now (no clicking needed)
        import company_avatar
        for name in company_avatar.mark_all():
            log.info("Company avatar %s marked (%s)", name, (company_avatar.load(name) or {}).get("by", ""))
    except Exception as e:   # noqa: BLE001 - the other solutions go on
        log.warning("Company avatars not marked: %s", e)
    state = data.setdefault("state", {})
    old_voices = {v["id"]: v for v in data.get("voices", [])}
    before_ref = data.get("default_voice", "")
    if voice:
        state["voice"] = voice
    if "animated" not in state:   # split like the source, so its ElevenLabs parts fit
        state["animated"] = animated_like(source, sb) if source else True
    plan = beats(sb, state["animated"])
    # narrators
    voices = [v for v in data.get("voices", []) if v["id"].startswith("elevenlabs-made")]
    for v in voices:   # the name from the files themselves (an earlier version took it from .env)
        src = Path(v.get("source") or data.get("source") or "-")
        if src.exists():
            v.setdefault("source", str(src))
            name = source_parts(src, plan)[2] or voice_name_of(src)
            if name and name != v.get("name"):
                v.update(name=name, who=ELEVEN_WHO.get(name.lower(), ""))
    if source and not any(v["id"] == "elevenlabs-made" for v in voices):
        made = existing_eleven(folder, source, plan)
        voices = ([made] if made else []) + voices
    for extra in add_voices or []:   # the same video made with another ElevenLabs voice
        extra = Path(extra).resolve()
        if any(v.get("source") == str(extra) for v in voices):
            continue
        if not (extra / "audio").exists():
            log.warning("%s: no audio folder (not a video made with a voice)", extra)
            continue
        made = existing_eleven(folder, extra, plan, vid=f"elevenlabs-made-{store.slugify(extra.name, 30)}")
        if made:
            voices.append(made)
    voices += kokoro_voices(folder, plan)
    new = new_eleven(folder, plan, state)
    if new:
        voices.append(new)
    if not voices:
        raise RuntimeError("No narrator could be made (Kokoro missing and no ElevenLabs voice): uv run tts.py --download")
    slot = slots(folder, plan, voices)
    tracks(folder, plan, voices, slot)
    # the voice the slide videos carry: the one asked for (--voice), else the first one with every part
    want = str(state.get("voice") or "").lower()
    reference = next((v["id"] for v in voices if want and want in (v["id"].lower(), v.get("name", "").lower())
                      and v["parts"] == v["of"]), None) \
        or next((v["id"] for v in voices if v["parts"] == v["of"]), voices[0]["id"])
    for v in voices:
        v["price"] = VOICE_PRICE[v["engine"]]
        v["label"] = voice_label(v)
        if v.get("make_s") is None and (old_voices.get(v["id"]) or {}).get("make_s") is not None:
            v["make_s"] = old_voices[v["id"]]["make_s"]
    data.update(voices=voices, default_voice=reference, seconds=round(sum(slot) / RATE, 1), parts=len(plan),
                scenes=len(sb["scenes"]), title=sb.get("title", data.get("title", "")))
    _save(folder, data)
    full = [v for v in voices if v["parts"] == v["of"]]
    cache: dict[str, dict] = {}

    def fixed_for(vid: str) -> dict:
        if vid not in cache:
            cache[vid] = fixed_audio(folder, plan, vid, slot)
        return cache[vid]

    def first_voice(sol: dict) -> str:
        ids = [v["id"] for v in voices_for(sol, full)]
        return reference if reference in ids else (ids[0] if ids else reference)

    def made(sol: dict, vid: str, name: str = "", look: dict | None = None) -> tuple[Path, float]:
        """A video and what Claude cost while it was made (checks some tools run)."""
        import llm
        mark = llm.meter_mark()
        try:
            out = render(folder, sol, fixed_for(vid), state["animated"], name=name, **({"look": look} if look else {}))
        finally:
            claude = sum(float(c.get("cost_usd") or 0) for c in llm.calls_since(mark) if c.get("step") != "voice")
        return out, claude

    # solutions: first one video each (a presenter: with a voice that fits it)
    before = {s["id"]: s for s in data.get("solutions", [])}
    every = solutions()
    asked = set(only or default_ids())   # what this run makes; videos made before for the others stay
    rows = []
    for sol in every:
        old = before.get(sol["id"], {})
        if sol["id"] not in (only or default_ids()):   # not asked this time: a video made before stays and is shown
            rows.append({**(old or {**{k: v for k, v in sol.items() if k != "set"}, "status": "not asked"}),
                         "hidden": old.get("status") != "done"})
            continue
        talks = sol.get("talks")
        if talks and old.get("status") == "done" and not old.get("voice"):
            old["voice"] = before_ref or reference   # made before narrators could be picked: the voice it had
        fits = not talks or old.get("voice") in [v["id"] for v in voices_for(sol, full)]
        if old.get("status") == "done" and (folder / old.get("file", "-")).exists() and sol["id"] not in (redo or set()) \
                and fits:
            rows.append({**old, "hidden": False})
            continue
        row = {**{k: v for k, v in sol.items() if k != "set"}}
        log.info("=== %s%s", sol["group"], f" – {sol['variant']}" if sol.get("variant") else "")
        t0 = time.perf_counter()
        vid = first_voice(sol) if talks else reference
        try:
            out, claude = made(sol, vid)
            row.update(status="done", file=out.relative_to(folder).as_posix(), seconds=round(media.duration_s(out), 1),
                       render_s=round(time.perf_counter() - t0), size_mb=round(out.stat().st_size / 1e6, 1),
                       note=sol.get("note", ""), presenter=sol.get("presenter", ""), claude_usd=round(claude, 4))
            if talks:
                row.update(voice=vid, by_voice={vid: row["file"]})
            log.info("%s -> %s (%s s)", sol["id"], out.name, row["render_s"])
        except Skipped as e:
            row.update(status="skipped", reason=str(e)[:300])
            log.warning("%s skipped: %s", sol["id"], e)
        except Exception as e:   # noqa: BLE001 - one solution failing must not stop the others
            row.update(status="failed", reason=f"{type(e).__name__}: {e}"[:400])
            log.error("%s failed: %s", sol["id"], str(e)[:400])
        rows.append(row)
        data["solutions"] = rows + [before[s["id"]] for s in every[len(rows):] if s["id"] in before]
        _save(folder, data)
    data["solutions"] = rows
    _save(folder, data)
    # then each presenter with every other narrator that fits it (so the mouth follows the voice picked)
    by_id = {s["id"]: s for s in every}
    for row in rows:
        sol = by_id[row["id"]]
        if not sol.get("talks") or row["id"] not in asked or row.get("status") != "done":
            continue
        by = row.setdefault("by_voice", {row.get("voice") or reference: row["file"]})
        todo = [v for v in voices_for(sol, full) if not (by.get(v["id"]) and (folder / by[v["id"]]).exists())]
        for k, v in enumerate(todo, 1):
            log.info("=== %s with %s (%d of %d)", sol["id"], v["label"], k, len(todo))
            try:
                out, _ = made(sol, v["id"], name=f"{sol['id']}--{v['id']}")
                by[v["id"]] = out.relative_to(folder).as_posix()
                row.get("voice_errors", {}).pop(v["id"], None)
            except Exception as e:   # noqa: BLE001 - noted; --resume makes it later
                row.setdefault("voice_errors", {})[v["id"]] = f"{type(e).__name__}: {e}"[:200]
                log.error("%s with %s failed: %s", sol["id"], v["label"], str(e)[:300])
            _save(folder, data)
    # then the other looks of each solution: the same content, voice and timing, drawn another way. First
    # each solution's look with one narrator, then (presenters) the look with every other narrator
    def look_video(row: dict, sol: dict, lk: dict, vid: str | None) -> None:
        talks = sol.get("talks")
        store_in = row.setdefault("by_look_voice", {}).setdefault(lk["id"], {}) if talks else row.setdefault("by_look", {})
        key = vid if talks else lk["id"]
        again = f"{sol['id']}:{lk['id']}" in (redo or set()) or sol["id"] in (redo or set())
        if store_in.get(key) and (folder / store_in[key]).exists() and not again:
            return
        name = f"{sol['id']}--{lk['id']}" + (f"--{vid}" if talks else "")
        log.info("=== %s, look %s%s", sol["id"], lk["name"], f", {vid}" if talks else "")
        t0 = time.perf_counter()
        errors = row.setdefault("look_errors", {})
        try:
            out, _ = made(sol, vid or reference, name=name, look=lk)
            store_in[key] = out.relative_to(folder).as_posix()
            row.setdefault("look_render_s", {})[lk["id"]] = round(time.perf_counter() - t0)
            errors.pop(lk["id"] if not talks else f"{lk['id']}:{vid}", None)
        except Exception as e:   # noqa: BLE001 - noted; --resume makes it later
            errors[lk["id"] if not talks else f"{lk['id']}:{vid}"] = f"{type(e).__name__}: {e}"[:300]
            log.error("%s, look %s failed: %s", sol["id"], lk["id"], str(e)[:300])
        _save(folder, data)

    todo = []
    for row in rows:
        sol = by_id[row["id"]]
        looks = looks_of(sol)
        if len(looks) < 2 or row["id"] not in asked or row.get("status") != "done":
            continue
        row["looks"] = [{k: v for k, v in lk.items() if k != "set"} for lk in looks]
        if sol.get("talks"):
            voices_here = [v["id"] for v in voices_for(sol, full)]
            first = row.get("voice") if row.get("voice") in voices_here else (voices_here or [reference])[0]
            todo += [(row, sol, lk, first) for lk in looks[1:]]
        else:
            row.setdefault("by_look", {})[looks[0]["id"]] = row["file"]
            todo += [(row, sol, lk, None) for lk in looks[1:]]
    for row, sol, lk, vid in todo:
        look_video(row, sol, lk, vid)
    for row, sol, lk, first in [x for x in todo if x[3]]:   # presenters: the look with the other narrators
        for v in voices_for(sol, full):
            if v["id"] != first:
                look_video(row, sol, lk, v["id"])
    shutil.rmtree(folder / "work", ignore_errors=True)
    return data


def voices_for(sol: dict, voices: list[dict]) -> list[dict]:
    """The narrators a presenter may speak with: a woman's voices for a woman, a man's for a man; a cartoon
    animal any. Only full narrations (every part spoken)."""
    full = [v for v in voices if v.get("parts") == v.get("of")]
    who = sol.get("who")
    return [v for v in full if not who or v.get("who") == who]


def summary(data: dict) -> str:
    lines = [f"\n{data.get('title', '')}: {data.get('seconds', 0):.0f} s, {data.get('parts', 0)} parts", "",
             "Narrators: " + "; ".join(v["label"] for v in data.get("voices", []))]
    for s in data.get("solutions", []):
        name = s["group"] + (f" – {s['variant']}" if s.get("variant") else "")
        lines.append(f"  {s.get('status', ''):<9} {name}" + (f": {s['reason']}" if s.get("reason") else
                                                             f" ({s.get('render_s', 0)} s to make)" if s.get("status") == "done" else ""))
    return "\n".join(lines)


def latest() -> Path:
    found = sorted(config.OUTPUT_DIR.glob("*-compare-*/comparison.json"))
    if not found:
        raise FileNotFoundError("No comparison yet: uv run compare_video.py")
    return found[-1].parent


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("topic", nargs="?", help="new content on this topic (otherwise the newest ElevenLabs video)")
    ap.add_argument("--general", action="store_true", help="with a topic the recordings don't cover")
    ap.add_argument("--slides", type=int, default=7, help="with a topic: number of slides (default 7)")
    ap.add_argument("--from", dest="source", type=Path, help="a video folder: its content and its ElevenLabs voice")
    ap.add_argument("--resume", action="store_true", help="finish the newest comparison (only what is missing or failed)")
    ap.add_argument("--folder", type=Path, help="finish this comparison folder")
    ap.add_argument("--only", help=f"comma-separated solution ids: {', '.join(IDS)}, company-<avatar>")
    ap.add_argument("--redo", help="comma-separated solution ids to make again; <id>:<look> for one look only "
                                   "(e.g. remotion:editorial)")
    ap.add_argument("--voice", default="", help="the narrator the videos (and the presenters' lips) follow, e.g. "
                    "George or kokoro-heart (default: the voice already made); with --redo for videos made before")
    ap.add_argument("--shrink", action="store_true", help="make the big videos smaller and give each a still (the page "
                    "loads faster, also through a shared link); nothing is rendered again")
    ap.add_argument("--add-voice", action="append", type=Path, default=[], metavar="FOLDER",
                    help="the same video made with another ElevenLabs voice: added to the narrators (no credits); "
                         "may be given several times")
    args = ap.parse_args()
    config.setup_logging()
    only = [x.strip() for x in (args.only or "").split(",") if x.strip()] or None
    redo = {x.strip() for x in (args.redo or "").split(",") if x.strip()}
    ids = [s["id"] for s in solutions()]
    with_looks = {f"{s['id']}:{lk['id']}" for s in solutions() for lk in looks_of(s)}
    bad = [x for x in (only or []) if x not in ids] + [x for x in sorted(redo) if x not in ids and x not in with_looks]
    if bad:
        ap.error(f"unknown solution id(s) {bad}; use {', '.join(ids)} (looks: {', '.join(sorted(with_looks))})")
    if args.shrink:
        done = shrink_all()
        print(f"{len(done)} video(s) made smaller" + "".join(f"\n  {d}" for d in done) + "\nStills made for the page.")
        return 0
    try:
        source = None
        reuse = bool(args.resume or args.folder)
        if not reuse and only and not args.topic and not args.source:   # --only adds to the newest comparison
            reuse = any(config.OUTPUT_DIR.glob("*-compare-*/comparison.json"))
        if reuse:
            folder = Path(args.folder).resolve() if args.folder else latest()
            src = (store.read_json(folder / "comparison.json", {}) or {}).get("source", "")
            source = Path(src) if src and Path(src).exists() else None
        elif args.topic:
            import deck_video
            planned = deck_video.plan(args.topic, args.slides, args.general)
            folder = new_folder(storyboard.load(planned), f"new content: {args.topic}")
        else:
            source = Path(args.source).resolve() if args.source else newest_source()
            if not (source / "storyboard.json").exists():
                raise FileNotFoundError(f"No storyboard.json in {source}")
            log.info("Content and ElevenLabs voice from: %s", source.name)
            folder = new_folder(storyboard.load(source), str(source))
        data = run(folder, only, redo, source, args.add_voice, args.voice)
    except (FileNotFoundError, RuntimeError, ValueError) as e:
        log.error("%s", e)
        return 1
    print(summary(data))
    print(f"\nFolder: {folder}\nSee it: uv run app.py, tab Comparison. Not everything made? Fix it, then: "
          f"uv run compare_video.py --resume")
    return 0 if any(s.get("status") == "done" for s in data["solutions"]) else 1


if __name__ == "__main__":
    code = main()
    import usage
    usage.report()
    sys.exit(code)
