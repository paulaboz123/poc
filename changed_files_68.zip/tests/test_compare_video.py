"""compare_video.py: the same content in every tool on one timeline, the ElevenLabs parts already made
reused (never spoken again), Kokoro voices, a new ElevenLabs voice that stops at the credit limit,
solutions that can't run noted while the others go on, and --resume finishing only what is missing."""
from __future__ import annotations

import os
import sys
import time

import numpy as np
import pytest
from conftest import needs_ffmpeg

import compare_video
import config
import media
import store
import tts

SB = {"title": "Snowflake in three slides", "goal": "What it is", "style": "illustrated", "level": "beginner",
      "minutes": 1, "scenes": [
          {"visual": "title", "heading": "Snowflake", "narration": "Snowflake is a data cloud for analytics."},
          {"visual": "cards", "heading": "Three layers", "narration": "Storage keeps the data. Compute runs the queries.",
           "elements": [{"title": "Storage", "detail": "files"}, {"title": "Compute", "detail": "warehouses"}]},
          {"visual": "bullets", "heading": "Key takeaways", "narration": "Pay for what you use and share data safely.",
           "items": ["Pay per use", "Share safely"]}]}


@pytest.fixture
def voices(monkeypatch):
    """A tone per voice, each voice at its own speed (so the common timeline matters); the given audio
    when TTS_ENGINE=fixed; ElevenLabs counted."""
    spoken = []
    monkeypatch.setattr(config, "ELEVENLABS_API_KEY", "")   # the person's .env never reaches the tests

    def synthesize(text, voice=None, context=None):
        if config.TTS_ENGINE == "fixed":
            return tts.FIXED[text]
        who = voice or (config.ELEVENLABS_VOICE if config.TTS_ENGINE == "elevenlabs" else config.TTS_VOICE)
        spoken.append((config.TTS_ENGINE, who, text))
        rate = 24000
        speed = 0.25 + (sum(map(ord, str(who))) % 4) * 0.05
        n = int(len(text.split()) * speed * rate)
        return (0.1 * np.sin(np.arange(n) / rate * 2 * np.pi * 220)).astype(np.float32), rate
    monkeypatch.setattr(tts, "synthesize", synthesize)
    real_check = tts.check
    monkeypatch.setattr(tts, "check", lambda e=None: (True, "test") if e == "kokoro" else real_check(e))
    return spoken


def _source(with_parts: bool = True):
    """A video made earlier with ElevenLabs: its storyboard and one voice file per part, in order."""
    folder = config.OUTPUT_DIR / "20261104-100000-snowflake-video-1m"
    store.write_json(folder / "storyboard.json", SB)
    store.write_json(folder / "info.json", {"tts": "ElevenLabs eleven_multilingual_v2 (cloud)"})
    plan = compare_video.beats(SB)
    if with_parts:
        for n in range(len(plan)):
            f = folder / "audio" / f"voice_{n:016x}.wav"
            f.parent.mkdir(parents=True, exist_ok=True)
            tts._write_wav(f, np.full(int((1.0 + n) * 24000), 0.05, dtype=np.float32), 24000)
            os.utime(f, (time.time() + n, time.time() + n))   # made in order
    return folder, plan


def test_the_newest_elevenlabs_video_is_the_source_and_its_parts_are_reused(project, voices):
    src, plan = _source()
    assert compare_video.newest_source() == src
    folder = compare_video.new_folder(SB, str(src))
    made = compare_video.existing_eleven(folder, src, plan)
    assert made["parts"] == len(plan) and not made["note"]
    assert made["label"].startswith("ElevenLabs \u2013 ") and "made" not in made["label"]   # no "already made" for business
    assert voices == []                                                   # nothing spoken again: no credits
    for n in range(len(plan)):
        assert compare_video._beat_file(folder, "elevenlabs-made", n).exists()


def test_every_voice_and_every_video_share_one_timeline(project, voices):
    src, plan = _source()
    folder = compare_video.new_folder(SB, str(src))
    vs = [compare_video.existing_eleven(folder, src, plan)] + compare_video.kokoro_voices(folder, plan)
    assert [v["id"] for v in vs][1:] == [k[0] for k in compare_video.KOKORO]
    assert {v["who"] for v in vs[1:]} == {"woman", "man"}
    slot = compare_video.slots(folder, plan, vs)
    for n in range(len(plan)):                                            # the longest voice fits every part
        assert slot[n] == max(len(compare_video._part_samples(folder, v["id"], n)) for v in vs)
    compare_video.tracks(folder, plan, vs, slot)
    total = sum(slot) / compare_video.RATE
    for v in vs:
        assert abs(media.stream_durations(folder / v["file"])["audio"] - total) < 0.15
    fixed = compare_video.fixed_audio(folder, plan, vs[0]["id"], slot)
    for n, (_, b) in enumerate(plan):   # what the videos are drawn with: the lead and the pause around it = the slot
        body, rate = fixed[b["text"]]
        assert len(body) + int(0.15 * rate) + int(b["pause"] * rate) == slot[n]
    assert compare_video.slots(folder, plan, vs + [{"id": "x"}]) == slot   # fixed once written


def test_a_new_elevenlabs_voice_stops_at_the_credit_limit_without_an_error(project, voices, monkeypatch):
    import usage
    _, plan = _source(with_parts=False)
    folder = compare_video.new_folder(SB, "test")
    monkeypatch.setattr(config, "ELEVENLABS_API_KEY", "x")
    monkeypatch.setattr(compare_video, "_used_eleven_voices", lambda: {tts.eleven_voice_id("brian"), tts.eleven_voice_id("lily")})
    left = {"n": 70}

    def quota(refresh=False):
        return {"used": 0, "limit": 1000, "left": left["n"], "resets": "", "tier": "", "status": "", "source": "test"}
    monkeypatch.setattr(usage, "elevenlabs", quota)
    real = tts.speak_to_wav

    def speak(text, out, pause_after_s=0.45, voice=None, context=None):
        left["n"] -= len(tts.clean_for_speech(text)) // 2            # flash: half a credit a character
        return real(text, out, pause_after_s, voice, context)
    monkeypatch.setattr(tts, "speak_to_wav", speak)
    state = {}
    new = compare_video.new_eleven(folder, plan, state)
    assert new and state["new_voice"] == "alice" and state["new_model"] == "eleven_flash_v2_5"   # not used before
    assert 1 <= new["parts"] < len(plan) and "credits" in new["note"] and "first" in new["label"]
    assert all(e == "elevenlabs" and who == "alice" for e, who, _ in voices)
    again = compare_video.new_eleven(folder, plan, state)                  # resume: nothing more, no error
    assert again["parts"] == new["parts"]


def test_resume_makes_only_what_is_missing(project, voices, monkeypatch):
    src, plan = _source()
    folder = compare_video.new_folder(SB, str(src))
    calls = []

    def fake_render(folder_, sol, fixed, animated=True, name=""):
        calls.append(sol["id"])
        if sol["id"] == "manim":
            raise RuntimeError("Manim crashed")
        if sol["id"] == "revideo":
            raise compare_video.Skipped("Node.js not found")
        out = folder_ / "videos" / f"{sol['id']}.mp4"
        out.parent.mkdir(exist_ok=True)
        media._run([config.FFMPEG, "-y", "-loglevel", "error", "-f", "lavfi", "-i", "color=white:s=64x36:d=1",
                    "-pix_fmt", "yuv420p", str(out)])
        return out
    monkeypatch.setattr(compare_video, "render", fake_render)
    data = compare_video.run(folder, ["html", "manim", "revideo"], None, src)
    st = {s["id"]: s["status"] for s in data["solutions"]}
    assert st["html"] == "done" and st["manim"] == "failed" and st["revideo"] == "skipped" and st["remotion"] == "not asked"
    assert "Manim crashed" in next(s["reason"] for s in data["solutions"] if s["id"] == "manim")
    assert data["default_voice"] == "elevenlabs-made" and len(data["voices"]) == 5
    calls.clear()
    data = compare_video.run(folder, ["html", "manim"], None, None)        # resume: html is done
    assert calls == ["manim"] and data["voices"][0]["id"] == "elevenlabs-made"
    calls.clear()
    compare_video.run(folder, ["html"], {"html"}, None)                    # --redo
    assert calls == ["html"]
    monkeypatch.setattr(sys, "argv", ["compare_video.py", "--only", "nope"])
    with pytest.raises(SystemExit):
        compare_video.main()


@needs_ffmpeg
@pytest.mark.slow(900)   # drawn in a browser
def test_real_videos_on_the_common_timeline(project, voices, monkeypatch):
    pytest.importorskip("playwright")
    src, plan = _source()
    folder = compare_video.new_folder(SB, str(src))
    data = compare_video.run(folder, ["html", "cartoon-fox"], None, src)
    st = {s["id"]: s for s in data["solutions"]}
    want = data["seconds"]
    for sid in ("html", "cartoon-fox"):
        assert st[sid]["status"] == "done", st[sid].get("reason")
        d = media.stream_durations(folder / st[sid]["file"])
        assert abs(d["video"] - want) < 0.6 and abs(d["audio"] - want) < 0.6, (sid, d, want)
    assert not (folder / "work").exists()


def test_the_parts_are_split_like_the_source_so_its_voice_fits(project, voices):
    sb = {**SB, "scenes": [SB["scenes"][0], {**SB["scenes"][1], "animation": "build",
                                            "narration": "Two layers. Storage keeps the data in files. Compute runs the queries fast.",
                                            "beats": ["Two layers.", "Storage keeps the data in files.", "Compute runs the queries fast."]},
                           SB["scenes"][2]]}
    assert len(compare_video.beats(sb, True)) == 5 and len(compare_video.beats(sb, False)) == 3
    folder = config.OUTPUT_DIR / "20261104-100000-split-video-1m"
    for n in range(3):   # made with ANIMATION=no: one part a scene
        f = folder / "audio" / f"voice_{n:016x}.wav"
        f.parent.mkdir(parents=True, exist_ok=True)
        tts._write_wav(f, np.zeros(24000, dtype=np.float32), 24000)
        os.utime(f, (time.time() + n, time.time() + n))
    assert compare_video.animated_like(folder, sb) is False
    for n in range(3, 5):
        tts._write_wav(folder / "audio" / f"voice_{n:016x}.wav", np.zeros(24000, dtype=np.float32), 24000)
    assert compare_video.animated_like(folder, sb) is True


def test_a_second_elevenlabs_voice_already_made_is_added_by_its_name(project, voices, monkeypatch):
    """George was the source; the same video made with Lily is added later: no credits, its real name,
    fitted into the timeline the videos already have."""
    src, plan = _source()
    folder = compare_video.new_folder(SB, str(src))
    monkeypatch.setattr(compare_video, "render", lambda *a, **k: (_ for _ in ()).throw(compare_video.Skipped("test")))
    compare_video.run(folder, ["html"], None, src)
    slot = compare_video.slots(folder, plan, [])
    lily = config.OUTPUT_DIR / "20261104-110000-snowflake-video-1m"
    store.write_json(lily / "storyboard.json", SB)
    with compare_video.settings(TTS_ENGINE="elevenlabs", ELEVENLABS_VOICE="lily"):
        fp = compare_video.make_video.voice_fingerprint()
    import hashlib
    for n, (_, b) in enumerate(plan):   # named the way make_video names Lily's parts; one longer than its place
        key = hashlib.sha1(f"{fp}|{b.get('voice') or ''}|{b['pause']}|{b['text']}".encode()).hexdigest()[:16]
        f = lily / "audio" / f"voice_{key}.wav"
        f.parent.mkdir(parents=True, exist_ok=True)
        n_s = int(slot[n] * (1.15 if n == 0 else 0.8) / compare_video.RATE * 24000)
        tts._write_wav(f, (0.2 * np.sin(np.arange(n_s) / 24000 * 2 * np.pi * 200)).astype(np.float32), 24000)
    data = compare_video.run(folder, ["html"], None, None, [lily])
    added = [v for v in data["voices"] if v.get("source") == str(lily.resolve())]
    assert len(added) == 1 and added[0]["name"] == "Lily" and added[0]["who"] == "woman" and not added[0]["note"]
    assert compare_video.slots(folder, plan, []) == slot                           # the videos' timeline is kept
    total = sum(slot) / compare_video.RATE
    assert abs(media.stream_durations(folder / added[0]["file"])["audio"] - total) < 0.15
    assert data["voices"][0]["id"] == "elevenlabs-made" and voices == [] or all(e != "elevenlabs" for e, _, _ in voices)
    other = config.OUTPUT_DIR / "20261104-120000-other-video-1m"           # different content: refused, no error
    (other / "audio").mkdir(parents=True)
    tts._write_wav(other / "audio" / "voice_x.wav", np.zeros(100, dtype=np.float32), 24000)
    data = compare_video.run(folder, ["html"], None, None, [other])
    assert not any(v.get("source") == str(other.resolve()) for v in data["voices"])


def test_a_voice_named_wrongly_before_gets_its_real_name(project, voices, monkeypatch):
    """An earlier version named the source's voice after .env (Lily) although it was George."""
    import hashlib
    src = config.OUTPUT_DIR / "20261104-090000-george-video-1m"
    store.write_json(src / "storyboard.json", SB)
    plan = compare_video.beats(SB)
    with compare_video.settings(TTS_ENGINE="elevenlabs", ELEVENLABS_VOICE="george"):
        fp = compare_video.make_video.voice_fingerprint()
    for _, b in plan:
        key = hashlib.sha1(f"{fp}|{b.get('voice') or ''}|{b['pause']}|{b['text']}".encode()).hexdigest()[:16]
        f = src / "audio" / f"voice_{key}.wav"
        f.parent.mkdir(parents=True, exist_ok=True)
        tts._write_wav(f, np.full(24000, 0.05, dtype=np.float32), 24000)
    monkeypatch.setattr(config, "ELEVENLABS_VOICE", "lily")
    folder = compare_video.new_folder(SB, str(src))
    monkeypatch.setattr(compare_video, "render", lambda *a, **k: (_ for _ in ()).throw(compare_video.Skipped("test")))
    data = compare_video.run(folder, ["html"], None, src)
    assert data["voices"][0]["name"] == "George" and data["voices"][0]["who"] == "man"
    data["voices"][0].update(name="Lily", label="ElevenLabs – Lily (already made)")   # as the old version saved it
    store.write_json(folder / "comparison.json", data)
    data = compare_video.run(folder, ["html"], None, None)
    assert data["voices"][0]["name"] == "George" and "George" in data["voices"][0]["label"]
    costs = compare_video.video_costs(folder, data)
    assert all("cost_usd" in v for v in costs["voices"]) and costs["cost_content"] >= 0


def test_presenters_get_a_video_per_fitting_narrator(project, voices, monkeypatch):
    """A woman presenter (a company avatar marked as a woman) speaks only with women's voices, a cartoon animal
    with any; each its own video, so the mouth follows the narrator picked. The solutions' first videos come
    before the extra narrators."""
    import company_avatar
    company_avatar.draw_demo("demo-anna", config.AVATARS_DIR / "demo-anna.png")
    company_avatar.save("demo-anna", {**company_avatar.guess(config.AVATARS_DIR / "demo-anna.png"), "who": "woman"})
    src, plan = _source()
    folder = compare_video.new_folder(SB, str(src))
    calls = []

    def fake_render(folder_, sol, fixed, animated=True, name=""):
        calls.append(name or sol["id"])
        out = folder_ / "videos" / f"{name or sol['id']}.mp4"
        out.parent.mkdir(exist_ok=True)
        media._run([config.FFMPEG, "-y", "-loglevel", "error", "-f", "lavfi", "-i", "color=white:s=64x36:d=1",
                    "-pix_fmt", "yuv420p", str(out)])
        return out
    monkeypatch.setattr(compare_video, "render", fake_render)
    only = ["html", "cartoon-fox", "company-demo-anna"]
    data = compare_video.run(folder, only, None, src)
    rows = {s["id"]: s for s in data["solutions"]}
    full = [v for v in data["voices"] if v["parts"] == v["of"]]
    women = {v["id"] for v in full if v["who"] == "woman"}
    assert calls[:3] == only                                                        # every solution first
    assert rows["company-demo-anna"]["voice"] in women and set(rows["company-demo-anna"]["by_voice"]) == women
    assert set(rows["cartoon-fox"]["by_voice"]) == {v["id"] for v in full} and "by_voice" not in rows["html"]
    assert all((folder / f).exists() for f in rows["cartoon-fox"]["by_voice"].values())
    assert all("new" not in v["label"] and "made" not in v["label"] for v in data["voices"])
    assert any("(woman, US)" in v["label"] for v in data["voices"])
    calls.clear()
    compare_video.run(folder, only, None, None)                                     # resume: everything is there
    assert calls == []
    assert "company-demo-anna" in compare_video.default_ids() and "cartoon-fox" in compare_video.DEFAULT_IDS
    assert not any(x in compare_video.IDS for x in ("did-woman", "tavus-man", "real3d-woman"))   # no real-looking people


def test_the_cost_of_a_video_made_from_scratch(project, voices, monkeypatch):
    """What a user would pay for one video made from nothing: Claude's planning and checks, the whole
    narration, the presenter for the whole video, the server's time. Reused parts are not free here;
    monthly fees are shown apart, not in one video's cost."""
    src, plan = _source()
    store.write_json(src / "run_card.json", {"cost": {"by_step": [
        {"step": "storyboard", "cost_usd": 0.05}, {"step": "rerank", "cost_usd": 0.01},
        {"step": "visual_review", "cost_usd": 0.02}, {"step": "voice", "cost_usd": 0.0}]}})
    folder = compare_video.new_folder({**SB, "plan_calls": [{"step": "storyboard", "cost_usd": 0.05},
                                                            {"step": "rerank", "cost_usd": 0.01}]}, str(src))
    data = {"source": str(src), "seconds": 120, "state": {"animated": True},
            "voices": [{"id": "elevenlabs-made", "engine": "elevenlabs", "name": "George", "who": "man", "parts": 3, "of": 3},
                       {"id": "elevenlabs-new", "engine": "elevenlabs", "name": "Alice", "who": "woman", "parts": 1,
                        "of": 3, "model": "eleven_flash_v2_5"},
                       {"id": "kokoro-heart", "engine": "kokoro", "name": "Heart", "who": "woman", "accent": "US",
                        "parts": 3, "of": 3, "make_s": 20.0}],
            "solutions": [{"id": "remotion", "renderer": "remotion", "status": "done", "render_s": 100, "claude_usd": 0.01},
                          {"id": "html", "renderer": "html", "status": "done", "render_s": 60}]}
    compare_video.video_costs(folder, data)
    assert data["cost_content"] == 0.08 and not data["cost_content_note"]          # planning + checks of the source
    assert data["cost_margin_pct"] == config.COST_MARGIN_PCT                         # added on the page, on top
    chars = sum(len(tts.clean_for_speech(b["text"])) for _, b in compare_video.beats(SB))
    george, alice, heart = data["voices"]
    assert george["cost_usd"] == round(chars * config.ELEVENLABS_USD_PER_1K_CHARS / 1000, 4) > 0
    assert alice["cost_usd"] == round(george["cost_usd"] / 2, 4)                   # the whole narration, flash rate
    assert "reused" not in george["cost_note"] and "$99" in george["monthly"]
    assert heart["label"] == "Kokoro \u2013 Heart (woman, US)" and 0 < heart["cost_usd"] < 0.01 and not heart["monthly"]
    rem, html = data["solutions"]
    assert rem["cost"]["licence"] == 0 and "$0 now" in rem["cost"]["licence_note"] and "$100 a month" in rem["cost"]["monthly"][0]
    assert rem["cost"]["claude"] == 0.01 and rem["cost"]["making"] > html["cost"]["making"] > 0
    assert html["cost"]["licence_note"] == "open source" and html["cost"]["monthly"] == []


def test_a_second_look_is_made_with_the_same_voice_and_picked_like_a_narrator(project, voices, monkeypatch):
    """Every tool also makes its video in a second look (the same content, voice and timing, drawn another
    way: Remotion editorial, the others VIDEO_LOOK=second); a presenter in the second look with every
    narrator that fits it; --resume makes only what is missing, --redo remotion:editorial only that look."""
    src, plan = _source()
    folder = compare_video.new_folder(SB, str(src))
    calls = []

    def fake_render(folder_, sol, fixed, animated=True, name="", look=None):
        calls.append((name or sol["id"], "".join((look or {}).get("set", {}).values())))
        out = folder_ / "videos" / f"{name or sol['id']}.mp4"
        out.parent.mkdir(exist_ok=True)
        media._run([config.FFMPEG, "-y", "-loglevel", "error", "-f", "lavfi", "-i", "color=white:s=64x36:d=1",
                    "-pix_fmt", "yuv420p", str(out)])
        return out
    monkeypatch.setattr(compare_video, "render", fake_render)
    data = compare_video.run(folder, ["html", "remotion", "cartoon-fox"], None, src)
    rows = {s["id"]: s for s in data["solutions"]}
    full = [v["id"] for v in data["voices"] if v["parts"] == v["of"]]
    n = len(full) - 1                                                              # the fox's other narrators
    assert [c[0] for c in calls[:3]] == ["html", "remotion", "cartoon-fox"]       # first videos, then the narrators
    assert calls[3 + n:6 + n] == [("html--second", "second"), ("remotion--editorial", "editorial"),
                                  (f"cartoon-fox--second--{rows['cartoon-fox']['voice']}", "second")]   # each look once
    assert len(calls) == 3 + n + 3 + n                                             # then the fox's look with the rest
    assert rows["remotion"]["by_look"] == {"classic": "videos/remotion.mp4", "editorial": "videos/remotion--editorial.mp4"}
    assert [lk["id"] for lk in rows["remotion"]["looks"]] == ["classic", "editorial"] and "set" not in rows["remotion"]["looks"][1]
    assert rows["html"]["by_look"]["second"] == "videos/html--second.mp4" and rows["html"]["looks"][1]["name"].startswith("Midnight")
    assert set(rows["cartoon-fox"]["by_look_voice"]["second"]) == set(full)        # the mouth follows each narrator
    calls.clear()
    compare_video.run(folder, ["html", "remotion", "cartoon-fox"], None, None)    # resume: all there
    assert calls == []
    compare_video.run(folder, ["html", "remotion", "cartoon-fox"], {"remotion:editorial"}, None)   # only that look
    assert calls == [("remotion--editorial", "editorial")]
    calls.clear()
    data = compare_video.run(folder, ["html"], None, None)                        # a later run for one tool only
    rows = {r["id"]: r for r in data["solutions"]}
    assert calls == [] and rows["remotion"]["hidden"] is False and rows["cartoon-fox"]["hidden"] is False   # still shown
    monkeypatch.setattr(sys, "argv", ["compare_video.py", "--resume", "--redo", "remotion:nope"])
    with pytest.raises(SystemExit):
        compare_video.main()



@needs_ffmpeg
def test_big_videos_are_made_smaller_with_a_still(project, monkeypatch):
    v = config.OUTPUT_DIR / "20261109-compare-x" / "videos" / "remotion-pro.mp4"
    v.parent.mkdir(parents=True)
    media._run([config.FFMPEG, "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc2=s=1280x720:d=4", "-f", "lavfi",
                "-i", "sine=f=220:d=4", "-c:v", "libx264", "-crf", "5", "-pix_fmt", "yuv420p", "-shortest", str(v)])
    before = v.stat().st_size
    monkeypatch.setattr(compare_video, "SHRINK_MB", before / 2e6)                 # "big" for this test
    assert compare_video.shrink_all() == ["20261109-compare-x/remotion-pro.mp4"]
    d = media.stream_durations(v)
    assert v.stat().st_size < before and abs(d["video"] - 4) < 0.3 and abs(d["audio"] - 4) < 0.3
    assert v.with_suffix(".jpg").exists() and compare_video.shrink_all() == []    # once is enough


def test_older_runs_of_the_same_content_stay_on_the_page():
    """A run with --only made a new comparison: the videos of the older one are still shown (merged)."""
    import app
    new = {"folder": "b", "source": "src", "title": "T", "voices": [{"id": "v1", "url": "/v1"}],
           "solutions": [{"id": "html", "status": "not asked"}, {"id": "remotion", "status": "done", "url": "/r2"},
                         {"id": "pro-woman", "status": "done", "url": "/p", "by_voice_url": {"v1": "/p1"}}]}
    old = {"folder": "a", "source": "src", "title": "T", "voices": [{"id": "v1", "url": "/old"}, {"id": "v2", "url": "/v2"}],
           "solutions": [{"id": "html", "status": "done", "url": "/h"}, {"id": "remotion", "status": "done", "url": "/r1"},
                         {"id": "manim", "status": "done", "url": "/m"},
                         {"id": "pro-woman", "status": "done", "url": "/p", "by_voice_url": {"v2": "/p2"}}]}
    other = {"folder": "c", "source": "other", "title": "U", "voices": [], "solutions": []}
    out = app.merged([new, other, old])
    assert [d["folder"] for d in out] == ["b", "c"]
    sol = {s["id"]: s for s in out[0]["solutions"]}
    assert sol["html"]["url"] == "/h" and sol["remotion"]["url"] == "/r2" and sol["manim"]["url"] == "/m"
    assert sol["pro-woman"]["by_voice_url"] == {"v1": "/p1", "v2": "/p2"}
    assert [v["id"] for v in out[0]["voices"]] == ["v1", "v2"] and out[0]["voices"][0]["url"] == "/v1"


def test_only_adds_to_the_newest_comparison(project, monkeypatch):
    """--only without --resume finishes the newest comparison instead of starting a new one."""
    import compare_video
    folder = config.OUTPUT_DIR / "20260101-000000-compare-x"
    folder.mkdir(parents=True)
    (folder / "comparison.json").write_text('{"solutions": [], "voices": []}')
    seen = {}
    monkeypatch.setattr(compare_video, "run", lambda f, only, *a, **k: seen.update(folder=f, only=only) or {"solutions": []})
    monkeypatch.setattr(compare_video, "summary", lambda d: "")
    monkeypatch.setattr(sys, "argv", ["compare_video.py", "--only", "html"])
    compare_video.main()
    assert seen == {"folder": folder, "only": ["html"]}
