# Documentation

| Document | Content |
|---|---|
| [ARCHITECTURE.md](ARCHITECTURE.md) | Components, request flow, knowledge base, deployment, security |
| [RAG_QUALITY.md](RAG_QUALITY.md) | Retrieval and answer grounding, quality measurement |
| [DEPLOY.md](DEPLOY.md) | CI/CD, Helm chart, configuration, operations |
| [MONITORING.md](MONITORING.md) | Metrics, answer evaluation in use, alerts |
| [COSTS.md](COSTS.md) | What is paid, how it is measured, cost controls |
| [TESTING.md](TESTING.md) | Test layers and commands |
| [EXPERIMENTS.md](EXPERIMENTS.md) | Optional renderers and voices (`experiments/`) |
| [ROADMAP.md](ROADMAP.md) | Open items |
