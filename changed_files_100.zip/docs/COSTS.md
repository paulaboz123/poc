# Costs

## What is paid

| Item | Paid | Notes |
|---|---|---|
| Claude on Amazon Bedrock (via Bifrost) | **yes**, per token | The only cost per request |
| Titan Text Embeddings v2 (pod) | yes, per token | Index build and one embedding per question; small |
| Kokoro voice, HTML slides, ffmpeg | no | Run in the pod |
| Cluster, gateway, ECR, Secrets Manager | shared platform | Charged to the platform, not per request |

## How cost is measured

Every model call is logged with its tokens (input, cached input, output) and cost in `cost_log.csv`; the price
per million tokens is set in `.env` (`PRICE_IN_PER_MTOK`, `PRICE_OUT_PER_MTOK`).

| Where | What |
|---|---|
| Page, tab **Prices & results** | Cost and tokens per result, cost by video length, spent today |
| Run card of each result | Model calls, tokens, cost, time |
| `uv run usage.py --steps` | Cost by step (understand, rerank, storyboard, review, ...) |
| `uv run costs_overview.py` | All results with tokens and cost |
| `uv run length_costs.py` | Measures one video per length |

Measured (Claude only): 1 min ≈ $0.20, 3 min ≈ $0.69, 5 min ≈ $1.04, 10 min ≈ $1.70, 15 min ≈ $2.27.
Re-measure with `length_costs.py` after a prompt or model change.

## Cost controls

| Control | Effect | Setting |
|---|---|---|
| Spending lock | Calls stop at the daily and per-run limit | `DAILY_BUDGET_USD` (default 20, max 100), `RUN_BUDGET_USD` (default 5) |
| Prompt caching | Repeated instructions and material read at 10% of the input price | `PROMPT_CACHE` |
| Result library | The same request returns the earlier result at no cost; 👎 removes it; "Make a new version" forces a new one | `LIBRARY` |
| Answer cache | The same question on the same material returns the earlier answer | `ANSWER_CACHE` |
| Self-review returns only its fixes | The storyboard is not written twice | `SELF_REVIEW=fixes` (default) |
| Off-topic gate | Requests outside the material stop before any paid call | always on |
