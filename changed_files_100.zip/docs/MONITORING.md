# Monitoring

Code: `monitoring.py`.

## Sources

| Source | Content |
|---|---|
| Page, tab **Prices & results** → *Quality and health* | Last 7 days: requests, failures, time per format, answer checks, judge score, votes |
| `python monitoring.py --days 7` | The same as Markdown tables |
| `/metrics` on port 9100 (Prometheus) | Counters only, no request text |
| Pod logs (JSON lines) | Every request and failure with its reason |
| `data/output/monitor.jsonl` | One line per request, answer and graded answer |

## Metrics

| Metric | Source |
|---|---|
| Requests by format and outcome; duration (median, p95) | Job worker |
| Model calls, tokens, cost by step; spend vs daily limit | `llm.py` |
| Queue length | Job worker |
| Results served from the library | `library.py` |
| Per answer: answered / not covered / refused / cached; sentences kept, corrected, removed | `answer.py` |
| Judge grading of a sample of answers (`EVAL_SAMPLE`) | `qa_eval.grounding` |
| 👍 / 👎 votes | Chat |

## Alert thresholds

Shared by the page (`monitoring.ATTENTION`) and the chart (`templates/monitoring.yaml`).

| Condition | Threshold |
|---|---|
| Failed requests | > 10% |
| Sentences removed by the answer check | > 15% |
| Judge score on the sample | < 0.9 |
| 👎 votes | > 20% |
| Daily spend | > 80% of the limit |
| App not responding | 10 minutes |
| Weekly test plan run (`evalCronJob`) | gate failed |

## Settings

| Setting | Default | Pod |
|---|---|---|
| `EVAL_SAMPLE` | 0 | 0.1 |
| `JUDGE_MODEL` | `REVIEW_MODEL`, else `CHAT_MODEL` | — |
| `METRICS_PORT` | 0 (off) | 9100 |
