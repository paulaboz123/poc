# Testing

## How to run

| What | Command | When |
|---|---|---|
| Product tests (offline, free) | `uv run pytest` (`-n auto` with `pytest-xdist` for all cores) | Every change |
| Code checks (style, types; rules in `ruff.toml`, `mypy.ini`) | `uv run --with ruff ruff check .`, `uv run --with mypy mypy` | Every change (also in CI) |
| Everything, incl. long renders | `uv run pytest -m "slow or not slow"` | Before a release |
| Experiment tests only | `uv run pytest -m experiment` | When changing `experiments/` |
| End to end with real Claude (~$1) | `uv run smoke.py` | Before a demo or release |
| Answer quality gate | `uv run qa_eval.py --set "<plan>.xlsx" --gate` | After a prompt, model or setting change |
| Lesson and video quality | `uv run evaluate.py` | After a storyboard or prompt change |
| Deployment files | `uv run tools/check_deploy.py --release proto-learning-agent` | Before pushing chart or CI changes |

Tests ignore the local `.env`: they always run with defaults. A test that exceeds its time limit writes its
stack to `pytest_timeout.log`.

## Layers

| Layer | What | Where |
|---|---|---|
| Deterministic | Parsing, checks, limits, routing, files, the page; a stand-in gateway (fake Claude, embeddings, cache) and voice, a temporary project per test | `tests/` |
| Real tools | ffmpeg, Chromium, Tesseract: renders, OCR, the page in a browser | `tests/` |
| Container and chart | Health checks, clean stop, JSON logs, sign-in header, image and chart agree | `tests/test_deploy.py`, CI `lint-chart` |
| Adversarial | Prompt injection, off-topic, unsafe requests, personal data, forbidden models | `test_guards`, `test_safeguards`, `test_off_topic` |
| Regression evaluation | Answer quality on a fixed test plan, judge calibration | `qa_eval.py`, `calibrate.py` |
| Live integration | Real gateway, models and keys | `smoke.py` |
| Production | Sampled judge grading, 👍/👎 | `docs/MONITORING.md` |

Model output is never asserted as exact text: tests check the code's decisions (what is kept, removed, cited,
refused, cached, charged); model quality is measured by the evaluation layers.
