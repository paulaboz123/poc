"""
app.py - Lesson Studio: a chat page for asking the training material, and showing it to others.

  uv run app.py            # opens http://localhost:8765 in the browser
  uv run app.py --port 9000 --no-browser

Tabs:
  Ask              one box: a question gets an answer with its sources; a request for a document,
                   slides, a video, a conversation or audio gets that (the request decides, ask.py).
                   Chats are kept (chats.py): the list on the left reopens an earlier one.
  Prices & results what each kind of request costs (costs.py: measured here, else estimated),
                   spend today and in total, every result with its links (videos, documents, slides)

It runs the same pipeline as ask.py (ask.run). One request is made at a time (rendering uses the
whole laptop). The server listens only on this computer (127.0.0.1) and serves only data/output.

Sharing with someone who has no copy of the project (e.g. the product owner):
  1. APP_PASSWORD=<something long> in .env (then the page asks for it; without it a shared link is refused)
  2. uv run app.py (restart it after changing .env): its first line must say "password on"
  3. VS Code > Ports > Forward a Port > 8765, right-click > Port Visibility > Public; send the
     address and the password. It works while this machine is on and app.py runs.
  Ask the data owner first: the results and the material's excerpts go through Microsoft's tunnel.
  Spending stays under DAILY_BUDGET_USD.

In a container or on a server (Dockerfile, docs/DEPLOY.md): uv run app.py --host 0.0.0.0 --no-browser
(APP_HOST=0.0.0.0). It then refuses to start without APP_PASSWORD. /status answers without signing in (health check).
"""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import hmac
import json
import logging
import mimetypes
import os
import queue
import re
import socket
import statistics
import sys
import threading
import time
import uuid
import webbrowser
from collections.abc import Callable, Iterator
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import ParseResult, parse_qs, quote, unquote, urlparse

import ask
import chats
import compare
import config
import lesson
import llm
import monitoring
import store
import storyboard

log = logging.getLogger("app")
SWITCHED = ("CHAT_MODEL", "CHAT_BACKEND", "TTS_ENGINE", "REVIEW_MODEL", "RENDERER", "TTS_VOICE", "ELEVENLABS_VOICE",
            "PRO_PRESENTER", "PRO_PERSON", "CARTOON_PRESENTER")   # what a job may change for itself
_before_job: dict = {}
JOBS: dict[str, dict] = {}
# Requests wait in line and are made one after another: the settings a request picks (model, voice, tool) are
# switched in config for its run (chosen()), so two at the same time would mix them. Nobody is turned away.
QUEUE: queue.Queue = queue.Queue()
_worker: threading.Thread | None = None
MAX_WAITING_PER_USER = 3


def _work_forever() -> None:
    while True:
        job = QUEUE.get()
        try:
            if STOPPING.is_set() or job["status"] == "stopped":   # app stopping / stopped on the page while waiting
                continue
            work(job)   # looked up on each run (tests replace it)
        except Exception:   # noqa: BLE001 - one broken job must not stop the line
            log.exception("Job %s failed outside its own handling", job.get("id"))
        finally:
            QUEUE.task_done()


def enqueue(job: dict) -> None:
    """Put a request in line; start the worker that makes them one at a time if it is not running."""
    global _worker
    QUEUE.put(job)
    if _worker is None or not _worker.is_alive():
        _worker = threading.Thread(target=_work_forever, name="job-worker", daemon=True)
        _worker.start()


def ahead_of(job: dict) -> int:
    """How many requests are made before this one (the one being made included)."""
    return sum(1 for j in JOBS.values() if j is not job and j["status"] in ("queued", "running")
               and j["started"] <= job["started"])
BUSY = threading.Lock()

# The formats as the person sees them: settings for ask.run, and how to ask for them in words
FORMATS: list[dict[str, Any]] = [
    {"id": "auto", "label": "Auto (from my words)", "settings": {},
     "how": "", "example": ""},
    {"id": "answer", "label": "Answer to a question", "settings": {"format": "answer"}, "kind": "answer",
     "how": "Ask a question: a short answer with the source of every sentence.", "example": "What is a left join?"},
    {"id": "document", "label": "Text lecture", "settings": {"format": "text"}, "kind": "document",
     "how": "Ask for something to read: a document, lecture notes, an explanation, a summary.",
     "example": "Write a document on the three Scrum roles, with a comparison table and a summary"},
    {"id": "slides", "label": "Presentation (PDF + PowerPoint)", "settings": {"format": "slides"}, "kind": "slides",
     "how": "Ask for a presentation or slides you will present yourself (PDF + PowerPoint with speaker notes).",
     "example": "A simple 6-slide presentation on sprint planning that I can present myself"},
    {"id": "silent", "label": "Animated slides (no voice)", "settings": {"format": "video"}, "kind": "video",
     "config": {"TTS_ENGINE": "silent"},
     "how": "Ask for animated slides without a voice (a video to watch at your own pace).",
     "example": "Animated slides on the sprint review, no voice, about 2 minutes"},
    {"id": "video", "label": "Slides with narrator", "settings": {"format": "video"}, "kind": "video",
     "how": "Ask for a video or an animated presentation with a voice. Add 'clean slides' or 'with illustrations' for the look.",
     "example": "A 2-minute video lesson on the daily scrum for beginners, with illustrations"},
    {"id": "dialogue", "label": "Two characters talking", "picker": False, "settings": {"format": "dialogue", "style": "dialogue"},
     "kind": "dialogue", "how": "Ask for two people or characters talking about the topic, a conversation or an interview.",
     "example": "A 3-minute video where two characters talk about the sprint review"},
    {"id": "presenter", "label": "Slides with presenter",
     "settings": {"format": "video", "style": "presenter", "characters": "cartoon"}, "kind": "video",
     "how": "Ask for a cartoon, an animated character or an animal presenting the topic.",
     "example": "A 2-minute cartoon where a bear explains the definition of done"},
    {"id": "audio", "label": "Audio", "picker": False, "settings": {"format": "audio"}, "kind": "audio",
     "how": "Ask for something to listen to: audio, a podcast, for the way to work.",
     "example": "Something to listen to on the way to work: 3 minutes on the product backlog"},
]
LOOKS = [("auto", "Auto"), ("clean", "Clean slides"), ("illustrated", "With illustrations"),
         ("presenter", "Cartoon presenter")]
LEVELS = [("auto", "Auto"), ("beginner", "Beginner"), ("intermediate", "Intermediate"), ("expert", "Expert")]
LENGTHS = [0, 1, 2, 3, 5, 8]   # 0 = auto; 4+ minute videos become courses with chapters


class JobLog(logging.Handler):
    """Collects the log lines while a job runs (shown as progress on the page). One job runs
    at a time, so every line belongs to it, also those of the parallel chapter threads."""

    def __init__(self, job: dict) -> None:
        super().__init__(logging.INFO)
        self.job = job
        self.setFormatter(logging.Formatter("%(asctime)s %(message)s", "%H:%M:%S"))

    def emit(self, record: logging.LogRecord) -> None:
        """Keep the log line on the job, for the page's progress (the last 200 lines)."""
        if record.name in ("httpx", "urllib3"):
            return
        self.job["log"].append(self.format(record)[:300])
        del self.job["log"][:-200]


def file_url(path: str) -> str:
    """The address under /files/ of a file in data/output."""
    rel = Path(path).resolve().relative_to(config.OUTPUT_DIR.resolve())
    return "/files/" + quote(rel.as_posix())


# --- what the page offers -------------------------------------------------------------------
def voices() -> list[dict]:
    """The voice engines that work here (Kokoro, plus cloud voices when they are set up)."""
    import tts
    out = []
    for engine, label in (("kokoro", "Kokoro (free, local)"), ("elevenlabs", "ElevenLabs (most natural, paid)"),
                          ("system", "Windows voice (free, robotic)")):
        ok, why = tts.check(engine)
        if ok or engine == defaults()["TTS_ENGINE"]:
            out.append({"id": engine, "label": label, "ok": ok, "detail": why,
                        "usd_per_1k": {"elevenlabs": config.ELEVENLABS_USD_PER_1K_CHARS}.get(engine, 0)})
    return out


def suggestions() -> dict:
    """Topic suggestions: the topic maps of the sources (topics.py), else the source titles."""
    out, analysed = [], False
    rows = store.available_recordings()
    for r in rows:
        m = store.read_json(store.video_dir(r["video_id"]) / "topics.json", {}) or {}
        for t in m.get("topics", []):
            analysed = True
            if t.get("depth") == "brief":   # only mentioned in the source: too thin for a lesson
                continue
            out.append({"title": t["title"], "covers": t.get("covers", ""), "source": r["title"],
                        "level": t.get("level", ""), "minutes": t.get("minutes", 2)})
    across = (store.read_json(config.OUTPUT_DIR / "topics" / "topics.json", {}) or {}).get("across") or {}
    for t in reversed(across.get("shared_topics", [])):
        out.insert(0, {"title": t["title"], "covers": t.get("covers", ""), "source": "several sources",
                       "level": t.get("level", ""), "minutes": t.get("minutes", 3)})
    if not out:
        out = [{"title": r["title"], "covers": r.get("description", ""), "source": "", "level": "", "minutes": 2}
               for r in rows]
    return {"analysed": analysed, "topics": out[:60], "sources": len(rows)}


def models() -> list[dict]:
    """The models to pick from, with their list price (the configured ones, not the one a running job uses)."""
    out = config.model_choices(defaults()["CHAT_MODEL"], defaults()["CHAT_BACKEND"])
    for m in out:
        m["price_in"], m["price_out"] = (round(x, 4) for x in llm.price(m["id"], m["backend"]))
    return out


def running(owner: str = "") -> str:
    """This browser's request that is waiting or being made (never someone else's)."""
    return next((j["id"] for j in JOBS.values() if j["status"] in ("queued", "running")
                 and j.get("owner", "") == owner), "")


def state(owner: str = "") -> dict:
    """What the chat page needs on load: this browser's request being made, spend today."""
    job = JOBS.get(running(owner)) or {}
    return {"running": job.get("id", ""), "running_request": job.get("request", ""), "running_chat": job.get("chat", ""),
            "today": round(llm.spent_today(), 3), "daily": config.DAILY_BUDGET_USD}


def options(owner: str = "") -> dict:
    """Everything the page's choices need: formats, looks, levels, models, voices, topics, budget."""
    return {"formats": FORMATS, "looks": LOOKS, "levels": LEVELS, "lengths": LENGTHS, "models": models(),
            "voices": voices(), "topics": suggestions(), "course_from": course_min(), "labels": ask.LABELS,
            "default_voice": defaults()["TTS_ENGINE"], "running": running(owner),
            "budget": {"today": round(llm.spent_today(), 3), "daily": config.DAILY_BUDGET_USD},
            "elevenlabs": elevenlabs_left()}


def elevenlabs_left() -> dict | None:
    """ElevenLabs characters used and left (usage.py), or None when it is not set up."""
    import usage
    try:
        return usage.elevenlabs()
    except Exception:   # noqa: BLE001 - information only
        return None


def course_min() -> float:
    """From how many minutes a video becomes a course with chapters."""
    import course
    return course.COURSE_MIN_MINUTES


# --- cost estimate and report -----------------------------------------------------------------
BASE = {"document": (0.02, 0.01), "slides": (0.06, 0.04), "video": (0.06, 0.06), "dialogue": (0.08, 0.07),
        "audio": (0.06, 0.06), "course": (0.10, 0.07)}   # rough $ fixed + per minute, default model


def kind_of(fmt_id: str, minutes: float) -> str:
    """What a format and length make: document, slides, video, dialogue, audio or course."""
    f = next((f for f in FORMATS if f["id"] == fmt_id), FORMATS[0])
    kind = f.get("kind", "video")
    if kind in ("video", "dialogue") and minutes >= course_min():
        return "course"
    return kind


def estimate(fmt_id: str, minutes: float, model_id: str, voice: str) -> dict:
    """Cost of a lesson before making it: the average of earlier results of the same kind and
    model (per minute), else a rough figure from the model's price; plus a paid voice."""
    minutes = minutes or 2
    kind = kind_of(fmt_id, minutes)
    same = [r for r in compare.rows(kind=kind) if r["writing_model"].startswith(model_id) and r["cost_usd"]
            and r.get("minutes")]
    if same:
        per_min = statistics.median(float(r["cost_usd"]) / max(0.5, float(r["minutes"])) for r in same)
        cost, basis = per_min * minutes, f"median of {len(same)} earlier {kind} result(s) with this model"
    else:
        fixed, per = BASE.get(kind, BASE["video"])
        backend = next((m["backend"] for m in models() if m["id"] == model_id), defaults()["CHAT_BACKEND"])
        p_in, p_out = llm.price(model_id, backend)
        ref_in, ref_out = llm.price(defaults()["CHAT_MODEL"], defaults()["CHAT_BACKEND"])   # BASE is measured with it
        ratio = 0.0 if not (p_in + p_out) else (p_in + p_out) / (ref_in + ref_out) if (ref_in + ref_out) else 1.0
        cost, basis = (fixed + per * minutes) * ratio, "rough estimate from the model's price (no earlier results yet)"
    if voice == "elevenlabs" and kind not in ("document", "slides"):
        rate = config.ELEVENLABS_USD_PER_1K_CHARS
        cost += 900 * minutes / 1000 * rate * (1.15 if kind == "dialogue" else 1)
        basis += f"; voice ~{900 * minutes:,.0f} characters"
    if config.COST_MARGIN_PCT and cost:   # on the high side, to be safe
        cost *= 1 + config.COST_MARGIN_PCT / 100
        basis += f"; +{config.COST_MARGIN_PCT:g}% safety margin"
    return {"usd": round(cost, 3), "basis": basis, "kind": kind}


def report() -> dict:
    """Spend and results per model and per format."""
    rows = compare.rows()
    if rows:
        compare.write(rows)

    def group(key: str) -> list[dict]:
        out: dict[str, dict] = {}
        for r in rows:
            g = out.setdefault(r[key] or "-", {"name": r[key] or "-", "count": 0, "cost": [], "time": [], "faithful": [],
                                              "ok": 0})
            g["count"] += 1
            g["cost"].append(float(r["cost_usd"] or 0))
            if r.get("total_s"):
                g["time"].append(float(r["total_s"]))
            if r.get("faithful"):
                g["faithful"].append(float(r["faithful"]))
            g["ok"] += r.get("verdict") in ("OK", "CHECK")
        return [{"name": g["name"], "count": g["count"], "total_usd": round(sum(g["cost"]), 3),
                 "avg_usd": round(statistics.mean(g["cost"]), 3), "avg_s": round(statistics.mean(g["time"])) if g["time"] else None,
                 "avg_faithful": round(statistics.mean(g["faithful"]), 1) if g["faithful"] else None,
                 "usable": g["ok"]} for g in sorted(out.values(), key=lambda g: -g["count"])]
    return {"count": len(rows), "total_usd": round(sum(float(r["cost_usd"] or 0) for r in rows), 3),
            "today_usd": round(llm.spent_today(), 3), "daily_budget": config.DAILY_BUDGET_USD,
            "by_model": group("writing_model"), "by_kind": group("kind"),
            "csv": "/files/comparison.csv" if (config.OUTPUT_DIR / "comparison.csv").exists() else ""}


# what a file in a result's folder is, when it has none of the usual names (ask.FILES)
BY_SUFFIX = {".mp4": "video", ".mp3": "audio", ".html": "document", ".pdf": "pdf", ".pptx": "pptx", ".md": "markdown"}


def result_files(folder: Path) -> dict:
    """Links to a result's files: the usual names, else the files its run card lists, else any video,
    audio, document or slides in its folder (results made by other tools, or by earlier versions)."""
    files = {k: file_url(str(folder / f)) for k, f in ask.FILES.items() if (folder / f).exists()}
    if not set(files) & {"answer", "video", "avatar_video", "audio", "document", "pdf", "pptx"}:
        card = store.read_json(folder / "run_card.json", {}) or {}
        listed = [folder / f for f in card.get("files", []) if isinstance(f, str)]
        found = sorted((p for p in folder.glob("*") if p.suffix in BY_SUFFIX and "_silent" not in p.name),
                       key=lambda p: -p.stat().st_mtime)
        for path in [p for p in listed if p.exists()] + found:
            key = BY_SUFFIX.get(path.suffix)
            if key and key not in files and path.is_file():
                files[key] = file_url(str(path))
    return files


def results(limit: int = 1000) -> list[dict]:
    """Every result made, the newest first (the whole history; a limit only against a runaway list)."""
    rows = compare.rows()[:limit]
    fb = chats.feedback_by_result()
    for r in rows:
        folder = config.OUTPUT_DIR / r["folder"]
        r["files"] = result_files(folder) if folder.is_dir() else {}
        r["feedback"] = fb.get(r["folder"], {})
        if not r.get("topic"):
            r["topic"] = ((store.read_json(folder / "run_card.json", {}) or {}).get("request") or {}).get("text", "") \
                or r.get("title", "")
    return rows


def comparisons() -> list[dict]:
    """The comparisons made by compare_video.py, newest first, with links to their videos and voices."""
    out = []
    for path in sorted(config.OUTPUT_DIR.glob("*-compare-*/comparison.json"), reverse=True)[:40]:
        d = store.read_json(path, {}) or {}
        folder = path.parent
        for x in d.get("voices", []) + d.get("solutions", []):
            f = folder / x.get("file", "-")
            x["url"] = file_url(str(f)) if x.get("file") and f.exists() else ""
            jpg = f.with_suffix(".jpg")   # its still (compare_video.py makes it): shown until play
            x["poster"] = file_url(str(jpg)) if x.get("file") and jpg.exists() else ""
            x["by_voice_url"] = {vid: file_url(str(folder / rel)) for vid, rel in (x.get("by_voice") or {}).items()
                                 if (folder / rel).exists()}   # a presenter's video for each narrator
            x["by_look_url"] = {lid: file_url(str(folder / rel)) for lid, rel in (x.get("by_look") or {}).items()
                                if (folder / rel).exists()}   # the same video in each look
            x["by_look_voice_url"] = {lid: {vid: file_url(str(folder / rel)) for vid, rel in by.items() if (folder / rel).exists()}
                                      for lid, by in (x.get("by_look_voice") or {}).items()}   # a presenter: look x narrator
            x["version_by_url"] = {file_url(str(folder / rel)): {"v": v, "at": (x.get("made_at") or {}).get(rel, "")}
                                   for rel, v in (x.get("versions") or {}).items() if (folder / rel).exists()}
        d["folder"] = folder.name
        try:
            import compare_video
            fixed = {x["id"]: x for x in compare_video.solutions()}   # names, prices and kinds as they are now
            d["solutions"] = [s for s in d.get("solutions", []) if s.get("id") in fixed]   # a solution taken out
            for s in d.get("solutions", []):
                for k in ("talks", "group", "variant", "about", "price", "who"):
                    if k in fixed.get(s["id"], {}):
                        s[k] = fixed[s["id"]][k]
                looks = compare_video.looks_of(fixed[s["id"]]) if s.get("id") in fixed else []
                if len(looks) > 1:   # the looks' names as they are now
                    s["looks"] = [{k: v for k, v in lk.items() if k != "set"} for lk in looks]
            compare_video.video_costs(folder, d)
        except Exception as e:   # noqa: BLE001 - the costs are information only
            log.info("Costs of %s not worked out: %s", folder.name, e)
        d.pop("state", None)
        out.append(d)
    return merged(out)[:10]


def _made(s: dict) -> bool:
    return s.get("status") == "done" and bool(s.get("url"))


def merged(comps: list[dict]) -> list[dict]:
    """Comparisons of the same content (the same source video or topic) as one: the newest, with every video
    made in the older runs that the newest has not (a run with --only makes only some tools; nothing made
    before is lost from the page). Newest first."""
    out: list[dict] = []
    by_key: dict[str, dict] = {}
    for d in comps:   # newest first
        key = str(d.get("source") or d.get("title") or d.get("folder"))
        base = by_key.get(key)
        if base is None:
            by_key[key] = d
            out.append(d)
            continue
        have = {v.get("id") for v in base.get("voices", [])}
        base.setdefault("voices", []).extend(v for v in d.get("voices", []) if v.get("id") not in have and v.get("url"))
        mine = {s.get("id"): k for k, s in enumerate(base.get("solutions", []))}
        for s in d.get("solutions", []):
            if not _made(s):
                continue
            k = mine.get(s.get("id"))
            if k is None:
                base["solutions"].append(s)
                mine[s.get("id")] = len(base["solutions"]) - 1
                continue
            b = base["solutions"][k]
            if not _made(b):
                base["solutions"][k] = s
                continue
            for field in ("by_voice_url", "by_look_url", "version_by_url"):   # made only in the older run
                for x, url in (s.get(field) or {}).items():
                    b.setdefault(field, {}).setdefault(x, url)
            for lid, by in (s.get("by_look_voice_url") or {}).items():
                for vid, url in by.items():
                    b.setdefault("by_look_voice_url", {}).setdefault(lid, {}).setdefault(vid, url)
        base.setdefault("merged_from", []).append(d.get("folder"))
    return out


def decks() -> list[dict]:
    """Silent animated decks (deck_video.py): one video per engine."""
    out = []
    for folder in sorted(config.OUTPUT_DIR.glob("*-deck-*"), reverse=True)[:20]:
        videos = sorted(folder.glob("slides_*.mp4"))
        if videos:
            sb = store.read_json(folder / "storyboard.json", {}) or {}
            out.append({"title": sb.get("title") or folder.name, "created": sb.get("created", ""),
                        "videos": {v.stem.replace("slides_", ""): file_url(str(v)) for v in videos}})
    return out


# What Lesson Studio makes, as the price list shows it: id, name, example, kind of result (run cards),
# minutes, spoken (a narrator), presenter ("" | "cartoon")
OFFER = [
    ("answer", "Answer to a question", "a few sentences with their sources", "answer", 0, False, ""),
    ("document", "Text lecture", "about 5 minutes to read", "document", 5, False, ""),
    ("slides", "Presentation", "about 10 slides: PDF + PowerPoint with speaker notes", "slides", 10, False, ""),
    ("silent", "Animated slides (no voice)", "a 2-minute video", "video", 2, False, ""),
    ("video", "Slides with narrator", "a 2-minute video", "video", 2, True, ""),
    ("presenter", "Slides with presenter (our cartoon)", "a 2-minute video", "video", 2, True, "cartoon"),
]
CHARS_PER_MIN = 900   # spoken characters in a minute of narration

# What AWS costs a month is not worked out here: it comes only from the AWS Pricing Calculator's export in
# data/aws (aws_estimate.py).


def price_table(m: dict, p: dict) -> list[dict]:
    """One request of each kind Lesson Studio makes: the cost with a free voice (Kokoro, or none) and with
    ElevenLabs; made of Claude (measured on this project's runs where there are any), the voice, the
    presenter and the server's time; the safety margin included. Licences and plans: see subscriptions."""
    import compare_video
    import costs
    margin = 1 + config.COST_MARGIN_PCT / 100
    server_min = costs.render_per_min(p, m)                      # making one minute of video
    kokoro_min = compare_video.KOKORO_RTF * 60 * compare_video.CLOUD_PER_S
    eleven_min = CHARS_PER_MIN / 1000 * config.ELEVENLABS_USD_PER_1K_CHARS
    rows = []
    for key, what, example, kind, minutes, spoken, presenter in OFFER:
        if kind == "answer":
            ai, basis = m["answer"]
        else:
            per, basis = m[f"per_min_{kind}"]
            ai = per * minutes
        base = ai + (server_min * minutes if kind == "video" else 0.0)
        if presenter == "cartoon":
            base += server_min * minutes * 0.5                    # the presenter takes longer to draw
        free = base + (kokoro_min * minutes if spoken else 0.0)
        eleven = base + eleven_min * minutes if spoken else None
        rows.append({"key": key, "what": what, "example": example, "usd": round(free * margin, 3),
                     "usd_eleven": round(eleven * margin, 3) if eleven is not None else None,
                     "voice": "Kokoro voice (free)" if spoken else "no voice", "basis": basis})
    return rows


def prices() -> dict:
    """The price list, what each step costs, the subscriptions, spend so far, the full cost report, and AWS a
    month as the AWS Pricing Calculator's export says (nothing about AWS without one)."""
    import aws_estimate
    import compare_video
    import costs
    a, p = costs.load_inputs()
    m = costs.measured(costs.library())
    spent = m["_spent_total"][0]   # every logged model call, as "today" is counted
    report_file = config.OUTPUT_DIR / "costs" / "costs.html"
    try:   # the step costs: the newest comparison has every tool's time to make the same video
        folder = compare_video.latest()
        data = store.read_json(folder / "comparison.json", {}) or {}
        compare_video.video_costs(folder, data)
        steps = compare_video.cost_report(folder, data, content_usd_per_min=m["per_min_video"][0])
    except Exception as e:   # noqa: BLE001 - no comparison yet: the steps without the tools' times
        log.info("Step costs without a comparison: %s", e)
        steps = compare_video.cost_report(None, {}, content_usd_per_min=m["per_min_video"][0])
    return {"rows": price_table(m, p), "steps": steps["steps"], "subscriptions": steps["subscriptions"],
            "aws": aws_estimate.summary(),
            "checked": steps["checked"], "margin_pct": config.COST_MARGIN_PCT,
            "eleven_rate": config.ELEVENLABS_USD_PER_1K_CHARS, "today": round(llm.spent_today(), 3),
            "daily": config.DAILY_BUDGET_USD, "total": round(spent, 2),
            "report": file_url(str(report_file)) if report_file.exists() else "", "lengths": lengths()}


def lengths() -> dict:
    """What one video costs by length (length_costs.py), with links to the videos and the Excel file."""
    import length_costs
    try:
        rep = length_costs.report()
    except Exception as e:   # noqa: BLE001 - information only
        log.info("Costs by length not worked out: %s", e)
        return {"rows": []}
    for r in rep.get("rows", []) + rep.get("scratch", []):
        v = config.OUTPUT_DIR / r["folder"] / "lesson_video.mp4"
        r["url"] = file_url(str(v)) if v.exists() else ""
        m = re.search(r"-v(\d+)-", r["folder"])
        r["version"] = int(m.group(1)) if m else None
    x = length_costs.folder() / "length_costs.xlsx"
    rep["xlsx"] = file_url(str(x)) if x.exists() else ""
    return rep


# --- jobs --------------------------------------------------------------------------------------
def public(result: dict) -> dict:
    """What the page needs from a result (links instead of paths)."""
    card = result.get("card") or {}
    q = result["quality"]
    return {"format": result["format"], "understood": result["understood"], "title": card.get("title", ""),
            "folder": Path(result["folder"]).name, "files": {k: file_url(v) for k, v in result["files"].items()},
            "verdict": q["status"], "fail": q["fail"], "issues": q["issues"][:8], "review": q.get("review"),
            # from the library: what it costs now (reading the request), and what it cost when it was made
            "cost_usd": result["cost_usd"] if result.get("reused") else (card.get("cost") or {}).get("total_usd", result["cost_usd"]),
            "reused": bool(result.get("reused")), "made_cost_usd": result.get("made_cost_usd"),
            "request": result.get("request", ""), "seconds": result["seconds"],
            "sources": (card.get("input") or {}).get("used", [])[:8], "solution": card.get("solution", {}),
            "cost_lines": (card.get("cost") or {}).get("by_step", [])[:8], "answer": answer_part(result)}


def answer_part(result: dict) -> dict | None:
    """A question's answer for the page: the text with [n] and its numbered sources."""
    a = result.get("answer")
    if not a:
        return None
    return {"question": a.get("question", ""), "text": a.get("text", ""), "not_in_material": bool(a.get("not_in_material")),
            "not_covered": a.get("not_covered", ""),
            "sources": [{"n": x["n"], "title": x.get("title", ""), "kind": x.get("kind", ""), "where": x.get("where", ""),
                         "at": x.get("at", []), "evidence": x.get("evidence", [])[:2]} for x in a.get("sources", [])]}


def defaults() -> dict:
    """The configured model and voice (while a job runs: the ones from before its own choice)."""
    return dict(_before_job) or {k: getattr(config, k) for k in SWITCHED}


@contextlib.contextmanager
def chosen(model: dict | None, voice: str | None, extra: dict | None = None) -> Iterator[None]:
    """The model, voice and tool picked on the page, for this job only (one job runs at a time).
    A local model also does the review (the review must use the same backend)."""
    _before_job.update({k: getattr(config, k) for k in SWITCHED})
    try:
        for k, v in (extra or {}).items():
            if k in SWITCHED:
                setattr(config, k, v)
        if model:
            config.CHAT_MODEL, config.CHAT_BACKEND = model["id"], model["backend"]
            if model["backend"] != _before_job["CHAT_BACKEND"]:
                config.REVIEW_MODEL = model["id"]
        if voice:
            config.TTS_ENGINE = voice
        yield
    finally:
        for k, v in _before_job.items():
            setattr(config, k, v)
        _before_job.clear()


def readable_error(e: Exception) -> str:
    """What the page says about a failure: the gateway being slow or busy in plain words, else the error."""
    m = re.search(r"HTTP (408|429|502|503|504|529)|ReadTimeout|ConnectTimeout|timed out", str(e))
    if m:
        return (f"The AI service did not answer in time{f' (HTTP {m.group(1)})' if m.group(1) else ''}. The request "
                "is fine and nothing here is broken: try again in a minute. If it keeps happening, the company "
                "gateway is busy or down.")
    return f"{type(e).__name__}: {e}"[:600]


def chat_history(job: dict) -> list[dict]:
    """The chat's earlier finished turns [{request, answer}] (the answer's text, or what was made), so a
    follow-up question ("and who owns it?") is understood as a full one."""
    chat = chats.load(job.get("chat") or "", job.get("owner", "")) if job.get("chat") else None
    out = []
    for m in (chat or {}).get("messages", []):
        if m.get("job") == job.get("id"):
            break
        if m.get("status") != "done":
            continue
        r = m.get("result") or {}
        a = r.get("answer") or {}
        made = a.get("text") or (f"a {r.get('format', 'result')}: {r.get('title', '')}" if r else "")
        out.append({"request": m.get("request", ""), "answer": made})
    return out[-config.CHAT_HISTORY_TURNS:] if config.CHAT_HISTORY_TURNS > 0 else []


def work(job: dict) -> None:
    """Make one request (in the worker thread) and keep its progress, result or error on the job."""
    handler = JobLog(job)
    logging.getLogger().addHandler(handler)
    result: dict | None = None
    failure: BaseException | None = None
    try:
        with BUSY:
            llm.STOP.clear()   # a Stop meant for the request before this one
            storyboard.last_saved = None
            job["status"] = "running"
            if job["kind"] == "topics":
                import topics
                topics.run()
                job.update(status="done", result={"topics": suggestions()})
                return
            with chosen(job.get("model"), job.get("voice"), job.get("config")):
                if job["kind"] == "resume":   # a stopped video, finished from its folder
                    result = ask.resume(config.OUTPUT_DIR / job["folder"], job["review"], job.get("audio_only", False))
                else:
                    result = ask.run(job["request"], review=job["review"], overrides=job["overrides"],
                                     on_understood=lambda s: job.update(understood=s), history=chat_history(job))
            job.update(status="done", result=public(result))
    except ask.RequestRefused as e:
        job.update(status="refused", error=str(e))
    except lesson.NotEnoughMaterial as e:
        job.update(status="not_covered", error=str(e))
    except llm.Stopped as e:
        log.info("Job %s stopped on the page", job.get("id"))
        job.update(status="stopped", error=str(e), resume_folder=_resumable())
    except Exception as e:   # noqa: BLE001 - show any failure on the page instead of crashing the server
        log.exception("Job failed")
        failure = e
        job.update(status="error", error=readable_error(e), resume_folder=_resumable())
    finally:
        logging.getLogger().removeHandler(handler)
        job["finished"] = time.time()
        if job.get("chat"):   # kept with the chat, so it is there after a restart
            chats.add_result(job["chat"], job["id"], job["status"], job.get("result"), job.get("error", ""),
                             job["finished"] - job["started"])
        monitoring.request_finished(job, result, failure)


# --- tools and narrators to pick in the chat (the same as in the comparison) -----------------------
LEVEL_CHOICES = [("auto", "Auto"), ("beginner", "Beginner"), ("intermediate", "Intermediate"), ("expert", "Expert")]
ELEVEN_PICK = ("lily", "brian", "alice", "daniel", "charlotte", "will")
_choices: dict = {}


def tool_settings(tool: str) -> tuple[dict, dict]:
    """(config values, request overrides) for a tool id from compare_video.solutions() (the company's
    avatars included)."""
    import compare_video
    sol = next((x for x in compare_video.solutions() if x["id"] == tool), None)
    if not sol:
        return {}, {}
    over = {"style": sol["style"]}
    if sol.get("characters"):
        over["characters"] = sol["characters"]
    return {"RENDERER": sol["renderer"], **sol.get("set", {})}, over


def voice_settings(voice: str) -> dict:
    """kokoro:af_heart / elevenlabs:brian -> the config values for that narrator."""
    engine, _, name = (voice or "").partition(":")
    if engine == "kokoro" and name:
        return {"TTS_ENGINE": "kokoro", "TTS_VOICE": name}
    if engine == "elevenlabs" and name:
        return {"TTS_ENGINE": "elevenlabs", "ELEVENLABS_VOICE": name}
    return {}


def _quick_ok(sol: dict) -> tuple[bool, str]:
    """Can this tool run here? Quick checks only (nothing is installed by asking)."""
    import importlib.util
    r = sol.get("renderer", "")
    if r == "html":
        return importlib.util.find_spec("playwright") is not None, "needs playwright"
    if r.startswith("remotion"):
        return (config.EXPERIMENTS_DIR / "remotion" / "node_modules").exists(), "Remotion not installed (experiments/remotion, npm.cmd install)"
    if r == "manim":
        import manim_render
        return manim_render.available()
    if r == "hyperframes":
        import hyperframes_render
        return hyperframes_render.available()
    import deck_js
    return deck_js.available(r)


def choices() -> dict:
    """What can be picked under the chat box (checked at most once a minute)."""
    if _choices.get("at", 0) > time.time() - 60:
        return _choices["data"]
    import compare_video
    import tts
    tools = []
    for sol in compare_video.solutions():
        ok, why = _quick_ok(sol)
        tools.append({"id": sol["id"], "label": sol["group"] + (f" \u2013 {sol['variant']}" if sol.get("variant") else ""),
                      "ok": bool(ok), "why": "" if ok else why})
    voices = []
    if tts.check("kokoro")[0]:
        voices += [{"id": f"kokoro:{v}", "label": f"Kokoro \u2013 {name} ({who}, {accent})"}
                   for _, v, name, who, accent in compare_video.KOKORO]
    if config.ELEVENLABS_API_KEY:
        voices += [{"id": f"elevenlabs:{n}", "label": f"ElevenLabs \u2013 {n.capitalize()} "
                    f"({compare_video.ELEVEN_WHO.get(n, '')}, paid)"} for n in ELEVEN_PICK]
    renderer = next((t["label"] for t in tools if t["id"] == defaults()["RENDERER"]), defaults()["RENDERER"])
    voice = defaults()["TTS_ENGINE"] + (f" \u2013 {config.TTS_VOICE}" if defaults()["TTS_ENGINE"] == "kokoro" else "")
    data = {"formats": [{"id": f["id"], "label": f["label"].replace(" (from my words)", "")} for f in FORMATS
                        if f.get("picker", True)],
            "tools": tools, "voices": voices, "levels": [{"id": k, "label": v} for k, v in LEVEL_CHOICES],
            "defaults": {"tool": renderer, "voice": voice}}
    _choices.update(at=time.time(), data=data)
    return data


# --- the company's avatars (company_avatar.py): pictures in data/avatars, marked on the Avatars tab ---------
def avatars() -> dict:
    """The company avatars in data/avatars, with the address of each picture."""
    import company_avatar
    rows = company_avatar.listing()
    for a in rows:
        a["url"] = "/avatars/" + quote(a["file"])
    return {"folder": str(company_avatar.folder()), "avatars": rows}


def avatar_post(path: str, body: dict) -> tuple[dict, int]:
    """A new picture ({name, data: a data URL}: marked by AI at once), every unmarked picture marked by AI
    (/api/avatars/auto), one marked again by AI (/api/avatars/<name>/ai), marks moved by hand ({mouth, eyes,
    label, who}) or a deletion (/api/avatars/<name>/delete)."""
    import base64
    import binascii

    import company_avatar
    parts = [p for p in path.split("/") if p][2:]   # after /api/avatars
    try:
        if not parts:
            raw = str(body.get("data", ""))
            raw = raw.split(",", 1)[1] if raw.startswith("data:") else raw
            if len(raw) > 14_000_000:
                return {"error": "The picture is too big (at most about 10 MB)."}, 413
            name = company_avatar.add_picture(str(body.get("name") or "avatar"), base64.b64decode(raw, validate=True))
            company_avatar.mark(name, label=" ".join(str(body.get("name") or "").split())[:40])
            return {"ok": True, "name": name, **avatars()}, 200
        if parts == ["auto"]:
            return {"ok": True, "marked": company_avatar.mark_all(), **avatars()}, 200
        name = parts[0].lower()
        if len(parts) > 1 and parts[1] == "ai":
            if name not in company_avatar.pictures():
                return {"error": "No such avatar."}, 404
            company_avatar.mark(name)
            return {"ok": True, **avatars()}, 200
        if len(parts) > 1 and parts[1] == "delete":
            ok = company_avatar.delete(name)
            return ({"ok": True, **avatars()} if ok else {"error": "No such avatar."}), 200 if ok else 404
        company_avatar.save(name, {**body, "by": "hand"})
        return {"ok": True, **avatars()}, 200
    except FileNotFoundError as e:
        return {"error": str(e)}, 404
    except (ValueError, KeyError, TypeError, binascii.Error) as e:
        return {"error": f"Not saved: {e}"}, 400


def forget_old_jobs(after_s: float = 3600) -> None:
    """Finished jobs leave memory after an hour: their results are kept in their chat and in data/output."""
    now = time.time()
    for jid in [j["id"] for j in JOBS.values() if j.get("finished") and now - j["finished"] > after_s]:
        JOBS.pop(jid, None)


def new_job(body: dict, owner: str = "") -> tuple[dict | None, str, int]:
    """A lesson job from the page's form (request + clicked options), or (None, error, code). It goes into
    the chat body["chat"] (a new chat when there is none), which belongs to `owner` (the browser)."""
    kind = body.get("kind", "lesson")
    forget_old_jobs()
    if sum(1 for j in JOBS.values() if j.get("owner", "") == owner and j["status"] in ("queued", "running")) \
            >= MAX_WAITING_PER_USER:
        return None, f"You already have {MAX_WAITING_PER_USER} requests waiting. Wait until one is finished.", 429
    job = {"id": uuid.uuid4().hex[:10], "kind": kind, "status": "queued", "log": [], "started": time.time(),
           "owner": owner}
    if kind == "lesson":
        request = " ".join(str(body.get("request", "")).split())[:1000]
        if not request:
            return None, "Write a topic or what you want to learn.", 400
        fmt = next((f for f in FORMATS if f["id"] == body.get("format", "auto")), FORMATS[0])
        overrides = dict(fmt["settings"])
        if body.get("minutes"):
            overrides["minutes"] = float(body["minutes"])
        if body.get("level") not in (None, "", "auto"):
            overrides["level"] = body["level"]
        if body.get("look") not in (None, "", "auto") and fmt["id"] in ("auto", "video", "audio"):
            overrides["style"] = body["look"]
            if body["look"] == "presenter":
                overrides["characters"] = "cartoon"
        if body.get("fresh"):   # "Make a new version": not the one from the library
            overrides["fresh"] = True
        model = next((m for m in models() if m["id"] == body.get("model")), None)
        cfg: dict[str, Any] = {}
        tool = body.get("tool") or "default"
        if tool != "default" and fmt["id"] not in ("answer", "document", "slides"):
            cfg, tool_over = tool_settings(tool)
            if fmt["id"] != "dialogue":
                overrides.update(tool_over)
        voice = body.get("voice") or None
        if voice and ":" in voice:   # a narrator: engine + voice
            cfg.update(voice_settings(voice))
            voice = None
        if fmt.get("config"):   # e.g. animated slides: no voice, whatever narrator is picked
            cfg.update(fmt["config"])
            voice = None
        job.update(request=request, review=bool(body.get("review", True)), overrides=overrides, model=model,
                   voice=voice, config=cfg)
        picks = {k: str(body[k]) for k in ("format", "tool", "voice", "level") if body.get(k)}
        job["chat"] = chats.add_request(str(body.get("chat") or ""), owner, request, picks, job["id"])
    elif kind != "topics":
        return None, "Unknown job.", 400
    JOBS[job["id"]] = job
    enqueue(job)
    return job, "", 200


# --- web server ----------------------------------------------------------------------------------
LOGIN = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport"
content="width=device-width, initial-scale=1"><title>Lesson Studio</title><style>
body{margin:0;min-height:100vh;display:grid;place-items:center;background:#f5f6f8;color:#16202c;
font:15px/1.5 "Segoe UI",system-ui,-apple-system,Roboto,Arial,sans-serif}
form{background:#fff;border:1px solid #e3e7ec;border-radius:14px;padding:28px;width:min(340px,90vw)}
h1{font-size:18px;margin:0 0 4px}p{margin:0 0 16px;color:#5f6b7a;font-size:13.5px}
input{width:100%;box-sizing:border-box;border:1px solid #d5dbe2;border-radius:9px;padding:10px 12px;font:inherit}
button{margin-top:12px;width:100%;border:0;border-radius:9px;padding:10px;background:#0f5fae;color:#fff;
font:inherit;font-weight:600;cursor:pointer}.err{color:#b42d23;margin:10px 0 0}</style></head><body>
<form method="post" action="/login"><h1>Lesson Studio</h1><p>Enter the password you were given.</p>
<input type="password" name="password" autofocus autocomplete="current-password" aria-label="Password">
<button>Open</button>__ERR__</form></body></html>"""


SIGN_IN_DAYS = 30
MAX_BODY = 64 * 1024              # a request, a rename, feedback
MAX_UPLOAD = 12 * 1024 * 1024     # a company avatar picture (base64 in JSON)
# every answer: no MIME sniffing, no referrer leaks, only this site may frame the page (results open in iframes)
SECURITY_HEADERS = {"X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer",
                    "X-Frame-Options": "SAMEORIGIN"}
# the page itself: its own inline script and styles, nothing from other sites
PAGE_CSP = ("default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; font-src 'self' data:; "
            "style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; frame-src 'self'; "
            "frame-ancestors 'self'; object-src 'none'; base-uri 'none'; form-action 'self'")


def _token(issued: int | None = None) -> str:
    """The sign-in cookie: when it was issued and a signature over that with the password. It stops working
    after SIGN_IN_DAYS, and at once when the password changes."""
    issued = int(time.time()) if issued is None else issued
    sig = hmac.new(("lesson-studio:" + config.APP_PASSWORD).encode(), str(issued).encode(), hashlib.sha256)
    return f"{issued}.{sig.hexdigest()[:40]}"


def _token_ok(value: str) -> bool:
    issued, _, _ = value.partition(".")
    if not issued.isdigit() or time.time() - int(issued) > SIGN_IN_DAYS * 86400:
        return False
    return hmac.compare_digest(value, _token(int(issued)))


def _resumable() -> str:
    """The folder (its name) of the video the stopped or failed request was making, when its storyboard (the paid
    part) is there: the page offers Resume. "" for anything else (an answer, a document, slides)."""
    folder = storyboard.last_saved
    if not folder or not (folder / "storyboard.json").exists() or (folder / "lesson.json").exists():
        return ""
    return folder.name


def resume_job(job_id: str, owner: str) -> tuple[dict | None, str, int]:
    """The page's Resume (/api/jobs/<id>/resume): a new request in the same chat that finishes the stopped video
    from its folder, with the same choices (model, voice, tool). Only the browser that asked; the folder comes
    from the stopped request on the server, never from the browser."""
    old = JOBS.get(job_id)
    if not old or old.get("owner", "") not in ("", owner):
        return None, "Unknown request.", 404
    folder = old.get("resume_folder") or ""
    if old["status"] not in ("stopped", "error") or not folder or \
            not (config.OUTPUT_DIR / folder / "storyboard.json").exists():
        return None, "Nothing to resume.", 409
    if sum(1 for j in JOBS.values() if j.get("owner", "") == owner and j["status"] in ("queued", "running")) \
            >= MAX_WAITING_PER_USER:
        return None, f"You already have {MAX_WAITING_PER_USER} requests waiting. Wait until one is finished.", 429
    job = {"id": uuid.uuid4().hex[:10], "kind": "resume", "status": "queued", "log": [], "started": time.time(),
           "owner": owner, "request": old.get("request", ""), "review": old.get("review", True),
           "overrides": old.get("overrides", {}), "model": old.get("model"), "voice": old.get("voice"),
           "config": old.get("config", {}), "folder": folder,
           "audio_only": (old.get("understood") or {}).get("format") == "audio"}
    if old.get("chat"):
        job["chat"] = chats.add_request(old["chat"], owner, f"Resume: {old.get('request', '')}", {}, job["id"])
    old["resume_folder"] = ""   # resumed once
    JOBS[job["id"]] = job
    enqueue(job)
    return job, "", 200


def stop_job(job_id: str, owner: str) -> bool:
    """The page's Stop button (/api/jobs/<id>/stop), only for the browser that asked: a request still waiting is
    taken out of the line; the one being made stops before its next paid call or the next part of its video
    (llm.check_stop), and what it made so far is not shown."""
    job = JOBS.get(job_id)
    if not job or job.get("owner", "") not in ("", owner):
        return False
    if job["status"] == "queued":
        job.update(status="stopped", error="Stopped before it started.", finished=time.time())
        if job.get("chat"):
            chats.add_result(job["chat"], job["id"], "stopped", None, job["error"], 0)
        return True
    if job["status"] == "running":
        llm.STOP.set()
        log.info("Stop asked for job %s", job_id)
        return True
    return False


def chat_action(path: str, body: dict, owner: str) -> bool:
    """/api/chats/<id>/rename {title}, /delete, /feedback {job, rating, comment}: only on the owner's chat.
    Returns whether it was done."""
    _, _, _, chat_id, action = (path.split("/") + [""])[:5]
    if action == "rename":
        return chats.rename(chat_id, owner, str(body.get("title", "")))
    if action == "delete":
        return chats.delete(chat_id, owner)
    if action == "feedback":
        return chats.add_feedback(chat_id, owner, str(body.get("job", "")), str(body.get("rating", "")),
                                  str(body.get("comment", "")))
    return False


class Handler(BaseHTTPRequestHandler):
    """Lesson Studio's HTTP handler: the page, the JSON API and the files, behind the sign-in."""
    server_version = "LessonStudio/1.0"

    def _owner(self) -> str:
        """Whose chats these are: behind the company login, the signed-in person (from their e-mail, so the same
        chats on every device); otherwise this browser's id (a cookie set with the page)."""
        if config.AUTH_PROXY_HEADER:
            user = (self.headers.get(config.AUTH_PROXY_HEADER) or "").strip().lower()
            return hashlib.sha256(user.encode("utf-8")).hexdigest()[:24] if user else ""
        morsel = SimpleCookie(self.headers.get("Cookie") or "").get("ls_user")
        return morsel.value if morsel and chats.ID.fullmatch(morsel.value) else ""

    def _shared(self) -> bool:
        """The request came through a shared link (VS Code port forwarding, a tunnel), not from this
        computer's own browser: the tunnel adds X-Forwarded-* headers or keeps its own host name."""
        host = (self.headers.get("Host") or "").rsplit(":", 1)[0].strip("[]").lower()
        forwarded = any(self.headers.get(h) for h in ("X-Forwarded-For", "X-Forwarded-Host", "Forwarded"))
        return forwarded or host not in ("localhost", "127.0.0.1", "::1", "")

    def _allowed(self) -> bool:
        """No APP_PASSWORD: open only to this computer's own browser; a shared link is refused. With
        one: the cookie from /login."""
        if config.AUTH_PROXY_HEADER:   # signed in by the company login in front (oauth2-proxy)
            return bool((self.headers.get(config.AUTH_PROXY_HEADER) or "").strip())
        if not config.APP_PASSWORD:
            return not self._shared()
        morsel = SimpleCookie(self.headers.get("Cookie") or "").get("ls_auth")
        return morsel is not None and _token_ok(morsel.value)

    def _https(self) -> bool:
        """Behind https (a load balancer or an ingress says so): cookies are then sent over https only."""
        return (self.headers.get("X-Forwarded-Proto") or "").lower() == "https"

    def _body(self, limit: int = MAX_BODY) -> bytes | None:
        """The request body, or None after answering 400/413 (a missing, wrong or too large Content-Length)."""
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = -1
        if n < 0:
            self._json({"error": "Bad request."}, 400)
            return None
        if n > limit:
            self._json({"error": f"Too large (at most {limit // 1024} KB)."}, 413)
            return None
        return self.rfile.read(n)

    def _login(self, error: str = "", code: int = 200) -> None:
        err = f'<p class="err">{error}</p>' if error else ""
        self._send(LOGIN.replace("__ERR__", err).encode(), "text/html; charset=utf-8", code)

    def log_message(self, fmt: str, *args: object) -> None:   # quiet: the page shows the progress
        """Nothing to the terminal: the page shows the progress."""
        pass

    def log_request(self, code: int | str = "-", size: int | str = "-") -> None:   # noqa: ARG002 - base signature
        """Requests through a shared link are written to data/output/app_access.log (time, what, answer), so a
        page that does not open for someone else can be traced. Not to the terminal: on Windows a click in the
        terminal window pauses every program writing to it, and the page would hang for the other person.
        In a container (LOG_FORMAT=json) they go to the log with the other lines; the health checks are left out."""
        path = urlparse(self.path).path
        if path in ("/healthz", "/readyz") or not self._shared():   # the cluster checks every few seconds: no line
            return
        if config.LOG_FORMAT == "json":   # in a container: to the log collector, with the other lines
            logging.getLogger("access").info("%s %s -> %s", self.command, path, code)
            return
        try:
            line = f"{time.strftime('%Y-%m-%d %H:%M:%S')}  {self.command} {path} -> {code}\n"
            config.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
            with ACCESS_LOCK, open(config.OUTPUT_DIR / "app_access.log", "a", encoding="utf-8") as f:
                f.write(line)
        except Exception:   # noqa: BLE001 - a log line must never stop an answer
            pass

    def _send(self, body: bytes, ctype: str, code: int = 200, extra: dict | None = None) -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in {**SECURITY_HEADERS, **({"Content-Security-Policy": PAGE_CSP} if ctype.startswith("text/html")
                                            else {}), **(extra or {})}.items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, data: object, code: int = 200) -> None:
        self._send(json.dumps(data).encode(), "application/json", code)

    def do_GET(self) -> None:   # noqa: N802 - http.server API
        """The page, the JSON API and the files. Everything but /status needs the sign-in when a password is set."""
        url = urlparse(self.path)
        if url.path in PROBES:   # no sign-in, no data: for the link test and the cluster's health checks
            return PROBES[url.path](self)
        if not self._allowed():
            return self._refuse(url.path)
        route = self._get_route(url.path)
        if route is None:
            return self._send(b"not found", "text/plain", 404)
        return route(url)

    def _get_route(self, path: str) -> Callable[[ParseResult], None] | None:
        """The method that answers a GET of `path`, or None (404)."""
        exact = {
            "/": self._home,
            "/api/chats": lambda _u: self._json({"chats": chats.listing(self._owner())}),
            "/api/state": lambda _u: self._json(state(self._owner())),
            "/api/choices": lambda _u: self._json(choices()),
            "/api/comparisons": lambda _u: self._json(comparisons()),
            "/api/prices": lambda _u: self._json(prices()),
            "/api/decks": lambda _u: self._json(decks()),
            "/api/options": lambda _u: self._json(options(self._owner())),
            "/api/estimate": self._estimate,
            "/api/results": lambda _u: self._json(results()),
            "/api/report": lambda _u: self._json(report()),
            "/api/monitor": lambda u: self._json(monitoring.report(_days(u))),
            "/api/avatars": lambda _u: self._json(avatars()),
            "/api/brand": self._brand,
            "/brand/logo": self._brand_logo,
        }
        if path in exact:
            return exact[path]
        prefixed = (("/api/chats/", self._chat), ("/api/jobs/", self._job), ("/avatars/", self._avatar_picture),
                    ("/files/", lambda u: self._file(unquote(u.path[len("/files/"):]))))
        return next((fn for prefix, fn in prefixed if path.startswith(prefix)), None)

    def _status(self) -> None:
        """A quick test of a shared link: is the app reached at all (no sign-in, no data)."""
        came = "through a shared link" if self._shared() else "from this computer"
        text = (f"Lesson Studio is running.\nThis request came {came}."
                f"\nPassword: {'on' if config.APP_PASSWORD else 'OFF (a shared link is refused)'}.\n")
        self._send(text.encode(), "text/plain; charset=utf-8")

    def _healthz(self) -> None:
        """Liveness: the process answers. Nothing outside it is checked, so a slow gateway never restarts it."""
        self._json({"status": "ok", "version": config.APP_VERSION})

    def _readyz(self) -> None:
        """Readiness: 200 when the app can take requests (not stopping, the data folder writable), else 503."""
        ready, checks = readiness()
        self._json({"ready": ready, "checks": checks, "version": config.APP_VERSION}, 200 if ready else 503)

    def _refuse(self, path: str) -> None:
        """Not signed in: the sign-in page for the page itself, 401/403 for the API. Shared without a password:
        closed, and the page says how to set one."""
        if config.AUTH_PROXY_HEADER:
            return self._json({"error": "Sign in through the company login first."}, 401)
        if not config.APP_PASSWORD:
            if path == "/":
                return self._login("Shared without a password, so it stays closed. On the laptop: stop app.py (Ctrl+C) "
                                   "and start it with: uv run app.py --password <a long password>", 200)
            return self._json({"error": "No password set."}, 403)
        return self._login() if path == "/" else self._json({"error": "Sign in first."}, 401)

    def _home(self, _url: ParseResult) -> None:
        """The page; a new browser gets its own id (its chats and requests are only its own)."""
        extra = {} if self._owner() else {
            "Set-Cookie": f"ls_user={uuid.uuid4().hex[:16]}; Path=/; HttpOnly; SameSite=Lax; Max-Age={400 * 86400}"
                          + ("; Secure" if self._https() else "")}
        self._send(page().encode(), "text/html; charset=utf-8", extra=extra)

    def _chat(self, url: ParseResult) -> None:
        """One chat of this browser, with which of its requests are still being made."""
        chat = chats.load(url.path.rsplit("/", 1)[-1], self._owner())
        busy = {j["id"] for j in JOBS.values() if j["status"] in ("queued", "running")}
        self._json(chats.for_page(chat, busy) if chat else {"error": "No such chat."}, 200 if chat else 404)

    def _job(self, url: ParseResult) -> None:
        """A request's progress and result: only for the browser that asked."""
        job = JOBS.get(url.path.rsplit("/", 1)[-1])
        if not job or job.get("owner", "") not in ("", self._owner()):
            return self._json({"status": "unknown"}, 404)
        return self._json({**{k: v for k, v in job.items() if k != "owner"}, "ahead": ahead_of(job)})

    def _estimate(self, url: ParseResult) -> None:
        """What a request will cost and take, before it is sent (?format=&minutes=&model=&voice=)."""
        q = {k: v[0] for k, v in parse_qs(url.query).items()}
        try:
            minutes = float(q.get("minutes") or 0)
        except ValueError:
            minutes = 0
        self._json(estimate(q.get("format", "auto"), minutes, q.get("model") or defaults()["CHAT_MODEL"],
                            q.get("voice") or defaults()["TTS_ENGINE"]))

    def _avatar_picture(self, url: ParseResult) -> None:
        """A company avatar's picture (from data/avatars only)."""
        import company_avatar
        name = unquote(url.path[len("/avatars/"):])
        pic = company_avatar.pictures().get(company_avatar.slug(Path(name).stem))
        if not pic or pic.name != name:
            return self._send(b"not found", "text/plain", 404)
        return self._stream(pic, 0, pic.stat().st_size - 1, pic.stat().st_size,
                            mimetypes.guess_type(pic.name)[0] or "image/png", 200)

    def _brand(self, _url: ParseResult) -> None:
        """The company brand found in data/brand (brand.py)."""
        import brand
        s = brand.summary()
        s["logo_url"] = "/brand/logo" if s.get("logo") else ""
        s["folder"] = "data/brand"
        self._json(s)

    def _brand_logo(self, _url: ParseResult) -> None:
        """The company logo file."""
        import brand
        lg = brand.logo()
        if not lg:
            return self._send(b"not found", "text/plain", 404)
        return self._stream(lg, 0, lg.stat().st_size - 1, lg.stat().st_size,
                            mimetypes.guess_type(lg.name)[0] or "image/png", 200)

    do_HEAD = do_GET

    def do_POST(self) -> None:   # noqa: N802 - http.server API
        """Sign-in, new requests, chat actions (rename, delete, feedback) and avatar pictures."""
        path = urlparse(self.path).path
        if path == "/login":
            raw = self._body(4096)
            if raw is None:
                return None
            given = (parse_qs(raw.decode("utf-8", "replace")).get("password") or [""])[0]
            if config.APP_PASSWORD and hmac.compare_digest(given.encode(), config.APP_PASSWORD.encode()):
                cookie = (f"ls_auth={_token()}; Path=/; HttpOnly; SameSite=Lax; Max-Age={SIGN_IN_DAYS * 86400}"
                          + ("; Secure" if self._https() else ""))
                return self._send(b"", "text/plain", 303, {"Location": "/", "Set-Cookie": cookie})
            time.sleep(1)   # slows down guessing
            return self._login("Wrong password." if config.APP_PASSWORD else "No password is set.", 401)
        if not self._allowed():
            return self._json({"error": "Sign in first."}, 401)
        if STOPPING.is_set() and path == "/api/jobs":
            return self._json({"error": "Lesson Studio is restarting. Ask again in a minute."}, 503)
        if path.startswith("/api/jobs/") and path.endswith("/stop"):   # the Stop button
            ok = stop_job(path[len("/api/jobs/"):-len("/stop")], self._owner())
            return self._json({"ok": ok}, 200 if ok else 404)
        if path.startswith("/api/jobs/") and path.endswith("/resume"):   # the Resume button
            if STOPPING.is_set():
                return self._json({"error": "Lesson Studio is restarting. Ask again in a minute."}, 503)
            job, error, code = resume_job(path[len("/api/jobs/"):-len("/resume")], self._owner())
            return self._json({"id": job["id"], "chat": job.get("chat", "")} if job else {"error": error}, code)
        if path != "/api/jobs" and not path.startswith(("/api/chats/", "/api/avatars")):
            return self._send(b"not found", "text/plain", 404)
        raw = self._body(MAX_UPLOAD if path.startswith("/api/avatars") else MAX_BODY)
        if raw is None:
            return None
        try:
            body = json.loads(raw or b"{}")
        except (json.JSONDecodeError, UnicodeDecodeError):
            return self._json({"error": "Bad request."}, 400)
        if not isinstance(body, dict):
            return self._json({"error": "Bad request."}, 400)
        if path.startswith("/api/avatars"):   # /api/avatars {name, data}: a new picture; /api/avatars/<name> {marks}; .../delete
            return self._json(*avatar_post(path, body))
        if path.startswith("/api/chats/"):
            ok = chat_action(path, body, self._owner())
            return self._json({"ok": ok}, 200 if ok else 404)
        job, error, code = new_job(body, self._owner())
        return self._json({"id": job["id"], "chat": job.get("chat", "")} if job else {"error": error}, code)

    def _file(self, rel: str) -> None:
        """A file from data/output only (no other folder), with byte ranges so videos can seek."""
        root = config.OUTPUT_DIR.resolve()
        target = (root / rel).resolve()
        if (root not in target.parents or not target.is_file() or chats.folder().resolve() in target.parents
                or target.suffix.lower() == ".log"):   # chats only through /api/chats; logs hold others' addresses
            return self._send(b"not found", "text/plain", 404)
        ctype = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        if target.suffix in (".md", ".txt", ".srt"):
            ctype = "text/plain; charset=utf-8"
        size = target.stat().st_size
        rng = self.headers.get("Range")
        start, end, code = 0, size - 1, 200
        if rng and rng.startswith("bytes="):
            a, _, b = rng[6:].partition("-")
            try:
                start = int(a) if a else max(0, size - int(b))
                end = min(size - 1, int(b)) if a and b else size - 1
            except ValueError:
                start, end = 0, size - 1
            if not b:   # "from here on": a piece at a time, so a video starts at once and many can load together
                end = min(end, start + CHUNK_ON_REQUEST - 1)
            code = 206
        return self._stream(target, start, end, size, ctype, code)

    def _stream(self, target: Path, start: int, end: int, size: int, ctype: str, code: int) -> None:
        """Send part of a file in small blocks (never the whole video in memory at once)."""
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(max(0, end - start + 1)))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Cache-Control", "no-store")
        for k, v in SECURITY_HEADERS.items():
            self.send_header(k, v)
        if code == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.end_headers()
        if self.command == "HEAD":
            return
        with open(target, "rb") as f:
            f.seek(start)
            left = end - start + 1
            while left > 0:
                block = f.read(min(256 * 1024, left))
                if not block:
                    break
                self.wfile.write(block)
                left -= len(block)


CHUNK_ON_REQUEST = 1024 * 1024   # an open range ("bytes=0-") is answered with this much; the player asks for more


class Server(ThreadingHTTPServer):
    """The HTTP server: one thread per connection, so a long video download does not block the page."""
    daemon_threads = True
    ipv6: Server | None = None   # the same page on [::1], when localhost is IPv6 first

    def handle_error(self, request: Any, client_address: Any) -> None:
        """The browser stopping a video it no longer needs (seeking, another video, closing the tab) is
        normal: no error printed for it ("an established connection was aborted")."""
        if isinstance(sys.exc_info()[1], (ConnectionError, TimeoutError)):
            return
        super().handle_error(request, client_address)


class Server6(Server):
    """The same server on IPv6 (when localhost resolves to ::1)."""
    address_family = socket.AF_INET6


def also_on_ipv6(port: int) -> Server | None:
    """The same page on ::1 too (still only this computer). "localhost" can mean ::1 first: VS Code's
    port forwarding then reached nothing ("localhost refused to connect") with only 127.0.0.1."""
    try:
        extra = Server6(("::1", port), Handler)
    except OSError as e:   # no IPv6 on this computer, or the port taken there: 127.0.0.1 is enough
        log.info("Not on ::1: %s", e)
        return None
    threading.Thread(target=extra.serve_forever, daemon=True).start()
    return extra


LOCAL_HOSTS = ("127.0.0.1", "localhost", "::1")


def serve(port: int, open_browser: bool = True, host: str = "127.0.0.1") -> ThreadingHTTPServer:
    """host 127.0.0.1: only this computer (the default); 0.0.0.0: every address (a container, a server)."""
    if host not in LOCAL_HOSTS and not config.APP_PASSWORD and not config.AUTH_PROXY_HEADER:
        raise SystemExit(f"Listening on {host} (not only this computer) needs a password: set APP_PASSWORD "
                         "(in .env or the container's environment) or give --password.")
    server = Server((host, port), Handler)
    server.daemon_threads = True
    server.ipv6 = also_on_ipv6(server.server_address[1]) if host in LOCAL_HOSTS else None
    url = f"http://localhost:{server.server_address[1]}"
    if host not in LOCAL_HOSTS:
        print(f"Listening on {host}:{server.server_address[1]} (all addresses of this machine or container)")
    print(f"Lesson Studio: {url}   (Ctrl+C to stop)"
          + ("   password on" if config.APP_PASSWORD else
             "   NO PASSWORD: a shared link stays closed (uv run app.py --password <a long password>)"))
    if open_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    return server


ACCESS_LOCK = threading.Lock()
PROBES = {"/status": Handler._status, "/healthz": Handler._healthz, "/readyz": Handler._readyz}
STOPPING = threading.Event()   # set on SIGTERM: no new requests, the one being made may finish


def waiting_gauges() -> dict[str, tuple[str, Callable[[], float]]]:
    """The app's own values for /metrics: requests waiting in line and being made."""
    return {"lesson_studio_requests_waiting": ("Requests waiting in line", QUEUE.qsize),
            "lesson_studio_requests_running": ("Requests being made", lambda: sum(j["status"] == "running"
                                                                              for j in list(JOBS.values())))}


def _days(url: ParseResult) -> int:
    """?days=N of the monitoring report (1-90, default 7)."""
    try:
        return min(90, max(1, int(parse_qs(url.query).get("days", ["7"])[0])))
    except ValueError:
        return 7


def readiness() -> tuple[bool, dict[str, bool]]:
    """Can the app take requests? (ready, each check): not stopping, and the data folder can be written."""
    checks = {"not_stopping": not STOPPING.is_set(), "data_writable": _writable(config.DATA_DIR)}
    return all(checks.values()), checks


def _writable(folder: Path) -> bool:
    """A file can be created and removed in `folder` (a full or read-only volume cannot)."""
    try:
        folder.mkdir(parents=True, exist_ok=True)
        probe = folder / f".ready-{os.getpid()}"
        probe.write_bytes(b"")
        probe.unlink()
        return True
    except OSError:
        return False


def stop_when_idle(server: ThreadingHTTPServer, wait_s: float | None = None) -> None:
    """A clean stop (SIGTERM from Kubernetes or `docker stop`): refuse new requests and report not ready, let the
    request being made finish (at most `wait_s`, SHUTDOWN_WAIT_S), then stop the server. Requests still waiting
    are shown as stopped in their chats after the restart (chats.STOPPED)."""
    wait_s = config.SHUTDOWN_WAIT_S if wait_s is None else wait_s
    STOPPING.set()
    log.info("Stopping: no new requests; waiting up to %ss for the one being made", wait_s)
    deadline = time.monotonic() + wait_s
    while time.monotonic() < deadline and any(j["status"] == "running" for j in JOBS.values()):
        time.sleep(0.5)
    busy = [j["id"] for j in JOBS.values() if j["status"] in ("queued", "running")]
    if busy:
        log.warning("Stopped with %s request(s) not finished: %s", len(busy), ", ".join(busy))
    server.shutdown()


def on_sigterm(server: ThreadingHTTPServer) -> None:
    """Make SIGTERM a clean stop (stop_when_idle in its own thread: the server's loop must keep running)."""
    import signal

    def handler(_signum: int, _frame: object) -> None:
        if not STOPPING.is_set():
            threading.Thread(target=stop_when_idle, args=(server,), name="stop", daemon=True).start()
    signal.signal(signal.SIGTERM, handler)


def no_pause_on_click() -> None:
    """Windows: a click in the terminal window starts selecting text ("QuickEdit"), and while it is selecting
    every program writing to that window stops, the page with it (for someone on the shared link it loads
    for ever). Turned off for this window while app.py runs (no admin rights needed)."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        k32 = ctypes.windll.kernel32
        handle = k32.GetStdHandle(-10)   # the window's input
        mode = ctypes.c_uint32()
        if k32.GetConsoleMode(handle, ctypes.byref(mode)):
            k32.SetConsoleMode(handle, (mode.value & ~0x0040) | 0x0080)   # QuickEdit off, extended flags on
    except Exception as e:   # noqa: BLE001 - only a convenience
        log.info("QuickEdit not turned off: %s", e)


def main() -> int:
    """Command line: start Lesson Studio. Returns the exit code."""
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--port", type=int, default=int(os.environ.get("APP_PORT") or 8765))
    ap.add_argument("--host", default=os.environ.get("APP_HOST") or "127.0.0.1",
                    help="127.0.0.1 = only this computer (default); 0.0.0.0 in a container or on a server")
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--password", default="", help="the page's password for this run (instead of APP_PASSWORD in .env)")
    args = ap.parse_args()
    config.setup_logging()
    no_pause_on_click()
    if args.password:
        config.APP_PASSWORD = args.password.strip()
    server = serve(args.port, not args.no_browser, args.host)
    on_sigterm(server)
    if config.METRICS_PORT:
        monitoring.GAUGES.update(waiting_gauges())
        monitoring.serve(config.METRICS_PORT)
    log.info("Lesson Studio %s on %s:%s, data in %s, model %s (%s), voice %s, logs %s", config.APP_VERSION,
             args.host, server.server_address[1], config.DATA_DIR, config.CHAT_MODEL or "-", config.CHAT_BACKEND,
             config.TTS_ENGINE, config.LOG_FORMAT)
    with contextlib.suppress(KeyboardInterrupt):   # Ctrl+C stops the app
        server.serve_forever()
    server.server_close()
    log.info("Stopped")
    if any(j["status"] == "running" for j in JOBS.values()):
        # a request still being made (its own thread, inside the browser or the voice): leave without it. Python's
        # normal exit would stop that thread in the middle of native code and crash (exit code 139)
        logging.shutdown()
        os._exit(0)
    return 0


def page() -> str:
    """The page (app_page.html next to this file; read on every visit, so edits show after a reload)."""
    path = Path(__file__).with_name("app_page.html")
    return path.read_text(encoding="utf-8") if path.exists() else "<h1>app_page.html is missing next to app.py</h1>"


if __name__ == "__main__":
    import sys
    sys.exit(main())
