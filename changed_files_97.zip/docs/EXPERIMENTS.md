# Experiments: optional renderers and voices

None of this is needed by the default product path (**Kokoro voice + HTML slides**). Real-looking
(photographic) presenters are not supported.

## The same video in every tool (`compare_video.py`, tab Comparison)

One script, one timing, every tool, each in two looks, every narrator to switch under each video.

```
uv run compare_video.py                         # a new comparison from a topic of the recordings
uv run compare_video.py --from "<video folder>" # reuse an existing video's script
uv run compare_video.py "Snowflake" --general   # a topic the recordings don't cover
uv run compare_video.py --resume                # finish what failed, after a fix
uv run compare_video.py --only company          # only the company's characters
uv run compare_video.py --redo remotion:editorial
uv run compare_video.py --add-voice "<folder>"  # the same video with another ElevenLabs voice
```

| Tool | Needs | Looks (`VIDEO_LOOK=second` = the second) |
|---|---|---|
| HTML slides (the product) | Playwright's Chromium | Light / Midnight |
| Remotion (`RENDERER=remotion`, `REMOTION_LOOK`) | Node.js 18+, `cd experiments/remotion`, `npm.cmd install` | Classic / Editorial |
| Remotion Pro (`RENDERER=remotion-pro`) | as Remotion | Night sky / Aurora |
| Manim (`RENDERER=manim`) | `MANIM_CMD` | default / Chalkboard |
| Revideo, Motion Canvas (`deck_js.py`) | Node.js; packages install on first use | two each |
| HyperFrames (`RENDERER=hyperframes`) | Node.js 22; installs itself (~1 min), telemetry off, never published | default / dark coral |
| Cartoon presenter bear / fox (`cartoon.py`) | nothing (HTML) | |
| Company avatars as 2D parts (`avatar_parts.py`) | the pictures in `data/avatars` | |

A woman presenter gets women's voices, a man men's. What fails is listed with the reason; the others still run.

## One request through every voice and tool (`benchmark.py`)

```
uv run benchmark.py "a 1-minute video presentation on data connections" --minutes 1
uv run benchmark.py --from "<video folder>" --voices kokoro:bf_emma,elevenlabs:lily@flash --renderers html,remotion-pro
uv run benchmark.py --report "<comparison folder>"     # rebuild comparison.html
```

A narrator is `engine[:voice][@model][+plain]` (`elevenlabs:lily@flash`). `--audio-only` makes only the
narrations; `--vary KEY=a,b` tries any `.env` setting in several versions. Each narrator's voice is made once
and reused by every tool. Results: `comparison.html`, `benchmark.csv`.

## Silent decks in several engines (`deck_video.py`)

`uv run deck_video.py "Snowflake" --slides 7 [--general] [--engines html,manim]` → `slides_<engine>.mp4` + `engines.md`.

## Remotion Pro (`RENDERER=remotion-pro`)

Motion design (glass cards, counters, growing charts, push transitions) with code-drawn presenters:
`PRO_PRESENTER=robot | cat | person-3d | person-2d | company | none`; `PRO_AVATAR` picks the 2D look.
Licences: `remotion/assets/README.md` (cat: CC BY 4.0, credit needed). Faster: `person-2d`,
`VIDEO_WIDTH=1280`, `REMOTION_FPS=25`, `REMOTION_CONCURRENCY=4`. On Windows Remotion is started with
`node` and full paths; a failed render leaves `remotion_error.txt` in the video's folder.
`RENDERER=remotion-ai`: Claude writes each scene's animation code (checked, compiled; a failing scene uses the template).

## ElevenLabs voice (paid)

`TTS_ENGINE=elevenlabs` with `ELEVENLABS_API_KEY` (paid plans need approval). Every part is sent with what
comes before and after it (request stitching), steady settings and a fixed seed; one loudness for the whole
narration. The run card shows what ElevenLabs billed. `uv run usage.py` shows the characters left.
Test: `uv run tts.py --engine elevenlabs "A short test sentence."`.

## Generated clips around a lesson (`ai_clips.py`, `eleven_video.py`)

Scenery only (Google Veo made in ElevenLabs Image & Video), **never a presenter**. Only the title and the
scene headings go to Claude for the prompts; prompts with names, numbers or personal data are replaced.

```
uv run ai_clips.py prompts "<video folder>"     # clip_prompts.txt to paste into the tool
uv run ai_clips.py add "<video folder>" --clip intro.mp4 --clip end.mp4 --tool elevenlabs --model veo-3.1-fast --cost-usd 1.50
uv run eleven_video.py check                    # what the key may do (Pro plan for video by API)
```

Refused tools: Sora (OpenAI), Kling, Seedance, Hailuo, Wan, PixVerse.

## Old cost models (`costs.py`, `tiers.py`)

Estimates from list prices and assumed volumes (`settings/cost_assumptions.csv`, `settings/cost_prices.csv`, `settings/tiers.json`).
**Not used for reported figures:** the AWS costs come only from the AWS Pricing Calculator
(`docs/AWS_CALCULATOR.md`), Claude's cost from the measured tokens (`length_costs.py`).

## One-off analysis

`uv run ablation.py --set <plan> [--repeat 3]`: the test plan in 5 pipeline variants (content vs time
chunking, AI relevance, topic sections) → `ablation.md`.

## Lottie presenter

`uv run tools/add_lottie.py --talk talk.json --point point.json --licence "..."` replaces the drawn presenter
with a Lottie animation (checked: no internet pictures, no text); `--remove` goes back.
