"""
tiers.py - what each budget level costs: per video and per month, at different volumes.

Reads tiers.json (tools, plans and list prices per tier; edit it to try other prices or
volumes). When there are run cards in data/output, the measured average AI cost per video and
the measured characters per minute replace the assumptions, so the numbers follow real runs.

  uv run tiers.py                  # table for the volumes in tiers.json
  uv run tiers.py --minutes 5      # longer videos

Writes data/output/tiers.md and tiers.csv.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys

import config
import store

PATH = config.SETTINGS_DIR / "tiers.json"


def measured() -> dict:
    """Averages from the run cards of real videos: AI cost per video, spoken characters per minute."""
    costs, cpm = [], []
    for path in config.OUTPUT_DIR.glob("*/run_card.json") if config.OUTPUT_DIR.exists() else []:
        c = store.read_json(path, {}) or {}
        if c.get("kind") not in ("video", "dialogue", "course"):
            continue
        script = sum(x["cost_usd"] for x in c.get("cost", {}).get("by_step", []) if x["step"] != "voice")
        if script:
            costs.append(script)
        length = (c.get("time") or {}).get("video_length_s")
        chars = sum(x.get("characters", 0) for x in c.get("cost", {}).get("by_step", []) if x["step"] == "voice")
        if length and chars:
            cpm.append(chars / (length / 60))
    out = {}
    if costs:
        out["script_usd_per_video"] = round(sum(costs) / len(costs), 3)
    if cpm:
        out["characters_per_minute"] = round(sum(cpm) / len(cpm))
    return out


def plan_for(plans: list[dict], need: float, key: str) -> dict:
    """The cheapest plan that covers the need (characters or minutes a month), else the largest."""
    for p in plans:
        if p[key] >= need:
            return p
    return {**plans[-1], "over": True}


def tier_cost(tier: dict, a: dict, videos: int, all_tiers: dict) -> dict:
    """Monthly cost of one tier at a volume, with the plan chosen for each tool."""
    minutes = videos * a["video_minutes"]
    chars = minutes * a["characters_per_minute"]
    lines, total, notes = [], 0.0, []
    for it in tier["items"]:
        cost, plan = 0.0, ""
        if it.get("per_video") == "script":
            cost = videos * a["script_usd_per_video"]
        elif "per_video_usd" in it:   # a fixed price per video (e.g. generated clips)
            cost, plan = videos * it["per_video_usd"], f"${it['per_video_usd']:.2f} per video"
        elif "by_characters" in it:
            plans = it["by_characters"]
            if isinstance(plans, str):   # same plans as another tier
                plans = next(x for x in all_tiers[plans]["items"] if isinstance(x.get("by_characters"), list))["by_characters"]
            p = plan_for(plans, chars, "characters")
            cost, plan = p["monthly"], p["plan"]
            if p.get("over"):
                notes.append(f"{it['tool']}: {chars:,.0f} characters is more than the largest listed plan")
        elif "by_minutes" in it:
            p = plan_for(it["by_minutes"], minutes, "minutes")
            cost, plan = p["monthly"], p["plan"]
            first = it["by_minutes"][0]
            if minutes > first["minutes"]:
                notes.append(f"{it['tool']} {first['plan']} covers {first['minutes']} video minutes a month "
                             f"(~{first['minutes'] // a['video_minutes']:.0f} videos); above that a bigger plan is needed")
            if p.get("assumed"):
                notes.append(f"{it['tool']} {p['plan']}: price is an assumption (quote needed)")
        elif "monthly_per_editor" in it:   # one licence per person building videos (140 h a month each)
            hours = videos * max((x.get("hours_per_video", 0) for x in tier["items"]), default=0)
            editors = max(1, -(-int(hours) // 140))
            cost, plan = it["monthly_per_editor"] * editors, f"{editors} editor(s)"
        elif "hours_per_video" in it:
            cost = videos * it["hours_per_video"] * a["hourly_rate_usd"]
            plan = f"{videos * it['hours_per_video']:.0f} h"
        elif "one_off" in it:
            cost = it["one_off"] / it.get("spread_months", 12)
            plan = f"${it['one_off']:,} once, spread over {it.get('spread_months', 12)} months"
        else:
            cost = it.get("monthly", 0)
        if it.get("assumed"):
            notes.append(f"{it['tool']}: assumed figure")
        lines.append({"tool": it["tool"], "plan": plan, "monthly_usd": round(cost, 2)})
        total += cost
    return {"videos": videos, "minutes": minutes, "monthly_usd": round(total, 2),
            "per_video_usd": round(total / max(videos, 1), 2), "yearly_usd": round(total * 12),
            "lines": lines, "notes": sorted(set(notes))}


def build(minutes: float | None = None) -> dict:
    data = json.loads(PATH.read_text(encoding="utf-8"))
    a = {**data["assumptions"], **measured()}
    if minutes:
        a["video_minutes"] = minutes
    tiers = {t["id"]: t for t in data["tiers"]}
    rows = []
    for t in data["tiers"]:
        for v in a["videos_per_month"]:
            rows.append({"tier": t["name"], "id": t["id"], **tier_cost(t, a, v, tiers)})
    return {"checked": data["checked"], "note": data["note"], "assumptions": a, "tiers": data["tiers"],
            "rows": rows, "sources": data.get("sources", {})}


def markdown(r: dict) -> str:
    a = r["assumptions"]
    vols = a["videos_per_month"]
    out = [f"# Cost per budget tier ({a['video_minutes']:g}-minute videos)", "",
           f"Prices checked {r['checked']}. AI script cost per video: ${a['script_usd_per_video']}; "
           f"{a['characters_per_minute']} spoken characters per minute; editor time ${a['hourly_rate_usd']}/h.", "",
           "| Tier | " + " | ".join(f"{v} videos/month" for v in vols) + " |", "|---|" + "---|" * len(vols)]
    for t in r["tiers"]:
        cells = [next(x for x in r["rows"] if x["id"] == t["id"] and x["videos"] == v) for v in vols]
        out.append(f"| {t['name']} | " + " | ".join(f"${c['monthly_usd']:,.0f}/mo (${c['per_video_usd']:,.2f}/video)"
                                                   for c in cells) + " |")
    out += ["", "## What each tier gives", ""]
    for t in r["tiers"]:
        out += [f"**{t['name']}:** {t['what_you_get']} *Limits:* {t['limits']}", ""]
    notes = sorted({n for x in r["rows"] for n in x["notes"]})
    if notes:
        out += ["## Notes", ""] + [f"- {n}" for n in notes] + [""]
    out += [r["note"], "", "Sources: " + ", ".join(f"[{k}]({v})" for k, v in r["sources"].items())]
    return "\n".join(out) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--minutes", type=float, help="video length in minutes (default from tiers.json)")
    args = ap.parse_args()
    r = build(args.minutes)
    config.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    md = markdown(r)
    (config.OUTPUT_DIR / "tiers.md").write_text(md, encoding="utf-8")
    with open(config.OUTPUT_DIR / "tiers.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["tier", "videos_per_month", "video_minutes", "monthly_usd", "per_video_usd", "yearly_usd", "plans", "notes"])
        for x in r["rows"]:
            w.writerow([x["tier"], x["videos"], r["assumptions"]["video_minutes"], x["monthly_usd"], x["per_video_usd"],
                        x["yearly_usd"], "; ".join(f"{li['tool']}: {li['plan'] or '-'} ${li['monthly_usd']}" for li in x["lines"]),
                        "; ".join(x["notes"])])
    print(md)
    print(f"Written: {config.OUTPUT_DIR / 'tiers.md'} and tiers.csv")
    return 0


if __name__ == "__main__":
    sys.exit(main())
