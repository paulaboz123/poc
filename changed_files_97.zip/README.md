# Lesson Studio

Architecture overview: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

A person asks in plain words and gets a lesson made **only from the company's training recordings and
documents**: an **answer with its sources**, a **document**, a **slide deck**, a **narrated video**, a
**video with two talking characters**, or **audio**. Every result is checked (facts, safety, layout, sound),
gets a verdict (OK / CHECK / FAIL), its cost, the time it took and a run card (what it was made from and with).

The product is **Claude (Amazon Bedrock EU, through the Bifrost gateway) + the Kokoro voice + HTML slides**.
Voice, slides and video are made locally and cost nothing; only Claude is paid.
Optional renderers and voices for comparison are described in [Experiments](#experiments).

## Project rules

| Rule | How the code keeps it |
|---|---|
| Claude only on Bedrock **EU** (`eu.` model ids); no OpenAI; no models of Chinese origin (also offline) | every model call refuses OpenAI and Chinese-origin ids (`safety.model_not_allowed`); the EU ids come from `.env` |
| Keys only in `.env` (never in code, the image, S3 or a chat) | `.env` is in `.gitignore` and `.dockerignore` |
| Spending lock | `DAILY_BUDGET_USD` (default 20, never above 100), `RUN_BUDGET_USD` (default 5) |
| No real-looking (photographic) presenters | not in the code; presenters are drawn (bear, fox, the company's characters as 2D parts) |
| Personal data stays in | speaker names masked before anything leaves; company pictures stay local |
| Shared only with the data owner's approval and `APP_PASSWORD` | a shared link without a password is refused |
| Costs only from measured tokens and the AWS Pricing Calculator | no guessed prices in the code (`docs/AWS_CALCULATOR.md`) |

## How it works

```
data/input  (recordings + transcripts, documents, quizzes, description.xlsx)
   │  pipeline.py: read, cut into sections, describe the slides, index     (once per recording)
   ▼
app.py (Lesson Studio) / ask.py "request"
   1 understand  format, topic, length, level; off-topic requests stopped before any paid call
   2 find        meaning search + word search (BM25), each with the excerpt's search context, fused;
                 Claude keeps the excerpts that answer; none? searched again in the material's terms
   3 write       Claude writes the answer / document / storyboard from those excerpts only; an answer is
                 then checked sentence by sentence (unsupported removed, partly supported corrected)
   4 make        HTML slides (Chromium) + Kokoro voice + ffmpeg → video; or the document / deck / audio
   5 check       numbers vs sources, claim check, safety, personal data, layout, sound → verdict
   6 run card    input, sources, models, cost, time
```

## Run it locally

### Once

1. **Programs:** `ffmpeg` (and Tesseract OCR) on PATH, or their paths in `.env`. Check: `ffmpeg -version`.
2. **Python packages:** `uv sync` (or `uv add httpx python-dotenv python-docx python-pptx numpy pillow pydantic
   openpyxl pypdf kokoro-onnx playwright`, and `uv add --dev pytest ruff`).
3. **Browser for the slides:** `uv run playwright install chromium` (if blocked, the installed Edge is used).
4. **Settings:** copy `.env.bifrost.example` to `.env` and fill in the three values from the platform team:
   `BIFROST_BASE_URL`, `BIFROST_API_KEY`, `CHAT_MODEL` (the EU Sonnet id). HTTP 401: `BIFROST_AUTH_HEADER=x-bf-vk`.
5. **Voice** (~120 MB, once): `uv run tts.py --download`, then `uv run tts.py "A short test."`. If GitHub is
   blocked, download `kokoro-v1.0.int8.onnx` and `voices-v1.0.bin` from the kokoro-onnx release
   `model-files-v1.0` into `models/`.
6. **Check:** `uv run doctor.py --models` (every line `[OK]`) and `uv run pytest` (offline, free).

Search runs locally with Ollama's `nomic-embed-text` (`EMBED_BACKEND=ollama`), or on Bedrock Titan
(`EMBED_BACKEND=bifrost`). After changing it: `uv run index.py build`. If the meaning search is unavailable,
the word search alone is used and a warning is logged.

### Prepare the recordings

1. Put the videos (`.mp4`), their transcripts (`.vtt`/`.docx`, same name) and `description.xlsx`
   (`id`, `name`, `description`) into `data/input/`.
2. `uv run inventory.py`: set `include` to `yes` in `data/manifest.csv` for the videos to use.
3. Slide area of one video: `uv run slides.py --video <id> --preview`, then `SLIDE_CROP` / `SLIDE_MASK` in
   `.env` if a presenter or Teams panel covers the slide.
4. `uv run pipeline.py --mode easy --vision` (Claude reads the slides), then check the search:
   `uv run index.py search "how to join two tables" -k 5`.
5. Search contexts (once; better search): `uv run contextual.py` shows the price, `uv run contextual.py --yes`
   writes them and rebuilds the index.

### Lesson Studio

`uv run app.py` opens http://localhost:8765.

| Tab | What it does |
|---|---|
| **Ask** | one box like a chat; pick the output, narrator and level, or let the words decide. Every chat is kept (`data/output/chats`), per browser |
| **How it works** | the flow for business readers |
| **Prices & results** | what one video costs by length (measured, with Claude's tokens in + cached / out and the time it took), AWS a month (only from the calculator's export in `data/aws/`), spent today, every result with its links |
| **Comparison** | renderers and voices side by side (see [Experiments](#experiments)) |

Requests wait in line: one is made at a time, the page shows "Waiting in line: N ahead". Each browser sees only
its own requests; at most 3 may wait per browser.

**Sharing for a test** (with the data owner's approval): `APP_PASSWORD=<long>` in `.env`, restart (the first line
says "password on"), VS Code > Ports > Forward `8765` > Port Visibility > Public. Send the address and the password.
The sign-in lasts 30 days, then the password is asked again; over https the cookies are `Secure`. Requests are
limited in size (64 KB, pictures 12 MB) and every answer carries security headers. `<address>/status` (no sign-in)
tells whether the link reaches the app; every request is logged in `data/output/app_access.log`.

## What you can ask for

| Ask for... | You get | Made by |
|---|---|---|
| a question (what is, how do I, why) | a short answer, the source of every sentence (recording, time, exact words) | `answer.py` |
| a document, lecture notes | `lesson.html` (Ctrl+P = PDF) + `lesson.md` | `lesson.py` |
| slides to present myself | `slides.pdf`, `slides.pptx` (in the company template when it is in `data/brand/`), speaker notes | `deck.py` |
| a video | `lesson_video.mp4` + `lesson_audio.mp3`; 4+ minutes: a course with chapters | `make_video.py`, `course.py` |
| two people talking | the same video, a host asks and an expert explains, two voices | `make_video.py --style dialogue` |
| something to listen to | `lesson_audio.mp3` | as video |
| a topic the material doesn't cover (brownies) | "not in the training material", no Claude call | `ask.py` |

```
uv run ask.py "A 3-minute video where two people talk about the daily scrum"
uv run make_video.py --recording 13 --minutes 2 --plan-only     # check script.md, then:
uv run make_video.py --rerender "data/output/<folder>"
```

To fix a word in a video: edit `storyboard.json` in its folder and `--rerender` (no model call).
Look: `STYLE=clean | illustrated | presenter`; presenters `CHARACTERS=cartoon | people`,
`CARTOON_PRESENTER=bear | parts:ai:<name>` (a company character drawn in parts, `avatar_parts.py`).
Company look: logo, PowerPoint template, fonts and `brand.json` in `data/brand/` (`uv run brand.py --preview`).
Pronunciation: a row in `settings/pronunciation.csv` (`KPI,K P I`).

## Costs

**Per video only Claude costs money.** Every model call is logged in `cost_log.csv` with its fresh, cache-write,
cache-read and output tokens. The long instructions are cached (`PROMPT_CACHE=yes`): a cache read costs 10% of
the input price, a cache write 125%.

- **Measure:** `uv run length_costs.py "<a topic the recordings cover>"` makes 3, 5, 10 and 15-minute videos
  and writes `data/output/length_costs/length_costs.md` + `.xlsx` (shown in Prices & results).
  `--from 1m` extends an existing video step by step; `--report` only redoes the tables.
- **Price:** `PRICE_IN_PER_MTOK` / `PRICE_OUT_PER_MTOK` in `.env` = what the AWS Pricing Calculator's Bedrock
  entry shows (EU). Empty = list prices in `config.py` (+10% for EU ids).
- **AWS a month:** only from the calculator: `docs/AWS_CALCULATOR.md` says what to enter (Prod and Dev),
  the exported CSV goes into `data/aws/`.
- **Measured** (Claude only; measure again with `length_costs.py` after prompt or model changes): 1 min ~$0.20,
  3 min ~$0.69, 5 min ~$1.04, 10 min ~$1.70, 15 min ~$2.27.
- **Cheaper relevance check:** `RERANK_MODEL=<Haiku EU id>`; check the answers stay as good with `qa_eval.py`.

`uv run usage.py` shows today's spend against the limit; `uv run usage.py --steps` where the money goes, step by step. A question asked again with the same material and settings is answered from the cache ($0, `ANSWER_CACHE`). What costs what, what was cut and what stays for quality: `docs/COSTS.md`.

## Quality

| What | Command |
|---|---|
| Does everything work, with the real model (~$1) | `uv run smoke.py` (or `--quick`) → `data/output/smoke_report.md` |
| Answer quality on a test set (retrieval, hallucination, correctness, declines, copying) | `uv run qa_eval.py --draft 20`, then `uv run qa_eval.py` → `qa_report.html` |
| A test plan in Excel, as it is | `uv run qa_eval.py --set "<plan>.xlsx"` → `<plan>_results.xlsx` |
| Checks of any result (`--review`: claim by claim; `--listen`: Whisper hears the voice) | `uv run quality.py <folder>` / `--all` |
| Can the judge be trusted | `uv run calibrate.py export`, fill in your verdicts, `uv run calibrate.py score <file>` |
| Lessons and videos against a golden set | `uv run evaluate.py --draft`, then `uv run evaluate.py` |

Use a judge that is not the writer (`JUDGE_MODEL`, e.g. Opus when Sonnet writes). What the answers do against
hallucination, the settings and how to measure before and after: `docs/RAG_QUALITY.md`.

## Run it on AWS

One container (page, Kokoro, HTML slides, ffmpeg) in one pod on Kubernetes (EKS): `Dockerfile`, the Helm chart
`charts/proto-learning-agent/`, the GitLab pipeline `.gitlab-ci.yml` (checks, image build to ECR, GitOps image
tag bump to the `deploy-dev` branch). Details: `docs/DEPLOY.md`. On one EC2 machine: `docs/DOCKER_AWS.md`.

## Tests and code quality

```
uv run pytest                          # the product's tests (offline, stand-in models, free); -n auto: all cores
uv run pytest -m "slow or not slow"    # everything, including the long renders and the comparison
uv run --with ruff ruff check .        # style, complexity, docstrings, annotations
uv run --with mypy mypy                # types
```

What is tested and how, the layers (tests, eval gate, smoke) and how to make it faster: `docs/TESTING.md`.
The code rules (docstrings, types, small functions, where `except Exception` is allowed): `docs/CODE_STYLE.md`.
Monitoring and answer evaluation in use (the page's "Quality and health", `/metrics`, alerts, the weekly test plan run):
`docs/MONITORING.md`.

## Commands (product)

| Command | What it does |
|---|---|
| `uv run app.py [--port 8765] [--host 0.0.0.0] [--no-browser]` | Lesson Studio |
| `uv run ask.py "what, how long, which level"` | one result from the terminal |
| `uv run answer.py "question"` / `uv run retrieval.py "question"` | an answer with sources / only what would be used |
| `uv run lesson.py "topic" --minutes 5 --level beginner` | document |
| `uv run deck.py "topic" --minutes 4` | slides |
| `uv run make_video.py "topic" --minutes 2 [--style dialogue] [--plan-only]` / `--rerender <folder>` | video |
| `uv run course.py "request" --minutes 8` / `--redo-chapter N <folder>` | course with chapters |
| `uv run extend.py <folder or 1m> --minutes 5` | a longer video built on a shorter one |
| `uv run pipeline.py --mode easy [--vision] [--force]` | prepare all included recordings |
| `uv run documents.py` / `catalog.py` / `topics.py` / `glossary.py` | what was found besides recordings / description.xlsx checked / topics per recording / terms |
| `uv run index.py build` / `search "..."` | rebuild / test the search |
| `uv run contextual.py [--yes]` | search contexts for every excerpt: price / write them (once) |
| `uv run length_costs.py "topic"` / `uv run aws_estimate.py` | cost by length / what was read from the calculator export |
| `uv run doctor.py [--models]` / `uv run usage.py` / `uv run llm.py` | setup check / spend / model smoke test |
| `uv run compare.py` | every result side by side from the run cards |

Levels: `beginner`, `intermediate`, `expert`.

## When something fails

| Message | Fix |
|---|---|
| `HTTP 401/403 ... rejected` | wrong key or model not allowed: check `.env`, ask the platform team |
| `HTTP 404 ... model id unknown` | copy the exact id from `uv run doctor.py --models` |
| `CERTIFICATE_VERIFY_FAILED` | company TLS inspection: `CA_BUNDLE` = the company `.pem` |
| `Can this machine reach the gateway` | VPN/proxy, or the URL works only inside the cluster |
| `Is Ollama running?` | start Ollama (search falls back to word search meanwhile) |
| `Index was built with ...` | embedding model changed: `uv run index.py build` |
| `Spending lock: ...` | daily or per-command limit reached; raise it only if expected (max 100/day) |
| `You already have 3 requests waiting` (HTTP 429) | wait until one of this browser's requests is finished |
| presenter visible on the slides | `SLIDE_MASK`, then `--rerender` |

## Repo map

| Folder | Content |
|---|---|
| `/` (root) | Python modules (flat: run as `uv run <module>.py`), `Dockerfile`, `compose.yaml`, tool configs |
| `assets/` | Fonts, icons, illustrations, animation libraries |
| `charts/proto-learning-agent/` | Helm chart (`values.yaml`, `values-dev-eks.yaml`) |
| `docs/` | Architecture, design, deployment, costs, testing, monitoring |
| `eval/` | Golden set for `evaluate.py` |
| `experiments/` | Optional Node.js renderers (Remotion, Revideo, Motion Canvas, HyperFrames) |
| `settings/` | Editable settings files: `pronunciation.csv`, cost assumptions and prices |
| `skills/` | Prompts (`compose-video`, `compose-lesson`) |
| `tests/` | Offline tests (`uv run pytest`) |
| `tools/` | Helper scripts (`check_deploy.py`, `add_lottie.py`) |

| Part | Modules |
|---|---|
| Page and requests | `app.py`, `app_page.html`, `chats.py`, `ask.py`, `runcard.py`, `compare.py` |
| Preparing the material | `pipeline.py`, `inventory.py`, `ingest.py`, `transcribe.py`, `slides.py`, `describe_slides.py`, `documents.py`, `catalog.py`, `chunking.py`, `index.py`, `glossary.py`, `topics.py` |
| Answers and lessons | `retrieval.py`, `contextual.py`, `answer.py`, `lesson.py`, `storyboard.py`, `document.py`, `deck.py`, `course.py`, `extend.py`, `dialogue.py` |
| Video | `make_video.py`, `slides_html.py`, `animation.py`, `render.py`, `illustrations.py`, `cartoon.py`, `avatar_parts.py`, `company_avatar.py` (picture store), `brand.py`, `tts.py`, `media.py` |
| Checks | `quality.py`, `facts.py`, `safety.py`, `qa_eval.py`, `evaluate.py`, `calibrate.py`, `smoke.py`, `doctor.py` |
| Core and cost | `config.py`, `llm.py`, `store.py`, `usage.py`, `length_costs.py`, `aws_estimate.py` |
| Prompts | `skills/compose-video/`, `skills/compose-lesson/` |
| Deploy | `Dockerfile`, `compose.yaml`, `.gitlab-ci.yml`, `charts/`, `docs/DEPLOY.md`, `docs/DOCKER_AWS.md`, `docs/AWS_CALCULATOR.md` |
| Design | `docs/ARCHITECTURE.md`, `docs/DESIGN.md`, `docs/RAG_QUALITY.md`, `docs/COSTS.md`, `docs/TESTING.md`, `docs/MONITORING.md` |

## Experiments

Optional renderers and voices, compared on the same content: Remotion, Remotion Pro, Manim, Revideo, Motion
Canvas, HyperFrames, ElevenLabs, generated scenery clips, and the earlier cost models. The default product path
(Kokoro + HTML slides) needs none of them and no Node.js. Usage: `docs/EXPERIMENTS.md`.
