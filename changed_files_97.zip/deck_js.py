"""
deck_js.py - the silent slide deck drawn by Revideo or Motion Canvas (both free, MIT licence, TypeScript
animation engines; Revideo is the fork of Motion Canvas built for rendering from code). Used by
deck_video.py (--engines revideo,motion-canvas): the same storyboard, the same timing as the other engines.

Each engine is a small Node.js project created next to this file the first time (revideo/ or
motion-canvas/), with its packages installed once (npm install, 1-2 minutes). Needs Node.js 18+.
The slide scene is the same code for both (their animation API is the same): written here as SCENE.

How each one renders, with no clicking:
  revideo        its own headless renderer (renderVideo) in a hidden Chrome
  motion-canvas  it has no headless renderer, only an editor in the browser with a "Render" button:
                 the editor is started here and its button is pressed by a hidden browser (Playwright),
                 then the video it writes is collected. If its editor changes, this is the part that can break.
"""
from __future__ import annotations

import json
import logging
import os
import re
import shutil
import socket
import subprocess
import time
from pathlib import Path

import config

log = logging.getLogger("deck_js")

ROOT = config.EXPERIMENTS_DIR   # one project folder per engine
VERSIONS = {"revideo": "0.11.0", "motion-canvas": "3.17.2"}
PACKAGES = {
    "revideo": ["@revideo/core", "@revideo/2d", "@revideo/renderer", "@revideo/vite-plugin", "@revideo/ffmpeg",
                "@revideo/ui"],
    "motion-canvas": ["@motion-canvas/core", "@motion-canvas/2d", "@motion-canvas/vite-plugin", "@motion-canvas/ui",
                      "@motion-canvas/ffmpeg", "vite"],
}
# Each engine its own look, so they can be told apart side by side (the content and timing are the same)
THEMES = {
    "revideo": {"bg": "#FBF7F2", "ink": "#1F2430", "quiet": "#6B6F7B", "accent": "#E4572E", "soft": "#FCE7DE",
                "card": "#FFFFFF", "line": "#EADFD5", "good": "#2E7D32", "bad": "#C62828", "font": "Georgia",
                "on_accent": "#FFFFFF", "move": "x"},
    "motion-canvas": {"bg": "#0F172A", "ink": "#E2E8F0", "quiet": "#94A3B8", "accent": "#38BDF8", "soft": "#0B3A55",
                      "card": "#1E293B", "line": "#334155", "good": "#4ADE80", "bad": "#F87171", "font": "Arial",
                      "on_accent": "#0F172A", "move": "y"},
}
THEME = THEMES["revideo"]
# VIDEO_LOOK=second: the other way round: Revideo dark plum and mint, Motion Canvas light with violet
SECOND_THEMES = {
    "revideo": {"bg": "#1C1729", "ink": "#F4EEFF", "quiet": "#B4AACB", "accent": "#5EEAD4", "soft": "#213F45",
                "card": "#272036", "line": "#3B3152", "good": "#86EFAC", "bad": "#FCA5A5", "font": "Arial",
                "on_accent": "#1C1729", "move": "y"},
    "motion-canvas": {"bg": "#F6F4EE", "ink": "#1D1A2E", "quiet": "#625D74", "accent": "#7C3AED", "soft": "#ECE4FF",
                      "card": "#FFFFFF", "line": "#E2DCEE", "good": "#15803D", "bad": "#B91C1C", "font": "Georgia",
                      "on_accent": "#FFFFFF", "move": "x"},
}


def theme_for(engine: str) -> dict:
    return (SECOND_THEMES if config.VIDEO_LOOK == "second" else THEMES).get(engine, THEME)


# One scene for both engines: __CORE__ / __2D__ are replaced by the engine's package names, __NAME__ by the
# scene name Revideo wants as the first argument of makeScene2D (Motion Canvas takes only the function).
SCENE = r"""
import {makeScene2D, Layout, Rect, Txt} from '__2D__';
import {all, createRef, waitFor, easeOutCubic, easeInCubic} from '__CORE__';
import deck from '../deck.json';

const T: any = (deck as any).theme;
const W = 1920, H = 1080;

function clean(s: any): string { return String(s ?? '').replace(/\*\*/g, '').trim(); }

function Card(props: {title?: string; detail?: string; value?: string; width: number; grow?: boolean}) {
  return (
    <Rect layout direction={'column'} gap={14} padding={[30, 32, 30, 40]} width={props.width} radius={18}
          fill={T.card} stroke={T.line} lineWidth={2} shadowColor={'#14213D18'} shadowBlur={24} shadowOffsetY={6}>
      <Rect width={8} height={44} radius={4} fill={T.accent} position={[-props.width / 2 + 18, 0]} layout={false}/>
      {props.value ? <Txt text={clean(props.value)} fontFamily={T.font} fontWeight={800} fontSize={64} fill={T.accent}/> : null}
      {props.title ? <Txt text={clean(props.title)} fontFamily={T.font} fontWeight={700} fontSize={38} fill={T.ink}
                          textWrap width={props.width - 72}/> : null}
      {props.detail ? <Txt text={clean(props.detail)} fontFamily={T.font} fontSize={28} lineHeight={40} fill={T.quiet}
                           textWrap width={props.width - 72}/> : null}
    </Rect>
  );
}

function items(sc: any): any[] {
  if (sc.elements && sc.elements.length) return sc.elements;
  return (sc.items || []).map((x: string) => ({title: x}));
}

// the content of one slide: a list of blocks that appear one after another
function blocks(sc: any): any[] {
  const v = sc.visual;
  const E = items(sc);
  const usable = W - 240;
  if (v === 'comparison' && sc.columns && sc.columns.length) {
    const n = sc.columns.length, w = (usable - 40 * (n - 1)) / n;
    return sc.columns.map((c: any) => (
      <Rect layout direction={'column'} gap={22} padding={[34, 40]} width={w} radius={18} fill={T.card}
            stroke={T.line} lineWidth={2}>
        <Txt text={clean(c.heading)} fontFamily={T.font} fontWeight={700} fontSize={40} fill={T.ink}/>
        {(c.items || []).map((it: string) => (
          <Layout layout direction={'row'} gap={18} alignItems={'center'}>
            <Rect width={16} height={16} radius={8}
                  fill={c.tone === 'positive' ? T.good : c.tone === 'negative' ? T.bad : T.accent}/>
            <Txt text={clean(it)} fontFamily={T.font} fontSize={32} fill={T.ink} textWrap width={w - 120}/>
          </Layout>
        ))}
      </Rect>
    ));
  }
  if (v === 'table' && sc.table_header && sc.table_header.length) {
    const n = sc.table_header.length, cw = usable / n;
    const row = (cells: string[], head: boolean, k: number) => (
      <Rect layout direction={'row'} fill={head ? T.accent : (k % 2 ? T.card : T.bg)} radius={head ? [14, 14, 0, 0] : 0}>
        {cells.map((c: string) => (
          <Layout padding={[20, 26]} width={cw}>
            <Txt text={clean(c)} fontFamily={T.font} fontWeight={head ? 700 : 400} fontSize={32}
                 fill={head ? T.on_accent : T.ink} textWrap width={cw - 52}/>
          </Layout>
        ))}
      </Rect>
    );
    return [row(sc.table_header, true, 0), ...(sc.table_rows || []).map((r: string[], k: number) => row(r, false, k + 1))];
  }
  if (v === 'callout' && E.length) {
    const e = E[0];
    return [(
      <Rect layout padding={[56, 64]} width={usable} radius={22} fill={T.soft} stroke={T.accent} lineWidth={3}>
        <Txt text={clean(e.title) + (e.detail ? '. ' + clean(e.detail) : '')} fontFamily={T.font} fontWeight={700}
             fontSize={52} lineHeight={70} fill={T.ink} textWrap width={usable - 128}/>
      </Rect>
    )];
  }
  if (v === 'concept') {
    const d = E[0] || {title: sc.subheading};
    const out = [(
      <Rect layout padding={[44, 56]} width={usable} radius={20} fill={T.card} stroke={T.line} lineWidth={2}>
        <Txt text={clean(d.title) + (d.detail ? ': ' + clean(d.detail) : '')} fontFamily={T.font} fontSize={44}
             lineHeight={62} fill={T.ink} textWrap width={usable - 112}/>
      </Rect>
    )];
    if (E[1]) out.push(<Card title={'Example'} detail={clean(E[1].title) + ' ' + clean(E[1].detail)} width={usable}/>);
    return out;
  }
  if (!E.length) return [];
  const n = E.length;
  const cols = n <= 3 ? n : n === 4 ? 2 : 3;
  const flow = v === 'steps' || v === 'timeline';
  const gap = flow ? 60 : 36;
  const w = flow ? (usable - gap * (n - 1)) / n : (usable - gap * (cols - 1)) / cols;
  // steps are numbered 01, 02 ...; stats and timeline show their value
  return E.map((e: any, i: number) => <Card title={e.title} detail={e.detail} width={w}
                                 value={v === 'stats' || v === 'timeline' ? e.value
                                        : v === 'steps' ? String(i + 1).padStart(2, '0') : ''}/>);
}

export default makeScene2D(__NAME__function* (view) {
  view.fill(T.bg);
  const slides: any[] = (deck as any).slides;
  const progress = createRef<Rect>();
  view.add(<Rect width={W} height={8} fill={T.line} y={H / 2 - 4}/>);
  view.add(<Rect ref={progress} width={1} height={8} fill={T.accent} x={-W / 2} offsetX={-1} y={H / 2 - 4}/>);
  view.add(<Txt text={clean((deck as any).title)} fontFamily={T.font} fontSize={22} fill={T.quiet}
                x={-W / 2 + 60} offsetX={-1} y={H / 2 - 44}/>);
  for (let k = 0; k < slides.length; k++) {
    const sc = slides[k];
    const total: number = sc.seconds;
    const slide = createRef<Layout>();
    const title = sc.visual === 'title';
    const parts = title ? [] : blocks(sc);
    // three arrangements: one row (steps, a few cards), a grid (4+ cards), a column (table, callout, concept)
    const column = ['table', 'callout', 'concept'].includes(sc.visual);
    const flowRow = !column && (['steps', 'timeline', 'comparison'].includes(sc.visual) || parts.length <= 3);
    const partRefs = parts.map(() => createRef<Layout>());
    view.add(
      <Layout ref={slide} layout direction={'column'} width={W} height={H} padding={[110, 120, 120, 120]} gap={28}
              justifyContent={title ? 'center' : 'start'} opacity={0} {...(T.move === 'y' ? {y: 90} : {x: 120})}>
        <Txt text={clean(sc.heading || (deck as any).title)} fontFamily={T.font} fontWeight={800}
             fontSize={title ? 96 : 62} lineHeight={title ? 112 : 76} fill={T.ink} textWrap width={W - 240}/>
        <Rect width={title ? 150 : 110} height={8} radius={4} fill={T.accent}/>
        {sc.subheading || title ? <Txt text={clean(sc.subheading || (deck as any).goal || '')} fontFamily={T.font}
                                       fontSize={title ? 40 : 32} fill={T.quiet} textWrap width={W - 240}/> : null}
        {title ? (sc.items || []).slice(0, 3).map((x: string) => (
          <Layout layout direction={'row'} gap={18} alignItems={'center'}>
            <Rect width={14} height={14} radius={7} fill={T.accent}/>
            <Txt text={clean(x)} fontFamily={T.font} fontSize={34} fill={T.ink}/>
          </Layout>)) : null}
        {parts.length ? (
          <Layout layout direction={'column'} grow={1} alignItems={'center'} justifyContent={'center'} marginTop={20}>
            <Layout layout direction={column ? 'column' : 'row'} wrap={column || flowRow ? 'nowrap' : 'wrap'}
                    width={column || flowRow ? null : W - 240} justifyContent={'center'}
                    gap={sc.visual === 'table' ? 0 : flowRow ? 36 : 28} alignItems={column ? 'center' : 'stretch'}>
              {parts.map((p: any, i: number) => (
                <Layout layout ref={partRefs[i]} opacity={0} alignItems={'stretch'}>{p}</Layout>))}
            </Layout>
          </Layout>) : null}
      </Layout>
    );
    const move: any = T.move === 'y' ? slide().y : slide().x;   // revideo slides in sideways, motion-canvas upwards
    yield* all(
      slide().opacity(1, 0.6, easeOutCubic), move(0, 0.6, easeOutCubic),
      progress().width(W * (k + 1) / slides.length, 0.6),
    );
    // the slide lasts exactly sc.seconds (the same timing as every other engine): 0.6 in, parts, wait, 0.5 out
    let used = 0.6;
    const build = sc.animation === 'build' || sc.animation === 'highlight';
    const fade = build ? 0.45 : 0.25;
    const step = build ? Math.max(fade, Math.min(1.6, (total - used - 1.5) / Math.max(1, parts.length))) : fade;
    for (const r of partRefs) {
      r().scale(0.94);
      yield* all(r().opacity(1, fade, easeOutCubic), r().scale(1, fade, easeOutCubic));
      if (step > fade) yield* waitFor(step - fade);
      used += step;
    }
    yield* waitFor(Math.max(0.1, total - used - 0.5));
    yield* all(slide().opacity(0, 0.5, easeInCubic), move(T.move === 'y' ? -90 : -120, 0.5, easeInCubic));
    slide().remove();
  }
});
"""

PROJECT_TS = """import {makeProject} from '__CORE__';
import deck from './scenes/deck?scene';
export default makeProject({scenes: [deck]});
"""

VITE_MC = """import {defineConfig} from 'vite';
import motionCanvasPlugin from '@motion-canvas/vite-plugin';
import ffmpegPlugin from '@motion-canvas/ffmpeg';
// both are CommonJS packages: their function may sit under .default
const motionCanvas: any = (motionCanvasPlugin as any).default ?? motionCanvasPlugin;
const ffmpeg: any = (ffmpegPlugin as any).default ?? ffmpegPlugin;
export default defineConfig({plugins: [motionCanvas(), ffmpeg()]});
"""

RENDER_RV = """import {renderVideo} from '@revideo/renderer';
// the ffmpeg exporter: Revideo's default (WebCodecs in the browser) fails in Playwright's Chromium, which has no
// H.264 encoder ("Cannot call 'encode' on a closed codec"). The output folder is relative: Revideo joins it to
// the current folder, which breaks Windows paths like C:\\...
const chrome = process.argv[2];
const port = parseInt(process.argv[3] || '9000', 10);   // a free port (another program may use 9000)
// Revideo always adds Chrome's '--single-process'. On Windows Chrome then drops the page while it opens it
// ("Navigating frame was detached"). This list answers "already there" when Revideo asks, so it is not added.
const args = ['--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage', '--disable-extensions'];
args.includes = (a, ...rest) => a === '--single-process' || Array.prototype.includes.call(args, a, ...rest);
try {
  const file = await renderVideo({
    projectFile: './src/project.ts',
    settings: {
      outFile: 'deck.mp4', outDir: './output', logProgress: true, viteBasePort: port,
      projectSettings: {size: {x: 1920, y: 1080}, background: '#FBF7F2',
                        exporter: {name: '@revideo/core/ffmpeg', options: {format: 'mp4'}}},
      puppeteer: {...(chrome ? {executablePath: chrome} : {}), protocolTimeout: 600000, args},
    },
  });
  console.log('WROTE ' + file);
  process.exit(0);   // its preview server keeps Node running otherwise
} catch (e) {
  console.error('FAILED ' + (e && e.stack ? e.stack : e));
  process.exit(1);
}
"""

TSCONFIG = json.dumps({"compilerOptions": {"target": "ES2020", "module": "ESNext", "moduleResolution": "bundler",
                                           "jsx": "react-jsx", "jsxImportSource": "__2D__/lib", "strict": False,
                                           "skipLibCheck": True, "resolveJsonModule": True,
                                           "allowSyntheticDefaultImports": True},
                       "include": ["src"]}, indent=2)


def project_dir(engine: str) -> Path:
    return ROOT / engine


def _names(engine: str) -> tuple[str, str]:
    return ("@revideo/core", "@revideo/2d") if engine == "revideo" else ("@motion-canvas/core", "@motion-canvas/2d")


def npm() -> str | None:
    return shutil.which("npm.cmd") or shutil.which("npm")


def write_project(engine: str, data: dict) -> Path:
    """The engine's project files (overwritten each time: the scene follows this file) and the deck."""
    core, two_d = _names(engine)
    d = project_dir(engine)
    (d / "src" / "scenes").mkdir(parents=True, exist_ok=True)
    pkg = {"name": f"deck-{engine}", "private": True, "type": "module",
           "dependencies": {p: VERSIONS[engine] if p != "vite" else "5.4.11" for p in PACKAGES[engine]}}
    if engine == "motion-canvas":
        pkg["scripts"] = {"serve": "vite"}
    (d / "package.json").write_text(json.dumps(pkg, indent=2), encoding="utf-8")
    (d / "tsconfig.json").write_text(TSCONFIG.replace("__2D__", two_d), encoding="utf-8")
    scene = SCENE.replace("__CORE__", core).replace("__2D__", two_d)
    scene = scene.replace("__NAME__", "'deck', " if engine == "revideo" else "")
    (d / "src" / "scenes" / "deck.tsx").write_text(scene, encoding="utf-8")
    (d / "src" / "project.ts").write_text(PROJECT_TS.replace("__CORE__", core), encoding="utf-8")
    (d / "src" / "deck.json").write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    if engine == "revideo":
        (d / "render.mjs").write_text(RENDER_RV.replace("'#FBF7F2'", repr(data["theme"]["bg"])), encoding="utf-8")
    else:
        (d / "vite.config.ts").write_text(VITE_MC, encoding="utf-8")
        meta = {"version": 0, "shared": {"background": data["theme"]["bg"], "range": [0, None], "size": {"x": 1920, "y": 1080},
                                         "audioOffset": 0},
                "preview": {"fps": 30, "resolutionScale": 1},
                "rendering": {"fps": 30, "resolutionScale": 1, "colorSpace": "srgb",
                              "exporter": {"name": "@motion-canvas/ffmpeg", "options": {"fastStart": True,
                                                                                        "includeAudio": False}}}}
        (d / "src" / "project.meta").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return d


def installed(engine: str) -> bool:
    d = project_dir(engine) / "node_modules"
    return all((d / p).exists() for p in PACKAGES[engine])


def install(engine: str) -> None:
    """npm install once (1-2 minutes). Chrome is not downloaded: the one Playwright installed is used."""
    if installed(engine):
        return
    exe = npm()
    if not exe:
        raise RuntimeError("Node.js not found (install Node.js 18+; npm must work in a terminal)")
    log.info("%s: installing its packages once (npm install, 1-2 minutes) ...", engine)
    env = {**os.environ, "PUPPETEER_SKIP_DOWNLOAD": "1"}
    r = subprocess.run([exe, "install", "--no-audit", "--no-fund"], cwd=project_dir(engine), capture_output=True,
                       text=True, encoding="utf-8", errors="replace", timeout=1200, env=env)
    if r.returncode != 0 or not installed(engine):
        raise RuntimeError(f"npm install for {engine} failed: {(r.stderr or r.stdout)[-600:]}")


def chrome() -> str | None:
    found = browsers()
    return found[0] if found else None


def browsers() -> list[str]:
    """Chromium browsers for Revideo's hidden browser, best first: DECK_CHROME, the one Playwright installed
    (uv run playwright install chromium), its headless shell, Edge or Chrome on this computer."""
    found: list[Path] = [Path(os.environ["DECK_CHROME"])] if os.getenv("DECK_CHROME") else []
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            path = Path(p.chromium.executable_path)
        found.append(path)
        root = path.parents[2] if len(path.parents) > 2 else path.parent   # ...ms-playwright/chromium-NNNN/chrome-x/
        found += sorted(root.glob("chromium_headless_shell-*/*/chrome-headless-shell*"), reverse=True)
    except Exception:   # noqa: BLE001 - no Playwright: try the browsers of the computer
        pass
    found += [Path(os.environ.get(v, "-")) / sub for v in ("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA")
              for sub in ("Microsoft/Edge/Application/msedge.exe", "Google/Chrome/Application/chrome.exe")]
    found += [Path("/usr/bin/chromium"), Path("/usr/bin/google-chrome")]
    out: list[str] = []
    for f in found:
        if f.is_file() and str(f) not in out:
            out.append(str(f))
    return out


def available(engine: str) -> tuple[bool, str]:
    if not npm():
        return False, "Node.js not found (npm must work in a terminal)"
    if engine == "motion-canvas":
        import importlib.util
        if importlib.util.find_spec("playwright") is None:
            return False, "Playwright is needed to press Motion Canvas's Render button: uv add playwright"
    return True, f"{engine} {VERSIONS[engine]} (Node.js)" + ("" if installed(engine) else ", installs on first use")


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _render_revideo(d: Path, out_dir: Path, timeout: int) -> Path:
    node = shutil.which("node.exe") or shutil.which("node")
    output = d / "output"
    shutil.rmtree(output, ignore_errors=True)
    made = output / "deck.mp4"
    errors = []
    for browser in (browsers() or [""])[:3]:   # e.g. "Navigating frame was detached": the browser died, try another
        args = [node, "render.mjs", browser, str(_free_port())]
        try:
            r = subprocess.run(args, cwd=d, capture_output=True, text=True, encoding="utf-8", errors="replace",
                               timeout=timeout)
        except subprocess.TimeoutExpired:
            raise RuntimeError(f"Revideo took longer than {timeout}s") from None
        if r.returncode == 0 and made.exists():
            return made
        errors.append(f"{Path(browser).name or 'its own browser'}: {_last_error(r.stderr or r.stdout)}")
        log.warning("Revideo failed with %s; trying another browser", errors[-1][:200])
    raise RuntimeError("Revideo failed: " + " | ".join(errors))


def _last_error(text: str) -> str:
    """The error line, not the whole stack."""
    lines = [x for x in (text or "").splitlines() if x.strip() and not x.lstrip().startswith("at ")]
    errs = [x for x in lines if "Error" in x or "FAILED" in x]
    return (errs[-1] if errs else "\n".join(lines[-5:]))[-800:]


def _render_motion_canvas(d: Path, out_dir: Path, timeout: int) -> Path:
    """Start Motion Canvas's editor, press Render in a hidden browser, wait for the video."""
    from playwright.sync_api import sync_playwright
    port = _free_port()
    # node + vite's own script (not vite.cmd): stopping it then stops the server on Windows too
    vite = d / "node_modules" / "vite" / "bin" / "vite.js"
    output = d / "output"
    shutil.rmtree(output, ignore_errors=True)
    node = shutil.which("node.exe") or shutil.which("node")
    server = subprocess.Popen([node, str(vite), "--port", str(port), "--strictPort", "--host", "127.0.0.1"], cwd=d,
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8",
                              errors="replace")
    try:
        deadline = time.time() + 90
        while time.time() < deadline:   # wait for the editor's server
            try:
                with socket.create_connection(("127.0.0.1", port), timeout=1):
                    break
            except OSError:
                if server.poll() is not None:
                    raise RuntimeError("Motion Canvas's editor did not start: "
                                       + _last_error(server.stdout.read() or "")) from None
                time.sleep(0.5)
        else:
            raise RuntimeError("Motion Canvas's editor did not start within 90 s")
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True, args=["--no-sandbox"])
            page = browser.new_page(viewport={"width": 1600, "height": 900})
            page.goto(f"http://127.0.0.1:{port}/", wait_until="networkidle", timeout=120_000)
            page.get_by_role("button", name=re.compile(r"^\s*render\s*$", re.I)).first.click(timeout=60_000)
            abort = page.get_by_role("button", name=re.compile(r"^\s*abort\s*$", re.I))
            try:   # the button turns into Abort while it renders
                abort.first.wait_for(state="visible", timeout=30_000)
            except Exception:   # noqa: BLE001 - a very short deck can finish before we look
                pass
            deadline = time.time() + timeout
            found: list[Path] = []
            last, stable = -1, 0
            while time.time() < deadline:
                time.sleep(2)
                found = [f for f in output.rglob("*.mp4")] if output.exists() else []
                size = sum(f.stat().st_size for f in found)
                stable = stable + 1 if size == last and size > 10_000 else 0
                last = size
                if abort.count() == 0 and stable >= 2:   # Render is back and the file stopped growing
                    break
            else:
                browser.close()
                raise RuntimeError(f"Motion Canvas did not finish within {timeout}s")
            browser.close()
        if not found:
            raise RuntimeError(f"Motion Canvas wrote no video within {timeout}s (its editor may have changed)")
        made = out_dir / "deck.mp4"
        shutil.copyfile(max(found, key=lambda f: f.stat().st_mtime), made)
        return made
    finally:
        server.terminate()
        try:
            server.wait(timeout=10)
        except subprocess.TimeoutExpired:
            server.kill()


def render(engine: str, data: dict, out: Path, timeout: int = 3600) -> Path:
    """Draw the deck (data from manim_render.deck_data, same shape) with Revideo or Motion Canvas into `out`."""
    ok, why = available(engine)
    if not ok:
        raise RuntimeError(why)
    d = write_project(engine, {**data, "theme": theme_for(engine)})
    install(engine)
    import store
    work = store.fresh_dir(out.parent / engine)
    t0 = time.perf_counter()
    log.info("%s: rendering %s slides, %.0f s ...", engine, len(data["slides"]), sum(s["seconds"] for s in data["slides"]))
    made = (_render_revideo if engine == "revideo" else _render_motion_canvas)(d, work, timeout)
    shutil.copyfile(made, out)
    log.info("%s: %s in %.0f s", engine, out.name, time.perf_counter() - t0)
    return out
