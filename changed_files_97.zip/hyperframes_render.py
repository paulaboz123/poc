"""
hyperframes_render.py - the slide deck drawn by HyperFrames (HeyGen's open-source video framework,
Apache-2.0: free also for companies, unlike Remotion's company licence): our slides as one HTML page
animated with GSAP, rendered frame by frame to MP4 in a hidden browser. Another option next to Remotion,
Revideo and Motion Canvas; the same content and timing, its own look.

Needs Node.js 22 or newer. The packages (hyperframes, gsap) install once into the folder hyperframes/
(npm.cmd install, about a minute). The browser Playwright installed is used, nothing is downloaded,
HyperFrames' telemetry and update checks are off, and nothing is published (no `hyperframes publish`).

  uv run deck_video.py --from "data\\output\\<video folder>" --engines hyperframes
  RENDERER=hyperframes in .env (or the tool "HyperFrames" in Lesson Studio) for narrated videos
"""
from __future__ import annotations

import html
import json
import logging
import os
import re
import shutil
import subprocess
import time
from pathlib import Path

import config

log = logging.getLogger("hyperframes_render")

VERSIONS = {"hyperframes": "0.9.15", "gsap": "3.12.5"}
MIN_NODE = 22
# its own look, so it can be told apart from the other engines side by side
THEME = {"bg": "#F5F3FF", "ink": "#1E1B4B", "quiet": "#5B5878", "accent": "#7C3AED", "soft": "#EDE9FE",
         "card": "#FFFFFF", "line": "#DDD6FE", "good": "#15803D", "bad": "#B91C1C", "on_accent": "#FFFFFF",
         "font": "Inter"}


# VIDEO_LOOK=second: dark ink with coral and gold
THEME_SECOND = {"bg": "#16141F", "ink": "#F7F3EA", "quiet": "#B5ADA0", "accent": "#FF6B4A", "soft": "#3A2320",
                "card": "#211E2C", "line": "#3A3546", "good": "#86EFAC", "bad": "#FCA5A5", "on_accent": "#16141F",
                "font": "Inter"}


def project_dir() -> Path:
    return config.EXPERIMENTS_DIR / "hyperframes"


def node() -> str | None:
    return shutil.which("node.exe") or shutil.which("node")


def npm() -> str | None:
    return shutil.which("npm.cmd") or shutil.which("npm")


def node_major() -> int:
    exe = node()
    if not exe:
        return 0
    try:
        out = subprocess.run([exe, "-v"], capture_output=True, text=True, timeout=20).stdout.strip()
        return int(re.match(r"v?(\d+)", out).group(1))
    except (OSError, subprocess.SubprocessError, AttributeError, ValueError):
        return 0


def installed() -> bool:
    d = project_dir() / "node_modules"
    return (d / "hyperframes" / "bin" / "hyperframes.mjs").exists() and (d / "gsap" / "dist" / "gsap.min.js").exists()


def available() -> tuple[bool, str]:
    if not npm() or not node():
        return False, "Node.js not found (npm must work in a terminal)"
    major = node_major()
    if major < MIN_NODE:
        return False, f"HyperFrames needs Node.js {MIN_NODE} or newer (this computer has {major or 'unknown'})"
    return True, f"HyperFrames {VERSIONS['hyperframes']} (Node.js {major})" + ("" if installed() else ", installs on first use")


def install() -> None:
    """npm install once. No browser is downloaded: Playwright's is used."""
    if installed():
        return
    exe = npm()
    if not exe:
        raise RuntimeError("Node.js not found (npm must work in a terminal)")
    d = project_dir()
    d.mkdir(parents=True, exist_ok=True)
    (d / "package.json").write_text(json.dumps({"name": "deck-hyperframes", "private": True, "type": "module",
                                                "dependencies": VERSIONS}, indent=2), encoding="utf-8")
    log.info("HyperFrames: installing its packages once (npm install, about a minute) ...")
    env = {**os.environ, "PUPPETEER_SKIP_DOWNLOAD": "1"}
    r = subprocess.run([exe, "install", "--no-audit", "--no-fund"], cwd=d, capture_output=True, text=True,
                       encoding="utf-8", errors="replace", timeout=1200, env=env)
    if r.returncode != 0 or not installed():
        raise RuntimeError(f"npm install for HyperFrames failed: {(r.stderr or r.stdout)[-600:]}")


# --- the page --------------------------------------------------------------------------------------
def _t(s) -> str:
    return html.escape(str(s or "").replace("**", "").strip())


def _items(sc: dict) -> list[dict]:
    if sc.get("elements"):
        return sc["elements"]
    return [{"title": x} for x in sc.get("items") or []]


def _card(e: dict, value: str = "") -> str:
    return ('<div class="card"><i class="tick"></i>' + (f'<div class="value">{_t(value)}</div>' if value else "")
            + (f'<div class="ct">{_t(e.get("title"))}</div>' if e.get("title") else "")
            + (f'<div class="cd">{_t(e.get("detail"))}</div>' if e.get("detail") else "") + "</div>")


def blocks(sc: dict) -> tuple[list[str], str]:
    """The content parts of one slide (they appear one after another) and how they are arranged."""
    v = sc.get("visual")
    E = _items(sc)
    if v == "comparison" and sc.get("columns"):
        tone = {"positive": "good", "negative": "bad"}
        parts = ['<div class="col"><div class="ch">' + _t(c.get("heading")) + "</div>"
                 + "".join(f'<div class="li"><i class="dot {tone.get(c.get("tone"), "")}"></i>{_t(x)}</div>'
                           for x in c.get("items") or []) + "</div>" for c in sc["columns"]]
        return parts, "row"
    if v == "table" and sc.get("table_header"):
        def row(cells, cls):
            return f'<div class="tr {cls}">' + "".join(f'<div class="td">{_t(c)}</div>' for c in cells) + "</div>"
        rows = [row(sc["table_header"], "th")] + [row(r, "odd" if k % 2 else "") for k, r in enumerate(sc.get("table_rows") or [])]
        return rows, "table"
    if v == "callout" and E:
        e = E[0]
        return [f'<div class="callout">{_t(e.get("title"))}{(". " + _t(e.get("detail"))) if e.get("detail") else ""}</div>'], "column"
    if v == "concept":
        d = E[0] if E else {"title": sc.get("subheading", "")}
        out = [f'<div class="concept">{_t(d.get("title"))}{(": " + _t(d.get("detail"))) if d.get("detail") else ""}</div>']
        if len(E) > 1:
            out.append(_card({"title": "Example", "detail": f'{E[1].get("title", "")} {E[1].get("detail", "")}'}))
        return out, "column"
    if not E:
        return [], "row"
    flow = v in ("steps", "timeline")
    parts = [_card(e, e.get("value", "") if v in ("stats", "timeline") else f"{i + 1:02d}" if v == "steps" else "")
             for i, e in enumerate(E)]
    if flow or len(E) <= 3:
        return parts, "row"
    return parts, "grid2" if len(E) == 4 else "grid3"


CSS = """
* { box-sizing: border-box; margin: 0; }
body { background: __bg__; }
#root { position: relative; width: 1920px; height: 1080px; overflow: hidden; background: __bg__;
        font-family: __font__, sans-serif; color: __ink__; }
#backdrop { position: absolute; inset: 0; background: __bg__; }
.slide { position: absolute; inset: 0; }
.inner { position: absolute; inset: 0; padding: 110px 120px 130px; display: flex; flex-direction: column; gap: 26px; }
.inner.title { justify-content: center; }
h1 { font-size: 62px; line-height: 1.2; font-weight: 800; letter-spacing: -0.5px; }
.title h1 { font-size: 96px; line-height: 1.12; }
.bar { width: 110px; height: 8px; border-radius: 4px; background: __accent__; }
.title .bar { width: 150px; }
.sub { font-size: 32px; color: __quiet__; line-height: 1.35; }
.title .sub { font-size: 40px; }
.goal { display: flex; align-items: center; gap: 18px; font-size: 34px; }
.goal .dot { width: 14px; height: 14px; }
.parts { flex: 1; display: flex; flex-direction: column; justify-content: center; margin-top: 14px; min-height: 0; }
.layout { display: flex; gap: 32px; align-items: stretch; }
.layout.row > .part { flex: 1; min-width: 0; }
.layout.column { flex-direction: column; }
.layout.grid2, .layout.grid3 { display: grid; gap: 28px; }
.layout.grid2 { grid-template-columns: 1fr 1fr; }
.layout.grid3 { grid-template-columns: 1fr 1fr 1fr; }
.layout.table { flex-direction: column; gap: 0; }
.part { display: flex; }
.part > * { flex: 1; }
.card { position: relative; background: __card__; border: 2px solid __line__; border-radius: 20px; padding: 30px 32px 30px 46px;
        box-shadow: 0 8px 26px rgba(30, 27, 75, 0.08); display: flex; flex-direction: column; gap: 12px; }
.card .tick { position: absolute; left: 18px; top: 34px; width: 8px; height: 44px; border-radius: 4px; background: __accent__; }
.value { font-size: 64px; font-weight: 800; color: __accent__; line-height: 1.05; }
.ct { font-size: 38px; font-weight: 700; line-height: 1.2; }
.cd { font-size: 28px; line-height: 1.4; color: __quiet__; }
.col { background: __card__; border: 2px solid __line__; border-radius: 20px; padding: 34px 40px; display: flex; flex-direction: column; gap: 20px; }
.ch { font-size: 40px; font-weight: 700; }
.li { display: flex; gap: 18px; align-items: baseline; font-size: 32px; line-height: 1.35; }
.dot { flex: none; display: inline-block; width: 16px; height: 16px; border-radius: 50%; background: __accent__; }
.dot.good { background: __good__; } .dot.bad { background: __bad__; }
.tr { display: flex; }
.tr .td { flex: 1; padding: 20px 26px; font-size: 32px; line-height: 1.3; }
.tr.th { background: __accent__; color: __on_accent__; font-weight: 700; border-radius: 14px 14px 0 0; }
.tr.odd { background: __card__; }
.callout { background: __soft__; border: 3px solid __accent__; border-radius: 24px; padding: 56px 64px; font-size: 52px;
           font-weight: 700; line-height: 1.35; }
.concept { background: __card__; border: 2px solid __line__; border-radius: 20px; padding: 44px 56px; font-size: 44px; line-height: 1.4; }
#track { position: absolute; left: 0; right: 0; bottom: 0; height: 8px; background: __line__; }
#progress { position: absolute; left: 0; bottom: 0; width: 1920px; height: 8px; background: __accent__; transform-origin: 0 50%; }
#deck-title { position: absolute; left: 60px; bottom: 30px; font-size: 22px; color: __quiet__; }
"""


def page(data: dict, fps: int | None = None) -> str:
    """The whole video as one HTML composition: every slide a clip with its own start and length (the
    same timing as every other engine), the parts appearing one after another, a progress bar."""
    T = {**(THEME_SECOND if config.VIDEO_LOOK == "second" else THEME), **(data.get("theme_override") or {})}
    css = CSS
    for k, v in T.items():
        css = css.replace(f"__{k}__", str(v))
    slides = data["slides"]
    total = round(sum(float(s["seconds"]) for s in slides), 3)
    body, js = [], []
    start = 0.0
    for k, sc in enumerate(slides):
        dur = float(sc["seconds"])
        title = sc.get("visual") == "title"
        parts, arrange = ([], "row") if title else blocks(sc)
        sub = sc.get("subheading") or (data.get("goal") if title else "")
        goals = "".join(f'<div class="goal"><i class="dot"></i>{_t(x)}</div>' for x in (sc.get("items") or [])[:3]) if title else ""
        parts_html = (f'<div class="parts"><div class="layout {arrange}">' + "".join(
            f'<div class="part" id="s{k}-p{i}">{p}</div>' for i, p in enumerate(parts)) + "</div></div>") if parts else ""
        body.append(f'<div id="s{k}" class="clip slide" data-start="{start:.3f}" data-duration="{dur:.3f}" '
                    f'data-track-index="1"><div id="s{k}-in" class="inner{" title" if title else ""}">'
                    f'<h1>{_t(sc.get("heading") or data.get("title"))}</h1><div class="bar"></div>'
                    + (f'<p class="sub">{_t(sub)}</p>' if sub else "") + goals + parts_html + "</div></div>")
        # in 0.6 s, the parts one by one (paced over the slide when it builds up), out in the last 0.5 s
        js.append(f'tl.fromTo("#s{k}-in", {{opacity: 0, y: 40, scale: 0.98}}, {{opacity: 1, y: 0, scale: 1, '
                  f'duration: 0.6, ease: "power3.out"}}, {start:.3f});')
        js.append(f'tl.to("#progress", {{scaleX: {(k + 1) / len(slides):.4f}, duration: 0.6, ease: "power2.out"}}, {start:.3f});')
        build = sc.get("animation") in ("build", "highlight")
        fade = 0.45 if build else 0.25
        step = max(fade, min(1.6, (dur - 0.6 - 1.5) / max(1, len(parts)))) if build else fade
        for i in range(len(parts)):
            js.append(f'tl.fromTo("#s{k}-p{i}", {{opacity: 0, y: 26}}, {{opacity: 1, y: 0, duration: {fade}, '
                      f'ease: "power2.out"}}, {start + 0.6 + i * step:.3f});')
        js.append(f'tl.to("#s{k}-in", {{opacity: 0, y: -36, duration: 0.45, ease: "power2.in"}}, '
                  f'{max(start + 0.7, start + dur - 0.5):.3f});')
        start += dur
    fps_attr = f' data-fps="{fps}"' if fps else ""
    return ("<!doctype html>\n<html><head><meta charset=\"utf-8\">\n<script src=\"assets/gsap.min.js\"></script>\n"
            f"<style>{css}</style></head>\n<body>\n"
            f'<div id="root" data-composition-id="main" data-start="0" data-duration="{total}" data-width="1920" '
            f'data-height="1080"{fps_attr}>\n<div id="backdrop"></div><div id="track"></div><div id="progress"></div>'
            f'<div id="deck-title">{_t(data.get("title"))}</div>\n' + "\n".join(body) + "\n</div>\n<script>\n"
            "const tl = gsap.timeline({paused: true});\ntl.set(\"#progress\", {scaleX: 0}, 0);\n" + "\n".join(js)
            + "\nwindow.__timelines = window.__timelines || {};\nwindow.__timelines[\"main\"] = tl;\n</script>\n"
            "</body></html>\n")


# --- rendering --------------------------------------------------------------------------------------
def browser() -> str:
    """Chrome's headless shell first (faster capture), else any Chromium found (deck_js.browsers)."""
    import deck_js
    found = deck_js.browsers()
    shell = [b for b in found if "headless" in Path(b).name.lower() or "headless_shell" in b.lower()]
    for root in {Path(b).parents[2] for b in found if len(Path(b).parents) > 2}:
        shell += [str(p) for p in sorted(root.glob("chromium_headless_shell-*/*/*headless*shell*")) if p.is_file()]
    return (shell or found or [""])[0]


def render(data: dict, out: Path, timeout: int = 3600) -> Path:
    """The deck (manim_render.deck_data) as a silent MP4 at `out`."""
    import store
    ok, why = available()
    if not ok:
        raise RuntimeError(why)
    install()
    work = store.fresh_dir(Path(out).parent / "hyperframes")
    (work / "assets").mkdir()
    shutil.copyfile(project_dir() / "node_modules" / "gsap" / "dist" / "gsap.min.js", work / "assets" / "gsap.min.js")
    (work / "index.html").write_text(page(data, config.VIDEO_FPS), encoding="utf-8")
    env = {**os.environ, "HYPERFRAMES_NO_TELEMETRY": "1", "HYPERFRAMES_NO_UPDATE_CHECK": "1",
           "HYPERFRAMES_SKIP_SKILLS": "1", "PUPPETEER_SKIP_DOWNLOAD": "1"}
    exe = browser()
    if exe:
        env["HYPERFRAMES_BROWSER_PATH"] = exe
    if config.FFMPEG and Path(config.FFMPEG).is_file():
        env["HYPERFRAMES_FFMPEG_PATH"] = str(config.FFMPEG)
        probe = Path(config.FFMPEG).with_name(Path(config.FFMPEG).name.replace("ffmpeg", "ffprobe"))
        if probe.is_file():
            env["HYPERFRAMES_FFPROBE_PATH"] = str(probe)
    made = work / "deck.mp4"
    cmd = [node(), str(project_dir() / "node_modules" / "hyperframes" / "bin" / "hyperframes.mjs"), "render",
           "-o", str(made), "--fps", str(config.VIDEO_FPS), "--quiet"]
    t0 = time.perf_counter()
    log.info("HyperFrames: rendering %s slides, %.0f s ...", len(data["slides"]), sum(s["seconds"] for s in data["slides"]))
    try:
        r = subprocess.run(cmd, cwd=work, capture_output=True, text=True, encoding="utf-8", errors="replace",
                           timeout=timeout, env=env)
    except subprocess.TimeoutExpired:
        raise RuntimeError(f"HyperFrames took longer than {timeout}s") from None
    if r.returncode != 0 or not made.exists():
        import deck_js
        raise RuntimeError("HyperFrames failed: " + deck_js._last_error(r.stderr or r.stdout))
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    os.replace(made, out)
    shutil.rmtree(work, ignore_errors=True)
    log.info("HyperFrames: %s in %.0f s", Path(out).name, time.perf_counter() - t0)
    return Path(out)
