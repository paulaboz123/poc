"""
costs.py - a cost estimate the way it is usually made at the proof-of-concept stage: not one number,
but what each kind of request costs, what a user costs a month, what the platform costs whatever the
use, what is paid once, and what people's time it needs, for a few adoption scenarios.

  uv run costs.py                  # report -> data/output/costs/costs.html (to send), costs.md, costs.xlsx
  (edit cost_assumptions.csv - users, usage, tools - and cost_prices.csv - list prices - then run again)

No cloud access is needed:
  measured    what each kind of result really cost on this proof of concept: every result keeps its
              model calls and their cost (run_card.json), test runs keep the judge's cost
              (qa_results.csv), the prepared recordings say how many hours and slides they have
  list price  the cloud and the paid tools, from the providers' public price lists (cost_prices.csv)
  assumption  how many users, how they use it, which tools (cost_assumptions.csv): the business's
              part. The report shows them, so anyone can see what the numbers rest on.

The parts of the estimate:
  1 price list    the cost of one request of each kind (an answer, a written lesson, a 10-minute
                  narrated video, a 60-minute animated course ...): AI + voice + rendering
  2 per user      a month of a light, a regular and a heavy user (made of 1)
  3 platform      fixed monthly cost by level: proof of concept / basic production / advanced
  4 once          preparing the library of recordings, and building the production version (person-days)
  5 people        hours a month to review content and run it
  6 scenarios     pilot / team / wide rollout: 2 x users + 3 + 5, a year with 4
Accuracy: a concept-stage estimate (AACE class 5: -20..-50% / +30..+100%). It narrows once a pilot
runs and the platform team gives its real numbers.
"""
from __future__ import annotations

import argparse
import csv
import logging
import statistics
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path

import config
import store

log = logging.getLogger("costs")

ASSUMPTIONS_FILE = config.SETTINGS_DIR / "cost_assumptions.csv"
PRICES_FILE = config.SETTINGS_DIR / "cost_prices.csv"

# name, default, unit, what it means (the business fills these in)
ASSUMPTIONS = [
    ("users_pilot", 10, "users", "scenario 1: a pilot"),
    ("users_team", 100, "users", "scenario 2: a department"),
    ("users_wide", 1000, "users", "scenario 3: a wide rollout"),
    ("share_light", 0.6, "share", "share of light users"),
    ("share_regular", 0.3, "share", "share of regular users"),
    ("share_heavy", 0.1, "share", "share of heavy users"),
    ("light", "answer=20;lesson=1", "per month", "what a light user asks for in a month (item=count; items: see the price list)"),
    ("regular", "answer=60;lesson=3;slides=1;video2=2", "per month", "what a regular user asks for in a month"),
    ("heavy", "answer=150;lesson=6;slides=2;video10=3;silent10=2;course60=1", "per month", "what a heavy user asks for in a month"),
    ("library_recordings", 1000, "recordings", "recordings in the library at the start"),
    ("avg_recording_minutes", 0, "min", "average length of a recording (0 = measured on your data)"),
    ("new_recordings_per_month", 20, "recordings", "new recordings added each month"),
    ("changed_share_per_month", 0.02, "share", "share of the library replaced or corrected each month (processed again)"),
    ("full_reprocess_per_year", 2, "times", "times a year everything is processed again (pipeline changes)"),
    ("share_without_transcript", 0.2, "share", "share of recordings without a Teams transcript (need transcription)"),
    ("transcription", "aws_transcribe", "", "aws_transcribe | elevenlabs_scribe | whisper_local (free, slow; not for production)"),
    ("voice", "kokoro", "", "kokoro (free, runs on our own server) | elevenlabs (most natural)"),
    ("video_renderer", "own", "", "own (ffmpeg + our slides) | remotion (licence for companies of 4+)"),
    ("store_videos", "no", "", "yes = the recordings are stored by this solution; no = they stay where they are (SharePoint/Stream)"),
    ("storage_gb_per_hour", 1.0, "GB", "storage per hour of recording when stored here"),
    ("test_runs_per_month", 4, "runs", "quality test runs a month (test plan + judge)"),
    ("tests_per_run", 19, "tests", "questions in the test plan"),
    ("review_minutes_per_video", 15, "min", "a person watches and approves each video before it is shared"),
    ("review_minutes_per_lesson", 5, "min", "a person reads each written lesson before it is shared (0 = not reviewed)"),
    ("ops_hours_basic", 8, "h/month", "running the basic production version: monitoring, fixes, updates"),
    ("ops_hours_advanced", 24, "h/month", "running the advanced version (on-call, feedback, tuning)"),
    ("day_rate_usd", 0, "USD/day", "cost of a person-day (0 = show days only)"),
]

# name, value, unit, source (list prices; check them against the AWS contract)
PRICES = [
    ("aws_transcribe_per_min", 0.024, "USD/min", "https://aws.amazon.com/transcribe/pricing/ (batch, tier 1; check the EU rate)"),
    ("elevenlabs_scribe_per_hour", 0.22, "USD/h", "https://elevenlabs.io/pricing/api (Scribe v2)"),
    ("elevenlabs_per_1k_chars", config.ELEVENLABS_USD_PER_1K_CHARS, "USD/1k chars",
     "Pro plan: $99 for 600,000 characters (the one rate for the whole project: ELEVENLABS_USD_PER_1K_CHARS in .env)"),
    ("titan_embed_per_1m_tokens", 0.02, "USD/1M tokens", "https://aws.amazon.com/bedrock/pricing/ (Titan Text Embeddings V2)"),
    ("opensearch_ocu_hour", 0.24, "USD/OCU-h", "https://aws.amazon.com/opensearch-service/pricing/ (Serverless; check the EU rate)"),
    ("opensearch_managed_small_month", 30, "USD/month", "smallest managed OpenSearch domain + storage, estimate"),
    ("s3_gb_month", 0.0245, "USD/GB-month", "https://aws.amazon.com/s3/pricing/ (Standard, Frankfurt; check)"),
    ("cloudwatch_logs_per_gb", 0.63, "USD/GB", "https://aws.amazon.com/cloudwatch/pricing/ (ingestion, Frankfurt; check)"),
    ("cloudwatch_alarm_month", 0.10, "USD/alarm-month", "https://aws.amazon.com/cloudwatch/pricing/ (standard alarm)"),
    ("cloudwatch_dashboard_month", 3.0, "USD/dashboard-month", "https://aws.amazon.com/cloudwatch/pricing/"),
    ("waf_month", 10, "USD/month", "https://aws.amazon.com/waf/pricing (1 web ACL + 5 rules), estimate"),
    ("fargate_vcpu_hour", 0.04656, "USD/vCPU-h", "https://aws.amazon.com/fargate/pricing/ (Frankfurt; check)"),
    ("fargate_gb_hour", 0.00511, "USD/GB-h", "https://aws.amazon.com/fargate/pricing/ (Frankfurt; check)"),
    ("remotion_per_render", 0.01, "USD/render", "https://www.remotion.dev/docs/license/pricing (Automators, companies of 4+)"),
    ("remotion_min_month", 100, "USD/month", "Remotion Automators monthly minimum"),
    ("chars_per_video_minute", 900, "chars", "spoken characters in a minute of narration"),
    ("tokens_per_recording_hour", 12000, "tokens", "transcript tokens in an hour of speech (~9,000 words)"),
    ("render_seconds_per_minute", 90, "s", "server time to make one minute of video (used until measured)"),
]

# the price list: key, what, result kind (run cards), minutes, spoken
CATALOG = [
    ("answer", "Answer to a question, with sources", "answer", 0, False),
    ("lesson", "Written lesson, ~5 min to read", "document", 5, False),
    ("slides", "Slides to present yourself, ~10 min", "slides", 10, False),
    ("video2", "Narrated video lesson, 2 min", "video", 2, True),
    ("video10", "Narrated video lesson, 10 min", "video", 10, True),
    ("silent10", "Animated slides, no narrator, 10 min", "video", 10, False),
    ("course60", "Course basics to advanced, 60 min, animated, no narrator", "course", 60, False),
    ("course60v", "Course basics to advanced, 60 min, with narrator", "course", 60, True),
    ("dialogue5", "Two people explaining, 5 min", "dialogue", 5, True),
    ("audio10", "Audio lesson, 10 min", "audio", 10, True),
]
VIDEO_KINDS = {"video", "course", "dialogue", "avatar video"}
# AI cost per minute of result when nothing of that kind was made yet (rough, from early runs)
FALLBACK_PER_MIN = {"document": 0.01, "slides": 0.01, "video": 0.08, "course": 0.09, "dialogue": 0.10, "audio": 0.06}
FALLBACK = {"slide": 0.01, "topics_per_hour": 0.12, "answer": 0.02, "answer_no_relevance": 0.013, "judge_per_answer": 0.05}
RELEVANCE_STEPS = {"rerank", "split question"}

# what the platform needs at each level, monthly (computed from the prices in tiers())
TIER_NAMES = {"poc": "Proof of concept (now)", "basic": "Basic production", "advanced": "Advanced production"}
# building the production version: work package, days low-high for basic, extra for advanced
BUILD = [
    ("Integration into the platform (endpoint, sign-in, the agent calls it)", 10, 15, "basic"),
    ("Automatic preparation of new recordings (scheduled pipeline)", 5, 10, "basic"),
    ("Deployment as code, CI/CD, test environment", 5, 10, "basic"),
    ("Monitoring, alerts, cost dashboard", 3, 5, "basic"),
    ("Security and data protection review, fixes", 5, 10, "basic"),
    ("Quality tests in CI (test plan, judge calibration)", 3, 5, "basic"),
    ("User acceptance test with a pilot group", 5, 10, "basic"),
    ("Per-user limits and usage tracking", 5, 8, "advanced"),
    ("Feedback loop (ratings, review queue, fixes from feedback)", 5, 10, "advanced"),
    ("Approval workflow for generated content (expert sign-off)", 8, 15, "advanced"),
    ("Search on slide images (multimodal), high availability, staging", 10, 20, "advanced"),
]


# --- Inputs and measurements ---------------------------------------------------------------
def _write_defaults(path: Path, header: list[str], rows: list[tuple]) -> None:
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


def _value(v: str):
    try:
        return float(v) if "." in v or "e" in v.lower() else int(v)
    except ValueError:
        return v.strip()


def load_inputs() -> tuple[dict, dict]:
    """The assumptions and prices (the files are written with defaults the first time; new
    names added in a later version are filled with their defaults)."""
    for path, marker in ((ASSUMPTIONS_FILE, "users_pilot"), (PRICES_FILE, "fargate_vcpu_hour")):
        if path.exists() and marker not in path.read_text(encoding="utf-8-sig"):   # from the first version: set aside
            path.replace(path.with_suffix(".old.csv"))
            log.info("%s was from the first version of this report: kept as %s, new one written",
                     path.name, path.with_suffix(".old.csv").name)
    if not ASSUMPTIONS_FILE.exists():
        _write_defaults(ASSUMPTIONS_FILE, ["name", "value", "unit", "what"], ASSUMPTIONS)
        log.info("Wrote %s with example volumes: put in the business's numbers and run again", ASSUMPTIONS_FILE.name)
    if not PRICES_FILE.exists():
        _write_defaults(PRICES_FILE, ["name", "value", "unit", "source"], PRICES)
    out = []
    for path, defaults in ((ASSUMPTIONS_FILE, ASSUMPTIONS), (PRICES_FILE, PRICES)):
        vals = {d[0]: d[1] for d in defaults}
        with open(path, encoding="utf-8-sig", newline="") as f:
            for r in csv.DictReader(f):
                if r.get("name") and (r.get("value") or "").strip() != "":
                    vals[r["name"].strip()] = _value(r["value"])
        out.append(vals)
    a, p = out
    # one price list for the whole project: the voice rate is the one in .env (the app and the comparison use
    # it too), and only the voices the app offers (an older file may still say Amazon Polly)
    p["elevenlabs_per_1k_chars"] = config.ELEVENLABS_USD_PER_1K_CHARS
    if str(a.get("voice")) not in ("kokoro", "elevenlabs"):
        log.info("voice '%s' in %s is not offered any more: priced as kokoro", a.get("voice"), ASSUMPTIONS_FILE.name)
        a["voice"] = "kokoro"
    return a, p


# --- Measured -------------------------------------------------------------------------------
def library() -> dict:
    """What the prepared recordings contain: count, hours, slides, described slides."""
    n, minutes, slides, described = 0, 0.0, 0, 0
    for row in store.read_manifest():
        vid = row.get("video_id", "")
        if not vid or not store.has_segments(vid) or row.get("media_type") == "document":
            continue
        segs = store.load_segments(vid)
        if not segs:
            continue
        n += 1
        minutes += max(s.get("end", 0) for s in segs) / 60
        sl = [s for s in store.load_slides(vid) if s.get("is_slide")]
        slides += len(sl)
        described += sum(1 for s in sl if s.get("visual"))
    hours = minutes / 60
    return {"recordings": n, "hours": round(hours, 2), "avg_minutes": round(minutes / n, 1) if n else None,
            "slides": slides, "described": described, "slides_per_hour": round(slides / hours, 1) if hours else None}


def logged_calls() -> list[dict]:
    if not config.COST_LOG.exists():
        return []
    with open(config.COST_LOG, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        try:
            r["cost"] = float(r.get("est_cost_usd") or 0)
        except ValueError:
            r["cost"] = 0.0
    return rows


def run_cards(kinds: tuple[str, ...]) -> list[tuple[Path, dict]]:
    """The run cards of the results of these kinds (every result keeps its own cost)."""
    if not config.OUTPUT_DIR.exists():
        return []
    cards = [(p, store.read_json(p, {}) or {}) for p in config.OUTPUT_DIR.glob("*/run_card.json")]
    return [(p, c) for p, c in cards if c.get("kind") in kinds]


def answer_costs() -> list[dict]:
    """Per answer: its whole cost, and the part spent on the AI relevance check (from its run card;
    the shared log can't tell an answer's relevance check from a video's)."""
    out = []
    for _, card in run_cards(("answer",)):
        steps = (card.get("cost") or {}).get("by_step", [])
        total = sum(s["cost_usd"] for s in steps)
        if total > 0:
            out.append({"total": total, "relevance": sum(s["cost_usd"] for s in steps if s["step"] in RELEVANCE_STEPS)})
    return out


def judge_costs() -> list[float]:
    """The judge's cost per graded answer, from the test runs (qa_results.csv)."""
    out = []
    for path in config.OUTPUT_DIR.glob("*-qa-eval/qa_results.csv") if config.OUTPUT_DIR.exists() else []:
        with open(path, encoding="utf-8-sig", newline="") as f:
            for r in csv.DictReader(f):
                try:
                    v = float(r.get("judge_cost_usd") or 0)
                except ValueError:
                    continue
                if v > 0:
                    out.append(v)
    return out


def result_costs() -> dict[str, dict]:
    """Per kind of result made here: AI cost per minute of result (without the voice, which is priced
    by the chosen engine) and server seconds per minute. From the run cards."""
    acc: dict[str, dict] = defaultdict(lambda: {"usd": 0.0, "minutes": 0.0, "n": 0, "secs": 0.0, "secs_min": 0.0})
    for p, card in run_cards(tuple(FALLBACK_PER_MIN) + ("avatar video",)):
        if card.get("plan_only"):
            continue
        info = store.read_json(p.parent / "info.json", {}) or {}
        minutes = (info.get("duration_s") or 0) / 60 or float((card.get("request") or {}).get("minutes") or 0)
        if minutes <= 0:
            continue
        kind = "video" if card["kind"] == "avatar video" else card["kind"]
        steps = (card.get("cost") or {}).get("by_step", [])
        a = acc[kind]
        a["usd"] += sum(s["cost_usd"] for s in steps if s["step"] != "voice")
        a["minutes"] += minutes
        a["n"] += 1
        total_s = (card.get("time") or {}).get("total_s")
        if total_s and kind in VIDEO_KINDS:
            a["secs"] += float(total_s)
            a["secs_min"] += minutes
    return acc


def measured(lib: dict) -> dict:
    """Unit costs; each says whether it was measured here or is a fallback estimate."""
    calls = logged_calls()
    by_step: dict[str, list[float]] = defaultdict(list)
    for c in calls:
        by_step[c.get("step", "")].append(c["cost"])
    m: dict[str, tuple[float, str]] = {}
    slide = by_step.get("describe_slide")
    m["slide"] = (statistics.mean(slide), f"measured, {len(slide)} slides") if slide else (FALLBACK["slide"], "estimate")
    topics = by_step.get("topics")
    m["topics_per_hour"] = ((statistics.mean(topics) / (lib["avg_minutes"] / 60), f"measured, {len(topics)} recordings")
                            if topics and lib.get("avg_minutes") else (FALLBACK["topics_per_hour"], "estimate"))
    answers = answer_costs()
    if answers:
        n = len(answers)
        m["answer"] = (sum(x["total"] for x in answers) / n, f"measured, {n} answers")
        m["answer_no_relevance"] = (sum(x["total"] - x["relevance"] for x in answers) / n, f"measured, {n} answers")
    else:
        m["answer"] = (FALLBACK["answer"], "estimate")
        m["answer_no_relevance"] = (FALLBACK["answer_no_relevance"], "estimate")
    judged = judge_costs()
    m["judge_per_answer"] = ((statistics.mean(judged), f"measured, {len(judged)} graded answers")
                             if judged else (FALLBACK["judge_per_answer"], "estimate"))
    rc = result_costs()
    for kind, fb in FALLBACK_PER_MIN.items():
        x = rc.get(kind)
        m[f"per_min_{kind}"] = ((x["usd"] / x["minutes"], f"measured, {x['n']} results") if x and x["minutes"]
                                else (fb, "estimate"))
    secs = sum(x["secs"] for x in rc.values())
    secs_min = sum(x["secs_min"] for x in rc.values())
    m["render_s_per_min"] = ((secs / secs_min, "measured on a laptop") if secs_min else (None, "list"))
    m["_spent_total"] = (round(sum(c["cost"] for c in calls), 2), f"{len(calls)} logged model calls")
    return m


# --- 1. Price list -----------------------------------------------------------------------------
def voice_per_min(a: dict, p: dict) -> float:
    chars = p["chars_per_video_minute"]
    return {"kokoro": 0.0, "elevenlabs": chars / 1000 * p["elevenlabs_per_1k_chars"]}.get(str(a["voice"]), 0.0)


def render_per_min(p: dict, m: dict) -> float:
    """Server cost of making one minute of video (a 2 vCPU / 4 GB task while it works)."""
    secs = m["render_s_per_min"][0] or p["render_seconds_per_minute"]
    per_hour = 2 * p["fargate_vcpu_hour"] + 4 * p["fargate_gb_hour"]
    return secs / 3600 * per_hour


def price_list(a: dict, p: dict, m: dict) -> list[dict]:
    """The cost of one request of each kind, split into its parts."""
    rows = []
    for key, what, kind, minutes, spoken in CATALOG:
        if kind == "answer":
            parts = {"AI": m["answer"][0]}
            basis = m["answer"][1]
        else:
            per_min, basis = m[f"per_min_{kind}"]
            parts = {"AI": per_min * minutes}
            if spoken or kind == "dialogue":
                parts["voice"] = voice_per_min(a, p) * minutes
            if kind in VIDEO_KINDS:
                parts["server"] = render_per_min(p, m) * minutes
                if str(a.get("video_renderer")) == "remotion":
                    parts["licence (per render)"] = p["remotion_per_render"]
        if config.COST_MARGIN_PCT:   # the same safety margin as the prices in Lesson Studio
            parts[f"safety margin (+{config.COST_MARGIN_PCT:g}%)"] = sum(parts.values()) * config.COST_MARGIN_PCT / 100
        rows.append({"key": key, "what": what, "minutes": minutes, "parts": parts, "total": sum(parts.values()),
                     "basis": basis})
    return rows


# --- 2. Per user -------------------------------------------------------------------------------
def usage(spec: str) -> dict[str, float]:
    out = {}
    for part in str(spec).split(";"):
        if "=" in part:
            k, v = part.split("=", 1)
            try:
                out[k.strip()] = float(v)
            except ValueError:
                pass
    return out


def per_user(a: dict, prices: list[dict]) -> dict[str, dict]:
    by_key = {r["key"]: r["total"] for r in prices}
    out = {}
    for profile in ("light", "regular", "heavy"):
        use = usage(a[profile])
        unknown = [k for k in use if k not in by_key]
        if unknown:
            log.warning("%s: unknown items %s (use %s)", profile, unknown, ", ".join(by_key))
        out[profile] = {"use": use, "usd": sum(by_key.get(k, 0.0) * n for k, n in use.items())}
    mix = {k: float(a[f"share_{k}"]) for k in out}
    out["average"] = {"use": {}, "usd": sum(out[k]["usd"] * w for k, w in mix.items()) / (sum(mix.values()) or 1)}
    return out


# --- 3. Platform -------------------------------------------------------------------------------
def tiers(a: dict, p: dict, hours_library: float) -> dict[str, dict[str, float]]:
    """Fixed monthly cost of the platform at each level (whatever the use)."""
    service = 0.5 * p["fargate_vcpu_hour"] * 730 + 1 * p["fargate_gb_hour"] * 730          # 0.5 vCPU, 1 GB, always on
    storage = (hours_library * float(a["storage_gb_per_hour"]) if str(a["store_videos"]).lower() == "yes"
               else hours_library * 0.05) * p["s3_gb_month"]                                 # processed data only: ~50 MB/h
    basic = {"search index (small managed OpenSearch)": p["opensearch_managed_small_month"],
             "the service that answers (container, always on)": service,
             "storage (S3)": storage,
             "logs (5 GB), 10 alarms, 1 dashboard": 5 * p["cloudwatch_logs_per_gb"] + 10 * p["cloudwatch_alarm_month"]
             + p["cloudwatch_dashboard_month"],
             "test environment (half of the above)": 0.5 * (p["opensearch_managed_small_month"] + service)}
    advanced = {"search index (OpenSearch Serverless, redundant)": 2 * p["opensearch_ocu_hour"] * 730,
                "the service that answers (2 containers, always on)": 2 * service,
                "storage (S3, with backups)": storage * 2,
                "logs (20 GB), 25 alarms, 3 dashboards": 20 * p["cloudwatch_logs_per_gb"] + 25 * p["cloudwatch_alarm_month"]
                + 3 * p["cloudwatch_dashboard_month"],
                "web firewall (WAF)": p["waf_month"],
                "staging environment (Serverless dev/test)": 1 * p["opensearch_ocu_hour"] * 730 + service}
    if str(a.get("video_renderer")) == "remotion":
        basic["Remotion licence (minimum)"] = advanced["Remotion licence (minimum)"] = p["remotion_min_month"]
    return {"poc": {"laptop, model gateway, free trials": 0.0}, "basic": basic, "advanced": advanced}


# --- 4. Once and recurring preparation ----------------------------------------------------------
def per_hour_processing(a: dict, p: dict, m: dict, lib: dict) -> dict[str, float]:
    """The cost of preparing one hour of recording, per step."""
    slides_per_hour = lib.get("slides_per_hour") or 20
    trans = {"whisper_local": 0.0, "aws_transcribe": p["aws_transcribe_per_min"] * 60,
             "elevenlabs_scribe": p["elevenlabs_scribe_per_hour"]}.get(str(a["transcription"]), 0.0)
    return {"transcription (only recordings without a Teams transcript)": trans * float(a["share_without_transcript"]),
            "slide descriptions (vision model)": slides_per_hour * m["slide"][0],
            "topics and topic sections": m["topics_per_hour"][0],
            "search index (embeddings)": p["tokens_per_recording_hour"] * 2.5 / 1e6 * p["titan_embed_per_1m_tokens"]}


def preparation(a: dict, p: dict, m: dict, lib: dict) -> dict:
    avg_min = float(a["avg_recording_minutes"]) or lib.get("avg_minutes") or 30.0
    h_lib = float(a["library_recordings"]) * avg_min / 60
    per_h = per_hour_processing(a, p, m, lib)
    rerun = sum(v for k, v in per_h.items() if not k.startswith("transcription"))   # a re-run keeps the transcripts
    monthly = {"new recordings": sum(per_h.values()) * float(a["new_recordings_per_month"]) * avg_min / 60,
               "replaced or corrected recordings": sum(per_h.values()) * h_lib * float(a["changed_share_per_month"]),
               "everything again after pipeline changes (spread over the year)":
                   rerun * h_lib * float(a["full_reprocess_per_year"]) / 12}
    return {"avg_minutes": avg_min, "hours": h_lib, "per_hour": per_h, "once": sum(per_h.values()) * h_lib,
            "monthly": monthly, "monthly_total": sum(monthly.values())}


def build_days(level: str) -> tuple[int, int]:
    rows = [b for b in BUILD if b[3] == "basic" or level == "advanced"]
    return sum(b[1] for b in rows), sum(b[2] for b in rows)


# --- 5./6. People and scenarios ------------------------------------------------------------------
def scenarios(a: dict, p: dict, m: dict, prices: list[dict], users: dict, plat: dict, prep: dict) -> list[dict]:
    by_key = {r["key"]: r for r in prices}
    mix = {k: float(a[f"share_{k}"]) for k in ("light", "regular", "heavy")}
    tests = float(a["test_runs_per_month"]) * float(a["tests_per_run"]) * (m["answer"][0] + m["judge_per_answer"][0])
    out = []
    for name, level in (("pilot", "basic"), ("team", "basic"), ("wide", "advanced")):
        n = float(a[f"users_{name}"])
        counts: dict[str, float] = defaultdict(float)
        for prof, w in mix.items():
            for k, c in users[prof]["use"].items():
                counts[k] += c * w * n
        use_usd = sum(by_key[k]["total"] * c for k, c in counts.items() if k in by_key)
        videos = sum(c for k, c in counts.items() if k in by_key and by_key[k]["minutes"] and k not in ("lesson", "slides"))
        review_h = (videos * float(a["review_minutes_per_video"]) + counts.get("lesson", 0) * float(a["review_minutes_per_lesson"])) / 60
        ops_h = float(a[f"ops_hours_{level}"])
        platform = sum(plat[level].values())
        month = use_usd + tests + prep["monthly_total"] + platform
        days = build_days(level)
        out.append({"name": name, "users": n, "level": level, "use": use_usd, "tests": tests, "prep": prep["monthly_total"],
                    "platform": platform, "month": month, "per_user": month / n if n else 0,
                    "year1": prep["once"] + 12 * month, "people_h": review_h + ops_h, "review_h": review_h, "ops_h": ops_h,
                    "build_days": days, "counts": dict(counts)})
    return out


# --- Report ------------------------------------------------------------------------------------
def usd(v: float) -> str:
    return f"${v:,.0f}" if v >= 100 else f"${v:,.2f}" if v >= 0.995 else f"${v:,.3f}"


def rng(v: float) -> str:
    """A concept-stage estimate as a range: about half to double."""
    return f"{usd(v * 0.5)} – {usd(v * 2)}"


def report(a: dict, p: dict, m: dict, lib: dict, prices: list[dict], users: dict, plat: dict, prep: dict,
           scen: list[dict]) -> list[str]:
    rate = float(a["day_rate_usd"])
    days = lambda d: f"{d[0]}–{d[1]} person-days" + (f" ({usd(d[0] * rate)} – {usd(d[1] * rate)})" if rate else "")  # noqa: E731
    md = ["# Cost estimate: answers and lessons from training recordings", "",
          f"{datetime.now():%Y-%m-%d} · Proof-of-concept estimate in USD, before AWS discounts and taxes. "
          "AI costs are measured on the proof of concept; cloud and tools are list prices; users and usage are "
          "assumptions to be confirmed. Expect the real figure between about half and double (a concept-stage "
          "estimate); it narrows after a pilot.", "",
          "## Summary", "",
          "| | Pilot | Team | Wide rollout |", "|---|---|---|---|",
          "| Users | " + " | ".join(f"{s['users']:,.0f}" for s in scen) + " |",
          "| Platform level | " + " | ".join(TIER_NAMES[s["level"]] for s in scen) + " |",
          "| Running cost a month | " + " | ".join(f"**{usd(s['month'])}**" for s in scen) + " |",
          "| of which usage (AI, voice, video) | " + " | ".join(usd(s["use"]) for s in scen) + " |",
          "| of which platform (fixed) | " + " | ".join(usd(s["platform"]) for s in scen) + " |",
          "| of which preparing recordings and tests | " + " | ".join(usd(s["prep"] + s["tests"]) for s in scen) + " |",
          "| Per user a month | " + " | ".join(usd(s["per_user"]) for s in scen) + " |",
          "| Likely range a month | " + " | ".join(rng(s["month"]) for s in scen) + " |",
          f"| Once: preparing {a['library_recordings']} recordings | " + " | ".join(usd(prep["once"]) for _ in scen) + " |",
          "| First year (once + 12 months) | " + " | ".join(f"**{usd(s['year1'])}**" for s in scen) + " |",
          "| Once: building the production version | " + " | ".join(days(s["build_days"]) for s in scen) + " |",
          "| People's time a month (review + running it) | " + " | ".join(f"{s['people_h']:.0f} h" for s in scen) + " |", "",
          "What drives the cost: the platform is a fixed cost and dominates at small scale; usage grows with "
          "users and with long videos; people's time (reviewing generated content) is the largest cost that is "
          "not on the AWS bill.", "",
          "## 1. What one request costs", "",
          "Each kind of request costs differently: a short answer costs cents, an hour-long course a few dollars. "
          "AI = writing and checking by the models; voice = the narrator; server = making the video.", "",
          "| Request | AI | Voice | Server | **Total** | Basis |", "|---|---|---|---|---|---|"]
    for r in prices:
        pt = r["parts"]
        md.append(f"| {r['what']} | {usd(pt.get('AI', 0))} | {usd(pt['voice']) if 'voice' in pt else '-'} | "
                  f"{usd(pt['server']) if 'server' in pt else '-'} | **{usd(r['total'])}** | {r['basis']} |")
    md += ["", f"Voice: {a['voice']}. Kinds not made in the proof of concept yet are estimates and are marked so; "
           "the longer results are scaled from the shorter ones per minute.", "",
           "## 2. What a user costs a month", "",
           "| User | Asks for in a month | Cost a month |", "|---|---|---|"]
    names = {r["key"]: r["what"] for r in prices}
    for prof in ("light", "regular", "heavy"):
        use = ", ".join(f"{n:g} × {names.get(k, k).lower()}" for k, n in users[prof]["use"].items())
        md.append(f"| {prof} ({float(a[f'share_{prof}']):.0%} of users) | {use} | {usd(users[prof]['usd'])} |")
    md += [f"| **average user** | | **{usd(users['average']['usd'])}** |", "",
           "Per-user limits (a daily, weekly or monthly allowance) keep this predictable: a limit in dollars "
           "per user caps the usage line of the summary.", "",
           "## 3. The platform: fixed cost a month, whatever the use", ""]
    for level in ("poc", "basic", "advanced"):
        md += [f"**{TIER_NAMES[level]}: {usd(sum(plat[level].values()))} a month**", ""]
        md += [f"- {k}: {usd(v)}" for k, v in plat[level].items()]
        md.append("")
    md += ["If the existing platform already runs a search index, hosting and monitoring, much of this is "
           "shared. Basic production: one region, small index, alerts and a test environment. Advanced: a "
           "redundant index, two service instances, staging, firewall, more monitoring.", "",
           "## 4. Paid once", "",
           f"**Preparing the library:** {usd(prep['once'])} for {a['library_recordings']} recordings "
           f"(~{prep['hours']:,.0f} hours). Per hour of recording:", "",
           "| Step | Per hour |", "|---|---|"]
    md += [f"| {k} | {usd(v)} |" for k, v in prep["per_hour"].items()]
    md += [f"| **total** | **{usd(sum(prep['per_hour'].values()))}** |", "",
           "After that only new and changed recordings are prepared (in the monthly cost: "
           f"{usd(prep['monthly_total'])} a month, including re-preparing everything "
           f"{a['full_reprocess_per_year']} times a year when the pipeline changes).", "",
           "**Building the production version** (rough, to be confirmed with the platform team):", "",
           "| Work | Basic | Advanced adds |", "|---|---|---|"]
    md += [f"| {w} | {lo}–{hi} days | |" if lvl == "basic" else f"| {w} | | {lo}–{hi} days |" for w, lo, hi, lvl in BUILD]
    b, adv = build_days("basic"), build_days("advanced")
    md += [f"| **total** | **{b[0]}–{b[1]} days** | **{adv[0]}–{adv[1]} days in all** |", "",
           "## 5. People's time a month", "",
           f"Reviewing generated content before it is shared ({a['review_minutes_per_video']} min a video, "
           f"{a['review_minutes_per_lesson']} min a written lesson) and running the service "
           f"({a['ops_hours_basic']} h a month basic, {a['ops_hours_advanced']} h advanced):", "",
           "| | " + " | ".join(s["name"] for s in scen) + " |", "|---|" + "---|" * len(scen),
           "| review | " + " | ".join(f"{s['review_h']:.0f} h" for s in scen) + " |",
           "| running it | " + " | ".join(f"{s['ops_h']:.0f} h" for s in scen) + " |", "",
           "## 6. With and without AI", "",
           "| Option | What you get | Usage cost a month (team) |", "|---|---|---|"]
    team = next(s for s in scen if s["name"] == "team")
    by_key = {r["key"]: r for r in prices}
    answers = team["counts"].get("answer", 0)
    docs = sum(c for k, c in team["counts"].items() if k in ("lesson", "slides"))
    md += [f"| A. No AI | search finds the recording, minute and slide | {usd(answers * 50 / 1e6 * p['titan_embed_per_1m_tokens'])} |",
           f"| B. AI answers and written lessons | A + answers with sources, lessons, slides | "
           f"{usd(answers * by_key['answer']['total'] + sum(by_key[k]['total'] * c for k, c in team['counts'].items() if k in ('lesson', 'slides')))} |",
           f"| C. B + videos and audio | B + narrated and animated videos | {usd(team['use'])} |", "",
           f"Without AI the platform and the library preparation stay (search needs the index); option A skips "
           f"the slide descriptions and topics ({usd(prep['per_hour']['slide descriptions (vision model)'] + prep['per_hour']['topics and topic sections'])} "
           f"an hour of recording). {docs:,.0f} lessons/slides and {answers:,.0f} answers a month in the team scenario.", "",
           "## How to make it more exact", "",
           "- Confirm users and usage (cost_assumptions.csv), and which platform parts already exist.",
           "- Ask the platform team for real prices (AWS Cost Explorer, negotiated discounts) and replace the list prices.",
           "- Run a pilot: every request records its cost, so a month of pilot gives the real per-user cost.",
           "- Cost controls: per-user limits, a smaller model for the relevance check, the local voice where quality allows.", "",
           "## Measured on the proof of concept", "",
           "| Unit | Cost | Basis |", "|---|---|---|",
           f"| answer, with AI relevance check | {usd(m['answer'][0])} | {m['answer'][1]} |",
           f"| answer, without AI relevance check | {usd(m['answer_no_relevance'][0])} | {m['answer_no_relevance'][1]} |",
           f"| describing a slide | {usd(m['slide'][0])} | {m['slide'][1]} |",
           f"| topics, per hour of recording | {usd(m['topics_per_hour'][0])} | {m['topics_per_hour'][1]} |",
           f"| grading a test answer (judge) | {usd(m['judge_per_answer'][0])} | {m['judge_per_answer'][1]} |",
           f"| server seconds per minute of video | {m['render_s_per_min'][0] or p['render_seconds_per_minute']:.0f} s | "
           f"{m['render_s_per_min'][1]} |", "",
           f"Proof of concept so far: {lib['recordings']} recordings ({lib['hours']} h, {lib['slides']} slides), "
           f"{usd(m['_spent_total'][0])} on model calls in total ({m['_spent_total'][1]}), development and tests included. "
           "It runs on free plans and trials, so licences (voice, video engine) are priced from list prices here.", "",
           "## Assumptions", "", "| | Value | Meaning |", "|---|---|---|"]
    md += [f"| {n} | {a[n]} | {w} |" for n, _, _, w in ASSUMPTIONS]
    md += ["", "## Prices and their sources", "", "| | Value | Source |", "|---|---|---|"]
    md += [f"| {n} | {p[n]} {u} | {s} |" for n, _, u, s in PRICES]
    md += ["", "Model prices: Claude list prices on Amazon Bedrock (EU, regional endpoint +10%), as logged per call."]
    return md


def write_xlsx(path: Path, a: dict, p: dict, prices: list[dict], users: dict, plat: dict, scen: list[dict]) -> None:
    from openpyxl import Workbook
    from openpyxl.styles import Font
    wb = Workbook()
    ws = wb.active
    ws.title = "Summary"
    ws.append(["", *[s["name"] for s in scen]])
    for label, key in (("Users", "users"), ("Running cost a month", "month"), ("usage", "use"), ("platform", "platform"),
                       ("preparing recordings", "prep"), ("tests", "tests"), ("per user a month", "per_user"),
                       ("first year", "year1"), ("people hours a month", "people_h")):
        ws.append([label, *[round(s[key], 2) for s in scen]])
    s2 = wb.create_sheet("Price list")
    s2.append(["Request", "Minutes", "AI", "Voice", "Server", "Total", "Basis"])
    for r in prices:
        pt = r["parts"]
        s2.append([r["what"], r["minutes"], round(pt.get("AI", 0), 4), round(pt.get("voice", 0), 4),
                   round(pt.get("server", 0), 4), round(r["total"], 4), r["basis"]])
    s3 = wb.create_sheet("Platform")
    s3.append(["Level", "Item", "USD a month"])
    for level, items in plat.items():
        for k, v in items.items():
            s3.append([TIER_NAMES[level], k, round(v, 2)])
    s4 = wb.create_sheet("Build")
    s4.append(["Work", "Days low", "Days high", "Level"])
    for row in BUILD:
        s4.append(list(row))
    for title, rows, head in (("Assumptions", [(n, a[n], u, w) for n, _, u, w in ASSUMPTIONS], ["name", "value", "unit", "what"]),
                              ("Prices", [(n, p[n], u, s) for n, _, u, s in PRICES], ["name", "value", "unit", "source"])):
        s = wb.create_sheet(title)
        s.append(head)
        for r in rows:
            s.append(list(r))
    for s in wb.worksheets:
        for c in s[1]:
            c.font = Font(bold=True)
        s.column_dimensions["A"].width = 55
    wb.save(path)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.parse_args()
    config.setup_logging()
    a, p = load_inputs()
    lib = library()
    m = measured(lib)
    prices = price_list(a, p, m)
    users = per_user(a, prices)
    prep = preparation(a, p, m, lib)
    plat = tiers(a, p, prep["hours"])
    scen = scenarios(a, p, m, prices, users, plat, prep)
    md = report(a, p, m, lib, prices, users, plat, prep, scen)
    out = config.OUTPUT_DIR / "costs"
    out.mkdir(parents=True, exist_ok=True)
    (out / "costs.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    import qa_eval
    (out / "costs.html").write_text(qa_eval.html_page(md), encoding="utf-8")
    try:
        write_xlsx(out / "costs.xlsx", a, p, prices, users, plat, scen)
    except ImportError:
        log.warning("openpyxl not installed: no costs.xlsx (the .html and .md are there)")
    print("\n".join(md[:22]))
    print(f"\nReport: {out / 'costs.html'} (send this), {out / 'costs.md'}, {out / 'costs.xlsx'}")
    print(f"Users, usage, tools: {ASSUMPTIONS_FILE.name}; prices: {PRICES_FILE.name}. Edit, then run again.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
