"""length_costs.py: videos of several lengths, measured, and the progression and limits worked out."""
from __future__ import annotations

from conftest import needs_ffmpeg
from test_end_to_end import _prepare_one_recording

import config
import length_costs


@needs_ffmpeg
def test_two_lengths_measured_with_progression_and_limits(gateway, fake_voice, monkeypatch):
    _prepare_one_recording()
    monkeypatch.setattr(length_costs, "RENDERER", "pillow")   # fast; the html renderer has its own tests
    voice_before = config.TTS_VOICE
    data = length_costs.run("how to join two tables", [1, 4])
    assert set(data["runs"]) == {"1", "4"} and not data.get("errors")
    assert config.RENDERER == "pillow" and config.TTS_VOICE == voice_before   # settings put back
    rows = data["runs"]
    assert rows["1"]["claude_usd"] > 0 and rows["4"]["length_s"] > rows["1"]["length_s"]
    rep = length_costs.report()
    assert [r["minutes"] for r in rep["rows"]] == [1, 4]
    assert all(r["total_usd"] >= r["claude_usd"] for r in rep["rows"])
    assert rep["progression"][-1]["minutes"] == 60 and rep["progression"][-1]["usd"] >= rep["progression"][0]["usd"]
    assert any("Spending lock" in x["limit"] for x in rep["limits"])
    md = length_costs.write(rep)
    assert "Progression" in md.read_text(encoding="utf-8")
    # made before: not made again
    calls = len(gateway.state["calls"])
    length_costs.run("how to join two tables", [1])
    assert len(gateway.state["calls"]) == calls


def test_fit_is_a_line():
    rows = [{"real_min": 3, "total_usd": 0.2}, {"real_min": 5, "total_usd": 0.3}, {"real_min": 10, "total_usd": 0.55}]
    a, b = length_costs.fit(rows, "total_usd")
    assert abs(b - 0.05) < 0.001 and abs(a - 0.05) < 0.01


@needs_ffmpeg
def test_each_length_built_on_the_one_before(gateway, fake_voice, monkeypatch):
    import extend
    import make_video
    import storyboard
    _prepare_one_recording()
    monkeypatch.setattr(length_costs, "RENDERER", "pillow")
    config.RENDERER = "pillow"
    first, _ = make_video.make("how to join two tables", None, 1, "beginner")
    assert extend.find_base("1m") == first.resolve()
    one = storyboard.load(first)
    data = length_costs.run_chain("1m", [1, 4, 8])
    assert set(data["runs"]) == {"1", "4", "8"} and not data.get("errors")
    r1 = data["runs"]["1"]   # the starting video, measured with the free setup in a copy
    assert r1["measured_copy_of"] == first.name and r1["claude_usd"] > 0 and r1["folder"] != first.name
    assert data["runs"]["4"]["built_on"] == first.name                                   # built on the original
    assert extend.find_base("1m") == first.resolve()                                     # not on the copy
    four, six = (storyboard.load(config.OUTPUT_DIR / data["runs"][k]["folder"]) for k in ("4", "8"))
    kept = [s["narration"] for s in one["scenes"] if s["visual"] not in ("question", "answer")]
    assert [s["narration"] for s in four["scenes"][:len(kept)]] == kept          # the 1-min video, word for word
    body4 = four["scenes"][:four["course"]["chapter_scenes"][-1][1]]
    assert [s["narration"] for s in six["scenes"][:len(body4)]] == [s["narration"] for s in body4]   # 6 keeps 4
    assert [s["section"] for s in four["scenes"]].count("Quiz") >= 2 and four["scenes"][-1]["section"] == "Summary"
    assert sum(s["section"] == "Summary" for s in six["scenes"]) == 1                  # one ending, not two
    assert six["course"]["extended_from"] == data["runs"]["4"]["folder"]
    r6 = data["runs"]["8"]
    assert r6["built_on"] == data["runs"]["4"]["folder"] and r6["claude_usd"] >= r6["claude_step_usd"] > 0
    assert six["stats"]["words"] > four["stats"]["words"] > sum(len(x.split()) for x in kept)
    assert any("Checking results" in t for t in r6["new_topics"] + data["runs"]["4"]["new_topics"])
    labels = [s["label"] for s in six["scenes"] if str(s.get("label", "")).startswith("CHAPTER")]
    assert labels and all(x.endswith(f"OF {len(six['course']['chapter_scenes'])}") for x in labels)
    rep = length_costs.report()
    assert rep["built_from"] == first.name and "built on the one before" in length_costs.write(rep).read_text()
    # made before: not made again
    calls = len(gateway.state["calls"])
    length_costs.run_chain("1m", [1, 4, 8])
    assert len(gateway.state["calls"]) == calls
