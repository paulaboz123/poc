"""
extend.py - make an existing video longer and keep what it already has: the video stays as it is
(the same scenes, the same words), new chapters come after it, then a quiz and a summary of the whole.
A 1-minute video becomes 5 minutes, that one 10, that one 15: each longer video is built on the shorter one.

  uv run extend.py data/output/<folder> --minutes 5      # the video in that folder, made 5 minutes long
  uv run extend.py 1m --minutes 5                        # the newest 1-minute video
  uv run extend.py data/output/<folder> --minutes 10 --plan-only   # only the script (read script.md first)
Normally length_costs.py --from runs it for 5, 10 and 15 minutes in a row.

How it works:
 1. What the video already covers: its chapters, headings and points (nothing is said twice).
 2. New chapters for the missing minutes, planned from the topic maps of the whole knowledge base:
    first what the recordings have on the video's own topic that it doesn't cover yet; when the topic
    is used up, the closest related topics (each with a sentence that bridges from what came before),
    so the video reaches its length. Nothing outside the recordings is added.
 3. Each chapter written from its parts of the recordings (as in course.py); still short after that:
    one more round of chapters on further topics.
 4. A quiz and a summary over the whole video (the shorter video's own quiz and summary go: they were
    its ending, not the longer video's).
 5. The voice of the kept part is reused when the voice is the same (only the new parts are spoken).
Claude writes only the new minutes: about the same cost per added minute as a course.
"""
from __future__ import annotations

import argparse
import inspect
import logging
import shutil
import sys
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path

import config
import course
import lesson
import llm
import make_video
import store
import storyboard
import topics

log = logging.getLogger("extend")
FILL_ROUNDS = 2          # extra rounds of chapters when the video is still short


class AlreadyLong(ValueError):
    """The video is already about as long as asked."""

SHORT_BY = 0.9           # "short": under 90% of the asked length

EXTEND_SCHEMA = {
    "type": "object",
    "properties": {
        "title": {"type": "string", "description": "Title of the whole longer video (the old one if it still fits)"},
        "chapters": {"type": "array", "items": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Chapter title, 2-7 words"},
                "new_topic": {"type": "boolean", "description": "true when the chapter leaves the video's own topic"},
                "bridge": {"type": "string", "description": "One spoken sentence linking it to what came before"},
                "purpose": {"type": "string", "description": "What the learner gets from this chapter, one sentence"},
                "key_points": {"type": "array", "items": {"type": "string"},
                               "description": "2-4 points the chapter teaches"},
                "weight": {"type": "number", "description": "Share of the time, 1 (short) to 3 (long)"},
                "parts": {"type": "array", "items": {
                    "type": "object",
                    "properties": {"recording": {"type": "string", "description": "recording id"},
                                   "start": {"type": "string", "description": "mm:ss"},
                                   "end": {"type": "string", "description": "mm:ss"}},
                    "required": ["recording", "start", "end"]},
                    "description": "Where in the recordings the content of this chapter is"},
            },
            "required": ["title", "new_topic", "bridge", "purpose", "key_points", "weight", "parts"],
        }},
    },
    "required": ["title", "chapters"],
}
EXTEND_SYSTEM = """You plan how to make an existing training video longer. The video stays exactly as it
is; you add chapters after it, for {add:g} more minutes, from the topic maps of the internal training
material (the knowledge base). Rules:
- Never repeat what the video already covers (listed below): build on it.
- First, what the knowledge base has on the video's own topic that the video does not cover yet:
  more detail, examples, how to do it, pitfalls, checks (new_topic = false).
- When the video's own topic is used up, go on with the closest related topics of the knowledge base
  (new_topic = true), in an order that makes sense for a learner, until the time is filled. The time
  must be filled: if little is related, take the next most useful topics of the knowledge base.
- bridge: one spoken sentence that leads from what came before into the chapter.
- {n_min}-{n_max} chapters. parts: the recording ids and time ranges of each chapter's content (from the
  maps). Never add content that is not in the maps.
- title: a title for the whole longer video; keep the old one if it still fits.
- Learner level: {level}."""


def find_base(spec: str | Path) -> Path:
    """A folder, or '1m' (or '1'): the newest video of about 1 minute (a lesson or a comparison)."""
    p = Path(spec)
    if p.exists():
        if not (p / "storyboard.json").exists():
            raise FileNotFoundError(f"No storyboard.json in {p}")
        return p.resolve()
    want = str(spec).lower().rstrip("m").strip()
    try:
        minutes = float(want)
    except ValueError:
        raise FileNotFoundError(f"No folder {spec}") from None
    for folder in sorted(config.OUTPUT_DIR.iterdir(), reverse=True):
        f = folder / "storyboard.json"
        if not folder.is_dir() or not f.exists() or "-measured-" in folder.name:   # length_costs.py's copies
            continue
        sb = store.read_json(f, {}) or {}
        if sb.get("style") == "dialogue" or not sb.get("scenes"):
            continue
        if abs(float(sb.get("minutes") or 0) - minutes) <= 0.5:
            return folder.resolve()
    raise FileNotFoundError(f"No {minutes:g}-minute video in {config.OUTPUT_DIR}: give its folder instead")


def split(sb: dict) -> tuple[list[dict], list[dict], list[list[int]]]:
    """The video's scenes to keep (without its own quiz and summary), its chapters and their scene ranges.
    A lesson (not a course) is one chapter: all of it."""
    c = sb.get("course") or {}
    scenes = sb["scenes"]
    if c.get("chapter_scenes"):
        ranges = [list(r) for r in c["chapter_scenes"]]
        keep = scenes[:ranges[-1][1]]
        chapters = [dict(ch) for ch in c["outline"]["chapters"]][:len(ranges)]
        return keep, chapters, ranges
    keep = [s for s in scenes if s.get("visual") not in ("question", "answer")]
    title = sb.get("title") or sb.get("topic") or "Introduction"
    points = [s.get("heading", "") for s in keep[1:5] if s.get("heading")]
    for s in keep:
        s.setdefault("section", f"Chapter 1: {title}")
        s.setdefault("sources", [])
    return keep, [{"title": title, "purpose": sb.get("goal", ""), "key_points": points, "weight": 2, "parts": []}], \
        [[0, len(keep)]]


def words(scenes: list[dict]) -> int:
    return sum(len(str(s.get("narration", "")).split()) for s in scenes)


def covered(chapters: list[dict], scenes: list[dict], ranges: list[list[int]]) -> str:
    """What the video covers, for the prompt: per chapter its title and its scenes' headings and points."""
    out = []
    for ch, (a, b) in zip(chapters, ranges, strict=True):
        lines = [f"- {s.get('heading', '')}" + (f": {'; '.join(map(str, s['items'][:4]))}" if s.get("items") else "")
                 for s in scenes[a:b] if s.get("heading")]
        out.append(f"{ch['title']}\n" + "\n".join(lines))
    return "\n\n".join(out)


def plan_more(title: str, now_min: float, add: float, level: str, maps: list[dict], what: str,
              model: str | None) -> dict:
    """New chapters for `add` more minutes."""
    n_min, n_max = max(1, round(add / 2.5)), max(2, min(8, round(add / 1.2)))
    system = EXTEND_SYSTEM.format(add=add, n_min=n_min, n_max=n_max, level=f"{level} ({lesson.LEVELS[level]})")
    prompt = (f"VIDEO NOW: {title} ({now_min:.1f} minutes)\nIT COVERS:\n{what}\n\nADD: {add:g} minutes\n\n"
              f"KNOWLEDGE BASE (topic maps)\n\n{course.maps_text(maps)}")
    data = llm.chat_json(prompt, EXTEND_SCHEMA, system=system, step="extend_outline", model=model,
                         max_tokens=3000, temperature=0.2)
    known = {m["ref"] for m in maps}
    chapters = []
    for ch in data.get("chapters", []):
        if not isinstance(ch, dict) or not ch.get("title"):
            continue
        ch["parts"] = [p for p in ch.get("parts", []) if isinstance(p, dict) and str(p.get("recording")) in known]
        ch["weight"] = max(1.0, min(3.0, float(ch.get("weight") or 2)))
        ch["key_points"] = [x for x in ch.get("key_points", []) if isinstance(x, str)][:4]
        ch["new_topic"] = bool(ch.get("new_topic"))
        bridge = " ".join(str(ch.get("bridge") or "").split())
        if bridge:   # the chapter's lead-in starts from it (chapter_instructions shows the purpose)
            ch["purpose"] = f"{bridge} {ch.get('purpose', '')}".strip()
        chapters.append(ch)
    total_w = sum(c["weight"] for c in chapters) or 1
    for ch in chapters:
        ch["minutes"] = round(max(0.8, add * ch["weight"] / total_w), 1)
    return {"title": str(data.get("title") or title), "chapters": chapters[:n_max]}


def write_chapters(plan: dict, first: int, level: str, refs: dict, all_segs: list[dict], model: str | None,
                   wishes: str) -> list[tuple[int, dict]]:
    """Chapters first.. of the plan (course.make_chapter, PARALLEL_CALLS at a time); a failed one is left out."""
    def one(n: int) -> dict | None:
        for attempt in (1, 2):
            try:
                return course.make_chapter(n, plan, level, refs, all_segs, model, wishes)
            except llm.BudgetExceeded:
                raise
            except (llm.LLMError, lesson.NotEnoughMaterial) as e:
                log.warning("Chapter %s, attempt %s failed: %s", n, attempt, str(e).splitlines()[0])
        return None
    numbers = list(range(first, len(plan["chapters"]) + 1))
    with ThreadPoolExecutor(max_workers=config.PARALLEL_CALLS) as pool:
        results = list(pool.map(one, numbers))
    return [(n, r) for n, r in zip(numbers, results, strict=True) if r is not None]


def extend(base: Path, minutes: float, *, model: str | None = None, wishes: str = "") -> Path:
    """The longer storyboard in a new folder (the voice of the kept part copied for reuse)."""
    old = storyboard.load(base)
    level = old.get("level") if old.get("level") in lesson.LEVELS else "beginner"
    keep, chapters, ranges = split(old)
    now_min = words(keep) / storyboard.SPOKEN_WPM
    n_quiz = 1 if minutes < 4 else 2 if minutes < 7 else 3   # a short video: one quiz question
    frame_min = (course.SUMMARY_WORDS + n_quiz * course.QUIZ_WORDS) / storyboard.SPOKEN_WPM
    if now_min + frame_min >= minutes * SHORT_BY:
        raise AlreadyLong(f"The video is already {now_min:.1f} min: ask for more than {now_min + frame_min:.0f} min")
    rows = store.available_recordings()
    if not rows:
        raise ValueError("No processed recordings yet: set include=yes in data/manifest.csv and run pipeline.py.")
    cost0, mark = llm.spent_this_run(), llm.meter_mark()
    maps = [topics.analyse_recording(r, model=model) for r in rows]
    refs = {m["ref"]: m["video_id"] for m in maps}
    all_segs = list(store.all_segments().values())
    style = old.get("style") if old.get("style") in storyboard.STYLES else "clean"
    plan = {"title": old.get("title", ""), "chapters": chapters, "style": style}
    scenes, sources = list(keep), dict(old.get("sources") or {})
    new_parts: list[dict] = []
    for round_ in range(1 + FILL_ROUNDS):
        have = words(scenes) / storyboard.SPOKEN_WPM
        add = round(minutes - have - frame_min, 1)
        if round_ and (have + frame_min >= minutes * SHORT_BY or add < 0.8):
            break
        more = plan_more(plan["title"], have, add, level, maps, covered(plan["chapters"], scenes, ranges), model)
        if not more["chapters"]:
            log.warning("No more chapters could be planned (round %s)", round_ + 1)
            break
        if round_ == 0:
            plan["title"] = more["title"]
        first = len(plan["chapters"]) + 1
        plan["chapters"] = plan["chapters"] + more["chapters"]
        made = write_chapters(plan, first, level, refs, all_segs, model, wishes)
        kept_numbers = {n for n, _ in made}
        dropped = [c["title"] for n, c in enumerate(plan["chapters"], 1) if n >= first and n not in kept_numbers]
        # renumber so the chapters are 1..N without gaps (a failed chapter is left out)
        plan["chapters"] = plan["chapters"][:first - 1]
        for n, r in made:
            new_n = len(plan["chapters"]) + 1
            ch = more["chapters"][n - first]
            if new_n != n:
                course._renumber(r, n, new_n, new_n, ch["title"])   # noqa: SLF001 - the same labels as a course
            plan["chapters"].append(ch)
            ranges.append([len(scenes), len(scenes) + len(r["scenes"])])
            scenes += r["scenes"]
            sources.update(r["sources"])
            new_parts.append({"title": ch["title"], "new_topic": ch["new_topic"], "minutes": ch["minutes"],
                              "warnings": r["stats"].get("warnings", [])})
        if dropped:
            plan.setdefault("dropped_chapters", []).extend(dropped)
        log.info("Round %s: %s new chapter(s), now %.1f min of %g", round_ + 1, len(made),
                 (words(scenes) / storyboard.SPOKEN_WPM) + frame_min, minutes)
    if len(plan["chapters"]) == len(chapters):
        raise lesson.NotEnoughMaterial("No new chapter could be made from the recordings")
    total = len(plan["chapters"])
    for a, _b in ranges:   # "CHAPTER 2 OF 5" on every chapter's title scene
        if str(scenes[a].get("label", "")).upper().startswith("CHAPTER"):
            n = next(i for i, r in enumerate(ranges, 1) if r[0] == a)
            scenes[a]["label"] = f"CHAPTER {n} OF {total}"
    chapter_sbs = [{"scenes": scenes[a:b]} for a, b in ranges]
    fr = course.frame(plan, chapter_sbs, level, minutes, model)
    fr["quiz"] = fr["quiz"][:n_quiz]
    sb = finish(old, base, plan, scenes, ranges, sources, fr, minutes, level, model, wishes, new_parts)
    sb["plan_cost_usd_est"] = round(llm.spent_this_run() - cost0, 4)
    sb["plan_calls"] = llm.calls_since(mark)
    sb["plan_cost_total_usd"] = round(base_cost(old) + sb["plan_cost_usd_est"], 4)
    out_dir = config.OUTPUT_DIR / f"{sb['created']}-{store.slugify(sb['topic'], 40)}-extended-{minutes:g}m"
    storyboard.save(sb, out_dir)
    voices = base / "audio" if (base / "audio").exists() else base / "voices"
    if voices.exists():   # the kept part's voice: reused when the voice is the same (same text, same voice)
        (out_dir / "audio").mkdir(parents=True, exist_ok=True)
        for w in voices.glob("voice_*.wav"):
            if not (out_dir / "audio" / w.name).exists():
                shutil.copy2(w, out_dir / "audio" / w.name)
    log.info("Longer storyboard: %s scenes, %s words (target %s), %s new chapter(s) -> %s", len(scenes),
             sb["stats"]["words"], sb["stats"]["target_words"], len(new_parts), out_dir / "script.md")
    return out_dir


def base_cost(sb: dict) -> float:
    """What Claude cost to write the shorter video (all its steps, when it was itself extended)."""
    if sb.get("plan_cost_total_usd") is not None:
        return float(sb["plan_cost_total_usd"])
    if sb.get("plan_calls"):
        return sum(float(c.get("cost_usd") or 0) for c in sb["plan_calls"])
    return float(sb.get("plan_cost_usd_est") or 0)


def finish(old: dict, base: Path, plan: dict, scenes: list[dict], ranges: list[list[int]], sources: dict,
           fr: dict, minutes: float, level: str, model: str | None, wishes: str, new_parts: list[dict]) -> dict:
    """The longer storyboard: the kept video -> new chapters -> quiz -> summary (as course.assemble)."""
    short = storyboard._short   # noqa: SLF001
    scenes = list(scenes)
    for q in fr["quiz"]:
        question = " ".join(q["question"].split())
        opts = [short(x) for x in q["options"]]
        scenes.append({"visual": "question", "heading": question, "items": opts,
                       "narration": f"{question} Pause and think.", "sources": [],
                       "pause_after": storyboard.QUESTION_PAUSE_S, "section": "Quiz"})
        scenes.append({"visual": "answer", "heading": question, "items": opts, "correct": q["correct"],
                       "narration": " ".join(q["answer_narration"].split()), "sources": [], "section": "Quiz"})
    scenes.append({"visual": "bullets", "heading": "Key takeaways", "items": [short(x) for x in fr["summary_items"]],
                   "narration": " ".join(fr["summary_narration"].split()), "sources": [], "section": "Summary"})
    warnings = [f"{p['title']}: {w}" for p in new_parts for w in p["warnings"]
                if not w.startswith("teaching structure")]
    new_topics = [p["title"] for p in new_parts if p["new_topic"]]
    if new_topics:
        warnings.insert(0, f"the video's own topic ran out: new topics added: {', '.join(new_topics)}")
    if plan.get("dropped_chapters"):
        warnings.insert(0, f"chapter(s) left out after errors: {', '.join(plan['dropped_chapters'])}")
    if not fr["quiz"]:
        warnings.append("no usable quiz question")
    n_words, target = words(scenes), int(minutes * storyboard.SPOKEN_WPM)
    if abs(n_words / target - 1) > 0.15:
        warnings.append(f"narration is {n_words} words, target {target}")
    kinds = [s["visual"] for s in scenes]
    stats = {"scenes": len(scenes), "words": n_words, "target_words": target,
             "length_ratio": round(n_words / target, 2), "est_minutes": round(n_words / storyboard.SPOKEN_WPM, 1),
             "chapters": len(ranges), "excerpts_given": len(sources),
             "excerpts_cited": len({x for s in scenes for x in s.get("sources", [])}),
             "teaching": {"objectives": bool(old.get("objectives") or fr["objectives"]), "example": "example" in kinds,
                          "question": "question" in kinds, "recap": True},
             "self_review_changes": [], "warnings": warnings}
    topic = old.get("topic") or (old.get("request") or {}).get("topic") or old.get("title", "video")
    characters = old.get("characters") or config.CHARACTERS
    return {"created": datetime.now().strftime("%Y%m%d-%H%M%S"), "topic": topic, "minutes": minutes,
            "level": level, "model": model or config.CHAT_MODEL, "title": plan["title"], "goal": fr["goal"],
            "style": plan["style"], "objectives": old.get("objectives") or fr["objectives"], "scenes": scenes,
            "stats": stats, "sources": sources, "characters": characters,
            "settings": storyboard.settings(model, extra_prompts=(EXTEND_SYSTEM, course.FRAME_SYSTEM,
                                                                  inspect.getsource(course.chapter_instructions))),
            "course": {"outline": {k: v for k, v in plan.items() if k != "style"}, "chapter_scenes": ranges,
                       "wishes": wishes, "extended_from": base.name, "base_minutes": old.get("minutes"),
                       "new_chapters": new_parts},
            "request": {"topic": topic, "recording": "", "minutes": minutes, "level": level, "wishes": wishes,
                        "kind": "course", "style": plan["style"], "characters": characters,
                        "extended_from": base.name}}


def make(base: Path, minutes: float, *, model: str | None = None, plan_only: bool = False,
         wishes: str = "") -> tuple[Path, dict]:
    """The longer video: the storyboard, then voice + pictures + video (unless plan_only)."""
    if not plan_only:
        make_video.check_voice_quota(minutes)
    out_dir = extend(base, minutes, model=model, wishes=wishes)
    return make_video.make(rerender=out_dir, plan_only=plan_only)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("base", help="the video's folder, or 1m for the newest 1-minute video")
    ap.add_argument("--minutes", type=float, required=True, help="the new length")
    ap.add_argument("--wishes", default="")
    ap.add_argument("--model", help="override CHAT_MODEL from .env")
    ap.add_argument("--plan-only", action="store_true", help="stop after the storyboard (read script.md first)")
    args = ap.parse_args()
    config.setup_logging()
    try:
        base = find_base(args.base)
        log.info("Built on: %s", base.name)
        out_dir, info = make(base, args.minutes, model=args.model, plan_only=args.plan_only, wishes=args.wishes)
    except lesson.NotEnoughMaterial as e:
        log.error("%s", e)
        return 2
    except (RuntimeError, ValueError, OSError) as e:
        log.error("%s", e)
        return 1
    print(f"\nScript: {out_dir / 'script.md'}")
    if not args.plan_only:
        m, s = divmod(int(info["duration_s"]), 60)
        print(f"Video:  {info['video']}  ({m}:{s:02d})")
    print(f"Estimated model cost: ${llm.spent_this_run():.3f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
