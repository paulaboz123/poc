"""
company_avatar.py - the company's own avatars as talking presenters: a picture of each character
(a simple drawn person) is made to talk in the video with its OWN pixels: nothing is redrawn and nothing
leaves this computer. With the voice the picture's lower lip and chin move down a little and show the
inside of the mouth (a deep shade of its own lips); a blink is a lid made of its own skin; when it is silent
the picture is exactly the original. It breathes slowly, leans toward the slide while the voice explains it
and hops to say hello. Remotion Pro draws it (PRO_PRESENTER=company), with the same motion design as the
other presenters.

  1. Put each picture in data/avatars (any name: "Anna Kowalska.png" becomes anna-kowalska), or add it on the
     Avatars tab. PNG with a see-through background is best; a JPG/PNG with a background works too (shown in
     a round portrait)
  2. Nothing to click: each picture is marked by Claude (vision, through the gateway: the eyes, the mouth, where
     the lips meet, the chin, woman or man), made exact with the picture's pixels and checked once by Claude
     on the picture with the marks drawn on it. It happens when a picture is added on the Avatars tab, when
     the tab opens, and before compare_video.py makes the videos (or: uv run company_avatar.py mark).
     The Avatars tab shows each one talking; the boxes can still be moved there by hand.
  3. uv run compare_video.py --resume    (or --only company-anna): a video per avatar and narrator,
     tab Comparison, group "Company avatar"
  uv run company_avatar.py list           what is there and what is still to mark
  uv run company_avatar.py demo           three stand-in characters (to try it before the real pictures)

The marks are kept next to the picture (<name>.json): where the mouth and the eyes are (as parts of
the picture, so any size works) and the colours sampled around them (skin over the closed mouth and
the eyelids, the lips, the lines).
"""
from __future__ import annotations

import argparse
import logging
import re
import shutil
import sys
from pathlib import Path

import numpy as np

import config
import store

log = logging.getLogger("company_avatar")
EXTS = (".png", ".webp", ".jpg", ".jpeg")
REMOTION_PRICE = "Free for teams of up to 3 people; companies: $0.01 a render, at least $100 a month"


def folder() -> Path:
    return Path(config.AVATARS_DIR)


def slug(text: str) -> str:
    """A name usable as a file name: "Anna Łęcka" -> "anna-lecka" (Polish letters, spaces and capitals allowed)."""
    import unicodedata
    t = str(text).lower().replace("ł", "l")
    t = unicodedata.normalize("NFKD", t).encode("ascii", "ignore").decode()
    s = re.sub(r"[^a-z0-9_-]+", "-", t).strip("-")[:40]
    return s or "avatar"


def pictures() -> dict[str, Path]:
    """{name: picture} in data/avatars (the name: the file name without its extension, made safe: "Anna K.png" ->
    anna-k)."""
    out: dict[str, Path] = {}
    if folder().exists():
        for f in sorted(folder().iterdir()):
            if f.is_file() and f.suffix.lower() in EXTS and slug(f.stem) not in out:
                out[slug(f.stem)] = f
    return out


def marks_file(name: str) -> Path:
    return folder() / f"{name}.json"


def load(name: str) -> dict | None:
    """The avatar's marks (None: not marked yet)."""
    data = store.read_json(marks_file(name), {}) if marks_file(name).exists() else {}
    return data if data.get("mouth") and len(data.get("eyes", [])) == 2 else None


def listing() -> list[dict]:
    """Every picture: its name, label, who, whether it is marked, the picture and its marks."""
    out = []
    for name, pic in pictures().items():
        m = load(name) or {}
        out.append({"name": name, "file": pic.name, "label": m.get("label") or name.replace("-", " ").title(),
                    "who": m.get("who", ""), "marked": bool(m), "marks": m or guess(pic)})
    return out


# --- reading the picture --------------------------------------------------------------------------
def _rgba(pic: Path, max_side: int = 0):
    from PIL import Image
    im = Image.open(pic).convert("RGBA")
    if max_side and max(im.size) > max_side:
        k = max_side / max(im.size)
        im = im.resize((max(1, round(im.width * k)), max(1, round(im.height * k))), Image.LANCZOS)
    return im


def cutout(pic: Path) -> bool:
    """Does the picture have a see-through background (then the character stands free, not in a circle)?"""
    a = np.asarray(_rgba(pic, 256))[..., 3]
    border = np.concatenate([a[0], a[-1], a[:, 0], a[:, -1]])
    return float((border < 20).mean()) > 0.5


def subject(px: np.ndarray, is_cut: bool) -> np.ndarray:
    """The character's pixels: not see-through, or (with a background) different from the corners' colour."""
    if is_cut:
        return px[..., 3] > 40
    rgb = px[..., :3].astype(np.float32)
    corners = np.stack([rgb[0, 0], rgb[0, -1], rgb[-1, 0], rgb[-1, -1]])
    bg = np.median(corners, axis=0)
    return np.linalg.norm(rgb - bg, axis=-1) > 38


def _components(mask: np.ndarray) -> list[dict]:
    """Connected dark spots (4-neighbours): their box, size and centre. Small pictures only (~200 px)."""
    h, w = mask.shape
    seen = np.zeros_like(mask, dtype=bool)
    out = []
    for y0, x0 in zip(*np.nonzero(mask), strict=True):
        if seen[y0, x0]:
            continue
        stack, pts = [(y0, x0)], []
        seen[y0, x0] = True
        while stack:
            y, x = stack.pop()
            pts.append((y, x))
            for ny, nx in ((y + 1, x), (y - 1, x), (y, x + 1), (y, x - 1)):
                if 0 <= ny < h and 0 <= nx < w and mask[ny, nx] and not seen[ny, nx]:
                    seen[ny, nx] = True
                    stack.append((ny, nx))
        ys, xs = np.array([p[0] for p in pts]), np.array([p[1] for p in pts])
        out.append({"n": len(pts), "x0": xs.min(), "x1": xs.max() + 1, "y0": ys.min(), "y1": ys.max() + 1,
                    "cx": xs.mean(), "cy": ys.mean()})
    return out


def guess(pic: Path) -> dict:
    """Where the eyes and the mouth probably are, to start from (checked and moved on the Avatars tab):
    the eyes as a pair of dark spots side by side in the upper part of the character, the mouth below
    them in the middle; else the usual places in a head-and-shoulders picture."""
    im = _rgba(pic, 220)
    px = np.asarray(im)
    W, H = im.size
    is_cut = cutout(pic)
    body = subject(px, is_cut)
    ys, xs = np.nonzero(body)
    if len(xs) < 50:
        bx0, by0, bx1, by1 = 0, 0, W, H
    else:
        bx0, by0, bx1, by1 = xs.min(), ys.min(), xs.max() + 1, ys.max() + 1
    bw, bh = bx1 - bx0, by1 - by0
    # the usual places (head-and-shoulders): eyes at ~33 % of the height, mouth at ~50 %
    fallback = {"eyes": [[(bx0 + bw * 0.355) / W, (by0 + bh * 0.31) / H, bw * 0.1 / W, bh * 0.06 / H],
                         [(bx0 + bw * 0.545) / W, (by0 + bh * 0.31) / H, bw * 0.1 / W, bh * 0.06 / H]],
                "mouth": [(bx0 + bw * 0.42) / W, (by0 + bh * 0.47) / H, bw * 0.16 / W, bh * 0.05 / H],
                "found": False}
    luma = px[..., :3].astype(np.float32) @ np.array([0.299, 0.587, 0.114], dtype=np.float32)
    top = np.zeros_like(body)
    top[by0:by0 + int(bh * 0.62), :] = True
    inside = body & top
    if inside.sum() < 50:
        return _rounded(fallback)
    dark = inside & (luma < min(90.0, float(np.percentile(luma[inside], 8))))
    spots = [c for c in _components(dark) if 3 <= c["n"] <= bw * bh * 0.01 and (c["x1"] - c["x0"]) < bw * 0.2
             and (c["x1"] - c["x0"]) <= 2.2 * (c["y1"] - c["y0"])]   # round-ish: pupils, not eyebrows
    best, score = None, 0.0
    mid = bx0 + bw / 2
    for i, a in enumerate(spots):
        for b in spots[i + 1:]:
            left, right = (a, b) if a["cx"] < b["cx"] else (b, a)
            gap = right["cx"] - left["cx"]
            if not (bw * 0.12 < gap < bw * 0.45) or abs(a["cy"] - b["cy"]) > bh * 0.04:
                continue
            centred = 1 - abs((left["cx"] + right["cx"]) / 2 - mid) / (bw / 2)
            alike = min(a["n"], b["n"]) / max(a["n"], b["n"])
            s = centred * 2 + alike + min(a["n"], b["n"]) / 50
            if s > score:
                best, score = (left, right, gap), s
    if not best:
        return _rounded(fallback)
    left, right, gap = best

    def box(c, pad_x, pad_y):
        w = max(c["x1"] - c["x0"], gap * 0.28) + 2 * pad_x
        h = max(c["y1"] - c["y0"], gap * 0.16) + 2 * pad_y
        return [(c["cx"] - w / 2) / W, (c["cy"] - h / 2) / H, w / W, h / H]

    eyes = [box(left, gap * 0.08, gap * 0.08), box(right, gap * 0.08, gap * 0.08)]
    ey = (left["cy"] + right["cy"]) / 2
    ex = (left["cx"] + right["cx"]) / 2
    # the mouth: below the eyes, between them, the spot that differs most from the skin there
    rgb = px[..., :3].astype(np.float32)
    zone = np.zeros_like(body)
    zone[int(ey + gap * 0.45):int(min(H, ey + gap * 1.35)), int(ex - gap * 0.6):int(ex + gap * 0.6)] = True
    zone &= body
    skin = _mode(rgb[zone]) if zone.any() else np.array([230.0, 190, 160])
    far = np.linalg.norm(rgb - skin, axis=-1) > 40
    cand = zone & far & (luma < skin @ np.array([0.299, 0.587, 0.114]) - 20)
    parts = [c for c in _components(cand) if c["n"] >= 3 and (c["x1"] - c["x0"]) >= gap * 0.18]
    if parts:
        m = max(parts, key=lambda c: c["n"] - abs(c["cx"] - ex) * 2)
        mw = max(m["x1"] - m["x0"], gap * 0.5) * 1.25
        mh = max(m["y1"] - m["y0"], gap * 0.14) * 1.3
        mouth = [(m["cx"] - mw / 2) / W, (m["cy"] - mh / 2) / H, mw / W, mh / H]
    else:
        mw, mh = gap * 0.62, gap * 0.2
        mouth = [(ex - mw / 2) / W, (ey + gap * 0.75 - mh / 2) / H, mw / W, mh / H]
    return _rounded({"eyes": eyes, "mouth": mouth, "found": True})


def _rounded(m: dict) -> dict:
    r = lambda b: [round(float(min(max(v, 0.0), 1.0)), 4) for v in b]   # noqa: E731
    return {"eyes": [r(e) for e in m["eyes"]], "mouth": r(m["mouth"]), "found": m.get("found", False)}


def _mode(pixels: np.ndarray) -> np.ndarray:
    """The most common colour (drawn characters are flat colours): the mean of the fullest of 16x16x16 bins."""
    p = np.asarray(pixels, dtype=np.float32).reshape(-1, 3)
    if not len(p):
        return np.array([230.0, 190, 160])
    q = (p // 16).astype(np.int32)
    key = q[:, 0] * 256 + q[:, 1] * 16 + q[:, 2]
    top = np.bincount(key).argmax()
    return p[key == top].mean(axis=0)


def _hex(rgb) -> str:
    return "#{:02x}{:02x}{:02x}".format(*(int(max(0, min(255, round(float(v))))) for v in rgb[:3]))


def colours(pic: Path, marks: dict) -> dict:
    """The colours drawn over the picture: the skin around the mouth (it covers the closed mouth while
    the mouth is open), the skin above each eye (the eyelids), the lips and the lines (the darkest)."""
    im = _rgba(pic, 600)
    px = np.asarray(im).astype(np.float32)
    W, H = im.size

    def region(b, grow_x=0.0, grow_y=0.0):
        x, y, w, h = b
        x0, x1 = int((x - w * grow_x) * W), int((x + w * (1 + grow_x)) * W)
        y0, y1 = int((y - h * grow_y) * H), int((y + h * (1 + grow_y)) * H)
        return max(0, x0), max(0, y0), min(W, max(x1, x0 + 1)), min(H, max(y1, y0 + 1))

    def pixels(x0, y0, x1, y1, hole=None):
        p = px[y0:y1, x0:x1].copy()
        if hole:
            hx0, hy0, hx1, hy1 = hole
            p[max(0, hy0 - y0):max(0, hy1 - y0), max(0, hx0 - x0):max(0, hx1 - x0), 3] = 0
        p = p.reshape(-1, 4)
        return p[p[:, 3] > 128][:, :3]

    mouth = region(marks["mouth"])
    skin = _mode(pixels(*region(marks["mouth"], 0.45, 0.9), hole=mouth))
    inner = pixels(*mouth)
    away = inner[np.linalg.norm(inner - skin, axis=-1) > 60] if len(inner) else inner
    lip = _mode(away) if len(away) >= 4 else skin * 0.6
    lids, line = [], []
    for e in marks["eyes"]:
        eye = region(e)
        ring = pixels(*region(e, 0.5, 0.7), hole=eye)
        lids.append(_hex(_mode(ring) if len(ring) else skin))
        inside = pixels(*eye)
        if len(inside):
            luma = inside @ np.array([0.299, 0.587, 0.114])
            line.append(np.median(inside[luma <= np.percentile(luma, 10)], axis=0))
    inside_mouth = np.array(lip) * 0.45   # inside of the open mouth: a deep shade of the lips
    return {"skin": _hex(skin), "lids": lids, "lip": _hex(lip), "inside": _hex(inside_mouth),
            "line": _hex(np.mean(line, axis=0) if line else [40, 30, 28])}


# --- marked by AI (Claude's vision through the gateway), the picture's pixels used to make it exact ---------
AI_FIND = """This is a drawn character (an avatar) on a grid: the numbers on the edges are tenths of the width (top)
and of the height (left). Find, as parts of the picture (0 = left / top edge, 1 = right / bottom edge):
- left_eye and right_eye (as the viewer sees them): a box [x, y, width, height] around each whole eye (white,
  iris and lashes), a little bigger than the eye, not the eyebrow;
- mouth: a tight box [x, y, width, height] around the lips;
- lips: the height (y) where the upper and the lower lip meet (the mouth's opening line);
- chin: the height (y) of the lowest point of the chin (where the face ends, above the neck);
- face: a box [x, y, width, height] around the face from ear to ear and from the hairline to the chin;
- who: "woman" or "man" as the drawing shows (or "unclear").
Answer JSON only."""
AI_CHECK = """This drawn character has three boxes drawn on it: BLUE = left eye, GREEN = right eye, RED = mouth (lips),
a YELLOW line = where the lips meet, an ORANGE line = the chin's lowest point. The grid numbers are tenths
of the width (top) and of the height (left). Check each: does it sit exactly on that part? If all are
right, answer {"ok": true}. If any is off, answer {"ok": false} with corrected values for the wrong ones
only (left_eye, right_eye, mouth: [x, y, width, height]; lips, chin: y), as parts of the picture. JSON only."""
AI_SCHEMA = {"type": "object", "properties": {
    "left_eye": {"type": "array", "items": {"type": "number"}}, "right_eye": {"type": "array", "items": {"type": "number"}},
    "mouth": {"type": "array", "items": {"type": "number"}}, "lips": {"type": "number"}, "chin": {"type": "number"},
    "face": {"type": "array", "items": {"type": "number"}}, "who": {"type": "string"}, "ok": {"type": "boolean"}}}


def _sheet(pic: Path, marks: dict | None = None, side: int = 1024) -> Path:
    """The picture for the model: on a neutral grey (a see-through background would turn black), a light grid
    with its tenths written on the edges, and (to check) the marks drawn on it."""
    import tempfile

    from PIL import Image, ImageDraw, ImageFont
    im = _rgba(pic, side)
    W, H = im.size
    pad = 44
    try:
        font = ImageFont.load_default(size=18)
    except TypeError:   # an older Pillow: its small built-in font
        font = ImageFont.load_default()
    out = Image.new("RGB", (W + pad + 24, H + pad + 24), (205, 205, 205))
    bg = Image.new("RGBA", im.size, (190, 190, 190, 255))
    bg.alpha_composite(im)
    out.paste(bg.convert("RGB"), (pad, pad))
    d = ImageDraw.Draw(out)
    for k in range(11):
        x, y = pad + W * k / 10, pad + H * k / 10
        d.line([(x, pad), (x, pad + H)], fill=(120, 120, 120), width=1)
        d.line([(pad, y), (pad + W, y)], fill=(120, 120, 120), width=1)
        d.text((x - 8, 10), str(k), fill=(0, 0, 0), font=font)
        d.text((8, y - 10), str(k), fill=(0, 0, 0), font=font)
    if marks:
        def rect(b, colour):
            x, y, w, h = b
            d.rectangle([pad + x * W, pad + y * H, pad + (x + w) * W, pad + (y + h) * H], outline=colour, width=3)
        rect(marks["eyes"][0], (30, 90, 255))
        rect(marks["eyes"][1], (20, 170, 60))
        rect(marks["mouth"], (230, 30, 30))
        for key, colour in (("lips", (240, 200, 0)), ("chin", (255, 130, 0))):
            if marks.get(key):
                y = pad + marks[key] * H
                d.line([(pad + W * 0.2, y), (pad + W * 0.8, y)], fill=colour, width=3)
    f = Path(tempfile.mkdtemp(prefix="avatar_")) / "sheet.jpg"
    out.save(f, quality=92)
    return f


def _ok_box(b) -> bool:
    return isinstance(b, list) and len(b) == 4 and all(isinstance(x, (int, float)) for x in b) \
        and 0 <= b[0] < 1 and 0 <= b[1] < 1 and 0.005 < b[2] <= 0.6 and 0.005 < b[3] <= 0.6


def refine(pic: Path, m: dict) -> dict:
    """The model's boxes made exact with the picture's pixels: each eye centred on its pupil (the darkest
    spot near it), the mouth fitted to the lips (the spot that differs most from the skin near it), the lips'
    line through the mouth. A box the pixels do not confirm is kept as the model gave it."""
    im = _rgba(pic, 400)
    px = np.asarray(im).astype(np.float32)
    W, H = im.size
    is_cut = cutout(pic)
    body = subject(px, is_cut)
    luma = px[..., :3] @ np.array([0.299, 0.587, 0.114], dtype=np.float32)
    out = {**m, "eyes": [list(e) for e in m["eyes"]], "mouth": list(m["mouth"])}

    def window(b, grow):
        x, y, w, h = b
        x0, y0 = max(0, int((x - w * grow) * W)), max(0, int((y - h * grow) * H))
        x1, y1 = min(W, int((x + w * (1 + grow)) * W) + 1), min(H, int((y + h * (1 + grow)) * H) + 1)
        return x0, y0, x1, y1

    for i, e in enumerate(m["eyes"]):
        x0, y0, x1, y1 = window(e, 0.5)
        zone = np.zeros_like(body)
        zone[y0:y1, x0:x1] = True
        zone &= body
        if zone.sum() < 20:
            continue
        dark = zone & (luma < min(110.0, float(np.percentile(luma[zone], 12))))
        spots = [c for c in _components(dark) if c["n"] >= 3]
        if not spots:
            continue
        cx, cy = (e[0] + e[2] / 2) * W, (e[1] + e[3] / 2) * H
        c = min(spots, key=lambda c: (c["cx"] - cx) ** 2 + (c["cy"] - cy) ** 2 - c["n"] * 0.5)
        if abs(c["cx"] - cx) > e[2] * W or abs(c["cy"] - cy) > e[3] * H:
            continue   # too far from where the model saw the eye: the model's box stays
        w, h = e[2] * W, e[3] * H
        out["eyes"][i] = [(c["cx"] - w / 2) / W, (c["cy"] - h / 2) / H, e[2], e[3]]
    mb = m["mouth"]
    x0, y0, x1, y1 = window(mb, 0.6)
    zone = np.zeros_like(body)
    zone[y0:y1, x0:x1] = True
    zone &= body
    if zone.sum() >= 20:
        rgb = px[..., :3]
        skin = _mode(rgb[zone])
        far = zone & (np.linalg.norm(rgb - skin, axis=-1) > 40) & (luma < skin @ np.array([0.299, 0.587, 0.114]) - 15)
        parts = [c for c in _components(far) if c["n"] >= 3 and (c["x1"] - c["x0"]) >= mb[2] * W * 0.3]
        if parts:
            mcx = (mb[0] + mb[2] / 2) * W
            c = max(parts, key=lambda c: c["n"] - abs(c["cx"] - mcx) * 3)
            pw, ph = (c["x1"] - c["x0"]) * 1.25, max(c["y1"] - c["y0"], 2) * 1.6
            out["mouth"] = [(c["cx"] - pw / 2) / W, (c["cy"] - ph / 2) / H, pw / W, ph / H]
            if not (out["mouth"][1] <= (m.get("lips") or -1) <= out["mouth"][1] + out["mouth"][3]):
                out["lips"] = c["cy"] / H + (c["y1"] - c["y0"]) * 0.15 / H
    return out


def ai_marks(pic: Path) -> dict:
    """Where the eyes, the mouth, the lips' line and the chin are, found by Claude (vision, through the gateway),
    made exact with the picture's pixels and checked once by Claude on the picture with the marks drawn on it.
    Raises llm.LLMError when no model can be reached (then guess() is used)."""
    import llm
    sheet = _sheet(pic)
    try:
        a = llm.parse_json(llm.describe_image(sheet, AI_FIND, step="avatar marks", max_side=1100))
    finally:
        sheet.unlink(missing_ok=True)
    eyes = [a.get("left_eye"), a.get("right_eye")]
    if not (all(_ok_box(e) for e in eyes) and _ok_box(a.get("mouth"))):
        raise llm.LLMError(f"The model's marks are incomplete: {str(a)[:200]}")
    face = a.get("face")
    face_ok = isinstance(face, list) and len(face) == 4 and all(isinstance(v, (int, float)) and 0 <= v <= 1 for v in face) \
        and face[2] > 0.05 and face[3] > 0.05
    m = {"eyes": sorted(eyes, key=lambda b: b[0]), "mouth": a["mouth"], "who": a.get("who", ""),
         "lips": a.get("lips"), "chin": a.get("chin"), "face": face if face_ok else None}
    m = refine(pic, m)
    sheet = _sheet(pic, m)
    try:   # one check by the model on the picture with the marks drawn on it
        c = llm.parse_json(llm.describe_image(sheet, AI_CHECK, step="avatar marks check", max_side=1100))
    except llm.LLMError:
        c = {"ok": True}
    finally:
        sheet.unlink(missing_ok=True)
    if not c.get("ok", True):
        fixed = dict(m)
        if _ok_box(c.get("left_eye")):
            fixed["eyes"] = [c["left_eye"], fixed["eyes"][1]]
        if _ok_box(c.get("right_eye")):
            fixed["eyes"] = [fixed["eyes"][0], c["right_eye"]]
        if _ok_box(c.get("mouth")):
            fixed["mouth"] = c["mouth"]
        for k in ("lips", "chin"):
            if isinstance(c.get(k), (int, float)) and 0 < c[k] < 1:
                fixed[k] = c[k]
        fixed["eyes"] = sorted(fixed["eyes"], key=lambda b: b[0])
        m = refine(pic, fixed)
    lips, chin = m.get("lips"), m.get("chin")
    mo = m["mouth"]
    if not (isinstance(lips, (int, float)) and mo[1] - mo[3] <= lips <= mo[1] + 2 * mo[3]):
        m["lips"] = mo[1] + mo[3] * 0.4
    if not (isinstance(chin, (int, float)) and m["lips"] < chin < 1):
        m.pop("chin", None)
    if not m.get("face"):
        m.pop("face", None)
    return {**_rounded(m), **{k: round(float(m[k]), 4) for k in ("lips", "chin") if m.get(k)},
            **({"face": [round(float(v), 4) for v in m["face"]]} if m.get("face") else {}),
            "who": m.get("who") if m.get("who") in ("woman", "man") else "", "found": True, "by": "ai"}


def mark(name: str, label: str = "") -> dict:
    """Mark one picture with no clicks: by Claude when the gateway is there, else found in the pixels."""
    pic = pictures()[name]
    try:
        m = ai_marks(pic)
    except Exception as e:   # noqa: BLE001 - no model reachable (or a bad answer): the pixels alone
        log.warning("Avatar %s: marked from the pixels only (%s)", name, str(e)[:200])
        m = {**guess(pic), "by": "guess"}
    old = load(name) or {}
    return save(name, {**m, "label": label or old.get("label") or name.replace("-", " ").title(),
                       "who": m.get("who") or old.get("who", "")})


def mark_all() -> list[str]:
    """Every picture in data/avatars that is not marked yet, marked (by Claude where it can)."""
    done = []
    for a in listing():
        if not a["marked"]:
            mark(a["name"])
            done.append(a["name"])
    return done


def save(name: str, marks: dict) -> dict:
    """Keep the marks of a picture (the colours sampled again). marks: mouth [x, y, w, h], eyes [[...], [...]]
    (parts of the picture's width and height), label, who (woman | man)."""
    pic = pictures().get(name)
    if not pic:
        raise FileNotFoundError(f"No picture {name} in {folder()}")
    def box(b):
        v = [float(x) for x in b]
        if len(v) != 4 or not all(0 <= x <= 1 for x in v) or v[2] <= 0.005 or v[3] <= 0.005:
            raise ValueError(f"A box is [x, y, width, height] as parts of the picture (0-1): {b}")
        return [round(x, 4) for x in v]
    eyes = marks.get("eyes") or []
    if len(eyes) != 2:
        raise ValueError("Two eyes are needed")
    data = {"label": " ".join(str(marks.get("label") or name).split())[:40],
            "who": marks.get("who") if marks.get("who") in ("woman", "man") else "",
            "mouth": box(marks["mouth"]), "eyes": sorted([box(e) for e in eyes], key=lambda b: b[0])}
    old = load(name) or {}
    if old and not any(k in marks for k in ("lips", "chin", "face")):   # moved by hand: the AI's chin and face stay,
        marks = {**marks, "chin": old.get("chin"), "face": old.get("face")}   # its lips' line if still in the mouth box
        mo = data["mouth"]
        if old.get("lips") and mo[1] <= old["lips"] <= mo[1] + mo[3]:
            marks["lips"] = old["lips"]
    for k in ("lips", "chin"):   # where the lips meet and the chin's lowest point (parts of the height)
        v = marks.get(k)
        if isinstance(v, (int, float)) and 0 < float(v) < 1:
            data[k] = round(float(v), 4)
    if marks.get("face"):
        data["face"] = box(marks["face"])
    data["by"] = marks.get("by", "")   # ai | guess | hand
    from PIL import Image
    with Image.open(pic) as im:
        data["size"] = list(im.size)
    data["cutout"] = cutout(pic)
    data["colours"] = colours(pic, data)
    store.write_json(marks_file(name), data)
    return data


def add_picture(name: str, raw: bytes) -> str:
    """A picture uploaded on the Avatars tab: kept as data/avatars/<name>.png (any image type in)."""
    import io

    from PIL import Image
    name = slug(name)
    try:
        im = Image.open(io.BytesIO(raw))
        im.load()
    except Exception as e:   # noqa: BLE001 - not a picture
        raise ValueError(f"Not a picture: {e}") from e
    if max(im.size) > 2400:   # big enough for a video; smaller files render faster
        k = 2400 / max(im.size)
        im = im.resize((round(im.width * k), round(im.height * k)), Image.LANCZOS)
    folder().mkdir(parents=True, exist_ok=True)
    old = pictures().get(name)
    if old and old.suffix.lower() != ".png":   # the same name in another type: replaced
        old.unlink(missing_ok=True)
    im.convert("RGBA").save(folder() / f"{name}.png")
    return name


def delete(name: str) -> bool:
    pic = pictures().get(name)
    if not pic:
        return False
    pic.unlink(missing_ok=True)
    marks_file(name).unlink(missing_ok=True)
    return True


# --- in the videos ---------------------------------------------------------------------------------
def solutions() -> list[dict]:
    """A comparison solution per marked avatar (compare_video.py): Remotion Pro's motion design with it."""
    out = []
    for a in listing():
        if not a["marked"]:
            continue
        out.append({"id": f"company-{a['name']}", "talks": True, "who": a["who"] or None, "group": "Company avatar",
                    "variant": a["label"], "renderer": "html", "style": "presenter", "characters": "cartoon",
                    "set": {"CARTOON_PRESENTER": f"company:{a['name']}"},
                    "about": "The company's own character beside the HTML slides: the mouth follows the narrator you "
                             "pick, it blinks, nods and breathes. Free, no Node.js.",
                    "price": "Free; the pictures are the company's own"})
    return out


def props(name: str, public: Path) -> dict:
    """What Remotion needs for one avatar; its picture is copied next to the voice (Remotion's public
    folder) as avatar_<name>.png and removed after the render."""
    m = load(name)
    pic = pictures().get(name)
    if not m or not pic:
        raise RuntimeError(f"Company avatar {name!r}: no picture or not marked in {folder()} "
                           "(Lesson Studio, tab Avatars)")
    target = public / f"avatar_{name}{pic.suffix.lower()}"
    shutil.copyfile(pic, target)
    return {"src": target.name, "w": m["size"][0], "h": m["size"][1], "mouth": m["mouth"], "eyes": m["eyes"],
            "cutout": m["cutout"], "colours": m["colours"], "label": m.get("label", name),
            **{k: m[k] for k in ("lips", "chin", "face") if m.get(k)}}


# --- on the HTML slides (free, no Node.js): the picture as a puppet for the cartoon runtime --------------
def _data_uri(pic: Path, max_side: int = 900) -> str:
    """The picture inline (the slide is a page of its own): at most max_side px, PNG."""
    import base64
    import io
    im = _rgba(pic, max_side)
    buf = io.BytesIO()
    im.save(buf, format="PNG", optimize=True)
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


def svg(name: str, cx: float, bottom: float, max_h: float, max_w: float, *, cls: str = "toon-presenter",
        who: str = "presenter") -> str:
    """The avatar for the HTML slides as an SVG group the cartoon runtime moves (cartoon.RUNTIME): the
    picture itself, with a mouth that opens with the voice (a soft patch of its own skin colour over the
    closed mouth, the open mouth drawn in a deep shade of its lips), eyelids for the blink (its own skin
    colour, a lash line in its own line colour), a slow nod, breathing and a sway. Silent and with the eyes
    open it is exactly the picture. A picture with a see-through background stands free, one with a
    background is a round portrait."""
    m = load(name)
    pic = pictures().get(name)
    if not m or not pic:
        raise RuntimeError(f"Company avatar {name!r}: no picture or not marked in {folder()} "
                           "(uv run company_avatar.py mark)")
    W, H = m["size"]
    c = m["colours"]
    k = min(max_h / H, max_w / W)
    if not m.get("cutout"):   # a round portrait: the circle around the face
        k = min(max_h, max_w) / min(W, H)
    x0, y0 = cx - W * k / 2, bottom - H * k
    mx, mw, mh = m["mouth"][0] * W, m["mouth"][2] * W, m["mouth"][3] * H
    lips = (m.get("lips") or (m["mouth"][1] + m["mouth"][3] * 0.45)) * H
    u = max(mw, 4) * 0.9 / 26   # the runtime's mouth is 26 units wide
    flat = 0.72   # the open mouth a little wider than tall: talking, not shouting
    patch_ry = max(7.0, mh * 0.75 / (u * flat))
    uid = slug(name)
    lids = "".join(
        f'<g class="t-lid" style="opacity:0"><ellipse cx="{(e[0] + e[2] / 2) * W:.1f}" cy="{(e[1] + e[3] / 2) * H:.1f}" '
        f'rx="{e[2] * W * 0.62:.1f}" ry="{e[3] * H * 0.66:.1f}" fill="url(#lid{i}-{uid})"/>'
        f'<path d="M{(e[0] - e[2] * 0.02) * W:.1f},{(e[1] + e[3] * 0.55) * H:.1f} Q{(e[0] + e[2] / 2) * W:.1f},'
        f'{(e[1] + e[3] * 0.85) * H:.1f} {(e[0] + e[2] * 1.02) * W:.1f},{(e[1] + e[3] * 0.55) * H:.1f}" stroke="{c["line"]}" '
        f'stroke-width="{max(1.5, e[3] * H * 0.13):.1f}" fill="none" stroke-linecap="round"/></g>'
        for i, e in enumerate(m["eyes"]))
    grads = (f'<radialGradient id="skin-{uid}"><stop offset="62%" stop-color="{c["skin"]}"/>'
             f'<stop offset="100%" stop-color="{c["skin"]}" stop-opacity="0"/></radialGradient>'
             + "".join(f'<radialGradient id="lid{i}-{uid}"><stop offset="70%" stop-color="{col}"/>'
                       f'<stop offset="100%" stop-color="{col}" stop-opacity="0"/></radialGradient>'
                       for i, col in enumerate(c["lids"])))
    clip, clip_use, ring = "", "", ""
    if not m.get("cutout"):   # the face in the middle of a circle
        e0, e1 = m["eyes"]
        fx = (e0[0] + e1[0] + e1[2]) / 2 * W
        fy = ((e0[1] + m["mouth"][1] + m["mouth"][3]) / 2) * H
        r = min(W, H) / 2
        clip = f'<clipPath id="round-{uid}"><circle cx="{fx:.1f}" cy="{fy:.1f}" r="{r:.1f}"/></clipPath>'
        clip_use = f' clip-path="url(#round-{uid})"'
        x0, y0 = cx - fx * k, bottom - (fy + r) * k
        ring = (f'<circle cx="{fx:.1f}" cy="{fy:.1f}" r="{r:.1f}" fill="none" stroke="#ffffff" '
                f'stroke-width="{6 / k:.1f}" opacity=".85"/>')
    mouth = (f'<g class="t-mouth" transform="translate({mx + mw / 2:.1f},{lips:.1f}) scale({u:.3f},{u * flat:.3f})">'
             f'<ellipse class="t-patch" cx="0" cy="0" rx="17" ry="{patch_ry:.1f}" fill="url(#skin-{uid})" style="opacity:0"/>'
             f'<ellipse class="t-open" cx="0" cy="2" rx="13" ry="1.5" fill="{c["inside"]}" stroke="{c["lip"]}" stroke-width="1.6"/>'
             f'<ellipse class="t-tongue" cx="0" cy="6" rx="6.5" ry="0" fill="#d9707e"/>'
             f'<path class="t-closed" d="M0,0" stroke="none"/></g>')
    shadow = (f'<ellipse cx="{W / 2:.1f}" cy="{H - 4 / k:.1f}" rx="{W * 0.42:.1f}" ry="{14 / k:.1f}" fill="#0f1b2d" opacity=".10"/>'
              if m.get("cutout") else "")
    return (f'<g class="toon {cls}" data-who="{who}" data-kind="company" transform="translate({x0:.1f},{y0:.1f}) scale({k:.4f})">'
            f'<defs>{grads}{clip}</defs>{shadow}'
            f'<g class="t-sway" style="transform-box:fill-box;transform-origin:50% 100%">'
            f'<g class="t-breathe" style="transform-box:fill-box;transform-origin:50% 100%">'
            f'<g class="t-head" style="transform-box:fill-box;transform-origin:50% 100%"><g{clip_use}>'
            f'<image href="{_data_uri(pic)}" x="0" y="0" width="{W}" height="{H}" preserveAspectRatio="none"/>'
            f'{lids}{mouth}</g>{ring}</g></g></g></g>')


def preview(name: str, out: Path | None = None) -> Path:
    """A still of the avatar three times: silent, talking (mouth open), blinking - to check it at a glance:
    data/output/avatar_<name>.png."""
    out = out or config.OUTPUT_DIR / f"avatar_{name}.png"
    out.parent.mkdir(parents=True, exist_ok=True)
    one = svg(name, 0, 0, 420, 360)
    parts = []
    for i, label in enumerate(("silent", "talking", "blink")):
        parts.append(f'<g transform="translate({220 + i * 420},560)">{one}</g>'
                     f'<text x="{220 + i * 420}" y="600" text-anchor="middle" font-family="sans-serif" font-size="22" '
                     f'fill="#334">{label}</text>')
    html = ('<html><body style="margin:0;background:#f6ead8"><svg width="1280" height="620" viewBox="0 0 1280 620">'
            + "".join(parts) + '</svg><script>const gs=document.querySelectorAll(".toon");'
            'const o=gs[1].querySelector(".t-open");o.setAttribute("ry","15");o.setAttribute("rx","11");'
            'gs[1].querySelector(".t-patch").style.opacity=1;gs[1].querySelector(".t-tongue").setAttribute("ry","3");'
            'gs[1].querySelector(".t-tongue").setAttribute("cy","12");'
            'gs[2].querySelectorAll(".t-lid").forEach(e=>e.style.opacity=1);</script></body></html>')
    page_file = out.with_suffix(".html")
    page_file.write_text(html, encoding="utf-8")
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": 1280, "height": 620})
        pg.goto(page_file.resolve().as_uri())
        pg.wait_for_timeout(300)
        pg.screenshot(path=str(out))
        b.close()
    page_file.unlink(missing_ok=True)
    return out


# --- stand-in characters (to try it before the company's pictures are there) ------------------------
DEMO = {   # name: who, skin, hair, top, hair style
    "demo-anna": ("woman", (241, 194, 160), (92, 54, 38), (40, 98, 160), "bob"),
    "demo-tom": ("man", (205, 150, 112), (40, 32, 30), (52, 120, 96), "short"),
    "demo-maya": ("woman", (150, 102, 74), (26, 20, 20), (178, 70, 90), "bun"),
}


def draw_demo(name: str, out: Path, size: int = 900) -> Path:
    """A simple flat drawn person (head and shoulders, see-through background): a stand-in for a company
    avatar, drawn at twice the size and scaled down for smooth edges."""
    from PIL import Image, ImageDraw
    who, skin, hair, top, style = DEMO[name]
    S = size * 2
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    k = S / 100
    def E(x0, y0, x1, y1, c):
        d.ellipse([x0 * k, y0 * k, x1 * k, y1 * k], fill=c)
    def R(x0, y0, x1, y1, r, c):
        d.rounded_rectangle([x0 * k, y0 * k, x1 * k, y1 * k], radius=r * k, fill=c)
    dark = tuple(int(v * 0.8) for v in skin)
    # shoulders and top
    R(14, 74, 86, 120, 18, top)
    d.polygon([(42 * k, 74 * k), (50 * k, 86 * k), (58 * k, 74 * k)], fill=(250, 250, 250))
    R(44, 60, 56, 78, 4, dark)                                   # neck
    if style == "bun":
        E(40, 4, 60, 22, hair)
    if style in ("bob", "bun"):
        R(25, 16, 75, 66 if style == "bob" else 50, 20, hair)     # hair behind the face
    E(29, 20, 71, 68, skin)                                      # face
    E(26, 40, 32, 50, skin)
    E(68, 40, 74, 50, skin)                                      # ears
    if style == "bob":
        d.chord([27 * k, 14 * k, 73 * k, 52 * k], 180, 360, fill=hair)
        d.polygon([(30 * k, 30 * k), (58 * k, 27 * k), (35 * k, 40 * k)], fill=hair)
    elif style == "short":
        d.chord([28 * k, 14 * k, 72 * k, 46 * k], 180, 360, fill=hair)
        R(28, 26, 34, 40, 3, hair)
        R(66, 26, 72, 40, 3, hair)
    else:
        d.chord([28 * k, 16 * k, 72 * k, 48 * k], 180, 360, fill=hair)
    line = (40, 30, 28)
    for cx in (40.5, 59.5):                                      # eyes, brows
        E(cx - 2.6, 39.5, cx + 2.6, 45.5, (255, 255, 255))
        E(cx - 1.7, 40.6, cx + 1.7, 45.2, line)
        E(cx - 0.4, 41.3, cx + 0.6, 42.4, (255, 255, 255))
        d.line([((cx - 4) * k, 36 * k), ((cx + 3.5) * k, 35.2 * k)], fill=hair, width=int(1.3 * k))
    d.line([(50 * k, 46 * k), (48.6 * k, 52 * k), (50.6 * k, 52.6 * k)], fill=dark, width=int(0.9 * k))   # nose
    E(33, 49, 39, 53, (min(255, skin[0] + 10), max(0, skin[1] - 25), max(0, skin[2] - 20)))
    E(61, 49, 67, 53, (min(255, skin[0] + 10), max(0, skin[1] - 25), max(0, skin[2] - 20)))   # cheeks
    d.arc([44 * k, 52 * k, 56 * k, 59 * k], 20, 160, fill=(150, 60, 60), width=int(1.4 * k))   # closed smile
    im = im.resize((size, size), Image.LANCZOS)
    out.parent.mkdir(parents=True, exist_ok=True)
    im.save(out)
    return out


def demo() -> list[str]:
    """The three stand-in characters in data/avatars, marked automatically."""
    names = []
    for name, (who, *_rest) in DEMO.items():
        pic = draw_demo(name, folder() / f"{name}.png")
        m = guess(pic)
        save(name, {**m, "label": name.split("-", 1)[1].title() + " (demo)", "who": who})
        names.append(name)
    return names


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cmd", choices=["list", "mark", "guess", "demo", "preview"], nargs="?", default="list",
                    help="mark: every picture not marked yet, by Claude (guess: the same); preview: a still of "
                         "each avatar silent, talking and blinking (data/output/avatar_<name>.png)")
    args = ap.parse_args()
    config.setup_logging()
    if args.cmd == "demo":
        print("Stand-in avatars:", ", ".join(demo()), f"in {folder()}")
    if args.cmd == "preview":
        mark_all()   # a new picture is marked first
        for a in listing():
            if a["marked"]:
                print(f"{a['name']}: {preview(a['name'])}")
    if args.cmd in ("mark", "guess"):
        for name in mark_all():
            m = load(name) or {}
            print(f"{name}: marked {'by Claude' if m.get('by') == 'ai' else 'from the pixels (no model reached)'}, "
                  f"{m.get('who') or 'any voice'}")
    rows = listing()
    if not rows:
        print(f"No pictures in {folder()} yet: put anna.png, tom.png ... there (or: uv run company_avatar.py demo)")
        return 0
    for a in rows:
        state = f"marked, {a['who'] or 'any voice'}" if a["marked"] else "not marked yet (tab Avatars)"
        print(f"  {a['name']:<20} {a['label']:<24} {state}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
