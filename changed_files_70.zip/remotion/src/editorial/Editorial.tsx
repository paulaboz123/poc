// "Editorial": the second look of the Remotion lesson (REMOTION_LOOK=editorial). The same storyboard,
// voice and timing as the classic look, shown another way: warm paper with a dotted grid, ink and coral,
// a serif display face. The elements are nodes on a line that is drawn as the voice reaches each one,
// numbers count up, two columns are split by a drawn line, tables become a ledger, quizzes get the
// right answer circled by hand, charts fill as rings (up to three values) or bars. Between scenes a
// coral and an ink band sweep across the page.
// Props are written by remotion_render.py (REMOTION_LOOK=editorial).
import React, {createContext, useContext, useEffect, useLayoutEffect, useRef, useState} from 'react';
import {AbsoluteFill, Audio, Sequence, continueRender, delayRender, interpolate, spring, staticFile, useCurrentFrame,
  useVideoConfig} from 'remotion';
import '@fontsource/fraunces/500.css';
import '@fontsource/fraunces/600.css';
import '@fontsource/fraunces/400-italic.css';
import '@fontsource/space-grotesk/500.css';
import '@fontsource/space-grotesk/700.css';
import '@fontsource/inter/400.css';
import '@fontsource/inter/500.css';
import type {LessonProps, Scene, Unit} from '../Lesson';

export type EditorialProps = LessonProps & {ink?: string; paper?: string; teal?: string};

const SERIF = 'Fraunces, Georgia, "Times New Roman", serif';
const GROTESK = '"Space Grotesk", Inter, "Segoe UI", sans-serif';
const SANS = 'Inter, "Segoe UI", Arial, sans-serif';
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const out3 = (x: number) => 1 - Math.pow(1 - x, 3);

type Pal = {ink: string; paper: string; coral: string; gold: string; teal: string; muted: string; faint: string};
const PalCtx = createContext<Pal>({ink: '#1d1b2f', paper: '#f5efe4', coral: '#ff5a36', gold: '#f2b632', teal: '#1f8a83',
  muted: 'rgba(29,27,47,.62)', faint: 'rgba(29,27,47,.12)'});
// seconds into the scene; a hidden copy laid out "at rest" (every element in) gets a time after the end
const TimeCtx = createContext(0);
const useT = () => useContext(TimeCtx);
const usePal = () => useContext(PalCtx);

const ramp = (t: number, a: number, b: number) => interpolate(t, [a, b], [0, 1], {...clamp, easing: out3});
const on = (w: number[] | null | undefined, t: number) => !!w && t >= w[0] && t <= w[1];
const clean = (s?: string) => (s || '').replace(/\*\*/g, '');
const pop = (t: number, at: number, fps: number, damping = 13) =>
  spring({frame: Math.round((t - at) * fps), fps, config: {damping, stiffness: 120, mass: 0.8}});

// A number in a text that counts up from 0 when it appears ("42%" -> 0% .. 42%; text without a number stays).
const Count: React.FC<{text: string; at: number}> = ({text, at}) => {
  const t = useT();
  const m = text.match(/-?\d[\d,]*(\.\d+)?/);
  if (!m) return <>{text}</>;
  const target = parseFloat(m[0].replace(/,/g, ''));
  const k = ramp(t, at, at + 1.1);
  const dec = m[1] ? m[1].length - 1 : 0;
  const now = (target * k).toLocaleString('en-US', {minimumFractionDigits: dec, maximumFractionDigits: dec});
  return <>{text.slice(0, m.index)}{now}{text.slice((m.index || 0) + m[0].length)}</>;
};

// Words that rise out of a mask one after another.
const Rise: React.FC<{text: string; at: number; size: number; style?: React.CSSProperties; gap?: number}> =
  ({text, at, size, style, gap = 0.06}) => {
  const t = useT();
  return (
    <div style={{fontSize: size, lineHeight: 1.08, ...style}}>
      {clean(text).split(/\s+/).filter(Boolean).map((w, i) => {
        const p = ramp(t, at + i * gap, at + i * gap + 0.6);
        return (
          <span key={i} style={{display: 'inline-block', overflow: 'hidden', verticalAlign: 'top', marginRight: '0.24em',
            paddingBottom: '0.08em'}}>
            <span style={{display: 'inline-block', transform: `translateY(${(1 - p) * 105}%)`}}>{w}</span>
          </span>
        );
      })}
    </div>
  );
};

// A line drawn from 0 to `k` of its length.
const Drawn: React.FC<{d: string; k: number; color: string; width: number; dash?: string}> = ({d, k, color, width, dash}) => (
  <path d={d} fill="none" stroke={color} strokeWidth={width} strokeLinecap="round" pathLength={1}
    strokeDasharray={dash || '1 1'} strokeDashoffset={dash ? 0 : 1 - Math.max(0, Math.min(1, k))}
    opacity={dash ? Math.min(1, k * 3) : 1} />
);

const Head: React.FC<{sc: Scene}> = ({sc}) => {
  const P = usePal();
  const t = useT();
  return (
    <div style={{marginBottom: 46}}>
      {sc.label ? <div style={{fontFamily: GROTESK, fontWeight: 700, fontSize: 22, letterSpacing: '.16em', textTransform: 'uppercase',
        color: P.coral, marginBottom: 14, opacity: ramp(t, 0, 0.4)}}>{sc.label}</div> : null}
      <Rise text={sc.heading} at={0.05} size={sc.heading.length > 48 ? 60 : 72}
        style={{fontFamily: SERIF, fontWeight: 600, color: P.ink, letterSpacing: '-0.015em', maxWidth: 1500}} />
      {sc.subheading ? <div style={{fontFamily: SANS, fontSize: 30, color: P.muted, marginTop: 14, maxWidth: 1400,
        opacity: ramp(t, 0.35, 0.9)}}>{clean(sc.subheading)}</div> : null}
      <svg width={260} height={14} style={{display: 'block', marginTop: 18}}>
        <Drawn d="M4 7 C 70 1, 150 13, 256 6" k={ramp(t, 0.3, 1.1)} color={P.coral} width={6} />
      </svg>
    </div>
  );
};

// The elements as nodes on a line drawn from one to the next as the voice reaches them.
const Flow: React.FC<{sc: Scene; w: number}> = ({sc, w}) => {
  const P = usePal();
  const t = useT();
  const {fps} = useVideoConfig();
  const n = sc.units.length;
  const at = (i: number) => sc.appear[Math.min(i, sc.appear.length - 1)] ?? 0.3 + i * 0.4;
  const anyOn = sc.active.some((x) => on(x, t));
  if (n > 4) {   // many: a timeline down the page, in two columns when it is long
    const cols = n > 6 ? 2 : 1;
    const per = Math.ceil(n / cols);
    const colW = (w - (cols - 1) * 60) / cols;
    return (
      <div style={{display: 'flex', gap: 60}}>
        {Array.from({length: cols}, (_, c) => (
          <div key={c} style={{position: 'relative', width: colW}}>
            <svg width={30} height={per * 104} style={{position: 'absolute', left: 17, top: 30}}>
              {Array.from({length: Math.max(0, Math.min(per, n - c * per) - 1)}, (_, k) => (   // circle to circle, with a gap
                <Drawn key={k} d={`M2 ${k * 104 + 38} L2 ${(k + 1) * 104 - 34}`}
                  k={ramp(t, at(c * per + k + 1) - 0.4, at(c * per + k + 1) + 0.1)} color={P.faint} width={4} />))}
            </svg>
            {sc.units.slice(c * per, c * per + per).map((u, k) => {
              const i = c * per + k;
              const s = pop(t, at(i), fps);
              const hot = on(sc.active[i], t);
              return (
                <div key={i} style={{display: 'flex', gap: 26, alignItems: 'flex-start', height: 104, opacity: s * (anyOn && !hot ? 0.45 : 1),
                  transform: `translateX(${(1 - s) * 40}px)`}}>
                  <div style={{width: 64, height: 64, flexShrink: 0, borderRadius: 32, border: `3px solid ${P.ink}`,
                    background: hot ? P.coral : P.paper, color: hot ? '#fff' : P.ink, display: 'flex', alignItems: 'center',
                    justifyContent: 'center', fontFamily: GROTESK, fontWeight: 700, fontSize: 26, position: 'relative', zIndex: 1}}>
                    {String(i + 1).padStart(2, '0')}</div>
                  <div style={{minWidth: 0}}>
                    <div style={{fontFamily: SERIF, fontWeight: 600, fontSize: 34, color: P.ink, lineHeight: 1.1}}>{clean(u.title)}</div>
                    {u.detail ? <div style={{fontFamily: SANS, fontSize: 23, color: P.muted, marginTop: 6, lineHeight: 1.3}}>{clean(u.detail)}</div> : null}
                  </div>
                </div>
              );
            })}
          </div>
        ))}
      </div>
    );
  }
  const colW = w / Math.max(1, n);
  const node = n > 3 ? 150 : 172;
  const y = node / 2 + 6;
  const xs = sc.units.map((_, i) => colW * i + colW / 2);
  // a line from one node to the next, stopping short of both (a node that is dimmed or still coming in
  // never shows a line through it); it draws itself when the next node appears
  const gap = node / 2 + 16;
  const segs = xs.slice(1).map((x, k) => ({a: xs[k] + gap, b: x - gap, k: ramp(t, at(k + 1) - 0.5, at(k + 1) + 0.1)}));
  return (
    <div style={{position: 'relative', width: w}}>
      <svg width={w} height={node + 12} style={{position: 'absolute', left: 0, top: 0}}>
        {segs.map((sg, k) => sg.b > sg.a ? (
          <React.Fragment key={k}>
            <Drawn d={`M${sg.a} ${y} L${sg.b} ${y}`} k={1} color={P.faint} width={4} dash="2 14" />
            <Drawn d={`M${sg.a} ${y} L${sg.b} ${y}`} k={sg.k} color={P.ink} width={5} />
          </React.Fragment>) : null)}
      </svg>
      <div style={{display: 'flex', position: 'relative'}}>
        {sc.units.map((u, i) => {
          const s = pop(t, at(i), fps, 11);
          const hot = on(sc.active[i], t);
          const pulse = hot ? 0.5 + 0.5 * Math.sin((t - at(i)) * 5) : 0;
          return (
            <div key={i} style={{width: colW, padding: '0 26px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column',
              alignItems: 'center', textAlign: 'center', opacity: Math.min(1, s * 1.4) * (anyOn && !hot ? 0.5 : 1)}}>
              <div style={{position: 'relative', width: node, height: node, margin: '6px 0 34px', transform: `scale(${0.4 + 0.6 * s})`}}>
                {hot ? <div style={{position: 'absolute', inset: -14 - pulse * 10, borderRadius: '50%', border: `3px solid ${P.coral}`,
                  opacity: 0.6 - pulse * 0.4}} /> : null}
                <div style={{position: 'absolute', inset: 0, borderRadius: '50%', border: `4px solid ${P.ink}`,
                  background: hot ? P.coral : i % 2 ? P.paper : '#fffaf2', color: hot ? '#fff' : P.ink,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: `8px 8px 0 ${hot ? P.ink : P.gold}`}}>
                  {u.icon ? <span style={{width: node * 0.42, height: node * 0.42, display: 'inline-flex'}} dangerouslySetInnerHTML={{__html: u.icon}} />
                    : <span style={{fontFamily: GROTESK, fontWeight: 700, fontSize: node * 0.32}}>{String(i + 1).padStart(2, '0')}</span>}
                </div>
              </div>
              {u.value ? <div style={{fontFamily: GROTESK, fontWeight: 700, fontSize: n > 3 ? 70 : 86, color: P.coral, lineHeight: 1, marginBottom: 12}}>
                <Count text={u.value} at={at(i)} /></div> : null}
              <div style={{fontFamily: SERIF, fontWeight: 600, fontSize: n > 3 ? 42 : 52, color: P.ink, lineHeight: 1.1}}>{clean(u.title)}</div>
              {u.detail ? <div style={{fontFamily: SANS, fontSize: n > 3 ? 27 : 31, color: P.muted, marginTop: 14, lineHeight: 1.35}}>
                {clean(u.detail)}</div> : null}
              {u.items ? <div style={{fontFamily: SANS, fontSize: 27, color: P.muted, marginTop: 10, lineHeight: 1.4}}>
                {u.items.map((x, k) => <div key={k}>{clean(x)}</div>)}</div> : null}
            </div>
          );
        })}
      </div>
    </div>
  );
};

// Two (or three) columns split by drawn lines; each item ticks in.
const Columns: React.FC<{sc: Scene; w: number; h: number}> = ({sc, w, h}) => {
  const P = usePal();
  const t = useT();
  const {fps} = useVideoConfig();
  const n = sc.units.length;
  const at = (i: number) => sc.appear[Math.min(i, sc.appear.length - 1)] ?? 0.3 + i * 0.5;
  return (
    <div style={{display: 'flex', position: 'relative', width: w, minHeight: h * 0.7}}>
      {sc.units.map((u, i) => {
        const s = pop(t, at(i), fps);
        const hot = on(sc.active[i], t);
        return (
          <div key={i} style={{flex: 1, padding: '0 90px', position: 'relative', opacity: Math.min(1, s * 1.3),
            transform: `translateY(${(1 - s) * 40}px)`}}>
            {i > 0 ? <svg width={8} height={h * 0.7} style={{position: 'absolute', left: -4, top: 0}}>
              <Drawn d={`M4 4 L4 ${h * 0.7 - 4}`} k={ramp(t, at(i) - 0.3, at(i) + 0.5)} color={P.ink} width={3} /></svg> : null}
            <div style={{display: 'inline-block', fontFamily: GROTESK, fontWeight: 700, fontSize: 20, letterSpacing: '.14em',
              padding: '8px 16px', borderRadius: 999, background: hot ? P.coral : P.ink, color: '#fff', marginBottom: 20}}>
              {String.fromCharCode(65 + i)}</div>
            <div style={{fontFamily: SERIF, fontWeight: 600, fontSize: 56, color: P.ink, lineHeight: 1.05, marginBottom: 30}}>{clean(u.title)}</div>
            {(u.items || (u.detail ? [u.detail] : [])).map((x, k) => {
              const p = ramp(t, at(i) + 0.35 + k * 0.28, at(i) + 0.75 + k * 0.28);
              return (
                <div key={k} style={{display: 'flex', gap: 18, alignItems: 'flex-start', marginBottom: 16, opacity: p,
                  transform: `translateX(${(1 - p) * 24}px)`}}>
                  <svg width={30} height={30} style={{flexShrink: 0, marginTop: 4}}>
                    <Drawn d="M4 16 L12 24 L26 6" k={p} color={i % 2 ? P.teal : P.coral} width={5} />
                  </svg>
                  <div style={{fontFamily: SANS, fontSize: 33, color: P.ink, lineHeight: 1.3}}>{clean(x)}</div>
                </div>
              );
            })}
          </div>
        );
      })}
      {n === 2 ? (
        <div style={{position: 'absolute', left: w / 2 - 44, top: -10, width: 88, height: 88, borderRadius: 44,
          background: P.gold, color: P.ink, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: SERIF,
          fontStyle: 'italic', fontSize: 36, transform: `scale(${pop(t, at(1), fps, 9)})`, boxShadow: `6px 6px 0 ${P.ink}`}}>vs</div>
      ) : null}
    </div>
  );
};

// A table as a ledger: the first column in serif, the rest after a dotted leader.
const Ledger: React.FC<{sc: Scene; w: number}> = ({sc, w}) => {
  const P = usePal();
  const t = useT();
  const at = (i: number) => sc.appear[Math.min(i, sc.appear.length - 1)] ?? 0.3 + i * 0.4;
  return (
    <div style={{width: w}}>
      {sc.units.map((u, i) => {
        const p = ramp(t, at(i), at(i) + 0.6);
        const hot = on(sc.active[i], t);
        return (
          <div key={i} style={{display: 'flex', alignItems: 'baseline', gap: 24, padding: '28px 0 28px 32px', position: 'relative',
            borderBottom: `2px solid ${P.faint}`, opacity: p, transform: `translateY(${(1 - p) * 26}px)`}}>
            <div style={{position: 'absolute', left: 0, top: 18, bottom: 18, width: 8, borderRadius: 4, background: P.coral,
              transform: `scaleY(${hot ? 1 : 0})`, transformOrigin: 'top'}} />
            <div style={{fontFamily: SERIF, fontWeight: 600, fontSize: 46, color: P.ink, whiteSpace: 'nowrap'}}>{clean(u.title)}</div>
            <div style={{flex: 1, borderBottom: `3px dotted ${P.muted}`, transform: 'translateY(-8px)', minWidth: 40}} />
            <div style={{fontFamily: SANS, fontSize: 31, color: hot ? P.ink : P.muted, maxWidth: w * 0.55, textAlign: 'right'}}>
              {clean(u.detail)}</div>
          </div>
        );
      })}
    </div>
  );
};

// Question and answer: lettered options; the right answer circled by hand.
const Quiz: React.FC<{sc: Scene; w: number}> = ({sc, w}) => {
  const P = usePal();
  const t = useT();
  const {fps} = useVideoConfig();
  const answer = sc.kind === 'answer';
  const at = (i: number) => sc.appear[Math.min(i, sc.appear.length - 1)] ?? 0.3 + i * 0.4;
  const cols = sc.units.length > 2 ? 2 : sc.units.length;
  const tileW = (w - (cols - 1) * 40) / cols;
  return (
    <div style={{display: 'flex', flexWrap: 'wrap', gap: 40, width: w}}>
      {sc.units.map((u, i) => {
        const s = pop(t, at(i), fps);
        const right = answer && sc.correct === i + 1;
        const circle = right ? ramp(t, 0.5, 1.5) : 0;
        return (
          <div key={i} style={{position: 'relative', width: tileW, padding: '30px 34px', boxSizing: 'border-box', borderRadius: 22,
            background: right ? '#fffaf2' : 'rgba(255,255,255,.55)', border: `3px solid ${P.ink}`,
            boxShadow: `8px 8px 0 ${right ? P.coral : P.faint}`, display: 'flex', gap: 24, alignItems: 'center',
            opacity: Math.min(1, s * 1.3) * (answer && !right ? 0.45 : 1), transform: `scale(${0.85 + 0.15 * s})`}}>
            <div style={{width: 64, height: 64, borderRadius: 32, flexShrink: 0, background: right ? P.coral : P.ink, color: '#fff',
              display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: GROTESK, fontWeight: 700, fontSize: 30}}>
              {right ? '✓' : String.fromCharCode(65 + i)}</div>
            <div style={{fontFamily: SERIF, fontWeight: 500, fontSize: 36, color: P.ink, lineHeight: 1.15}}>{clean(u.title)}</div>
            {right ? <svg viewBox="0 0 100 40" preserveAspectRatio="none" style={{position: 'absolute', left: -26, top: -22,
              width: 'calc(100% + 52px)', height: 'calc(100% + 44px)', overflow: 'visible'}}>
              <Drawn d="M52 3 C 90 2, 99 14, 97 22 C 94 34, 60 39, 40 38 C 14 37, 2 30, 3 20 C 4 9, 25 3, 58 5" k={circle}
                color={P.coral} width={0.9} /></svg> : null}
          </div>
        );
      })}
    </div>
  );
};

// Charts: up to three values as rings that fill, more as bars; numbers count up.
const Chart: React.FC<{sc: Scene; w: number; h: number}> = ({sc, w, h}) => {
  const P = usePal();
  const t = useT();
  const c = sc.chart!;
  const max = Math.max(...c.values.map((v) => Math.abs(v)), 1);
  const at = (i: number) => sc.appear[Math.min(i, sc.appear.length - 1)] ?? 0.3 + i * 0.4;
  const unit = c.unit ? ` ${c.unit}` : '';
  const pct = (c.unit || '').includes('%');
  const body = c.values.length <= 3 ? (
    <div style={{display: 'flex', justifyContent: 'space-around', alignItems: 'center', width: w}}>
      {c.values.map((v, i) => {
        const k = ramp(t, at(i), at(i) + 1.2);
        const R = 130, L = 2 * Math.PI * R;
        const share = pct ? Math.min(1, Math.abs(v) / 100) : Math.abs(v) / max;
        const hi = c.highlight === i + 1;
        return (
          <div key={i} style={{display: 'flex', flexDirection: 'column', alignItems: 'center', opacity: ramp(t, at(i) - 0.2, at(i) + 0.3)}}>
            <div style={{position: 'relative', width: 2 * R + 40, height: 2 * R + 40}}>
              <svg width={2 * R + 40} height={2 * R + 40} style={{transform: 'rotate(-90deg)'}}>
                <circle cx={R + 20} cy={R + 20} r={R} fill="none" stroke={P.faint} strokeWidth={26} />
                <circle cx={R + 20} cy={R + 20} r={R} fill="none" stroke={hi || c.highlight === undefined ? P.coral : P.ink}
                  strokeWidth={26} strokeLinecap="round" strokeDasharray={`${L * share * k} ${L}`} />
              </svg>
              <div style={{position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: GROTESK, fontWeight: 700, fontSize: 62, color: P.ink}}><Count text={`${v}${unit}`} at={at(i)} /></div>
            </div>
            <div style={{fontFamily: SERIF, fontWeight: 600, fontSize: 34, color: P.ink, marginTop: 18, textAlign: 'center', maxWidth: 420}}>
              {clean(c.labels[i])}</div>
          </div>
        );
      })}
    </div>
  ) : (
    <div style={{width: w}}>
      {c.values.map((v, i) => {
        const k = ramp(t, at(i), at(i) + 1.0);
        const hi = c.highlight === i + 1;
        const rowH = Math.min(84, (h * 0.75) / c.values.length);
        return (
          <div key={i} style={{display: 'flex', alignItems: 'center', gap: 24, height: rowH, opacity: ramp(t, at(i) - 0.2, at(i) + 0.3)}}>
            <div style={{width: 360, fontFamily: SERIF, fontWeight: 600, fontSize: Math.min(34, rowH * 0.45), color: P.ink, textAlign: 'right'}}>
              {clean(c.labels[i])}</div>
            <div style={{flex: 1, height: rowH * 0.52, position: 'relative'}}>
              <div style={{position: 'absolute', left: 0, top: 0, bottom: 0, width: `${(Math.abs(v) / max) * 100 * k}%`, borderRadius: 8,
                background: hi ? P.coral : P.ink, boxShadow: `5px 5px 0 ${hi ? P.ink : P.gold}`}} />
            </div>
            <div style={{width: 170, fontFamily: GROTESK, fontWeight: 700, fontSize: Math.min(40, rowH * 0.5), color: hi ? P.coral : P.ink}}>
              <Count text={`${v}${unit}`} at={at(i)} /></div>
          </div>
        );
      })}
    </div>
  );
  const last = at(c.values.length - 1) + 1.0;
  return (
    <div style={{width: w}}>
      {body}
      {c.takeaway ? <div style={{fontFamily: SERIF, fontStyle: 'italic', fontSize: 38, color: P.ink, marginTop: 40, opacity: ramp(t, last, last + 0.6)}}>
        {clean(c.takeaway)}
        <svg width={420} height={14} style={{display: 'block', marginTop: 8}}>
          <Drawn d="M4 8 C 120 2, 260 12, 416 5" k={ramp(t, last + 0.2, last + 1.0)} color={P.coral} width={5} /></svg>
      </div> : null}
    </div>
  );
};

const Body: React.FC<{sc: Scene; w: number; h: number}> = ({sc, w, h}) => {
  if (sc.chart) return <Chart sc={sc} w={w} h={h} />;
  if (sc.kind === 'question' || sc.kind === 'answer') return <Quiz sc={sc} w={w} />;
  if (sc.kind === 'comparison') return <Columns sc={sc} w={w} h={h} />;
  if (sc.kind === 'table') return <Ledger sc={sc} w={w} />;
  return <Flow sc={sc} w={w} />;
};

// The scene's content always inside its box: a hidden copy at rest is measured and the content scaled
// down when it needs more room (many or long elements).
const Fit: React.FC<{sc: Scene; w: number; h: number; t: number}> = ({sc, w, h, t}) => {
  const probe = useRef<HTMLDivElement>(null);
  const [k, setK] = useState(1);
  const [tall, setTall] = useState(h);
  useLayoutEffect(() => {
    const el = probe.current;
    if (!el) return;
    const need = Math.min(1, h / Math.max(1, el.scrollHeight), w / Math.max(1, el.scrollWidth));
    const next = need < 0.995 ? Math.max(0.55, need * 0.97) : 1;
    if (Math.abs(next - k) > 0.004) setK(next);
    if (Math.abs(el.scrollHeight - tall) > 1) setTall(el.scrollHeight);
  });
  const top = Math.max(0, (h - tall * k) / 2 - 20);   // centred in the space under the heading
  return (
    <>
      <div ref={probe} aria-hidden style={{position: 'absolute', left: 0, top: 0, width: w, visibility: 'hidden'}}>
        <TimeCtx.Provider value={sc.duration_s + 20}><Body sc={sc} w={w} h={h} /></TimeCtx.Provider>
      </div>
      <div style={{position: 'absolute', left: 0, top, width: w / k, transform: `scale(${k})`, transformOrigin: '0 0'}}>
        <TimeCtx.Provider value={t}><Body sc={sc} w={w / k} h={h / k} /></TimeCtx.Provider>
      </div>
    </>
  );
};

// The title scene: a big serif title, what the lesson covers as a numbered list, a drawn composition.
const Title: React.FC<{sc: Scene}> = ({sc}) => {
  const P = usePal();
  const t = useT();
  const {fps} = useVideoConfig();
  const spin = t * 8;
  return (
    <AbsoluteFill>
      <svg width={1920} height={1080} style={{position: 'absolute', inset: 0}}>
        <circle cx={1560} cy={470} r={300 * pop(t, 0.1, fps, 14)} fill={P.coral} />
        <circle cx={1560} cy={470} r={380} fill="none" stroke={P.ink} strokeWidth={3} strokeDasharray="4 16"
          transform={`rotate(${spin} 1560 470)`} opacity={ramp(t, 0.4, 1.0)} />
        <circle cx={1560 + 380 * Math.cos((spin + 30) * Math.PI / 180)} cy={470 + 380 * Math.sin((spin + 30) * Math.PI / 180)} r={22}
          fill={P.gold} stroke={P.ink} strokeWidth={3} opacity={ramp(t, 0.6, 1.0)} />
        <Drawn d="M1180 860 C 1320 700, 1500 960, 1820 760" k={ramp(t, 0.5, 1.8)} color={P.ink} width={5} />
        <rect x={1430} y={340} width={260} height={260} rx={30} fill="none" stroke="#fff" strokeWidth={6}
          transform={`rotate(${12 + spin * 0.5} 1560 470)`} opacity={ramp(t, 0.7, 1.2)} />
      </svg>
      <div style={{position: 'absolute', left: 150, top: 230, width: 1080}}>
        {sc.label ? <div style={{fontFamily: GROTESK, fontWeight: 700, fontSize: 24, letterSpacing: '.18em', textTransform: 'uppercase',
          color: P.coral, marginBottom: 26, opacity: ramp(t, 0, 0.5)}}>{sc.label}</div> : null}
        <Rise text={sc.heading} at={0.15} size={sc.heading.length > 40 ? 92 : 116}
          style={{fontFamily: SERIF, fontWeight: 600, color: P.ink, letterSpacing: '-0.02em'}} />
        {sc.subheading ? <div style={{fontFamily: SANS, fontSize: 34, color: P.muted, marginTop: 26, opacity: ramp(t, 0.6, 1.2)}}>
          {clean(sc.subheading)}</div> : null}
        <div style={{marginTop: 54}}>
          {sc.units.map((u, i) => {
            const p = ramp(t, sc.appear[i] ?? 0.8 + i * 0.3, (sc.appear[i] ?? 0.8 + i * 0.3) + 0.5);
            return (
              <div key={i} style={{display: 'flex', gap: 22, alignItems: 'baseline', fontSize: 34, marginBottom: 12, opacity: p,
                transform: `translateX(${(1 - p) * 30}px)`}}>
                <span style={{fontFamily: GROTESK, fontWeight: 700, color: P.coral, fontSize: 24}}>{String(i + 1).padStart(2, '0')}</span>
                <span style={{fontFamily: SANS, fontWeight: 500, color: P.ink}}>{clean(u.title)}</span>
              </div>
            );
          })}
        </div>
      </div>
    </AbsoluteFill>
  );
};

const SceneView: React.FC<{sc: Scene; i: number; total: number}> = ({sc, i, total}) => {
  const P = usePal();
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const big = String(i + 1).padStart(2, '0');
  return (
    <TimeCtx.Provider value={t}>
      <AbsoluteFill>
        <div style={{position: 'absolute', right: 60, bottom: -120, fontFamily: SERIF, fontWeight: 600, fontSize: 380, lineHeight: 1,
          color: 'transparent', WebkitTextStroke: `3px ${P.faint}`, opacity: ramp(t, 0.1, 0.8),
          transform: `translateY(${(1 - ramp(t, 0, 0.9)) * 80}px)`}}>{big}</div>
        {sc.kind === 'title' ? <Title sc={sc} /> : (
          <div style={{position: 'absolute', left: 150, top: 120, width: 1640, height: 860}}>
            <Head sc={sc} />
            <div style={{position: 'absolute', left: 0, right: 0, top: sc.subheading ? 270 : 220, bottom: 0}}>
              <Fit sc={sc} w={1640} h={sc.subheading ? 590 : 640} t={t} />
            </div>
          </div>
        )}
      </AbsoluteFill>
    </TimeCtx.Provider>
  );
};

// Paper with a dotted grid, the lesson's title, the page number and a progress rule.
const Page: React.FC<{title: string; scenes: Scene[]; total: number}> = ({title, scenes, total}) => {
  const P = usePal();
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const i = Math.max(0, scenes.findIndex((s) => t >= s.start_s && t < s.start_s + s.duration_s));
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <div style={{position: 'absolute', left: 150, top: 54, fontFamily: GROTESK, fontWeight: 500, fontSize: 20, letterSpacing: '.16em',
        textTransform: 'uppercase', color: P.muted}}>{title}</div>
      <div style={{position: 'absolute', right: 80, top: 50, fontFamily: GROTESK, fontWeight: 700, fontSize: 22, color: P.ink,
        fontVariantNumeric: 'tabular-nums'}}>{String(i + 1).padStart(2, '0')}<span style={{color: P.muted}}> — {String(scenes.length).padStart(2, '0')}</span></div>
      <div style={{position: 'absolute', left: 64, top: 54, bottom: 54, width: 3, background: P.faint}} />
      {scenes.map((s, k) => (
        <div key={k} style={{position: 'absolute', left: 57, top: 54 + (k / Math.max(1, scenes.length - 1)) * (1080 - 108) - 8,
          width: 17, height: 17, borderRadius: 9, border: `3px solid ${P.ink}`, background: k <= i ? P.coral : P.paper}} />
      ))}
      <div style={{position: 'absolute', left: 0, bottom: 0, height: 8, width: 1920 * Math.min(1, t / total), background: P.coral}} />
    </AbsoluteFill>
  );
};

// Between two scenes a coral and an ink band sweep across the page (covering the cut).
const Wipes: React.FC<{scenes: Scene[]}> = ({scenes}) => {
  const P = usePal();
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const cut = scenes.slice(1).map((s) => s.start_s).find((c) => t > c - 0.45 && t < c + 0.45);
  if (cut === undefined) return null;
  const band = (delay: number, color: string) => {
    const k = interpolate(t, [cut - 0.45 + delay, cut + 0.4 + delay], [0, 1], clamp);
    const x = interpolate(k, [0, 1], [-2400, 2400], {easing: (v) => (v < 0.5 ? 4 * v * v * v : 1 - Math.pow(-2 * v + 2, 3) / 2)});
    return <div style={{position: 'absolute', top: -200, bottom: -200, left: x, width: 2200, background: color, transform: 'skewX(-14deg)'}} />;
  };
  return <AbsoluteFill style={{overflow: 'hidden'}}>{band(0, P.coral)}{band(0.06, P.ink)}</AbsoluteFill>;
};

const useFonts = () => {
  const [handle] = useState(() => delayRender('Loading fonts'));
  useEffect(() => {
    Promise.all([
      document.fonts.load('600 60px Fraunces'), document.fonts.load('italic 400 40px Fraunces'),
      document.fonts.load('700 30px "Space Grotesk"'), document.fonts.load('500 30px "Space Grotesk"'),
      document.fonts.load('400 30px Inter'), document.fonts.load('500 30px Inter'),
    ]).then(() => continueRender(handle)).catch(() => continueRender(handle));
  }, [handle]);
};

export const Editorial: React.FC<EditorialProps> = ({scenes, audio, title, fps, width, total_s, accent, accent2, ink, paper, teal}) => {
  useFonts();
  const pal: Pal = {ink: ink || '#1d1b2f', paper: paper || '#f5efe4', coral: accent || '#ff5a36', gold: accent2 || '#f2b632',
    teal: teal || '#1f8a83', muted: 'rgba(29,27,47,.62)', faint: 'rgba(29,27,47,.13)'};
  const k = width / 1920;
  return (
    <PalCtx.Provider value={pal}>
      <AbsoluteFill style={{background: pal.paper, fontFamily: SANS}}>
        {audio ? <Audio src={staticFile(audio)} /> : null}
        <AbsoluteFill style={{width: 1920, height: 1080, transform: `scale(${k})`, transformOrigin: '0 0'}}>
          <AbsoluteFill style={{backgroundImage: `radial-gradient(${pal.faint} 2px, transparent 2.5px)`, backgroundSize: '36px 36px',
            backgroundPosition: '18px 18px'}} />
          {scenes.map((sc, i) => (
            <Sequence key={i} from={Math.round(sc.start_s * fps)} durationInFrames={Math.max(1, Math.round(sc.duration_s * fps))} layout="none">
              <SceneView sc={sc} i={i} total={scenes.length} />
            </Sequence>
          ))}
          <Page title={title} scenes={scenes} total={total_s} />
          <Wipes scenes={scenes} />
        </AbsoluteFill>
      </AbsoluteFill>
    </PalCtx.Provider>
  );
};
