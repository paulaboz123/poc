# Video lesson PoC

A person writes what they want to learn (topic, length, level, format) and gets a lesson made
**only from the training material**: a **document**, a **slide deck**, an **animated narrated
video**, a **video with two talking characters**, a **cartoon presenter**, or **audio**. Every
result is checked (truth, safety, layout, sound) and gets a verdict (OK / CHECK / FAIL), a
cost and a run card (what it was made from and with).

## Quick start

| What | Command |
|---|---|
| **Lesson Studio** (chat page: ask a question or for a document / slides / video / audio; prices and results with links; a password for sharing) | `uv run app.py` → opens http://localhost:8765 |
| **Does everything work here?** (one small result of every kind, with the real model) | `uv run smoke.py` (~15 min, ~$1) or `uv run smoke.py --quick` (~4 min) → `data/output/smoke_report.md` |
| One lesson from the terminal | `uv run ask.py "A 2-minute video where two characters talk about the daily scrum"` |
| **The same request with every tool, side by side** (slides and animation per tool, audio per narrator, cost of each) | `uv run benchmark.py "a 1-minute video presentation on data connections"` → `comparison.html` |
| What results cost, side by side | `uv run compare.py` |
| What each budget level gives and costs | `uv run tiers.py` |
| **What is spent and left** (today's spend, ElevenLabs characters left, Remotion); also printed after every run and shown at the top of Lesson Studio | `uv run usage.py` |
| **Pro look in Remotion**: motion-design scenes (glass cards, counters, growing charts, push transitions) and 3D presenters that talk with the voice, wave, point at the screen | `RENDERER=remotion-pro` in `.env` (once: `cd remotion`, `npm.cmd install`), or `benchmark.py --renderers "html,remotion-pro"` |
| **Real-looking presenter** saying our narration (ElevenLabs lip sync: Creatify Aurora) over a video you already have | `uv run ai_clips.py voice "data\output\<video folder>"`, make the clip in ElevenLabs, then `uv run ai_clips.py presenter ... --clip x.mp4` |
| **Real-looking clips** (people, places, nature: Google Veo made in ElevenLabs Image & Video) as intro, cutaways and outro of a video you already have | `uv run ai_clips.py prompts "data\output\<video folder>"`, make the clips in the tool, then `uv run ai_clips.py add ...` |
| Setup check | `uv run doctor.py` |

| Setting | Models | Needs | Quality / speed |
|---|---|---|---|
| **Gateway** (`.env.bifrost.example`) | Claude Sonnet on Amazon Bedrock (EU) via Bifrost; search stays local | URL + key + model id from the platform team | good / fast; ~$0.10-0.20 per short video |
| **Local** (`.env.local.example`) | Llama 3.1 (Meta), Gemma 3 (Google), nomic-embed-text, all in Ollama | nothing | OK / slow (minutes per lesson) |

Cost per video: the material sent to the model grows with the video length
(`MIN_MATERIAL_WORDS`, `MATERIAL_WORDS_PER_MINUTE`), and with `PROMPT_CACHE=yes` (default) the
self-review re-reads it from the cache at ~10% of the price. The run card shows the real cost.

Voice (Kokoro) and video (ffmpeg, browser engine) run on the laptop. No models of Chinese origin.

```
data/input  (videos, transcripts, documents, quizzes, images ...)
   │  inventory.py / documents.py / pipeline.py   read, clean, index (noise and German left out)
   ▼
ask.py / app.py "request"
   1 understand   format, topic, length, level, style (refuses off-rule requests)
   2 material     the most relevant excerpts of the whole knowledge base
   3 write        Claude writes the document / storyboard / conversation from them, then reviews it
   4 make         slides + motion + characters + voice → video, or the document / deck / audio
   5 check        numbers vs sources, AI review, safety, personal data, layout, sound → verdict
   6 run card     input, solution, cost, time
```

---

## The product and the experiments

What a department would get (cost-first: free voice Kokoro, our HTML slides) is a small part of this
repo; the rest compared tools for the PoC. Moving to the cloud, take the product files; leave the rest.

| Part | Files |
|---|---|
| **Product: the page and requests** | `app.py`, `app_page.html`, `chats.py`, `ask.py` |
| **Product: preparing the material** | `inventory.py`, `ingest.py`, `transcribe.py`, `slides.py`, `describe_slides.py`, `documents.py`, `catalog.py`, `chunking.py`, `index.py`, `glossary.py`, `topics.py`, `pipeline.py` |
| **Product: answers and lessons** | `retrieval.py`, `answer.py`, `lesson.py`, `storyboard.py`, `document.py`, `deck.py`, `course.py`, `dialogue.py` |
| **Product: the video** | `make_video.py`, `slides_html.py`, `animation.py`, `render.py`, `illustrations.py`, `images.py`, `cartoon.py`, `tts.py`, `media.py` |
| **Product: checks, costs, settings** | `quality.py`, `facts.py`, `safety.py`, `runcard.py`, `compare.py` (the results list), `llm.py`, `usage.py`, `costs.py`, `config.py`, `store.py`, `doctor.py`, `smoke.py`, `qa_eval.py`, `evaluate.py`, `calibrate.py` |
| Experiments: other video tools | `remotion_render.py` + `remotion/`, `react_scenes.py`, `manim_render.py`, `deck_js.py` + `revideo/` + `motion-canvas/`, `hyperframes_render.py`, `deck_video.py` |
| Company avatars (talking presenters from the company's pictures) | `company_avatar.py`, `remotion/src/pro/CompanyAvatar.tsx`, tab Avatars |
| Experiments: generated clips (scenery, no presenters) | `ai_clips.py`, `eleven_video.py` |
| Experiments: comparisons | `compare_video.py`, `benchmark.py`, `tiers.py`, `ablation.py` |

The product needs no Node.js: only Python, a browser (Playwright's Chromium) and ffmpeg. One link to keep in
mind: Lesson Studio takes its list of video tools from `compare_video.py` (keep that file, or give the page
only the tools in use).

## Part A: run everything locally (start here)

### A1. One-time setup

1. **Copy the files** from the zip into your project folder (overwrite everything). Keep your
   `data/`, `models/`, `.env`, `pyproject.toml` and `uv.lock`.
2. **Programs** (once): `ffmpeg` and Tesseract OCR on PATH (or their paths in `.env`), Ollama only
   for the local route. Check with `ffmpeg -version`.
3. **Python packages** (one command; already installed ones are skipped):
   ```
   uv add httpx python-dotenv python-docx python-pptx numpy pillow pydantic openpyxl pypdf kokoro-onnx playwright
   uv add --dev pytest ruff
   ```
   Optional: `uv add faster-whisper` (transcripts for recordings without one),
   `uv add pyttsx3` (the Windows voice as a fallback).
4. **Browser for the designer slides** (once): `uv run playwright install chromium`.
   If that download is blocked, the installed Microsoft Edge is used automatically.
5. **Settings:** copy `.env.bifrost.example` (Claude through the gateway) or `.env.local.example`
   (local models), rename the copy to `.env`, fill in the key. Keep an existing `.env`, and add the
   new lines from the example (`STYLE`, `CHARACTERS`, `HOST_VOICE`, `EXPERT_VOICE`, `GSAP`).
6. **Voice** (two files, ~120 MB, once):
   ```
   uv run tts.py --download
   uv run tts.py "Joining data means combining two tables on a shared key."
   ```
   Listen to `data/output/tts_test_kokoro.wav`. If GitHub is blocked, download `kokoro-v1.0.int8.onnx` and
   `voices-v1.0.bin` in the browser from
   https://github.com/thewh1teagle/kokoro-onnx/releases/tag/model-files-v1.0 into `models/`.
7. **Check:**
   ```
   uv run doctor.py
   uv run python -m pytest tests -q
   ```
   `doctor.py`: every line `[OK]` (`[WARN]` for optional parts is fine). The tests run offline
   and free with stand-in models (a few minutes); expect all passed. Run them after every code change.

### A2. Prepare the recordings

7. Put the files in `data/input/` (sub-folders are fine): the slide videos (`.mp4`), their
   transcripts (`.vtt`/`.docx`, same name as the video), and `description.xlsx` (columns `id`, `name`, `description`).
8. ```
   uv run inventory.py
   ```
   A table appears. Every video should have an id, a transcript and `OK`. Open
   `data/manifest.csv` and set `include` to `yes` for the videos to use (screen demos without slides: `no`).
9. **Slide area**, for one video (the `video_id` is in the manifest, e.g. `13-introduction-to-joining-data-d25c`):
   ```
   uv run pipeline.py --mode easy
   uv run slides.py --video <video_id> --preview
   ```
   Open `data/processed/<video_id>/crop_preview.jpg`. The red box is what is read as the slide.
   - presenter or Teams panel **next to** the slide → set `SLIDE_CROP` in `.env`, then
     `uv run pipeline.py --mode easy --force`
   - presenter camera **on top of** the slide → set `SLIDE_MASK` (blue box); it is hidden in the video
   - look at `data/processed/<video_id>/slides/`: each slide should appear once, complete
10. **Search check:**
    ```
    uv run index.py search "how to join two tables" -k 5
    ```
    The right recording should be on top.

### A3. Make lessons and videos

11. **Plan a video first** (cheap check), then make it:
    ```
    uv run make_video.py --recording 13 --minutes 2 --plan-only
    ```
    Read `data/output/<folder>/script.md`. If it's fine:
    ```
    uv run make_video.py --rerender "data/output/<folder>"
    ```
    Watch `lesson_video.mp4`, listen to `lesson_audio.mp3`.
12. **Topic across all recordings, in one go:**
    ```
    uv run make_video.py "how to join two tables" --minutes 2
    ```
13. **Text lesson:**
    ```
    uv run lesson.py "how to join two tables" --minutes 5 --level beginner
    ```

### Lesson Studio: the page to show others

`uv run app.py` opens http://localhost:8765 (stop with Ctrl+C).

| Tab | What it does |
|---|---|
| **Ask** | one box, like a chat; under it you may pick the output, the tool (any of the comparison's), the narrator and the level (default: from the words and `.env`). A question gets a short answer with its sources (recording, time, exact words); a request for a document, slides, a video, two people talking or audio gets that, shown in the page (player, document, slides) with its links, verdict, cost and time. Every chat is kept (`data/output/chats`): the list on the left reopens it, also after a restart; each browser has its own chats |
| **How it works** | for business: the flow in plain blocks (once per recording: material → written down → knowledge base; every request: ask → find → write (Claude, the only paid step) → check → make → deliver) |
| **Comparison** | the videos of `compare_video.py` (every video ever made for the same content, also from older runs; only what was made is offered), at the bottom which tool to choose and why (verdict, best for, strengths, weaknesses, licence, measured time to make 1 min): one card per tool, a narrator, a presenter and a look to pick under each video (every tool in two looks, the same content, voice and timing: e.g. Remotion Classic / Editorial, HTML Light / Midnight, Remotion Pro Night sky / Aurora; costs: tab Prices & results) |
| **Prices & results** | what one video costs by length (`length_costs.py`: 3, 5, 10, 15 min measured, the progression up to 60 min, the limits); what the whole solution costs a month, in its own AWS account (not joined to the agent platform): minimum (production only, Kokoro, HTML slides) and optimal (production + test, AWS support, ElevenLabs Pro): the cloud, Claude (grows with use, `COST_MARGIN_PCT` 10% on top), voice, video tool; the cloud part by part; the subscriptions (plans, price a month, limits); spent today and in total; every result with its links |

**Sharing it with someone without a copy of the project** (e.g. for testing): ask the data owner first,
then put `APP_PASSWORD=<something long>` in `.env`, run `uv run app.py` (restart it after changing `.env`; its first line must say "password on"; without a password a shared link is refused), and in VS Code: Ports >
Forward a Port > `8765`, right-click > Port Visibility > Public. Send the address and the password.
It works while this laptop is on and app.py runs; spending stays under `DAILY_BUDGET_USD`.
Check a link with `<address>/status` (no sign-in): it says whether the request reached this laptop. Every
request through the link is written to `data/output/app_access.log` (not to the terminal: on Windows a
click in the terminal would pause the app; app.py also turns that "QuickEdit" pause off for its window).

**What a video costs by length** (the client's free setup: Kokoro + HTML slides):
`uv run length_costs.py "<a topic the recordings cover>"` makes 3, 5, 10 and 15-minute videos (Claude: ~$1-2 in total),
measures each step and writes `data/output/length_costs/length_costs.md` + `.xlsx`; shown in Prices & results.
A length already made is skipped (run it again after an error); `--report` only redoes the tables.
Built on an existing video instead: `uv run length_costs.py --from 1m` takes the newest 1-minute video and makes
it 5 minutes long, that one 10, that one 15 (`extend.py`): each keeps the shorter video word for word and adds
chapters after it, then one quiz and summary of the whole; when the video's topic runs out in the recordings,
the closest related topics are added (named in the table) so the length is reached. One step alone:
`uv run extend.py <folder or 1m> --minutes 5`.

**The company's avatars talking on the HTML slides (free, no Node.js)**: put the 3 pictures in `data/avatars`
(e.g. `anna.png`), then `uv run company_avatar.py mark` (Claude finds the eyes and the mouth) and
`uv run company_avatar.py preview` (`data/output/avatar_<name>.png`: silent, talking, blinking). Videos:
`uv run compare_video.py --only company-anna` (tab Comparison), or `CARTOON_PRESENTER=company:anna` in `.env`
for every "Slides with presenter" video. The picture stays as it is; its mouth opens with the voice over a patch
of its own skin colour, it blinks with lids of its own skin, nods and breathes.

**The company look** (`brand.py`): put the logo (`logo.png`, best with a see-through background), the PowerPoint
template (`.pptx`/`.potx`), optionally the font files and `brand.json` in `data/brand/`, restart. The HTML slides take
its colours, font and logo; presentations are made in the template (editable text, `slides.pptx`; the pictures in
`slides_pictures.pptx`); every other video tool gets the colours where it takes them and the logo in the corner.
`uv run brand.py --preview` shows what was found and a sample slide. `BRAND=off` in `.env` switches it off.

### Output types: the request decides

`ask.py` reads what the person wants and makes one of these:

| Ask for... | You get | Made by |
|---|---|---|
| just a question (what is, how do I, why ...) | a short answer, the source of every sentence (recording, time, exact words): `answer.md` | `answer.py` |
| a document, lecture notes, an explanation to read | `lesson.html` (open in a browser, Ctrl+P = PDF) + `lesson.md`: short answer first, sections with **bold** key terms, bullets, tables, examples, "Remember" boxes, takeaways, summary, glossary, self-check questions | `lesson.py` |
| a simple presentation, slides to present myself | `slides.pdf`, `slides.pptx` (with `uv add python-pptx`), `notes.md` speaker notes | `deck.py` |
| an animated presentation with a narrator, a video | `lesson_video.mp4` + `lesson_audio.mp3` (style clean / illustrated / presenter) | `make_video.py`, 4+ min: `course.py` |
| two people talking, a conversation, an interview | the same video, but a host asks and an expert explains, two voices, two people beside the slide | `make_video.py --style dialogue` |
| something to listen to | `lesson_audio.mp3` | as video |

```
uv run ask.py "Napisz mi dokument o rolach w Scrumie, z tabelą i podsumowaniem"
uv run ask.py "A simple 6-slide presentation on sprint planning that I can present myself"
uv run ask.py "A 3-minute video where two people talk about the daily scrum"
```
Voices of the two people: `HOST_VOICE`, `EXPERT_VOICE` in `.env` (Kokoro voices, `uv run tts.py --voices`).

Characters (presenter and dialogue styles): `CHARACTERS=cartoon` (default) = a bear (expert / presenter)
and a fox (host) whose mouths move with their own voice, who blink, nod and point at the screen;
`CHARACTERS=people` = the drawn people. A request that asks for a cartoon / fairy tale / animals gets
the cartoon presenter. Per video: `--characters cartoon|people`. The characters are drawn in code
(`cartoon.py`), so they look the same in every scene and nothing random can appear.

Every result has a **run card** (`run_card.md` / `run_card.json` in its folder): the request, which
sources were used, which models and tools made it (writing, review, search, voice, slides, characters,
pictures), the cost of every model call by step and model, the time, and the quality verdict.
To compare two setups (free vs paid, Sonnet vs Opus, two voices): run the same request twice with one
setting changed in `.env`, then `uv run compare.py --topic "<topic>"`.

### Answers to questions, and how good they are (answer.py, qa_eval.py)

A question in, a text answer out, from the knowledge base only, with the source of every sentence:
```
uv run answer.py "What is coffee?"
uv run answer.py "Who orders the Product Backlog?" --length medium
```
1. **Find** (`retrieval.py`): a meaning search (embeddings) and a word search (BM25: exact names,
   terms, acronyms, numbers), fused and weighted by `SOURCE_PRIORITY`; then the model reads the ~30
   best candidates and keeps those that really answer the question (`RETRIEVAL=hybrid+rerank`).
2. **Write**: Claude answers from those excerpts only, most important first, in its own words;
   every sentence cites its excerpts and gives an evidence quote. Not covered = "not covered", no answer.
3. **Check in code**: real sources, evidence quote found in the source, numbers in the sources, share
   copied word for word (above `COPY_LIMIT` rewritten once).
4. **answer.md**: the answer with [1] [2], and per source the recording or document, the place
   (`03:10-04:05 · slide "Three roles"`, page, section) and the evidence quote. `answer.json` has everything.

**Measuring quality** on a test set (`eval/qa_set.csv`, edit in Excel; `eval/qa_set_example.csv` shows the columns):
```
uv run qa_eval.py --draft 20     # a first set from your material: specific, general and out-of-scope questions
uv run qa_eval.py                # answer and score every question -> data/output/<time>-qa-eval/qa_report.html
uv run qa_eval.py --compare      # the same set with meaning / hybrid / hybrid+rerank: before and after
uv run qa_eval.py --set "Video_Accuracy_Test_Plan.xlsx"   # the client's test plan as it is
```
The client's plan is read as it is (Test ID, Category, Prompt, Source Video (ID+name), Expected fact;
rows with the same Test ID = one question with several videos and facts; "4 - Tools @SE" = catalog
number 4 or that name). The results also go into a copy of the plan, `<name>_results.xlsx`: the
answer, its sources (video · time), per row whether the expected fact is in the answer and the
expected video was found, claims not in the sources, PASS / CHECK and why.
| Area | Metrics |
|---|---|
| Finding the information | retrieval hit rate, MRR, answer cites the expected source |
| No hallucination | faithfulness (claim by claim, judge model), hallucination rate, evidence found word for word, numbers not in the sources, invented or missing sources (code) |
| Correct and complete | key-fact recall, correctness vs expected answer, relevance, completeness, clarity (judge model, 1-5) |
| Knows what it doesn't know | declines out-of-scope questions, false refusals |
| Own words | share copied word for word |
| Cost and time | per answer |

The report explains how each metric is measured and why, lists the failed questions with the
reason (e.g. the unsupported claim), every answer with its sources, and the previous run to compare.
Set `JUDGE_MODEL` to another model than the writer (e.g. Opus when Sonnet writes) so answers are
not graded by the model that wrote them; `RERANK_MODEL` can be Haiku (cheap).

### Comparing tools: one request, every tool at its best (benchmark.py)

One request, one script (written once, so the content is the same everywhere), every narrator and
every video tool, as slides and as an animation:
```
uv run benchmark.py "a 1-minute video presentation on data connections" --minutes 1
uv run benchmark.py --from "data/output/<an existing video folder>"            # reuse a script
uv run benchmark.py --report "data/output/<comparison folder>"                 # rebuild the page
```
Default: narrators Kokoro (local, free) and ElevenLabs; tools "local, open source" (designer slides
with motion, drawn characters) and Remotion Pro (motion design, 3D presenters); types slides and
animation = 8 videos. Open `comparison.html` in the comparison folder: a table per type (tool x
narrator, each video with its length, voice cost, time and checks), the audio of each narrator
(the same narration, other voices), the AI video section (ElevenLabs Veo clips or a lip-synced
presenter, once added with `ai_clips.py` and the page rebuilt with `--report`) and the cost of every
version. Rate them in `benchmark.csv`. Each video uses its narrator's own timing, so picture and
voice always fit; versions with the same narrator are equally long. Other combinations:
`--voices kokoro,elevenlabs,system --renderers html,remotion,remotion-ai,remotion-pro --styles
clean,illustrated,presenter,dialogue`. Versions that can't run (no key, no Node.js) are listed with
the reason; a version that breaks is listed as failed and the others still run. Each narrator's voice
is made once and reused by every tool (no double cloud cost).

**Compare configurations, not only tools.** A narrator is `engine[:voice][@model][+plain]`, and the
Remotion Pro presenters are a list too:
```
uv run benchmark.py --from "data/output/<folder>" --styles presenter --renderers remotion-pro ^
  --voices kokoro:af_heart,kokoro:bf_emma,elevenlabs:lily,elevenlabs:lily+plain,elevenlabs:george@flash ^
  --presenters robot,cat,person-3d,person-2d:micah,person-2d:notionists
```
| Part | Options |
|---|---|
| `kokoro:<voice>` | `af_heart`, `af_bella`, `af_nicole`, `bf_emma`, `am_michael`, `bm_george` … (`uv run tts.py --voices`) |
| `elevenlabs:<voice>` | `lily`, `matilda`, `jessica`, `alice`, `sarah`, `laura`, `george`, `brian`, `daniel`, `will`, `eric` … or a voice id |
| `@<model>` (ElevenLabs) | `v2` multilingual (best for narration, default), `flash`, `turbo` (half the credits), `v3` (most expressive; no context) |
| `+plain` (ElevenLabs) | the old way: every sentence spoken on its own (to hear what the context does) |
| `--presenters` | `robot`, `cat`, `person-3d`, `person-2d`, `person-2d:micah` / `:avataaars` / `:notionists`, `none` |

| `--audio-only` | only the narration of each narrator, no video: 8 voices in a few minutes |
| `--vary KEY=a,b` | any `.env` setting in several versions (repeatable; every combination): `THEME_ACCENT=#0b6e79,#7c3aed`, `GSAP=yes,no`, `VIDEO_WIDTH=1280,1920`, `REMOTION_FPS=25,30`, `ELEVENLABS_STABILITY=0.4,0.6` |
| `--characters` | the drawn bear and fox of the built-in engines (`cartoon`, `people`); default none, so their animation versions are left out |

The ElevenLabs characters are counted per narrator (5 narrators of a 1-minute lesson ≈ 5,000).
A version where Remotion failed is shown as "Not this tool" (it was made with the designer slides),
and `remotion_error.txt` in its folder has the full message.
Each variant's `run_card.json` keeps the exact settings; `comparison.html` shows them next to the video.

**ElevenLabs sound.** A lesson is spoken in short parts so the slides follow the voice. Each part is
sent with what comes before and after it (request stitching: the ids of the parts just spoken, else
their text, and the next sentence), with steady settings (`ELEVENLABS_STABILITY=0.6`, speaker boost)
and a fixed seed, and the silence at its ends is cut: one flowing narration instead of separate
sentences. The audio comes at 44.1 kHz as in ElevenLabs' own web app (`ELEVENLABS_FORMAT=mp3_44100_128`,
every plan), and the whole narration gets one steady loudness (one gain, no level control that
"pumps"). The cost on the run card is what ElevenLabs says it billed (its `character-cost`).

**Remotion on Windows.** It is started with `node` and Remotion's own script (not `npx.cmd`), with full
paths; missing packages are installed automatically (`npm install`, once). If a render fails, the
full message is in `remotion_error.txt` in the video's folder. Faster renders: `REMOTION_FPS=25`
(about 17% faster), `REMOTION_CONCURRENCY` up to the number of cores, `PRO_PRESENTER=person-2d`.

| Option | Setup | Cost |
|---|---|---|
| Kokoro voice | (default) | free, local |
| ElevenLabs voice | `ELEVENLABS_API_KEY` in `.env` (free trial: ~10 min a month; `uv run tts.py --engine elevenlabs --voices`) | `ELEVENLABS_USD_PER_1K_CHARS` (paid-plan rate) per 1,000 characters |
| Built-in video engine | (default) | free |
| Remotion | Node.js 18+, then `cd remotion` + `npm install` (once) | free for evaluation; company licence for production |

Test one voice alone: `uv run tts.py --engine elevenlabs "A short test sentence."` (voice: `ELEVENLABS_VOICE`).

### Budget tiers: what each level gives and costs

`uv run tiers.py` → `data/output/tiers.md` / `tiers.csv`: monthly cost and cost per video for each
budget tier (0 free at its best, 1 basic paid, 2b own branded cartoon character, 2c manual business
cartoons, 2d generated scenes, 3 enterprise; no real-looking presenters: not allowed in this project) at 20 / 100 / 500 videos a month. Prices and
volumes are in `tiers.json` (with sources and the date they were checked; edit to try others).
Once real videos exist, their run cards replace the assumed AI cost and characters per minute.

**Real-looking clips** (Google Veo; scenery and places, never a presenter). Our engines and Remotion draw with code, so they
never look like filmed reality, however good the animation. Real-looking people, places, waves or
falling leaves need a generative video model. Bedrock EU has none, and the free plans of
ElevenLabs and Runway have no video; ElevenLabs Starter ($6/month, 30,000 credits,
needs approval) has Image & Video with Google Veo. Clips are 8 s, cannot show exact text, and
the same person looks different in each clip, so they go around our lesson, not instead of it:
```
uv run ai_clips.py prompts "data\output\<video folder>"          # clip_prompts.txt: 3 generic prompts to paste
uv run ai_clips.py add "data\output\<video folder>" --clip intro.mp4 --clip middle.mp4 --clip end.mp4 --tool elevenlabs --model veo-3.1-fast --cost-usd 1.50
```
→ `lesson_video_clips.mp4` (+ `.srt`): the first clip before the lesson, the last after it, the
others in a pause after a full sentence (nobody speaks over them). `--into <file>.mp4`
puts them around another video of the folder. Only the title and scene headings go to Claude for the
prompts, and prompts with names, numbers or personal data are replaced by built-in ones: they are
pasted into an outside tool. Never Sora (no OpenAI in this project), Kling, Seedance, Hailuo, Wan or PixVerse (refused). The run
card shows the tool, model, prompts and cost (`--cost-usd`: the credits used, takes thrown away
included, as dollars of the plan); it is not counted in the daily Bedrock limit.

**ElevenLabs video from the code** (`eleven_video.py`): the same models by API, but only on the Pro
plan ($99/month); lower plans get "paid_plan_required" (said in plain words), and the free plan has
no video at all, not even in the web app. `uv run eleven_video.py check` tells what the key can do
without using credits; `clip <folder> --prompt 1` makes a Veo clip from `clip_prompts.txt`; the credits used are read from the
account and become the cost on the run card.

**Remotion Pro** (`RENDERER=remotion-pro`): the same storyboard, voice and timing drawn as a
motion-design video (`remotion/src/pro`): a living dark backdrop, glass cards that flip in as the voice
reaches them, flows that draw themselves, counters and bar charts that grow, a quiz that reveals the
answer, push transitions between scenes, and presenters that talk in time with the voice, wave, turn
and point at the screen and are happy about the right answer: none in slides (clean, illustrated),
one in the presenter style, two in conversations. Choose who in `.env`:

| `PRO_PRESENTER` | Who | Licence (`remotion/assets/README.md`) | Render time* |
|---|---|---|---|
| `robot` (default) | 3D glossy toy robot | CC0 | ~5x |
| `cat` | 3D toon cat | CC BY 4.0: credit "Toon Cat FREE by Omabuarts Studio" in the video description | ~5x |
| `person-3d` | 3D woman (presenter, expert) and man (host) in suits | CC0 | ~5x |
| `person-2d` | 2D illustrated person in a round portrait; `PRO_AVATAR=micah` (colourful), `avataaars` (cartoon) or `notionists` (line art, with hand gestures) | CC BY 4.0 / free use / CC0 | ~1.2x |
| `company` | the company's own avatar: its picture (`data/avatars/<name>.png`, marked on the Avatars tab) made to talk: the mouth opens with the voice, the eyes blink, it breathes, leans to the slide, waves hello; `PRO_AVATAR=<name>` | the company's own | ~1.2x |
| `none` | the scenes only | | 1x |

\* compared with no presenter, measured here without a graphics chip. **Faster videos:** `person-2d`;
`VIDEO_WIDTH=1280` (720p, about 1.4x faster); `REMOTION_CONCURRENCY=4` (all cores of a 4-core laptop;
more memory). 3D is drawn by the browser the way it chooses (fast, uses the graphics chip if there is
one); if that fails the render is retried with `swangle` (always works, several times slower).
After updating: `cd remotion`, `npm.cmd install` (new: the 2D drawing packages). Code-drawn, so
still an animation, not a real person; for real people use the presenter route above.

Every result is checked automatically (`quality.json`, verdict OK / CHECK / FAIL): numbers must be in
the sources, a model review scores faithfulness (skip with `--no-review`), inappropriate words and
personal data fail. Requests that try to steer the AI, ask for offensive content or for facts from
outside the material are refused before anything is made.
The conversation may not add facts: every scene is checked (numbers, length, wording) and a
scene that fails is read by one voice (a warning in the log and `script.md` shows who says what).

Motion: slides animate with GSAP (bundled, free licence; `GSAP=no` in `.env` = the simpler
built-in motion). A professional animated presenter (Lottie, e.g. from LottieFiles) can replace
the drawn one: `uv run tools/add_lottie.py --talk talk.json --point point.json --licence "Lottie Simple License"`
(checked first: no internet pictures, no text, size); `--remove` goes back to the drawing.

To fix a sentence or on-screen word in a video: edit `storyboard.json` in the output folder
(`narration`, `heading`, `items`) and run `--rerender`. No model call.

---

## Part B: switch to the gateway (Claude on Bedrock)

You need the 3 values from the platform team's e-mail: the **address** (`ANTHROPIC_BASE_URL`),
the **virtual key**, and the **Sonnet 5 model id (EU)**. Search keeps running locally
(Claude cannot make embeddings), so Ollama with `nomic-embed-text` stays installed.

1. Copy `.env.bifrost.example` and rename the copy to `.env` (the old `.env` is replaced;
   copy your `SLIDE_CROP` / `SLIDE_MASK` values over first).
2. Fill in 3 lines, values exactly as in the e-mail:
   ```
   BIFROST_BASE_URL=<the address; the /anthropic ending can stay>
   BIFROST_API_KEY=<the virtual key>
   CHAT_MODEL=<the Sonnet 5 id, e.g. bedrock/eu.anthropic.claude-sonnet-...>
   ```
3. Check:
   ```
   uv run doctor.py --models
   ```
   Look for `[OK] chat model answers: 'OK'`. A model list may or may not appear; either is fine.
   If you get HTTP 401: set `BIFROST_AUTH_HEADER=x-bf-vk` and try again.
4. Prepare again with Claude reading the slides (segments and slides are kept):
   ```
   uv run pipeline.py --mode easy --vision
   ```
5. Same commands as in A3:
   ```
   uv run make_video.py --recording 13 --minutes 2 --plan-only
   uv run make_video.py --rerender "data/output/<folder>"
   ```
   Compare `script.md` with the local one: that comparison is useful for the demo.

**Other models:** for one run add `--model <id>` (e.g. the Opus 5 id from the e-mail); to switch
for good, change `CHAT_MODEL`. Use EU ids only (the platform team asked for that).

### Models and cost

| Job | Model | Cost (estimate) |
|---|---|---|
| Storyboard, text lesson, reading slides | Claude Sonnet 5 (EU) | ~$0.03-0.06 per 2-min video; ~$0.006 per slide, once |
| Search | nomic-embed-text, local | free |
| Comparison now and then | Claude Opus 5 | ~2.5x Sonnet |

### Spending lock

| Setting | Default | What happens |
|---|---|---|
| `DAILY_BUDGET_USD` | 20 | no more gateway calls today once reached |
| `RUN_BUDGET_USD` | 5 | one command stops once it has spent this much (protects against loops) |
| hard maximum | 100 | fixed in the code: a higher `DAILY_BUDGET_USD` is cut down to 100 |

Costs are estimated from token counts with list prices (+10% for EU ids, and the higher price
when a version is unknown), logged per call in `cost_log.csv`. `uv run doctor.py` shows today's
total. Only this pipeline is counted: Claude Code on the same key counts toward the platform's
own limit too.

---

## Part C: check quality

**Quality checks:** `uv run quality.py --all [--review] [--listen]`, or
`make_video.py ... --check [--review] [--listen]` for one video.
- `--review`: the model scores each scene, and the **claim check** splits the narration and the
  on-screen points into claims and checks each against the excerpts the scene cites (spoken text and
  slides), with the same judge as the answers. A claim the sources don't support = FAIL, listed.
- `--listen`: Whisper listens to the finished voice and compares it with the script: the share of
  words that don't come out as written, and the terms heard as something else (free, local).

Status per video:

| Status | Meaning |
|---|---|
| OK | nothing found |
| CHECK | worth a look: length off, reads a slide aloud, text too long on screen, words to listen to, review score 3 or lower |
| FAIL | broken (missing or out-of-sync video), a number not in the sources, or a claim the sources don't support |
| PLAN | storyboard only, not rendered yet |

**Pronunciation:** if the voice says a term wrongly, add a row to `pronunciation.csv`
(`KPI,K P I`), test with `uv run tts.py "The KPI ..."`, then `--rerender`. Subtitles keep the
original spelling. The quality check lists unusual words and the glossary's terms to listen to;
`--listen` finds the mispronounced ones for you.

**Can the judge be trusted?** The answer and video checks are graded by a model (the judge). Before
reporting its Major / hallucination counts, check a sample by hand once per judge model:
`uv run calibrate.py export` (40 of the judge's verdicts from the newest qa-eval run → `calibration.xlsx`,
the judge's own verdicts hidden), fill in YOUR VERDICT, then `uv run calibrate.py score <file>`:
agreement (kappa), and the share of the judge's flags that are real (real Major ≈ judge's Major × that share).
Use a judge that is not the writer (`JUDGE_MODEL`, e.g. Opus when Sonnet writes); qa_eval warns otherwise.

---

## Commands at a glance

| Command | What it does |
|---|---|
| `uv run app.py [--port 8765]` | Lesson Studio: chat page (answers with sources, documents, slides, videos, audio), prices and results; `APP_PASSWORD` in `.env` before sharing it |
| `uv run smoke.py [--quick] [--only document,video]` | one small result of every kind with the real model: what works, time, cost, verdict |
| **`uv run ask.py "what you want, how long, which level"`** | **the main entry: a lesson from the whole knowledge base** (document, simple slides, narrated video, two-person conversation or audio, as asked; 4-15 min videos: a course with chapters) |
| `uv run documents.py [--ai-triage] [--render-html]` | what was found in `data/input` besides recordings, and why each file is used or left out |
| `uv run topics.py` | what each recording covers, with ready requests → `data/output/topics/topics.md` |
| `uv run course.py "request" --minutes 8` / `--redo-chapter N <folder>` | a course directly / remake one chapter |
| `uv run evaluate.py --draft`, then `uv run evaluate.py` | quality as numbers on a fixed set of requests, compared with the last run |
| `uv run doctor.py [--models] [--try <id>]` | checks the setup (and tries each Claude model once: which ones your key may use) |
| `uv run inventory.py` | finds recordings, pairs transcripts and Excel rows → `data/manifest.csv` |
| `uv run chunking.py [--video <id>]` | cut transcripts where the subject, screen or speaker changes, group the pieces into topic sections (runs inside pipeline.py; `--video` shows each piece and why it starts there) |
| `uv run glossary.py [--ai]` | acronyms, tool names and Whisper misspellings found automatically → `data/glossary.csv`; used for Whisper hints and search (runs inside pipeline.py; `--ai` adds definitions) |
| `uv run ablation.py --set <plan> [--repeat 3] [--only full,time]` | the test plan in 5 pipeline variants side by side (content vs time chunking, AI relevance on/off, topic sections on/off), each run N times, with the difference to full and whether it could be chance → `ablation.md` |
| `uv run deck_video.py "Snowflake" --slides 7 [--general] [--engines html,manim]` | animated slides WITHOUT a voice, the same content drawn by several engines side by side: our designer slides, Remotion, Remotion Pro, Remotion AI, Manim, Revideo, Motion Canvas (the last two need Node.js; their packages install on first use) → `slides_<engine>.mp4` + `engines.md` in the deck folder; `--general` for a topic the recordings don't cover; `--folder <deck>` draws it again for free |
| `uv run compare_video.py` / `--from <video>` / `"Snowflake" --general` / `--resume` | the SAME video made by every tool, each in two looks (`VIDEO_LOOK`: its own and a second one; presenters in both looks with every narrator) (designer slides, Remotion (Classic and Editorial), Remotion Pro, Manim, Revideo, Motion Canvas, HyperFrames, cartoon presenter bear/fox and every marked company avatar (one video per narrator: the mouth follows the voice picked); only with `--only`: Remotion Pro's drawn and 3D people) on one timeline, with every narrator to switch under each video (the ElevenLabs voice already made is reused, 4 Kokoro voices, a new ElevenLabs voice up to the credits left); see it in Lesson Studio, tab Comparison; a woman presenter gets women's voices, a man men's; `--redo remotion:editorial` makes one look again; `--add-voice <folder>` adds the same video made with another ElevenLabs voice; what fails is noted, `--resume` finishes it after a fix |
| `RENDERER=hyperframes` (or pick it in the chat; `deck_video.py --engines hyperframes`) | the slides drawn by HyperFrames (HeyGen's open-source HTML + GSAP framework, Apache-2.0: free also for companies, an alternative to Remotion's company licence), our narration added; needs Node.js 22; installs itself on first use (npm, ~1 min), uses Playwright's browser, telemetry off |
| `uv run company_avatar.py` / `mark` / `demo` | the company's avatars: what is in `data/avatars`; `mark` marks every picture not marked yet by Claude (also done by the Avatars tab and by `compare_video.py`); `demo` adds three stand-in characters to try it with |
| `VIDEO_LOOK=second` | every tool's second look: HTML "Midnight" (navy, violet, mint), Remotion Pro "Aurora" (plum sky, ribbons), Manim "Chalkboard", Revideo plum and mint, Motion Canvas light and violet, HyperFrames dark with coral, Remotion "Editorial" |
| `REMOTION_LOOK=editorial` (with `RENDERER=remotion`) | Remotion's second look: warm paper, ink and coral, a serif title face; elements as nodes on a line drawn with the voice, counters, a ledger for tables, rings for up to three values, the right answer circled by hand; `classic` (default) is the light-card look |
| `uv run costs.py` | cost estimate to send: price per kind of request (answer, lesson, 10-min video, 60-min course ...), cost per user a month, platform by level (PoC / basic / advanced), once-only costs (library, build days), people's time, pilot / team / wide scenarios; AI costs measured on your runs, cloud from list prices → `data/output/costs/costs.html`; volumes and tools in `cost_assumptions.csv`, prices in `cost_prices.csv` |
| `uv run calibrate.py export` / `score <file>` | a person checks a sample of the judge's verdicts; agreement and how many of its flags are real |
| `uv run catalog.py [--no-analyse]` | description.xlsx vs data/input → `data/output/description_checked.xlsx`: video/audio/transcript present or MISSING, transcript source, slides, topics; recordings not in the Excel added with a 1-3 sentence description (after `pipeline.py --mode all --vision`) |
| `uv run pipeline.py --mode easy [--vision] [--force]` | prepares all included recordings |
| `uv run slides.py --video <id> --preview` | shows the slide area (crop) and the hidden area (mask) |
| `uv run index.py search "..."` | tests search |
| `uv run make_video.py "topic" --minutes 2` | video from all recordings |
| `uv run make_video.py --recording 13 --minutes 2` | video from one recording (Excel id) |
| `uv run make_video.py ... --plan-only` / `--rerender <folder>` | plan only / voice + video from an (edited) plan |
| `uv run lesson.py "topic" --minutes 5 --level beginner` | document (`lesson.html` + `lesson.md`) |
| `uv run deck.py "topic" --minutes 4 [--style clean]` / `--rerender <folder>` | simple presentation: `slides.pdf`, `slides.pptx`, speaker notes |
| `uv run make_video.py "topic" --minutes 3 --style dialogue [--characters cartoon\|people]` | video in which a host and an expert talk |
| `uv run quality.py <folder>` / `--all [--review]` | checks of any result: video, slides or document |
| `uv run answer.py "question"` / `uv run retrieval.py "question"` | a text answer with the source, place and evidence of every sentence / only what would be used |
| `uv run qa_eval.py --draft 20` / `qa_eval.py` / `--compare` | test questions from the material / answer quality report (retrieval, hallucination, correctness, declines, copying) / retrieval modes compared |
| `uv run benchmark.py "topic" --voices kokoro:bf_emma,elevenlabs:lily@flash --renderers html,remotion-pro --presenters cat,person-2d` | the same script through different voices, models, video engines and presenters → `comparison.html`, `benchmark.csv` |
| `uv run tiers.py [--minutes 5]` | cost per budget tier at 20/100/500 videos a month → `tiers.md` |
| `uv run usage.py` | spent today vs the daily limit; ElevenLabs characters used and left this month (and when they reset); Remotion has no usage limit |
| `RENDERER=remotion-ai` in `.env`, or `benchmark.py --renderers "html,remotion-ai"` | Remotion where Claude writes each scene's animation code (checked, compiled; a scene that fails uses the template) |
| `RENDERER=remotion-pro` / `benchmark.py --renderers "html,remotion-pro"` | motion-design video with presenters (talk, wave, point, happy on the answer); `PRO_PRESENTER=robot`, `cat`, `person-3d`, `person-2d` (+ `PRO_AVATAR`), `company` (+ `PRO_AVATAR=<name>`) or `none` |
| `uv run eleven_video.py check` / `clip <folder> --prompt 1` / `presenter <folder> --image p.jpg` | ElevenLabs video by API (Pro plan): Veo clip, talking presenter; credits read from the account → cost |
| `uv run ai_clips.py voice <folder> --seconds 8` / `presenter <folder> --clip talking.mp4` | narration excerpt for a lip-sync model / the talking presenter in a window over the lesson |
| `uv run ai_clips.py prompts <folder>` / `add <folder> --clip a.mp4 --clip b.mp4 --tool elevenlabs --model veo-3.1-fast --cost-usd 1.5` | real-looking AI clips (Google Veo, made by hand in the tool) as intro, cutaways and outro of a finished video → `lesson_video_clips.mp4`; cost on the run card |
| `uv run compare.py [--topic "..."] [--kind video]` | all results side by side from their run cards: model, voice, cost, time, verdict → `data/output/comparison.csv` |
| `uv run tools/add_lottie.py --talk x.json [--point y.json] --licence "..."` / `--remove` | professional animated presenter for the presenter style |
| `uv run quality.py --all [--review] [--visual]` | checks every video (OK / CHECK / FAIL / PLAN): true numbers, voice matches screen, layout, audio, safety; `--visual` = the vision model reviews every slide |
| `uv run python -m pytest tests` | automatic tests (offline, free, ~1-2 min) |
| `uv run --with ruff ruff check .` | code style and common bugs |
| `uv run tts.py "text"` | voice test |
| `uv run llm.py` | model smoke test |

Levels: `beginner`, `intermediate`, `expert`.

## Output of a video

Folder `data/output/<time>-<topic>-video-<n>m/`:

| File | What |
|---|---|
| `lesson_video.mp4` | the video lesson (subtitles inside as a track) |
| `lesson_video.srt` | subtitles |
| `lesson_audio.mp3` | audio lesson |
| `script.md` | narration + on-screen text per scene, with sources (recording + time) |
| `storyboard.json` | the same as data; edit it and `--rerender` |
| `info.json` | length, timings, estimated cost, warnings |
| `quiz.md`, `quiz.json` | the check-yourself questions with answers |
| `chapters.txt` | courses: table of contents (the chapters are also marks in the mp4) |
| `audio/voice_*.wav` | the voice per part of a scene; unchanged texts are reused on `--rerender` |
| `scenes/scene_NN.png` | each scene in its final state (for the report and a quick look) |

Look: `STYLE` in `.env` or in the request ("simple", "with pictures", "with a presenter"):
`clean` designer slides only, `illustrated` + pictures of people at work where they fit the
slide, `presenter` a person stands next to every slide. Needs `uv add playwright` once (it
uses the installed Edge if Playwright's Chromium can't be downloaded); without it the simple
slides are used. `uv run illustrations.py` shows all pictures; `uv run images.py` tests AI pictures.

Animation: elements appear or are highlighted when the voice reaches them (`build` /
`highlight` in `storyboard.json`, with `cues` = where in the narration each element starts);
`script.md` shows the cut points as ▸. `ANIMATION=no` in `.env` renders still slides.

`storyboard.json` also records how it was made (`settings`: model, prompt and code version,
switches), shown at the end of `script.md`.

## When something fails

| Message | Fix |
|---|---|
| `Is Ollama running?` | start the Ollama app |
| `ollama pull ...` in doctor | the model isn't downloaded yet: run that command |
| `Prompt is ~N tokens ... exceeds NUM_CTX` | lower `MAX_MATERIAL_WORDS` or raise `NUM_CTX` in `.env` |
| `HTTP 401/403 ... rejected` | wrong key or model not allowed for it: check `.env`, ask the platform team |
| `HTTP 404 ... model id unknown` | copy the exact id from `uv run doctor.py --models` |
| `CERTIFICATE_VERIFY_FAILED` | company TLS inspection: set `CA_BUNDLE` to the company `.pem` |
| `Can this laptop reach the gateway` | VPN/proxy, or the URL works only inside their cluster |
| `Index was built with ...` | embedding model changed: `uv run index.py build` |
| `Recordings don't seem to cover` | other wording, or lower `MIN_SCORE` |
| `Spending lock: ...` | daily or per-command limit reached; raise it in `.env` only if expected (max 100/day) |
| `CHAT_MODEL is empty` | paste the Sonnet id from the e-mail |
| `Both gateway routes failed` | check the address and the model id; send the message (without the key) |
| presenter visible on slides in the video | `SLIDE_MASK`, then `--rerender` |
| very slow storyboard locally | `CHAT_MODEL=llama3.2:3b`, or shorter `--minutes` |

## Files

| File | Role |
|---|---|
| `config.py` | all settings, read from `.env` |
| `llm.py` | every model call: gateway or Ollama, retries, cost log, budget stop |
| `inventory.py`, `ingest.py`, `slides.py`, `describe_slides.py`, `index.py`, `pipeline.py`, `transcribe.py` | preparing recordings |
| `lesson.py` | text lesson |
| `storyboard.py`, `tts.py`, `render.py`, `make_video.py` | narrated video |
| `quality.py` | checks of every result |
| `pronunciation.csv` | how the voice says special terms |
| `tests/` | automatic tests with a stand-in gateway and voice |
| `store.py`, `media.py` | files on disk; ffmpeg / Tesseract |
| `skills/compose-video/`, `skills/compose-lesson/` | the prompts (SKILL.md, the platform's format) |
| `evaluate.py`, `eval/` | scoring lessons, videos and courses against a golden set |
| `slides_html.py` | designer slides drawn by a browser engine (icons, cards, diagrams, stats, charts, formulas, calculations, motion, the presenter) |
| `facts.py`, `safety.py` | numbers checked against the sources, calculations recomputed / inappropriate content, icons, hidden instructions, AI-picture check |
| `illustrations.py`, `images.py` | people and office illustrations (Humaaans, CC0) / AI pictures via the gateway |
| `assets/` | icons (Lucide, ISC), font (Inter, OFL), people (Humaaans, CC0) with their licences |
| `documents.py` | Word, PowerPoint, PDF, Excel, HTML quizzes, JSON, XML, images: read, filtered, ingested |
| `ask.py`, `course.py`, `topics.py` | requests in plain words, courses with chapters, topic map |
| `docs/DESIGN.md` | how it works and why (decisions, quality, limits) |
| `NEXT_STEPS.md` | what's left to the demo (`doctor.py` reminds you) |
| `doctor.py` | checks the setup |
