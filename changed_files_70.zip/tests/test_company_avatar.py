"""company_avatar.py: the company's own characters made to talk from a picture. The mouth and the eyes
found automatically (to check on the Avatars tab), the colours sampled around them, one comparison
solution per marked avatar (a woman's voices for a woman), the picture handed to Remotion and removed
after, pictures added and deleted from the page. A real render (slow) checks that the mouth moves with
the voice and the eyes blink."""
from __future__ import annotations

import base64
import io

import numpy as np
import pytest

import app
import company_avatar as ca
import config

# where draw_demo puts the parts (parts of the picture): the pupils' centres, the closed smile
EYES = [(0.405, 0.425), (0.595, 0.425)]
MOUTH = (0.5, 0.56)


def _inside(box, x, y, slack=0.0):
    bx, by, bw, bh = box
    return bx - slack <= x <= bx + bw + slack and by - slack <= y <= by + bh + slack


def test_the_eyes_and_the_mouth_are_found_in_a_drawn_character(project):
    for name in ca.DEMO:
        pic = ca.draw_demo(name, config.AVATARS_DIR / f"{name}.png")
        m = ca.guess(pic)
        assert m["found"], name
        assert all(_inside(b, x, y) for b, (x, y) in zip(m["eyes"], EYES, strict=True)), (name, m)
        assert _inside(m["mouth"], *MOUTH, slack=0.01), (name, m)
        assert m["mouth"][2] < 0.25 and all(e[2] < 0.15 for e in m["eyes"])     # boxes about the size of the parts
    assert ca.cutout(config.AVATARS_DIR / "demo-anna.png")


def test_a_picture_with_a_background_is_marked_too_and_shown_as_a_portrait(project):
    from PIL import Image
    pic = ca.draw_demo("demo-tom", config.AVATARS_DIR / "x.png")
    im = Image.open(pic)
    flat = Image.new("RGBA", im.size, (214, 226, 240, 255))
    flat.alpha_composite(im)
    flat.convert("RGB").save(config.AVATARS_DIR / "tom.jpg")
    pic.unlink()
    m = ca.guess(config.AVATARS_DIR / "tom.jpg")
    assert all(_inside(b, x, y, 0.01) for b, (x, y) in zip(m["eyes"], EYES, strict=True)), m
    saved = ca.save("tom", {**m, "label": "Tom", "who": "man"})
    assert saved["cutout"] is False and saved["size"] == [900, 900]


def test_the_marks_keep_the_colours_drawn_over_the_picture(project):
    pic = ca.draw_demo("demo-anna", config.AVATARS_DIR / "demo-anna.png")
    saved = ca.save("demo-anna", {**ca.guess(pic), "label": "  Anna  ", "who": "woman"})
    skin = ca.DEMO["demo-anna"][1]
    c = saved["colours"]
    assert np.abs(np.array([int(c["skin"][i:i + 2], 16) for i in (1, 3, 5)]) - skin).max() <= 16   # the face's skin
    assert all(lid == c["skin"] for lid in c["lids"])                              # eyelids: the skin around the eyes
    assert int(c["lip"][1:3], 16) > int(c["lip"][3:5], 16) + 40                    # the lips: red
    assert saved["label"] == "Anna" and saved["who"] == "woman" and ca.load("demo-anna")["eyes"][0][0] < saved["eyes"][1][0]
    with pytest.raises(ValueError, match="Two eyes"):
        ca.save("demo-anna", {"mouth": saved["mouth"], "eyes": [saved["eyes"][0]]})
    with pytest.raises(ValueError, match="parts of the picture"):
        ca.save("demo-anna", {"mouth": [0.4, 0.5, 2, 0.1], "eyes": saved["eyes"]})
    with pytest.raises(FileNotFoundError):
        ca.save("nobody", {"mouth": saved["mouth"], "eyes": saved["eyes"]})


def test_each_marked_avatar_is_a_solution_with_its_voices(project):
    import compare_video
    ca.demo()
    ca.draw_demo("demo-tom", config.AVATARS_DIR / "unmarked.png")            # a picture not marked yet: not offered
    sols = {s["id"]: s for s in compare_video.solutions()}
    assert {"company-demo-anna", "company-demo-tom", "company-demo-maya"} <= set(sols) and "company-unmarked" not in sols
    tom = sols["company-demo-tom"]
    assert tom["who"] == "man" and tom["talks"] and tom["renderer"] == "html" and tom["style"] == "presenter"
    assert tom["set"] == {"CARTOON_PRESENTER": "company:demo-tom"} and tom["variant"] == "Tom (demo)"
    rows = {a["name"]: a for a in ca.listing()}
    assert rows["unmarked"]["marked"] is False and rows["unmarked"]["marks"]["eyes"]          # a guess to start from


def test_remotion_gets_the_picture_and_its_marks(project, tmp_path, monkeypatch):
    import remotion_render
    import tts
    ca.demo()
    wav = tmp_path / "work" / "narration.wav"
    wav.parent.mkdir()
    tts._write_wav(wav, (0.2 * np.sin(np.arange(24000) / 24000 * 2 * np.pi * 200)).astype(np.float32), 24000)
    monkeypatch.setattr(config, "PRO_PRESENTER", "company")
    monkeypatch.setattr(config, "PRO_AVATAR", "demo-maya")
    sb = {"title": "T", "style": "presenter", "scenes": [{"visual": "bullets", "heading": "H", "narration": "One two three.",
                                                          "items": ["a", "b"]}]}
    plan = [(0, {"text": "One two three.", "pause": 0.3})]
    data = remotion_render.pro_props(sb, plan, [1.0], wav)
    assert data["character"] == "company" and len(data["company"]) == 1
    look = data["company"][0]
    assert look["src"] == "avatar_demo-maya.png" and (wav.parent / look["src"]).exists() and look["cutout"] is True
    assert look["mouth"] == ca.load("demo-maya")["mouth"] and len(look["eyes"]) == 2 and look["colours"]["skin"]
    duo = remotion_render.pro_props({**sb, "style": "dialogue"}, plan, [1.0], wav)
    assert [c["src"] for c in duo["company"]] == ["avatar_demo-maya.png", "avatar_demo-tom.png"]   # the other one: a man
    monkeypatch.setattr(config, "VIDEO_LOOK", "second")                          # the second look: aurora colours
    aurora = remotion_render.pro_props(sb, plan, [1.0], wav)
    assert aurora["backdrop"] == "aurora" and aurora["cast"][0]["color"] == "#3fe0c5" and aurora["accent"] == "#ff5fa2"
    monkeypatch.setattr(config, "VIDEO_LOOK", "main")
    monkeypatch.setattr(config, "PRO_AVATAR", "nobody")
    with pytest.raises(RuntimeError, match="not marked"):
        remotion_render.pro_props(sb, plan, [1.0], wav)


def test_pictures_are_added_marked_and_deleted_from_the_page(project):
    from PIL import Image
    buf = io.BytesIO()
    Image.open(ca.draw_demo("demo-tom", project / "t.png")).save(buf, "PNG")
    body = {"name": "Tom Smith", "data": "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()}
    out, code = app.avatar_post("/api/avatars", body)
    assert code == 200 and out["name"] == "tom-smith" and (config.AVATARS_DIR / "tom-smith.png").exists()
    a = next(x for x in out["avatars"] if x["name"] == "tom-smith")
    assert a["url"] == "/avatars/tom-smith.png" and a["marked"] is True and a["label"] == "Tom Smith"   # marked at once
    out, code = app.avatar_post("/api/avatars/tom-smith", {**a["marks"], "label": "Tom", "who": "man"})
    assert code == 200 and next(x for x in out["avatars"] if x["name"] == "tom-smith")["marked"]
    assert app.avatar_post("/api/avatars", {"name": "x", "data": "bm90IGFuIGltYWdl"})[1] == 400   # not a picture
    assert app.avatar_post("/api/avatars/nobody", {"mouth": [0.1, 0.1, 0.1, 0.1], "eyes": []})[1] in (400, 404)
    out, code = app.avatar_post("/api/avatars/tom-smith/delete", {})
    assert code == 200 and not out["avatars"] and not (config.AVATARS_DIR / "tom-smith.json").exists()


@pytest.mark.slow(900)   # drawn by Remotion in a browser
def test_the_avatar_talks_and_blinks_in_a_real_video(project, tmp_path, monkeypatch):
    import media
    import remotion_render
    import tts
    ok, why = remotion_render.available()
    if not ok:
        pytest.skip(why)
    ca.demo()
    monkeypatch.setattr(config, "PRO_PRESENTER", "company")
    monkeypatch.setattr(config, "PRO_AVATAR", "demo-anna")
    monkeypatch.setattr(config, "VIDEO_WIDTH", 960)
    monkeypatch.setattr(config, "VIDEO_HEIGHT", 540)
    monkeypatch.setattr(config, "REMOTION_FPS", 24)
    rate = 24000
    t = np.arange(int(3.6 * rate)) / rate
    voice = (0.4 * np.sin(2 * np.pi * 180 * t) * (0.5 + 0.5 * np.sin(2 * np.pi * 3 * t)) * (t > 0.6)).astype(np.float32)
    work = tmp_path / "work"
    work.mkdir()
    wav = work / "narration.wav"
    tts._write_wav(wav, voice, rate)
    sb = {"title": "Joins", "style": "presenter", "scenes": [{"visual": "bullets", "heading": "Joins", "narration": "x",
                                                              "items": ["Inner", "Left"]}]}
    out = remotion_render.render(work, sb, [(0, {"text": "x", "pause": 0.2})], [3.6], wav, pro=True)
    assert abs(media.duration_s(out) - 3.6) < 0.3 and not (work / "avatar_demo-anna.png").exists()   # the picture removed
    frames = []
    for s in (2.0, 2.04, 2.08, 2.12, 2.16, 2.2):                                    # while it talks
        png = tmp_path / f"f{s}.png"
        media._run([config.FFMPEG, "-loglevel", "error", "-y", "-ss", str(s), "-i", str(out), "-frames:v", "1", str(png)])
        from PIL import Image
        frames.append(np.asarray(Image.open(png).convert("L"), dtype=np.float32))
    # the presenter stands on the right: its face changes from frame to frame (the mouth), the slide less
    right = [f[:, int(f.shape[1] * 0.68):] for f in frames]
    moved = max(float(np.abs(a - b).mean()) for a, b in zip(right, right[1:], strict=False))
    assert moved > 0.05


def test_any_file_name_works(project):
    ca.draw_demo("demo-anna", config.AVATARS_DIR / "Anna Łęcka.PNG")
    assert ca.slug("Anna Łęcka") == "anna-lecka" and list(ca.pictures()) == ["anna-lecka"]
    m = ca.guess(ca.pictures()["anna-lecka"])
    assert ca.save("anna-lecka", {**m, "who": "woman"})["who"] == "woman" and ca.listing()[0]["marked"]


def _claude(monkeypatch, answers):
    """A stand-in for Claude's vision: the answers in order; what it was shown is kept."""
    import llm
    shown = []

    def describe_image(path, prompt, **k):
        from PIL import Image
        with Image.open(path) as im:
            shown.append((k.get("step"), im.size, prompt))
        a = answers.pop(0)
        if isinstance(a, Exception):
            raise a
        return __import__("json").dumps(a)
    monkeypatch.setattr(llm, "describe_image", describe_image)
    return shown


def test_claude_marks_a_picture_and_its_pixels_make_the_marks_exact(project, monkeypatch):
    """No clicking: Claude's boxes (a little off, as a model's are) are snapped to the pupils and the lips by
    the picture's own pixels, then Claude checks them once on the picture with the marks drawn on it."""
    ca.draw_demo("demo-anna", config.AVATARS_DIR / "anna.png")
    off = 0.025
    shown = _claude(monkeypatch, [
        {"left_eye": [0.36 + off, 0.39 + off, 0.09, 0.07], "right_eye": [0.55 + off, 0.39 - off, 0.09, 0.07],
         "mouth": [0.43 + off, 0.535 + off, 0.14, 0.05], "lips": 0.56, "chin": 0.68, "face": [0.29, 0.2, 0.42, 0.48],
         "who": "woman"},
        {"ok": True}])
    m = ca.mark("anna")
    assert [x[0] for x in shown] == ["avatar marks", "avatar marks check"] and "grid" in shown[0][2]
    assert m["by"] == "ai" and m["who"] == "woman" and m["chin"] == 0.68 and m["face"][2] == 0.42
    for box, (x, y) in zip(m["eyes"], EYES, strict=True):                         # centred on the pupils again
        assert abs(box[0] + box[2] / 2 - x) < 0.012 and abs(box[1] + box[3] / 2 - y) < 0.012, (box, x, y)
    assert _inside(m["mouth"], *MOUTH, slack=0.005) and m["mouth"][1] <= m["lips"] <= m["mouth"][1] + m["mouth"][3]
    look = ca.props("anna", project)
    assert look["lips"] == m["lips"] and look["chin"] == 0.68 and look["face"] == m["face"]   # the animation follows


def test_claudes_check_corrects_a_wrong_box(project, monkeypatch):
    ca.draw_demo("demo-tom", config.AVATARS_DIR / "tom.png")
    _claude(monkeypatch, [
        {"left_eye": [0.36, 0.39, 0.09, 0.07], "right_eye": [0.55, 0.39, 0.09, 0.07], "mouth": [0.1, 0.85, 0.1, 0.05],
         "lips": 0.87, "chin": 0.95, "who": "man"},                                   # the mouth on the shirt
        {"ok": False, "mouth": [0.43, 0.535, 0.14, 0.05], "lips": 0.56, "chin": 0.68}])
    m = ca.mark("tom")
    assert _inside(m["mouth"], *MOUTH, slack=0.005) and m["who"] == "man" and m["chin"] == 0.68


def test_without_a_model_the_pixels_alone_mark_it(project, monkeypatch):
    import llm
    ca.draw_demo("demo-maya", config.AVATARS_DIR / "maya.png")
    _claude(monkeypatch, [llm.LLMError("gateway not reachable")])
    m = ca.mark("maya", label="Maya")
    assert m["by"] == "guess" and _inside(m["mouth"], *MOUTH, slack=0.01) and m["label"] == "Maya"
    assert ca.mark_all() == []                                                       # all marked: nothing to do
    moved = ca.save("maya", {"mouth": m["mouth"], "eyes": m["eyes"], "who": "woman", "by": "hand"})
    assert moved["by"] == "hand" and moved["who"] == "woman"



def test_on_the_html_slides_the_picture_talks_and_blinks(project, monkeypatch):
    """The free way (HTML slides, no Node.js): the picture inside the cartoon runtime's puppet: a mouth that
    opens with the voice over a patch of its own skin, eyelids of its own skin; silent it is the picture."""
    pytest.importorskip("playwright")
    import slides_html
    ca.demo()
    g = ca.svg("demo-anna", 1128, 724, 440, 296)
    assert 'class="toon toon-presenter" data-who="presenter"' in g and "data:image/png;base64," in g
    for part in ("t-patch", "t-open", "t-tongue", "t-lid", "t-head", "t-sway", "t-breathe"):
        assert part in g
    skin = ca.load("demo-anna")["colours"]["skin"]
    assert skin in g                                                       # the patch is its own skin colour
    monkeypatch.setattr(config, "CARTOON_PRESENTER", "company:demo-anna")
    html, n = slides_html.scene_html({"visual": "bullets", "heading": "Hi", "items": ["one"]}, lesson_title="T", goal="",
                                     page="1 / 2", style="presenter", characters="cartoon")
    assert "data-kind=\"company\"" in html
    out = ca.preview("demo-anna")
    from PIL import Image
    im = Image.open(out).convert("RGB")
    assert im.size == (1280, 620)
    m = ca.load("demo-anna")
    W, H = m["size"]
    k = min(420 / H, 360 / W)

    def at(i, fx, fy):   # a point of the picture in the i-th still (silent, talking, blink)
        return im.getpixel((round(220 + i * 420 - W * k / 2 + fx * W * k), round(560 - H * k + fy * H * k)))
    mx = m["mouth"][0] + m["mouth"][2] / 2
    lips = m.get("lips") or m["mouth"][1] + m["mouth"][3] * 0.45
    assert sum(at(1, mx, lips + 0.01)) < sum(at(0, mx, lips + 0.01)) - 120     # talking: the open mouth is dark
    e = m["eyes"][0]
    pupil = (e[0] + e[2] / 2, e[1] + e[3] / 2)
    assert sum(at(2, *pupil)) > sum(at(0, *pupil)) + 150                       # blink: skin over the dark pupil


@pytest.mark.slow
def test_an_html_video_with_the_company_avatar_talks(gateway, fake_voice, monkeypatch):
    """A real video with the HTML slides: the avatar's mouth moves with the voice across the frames."""
    pytest.importorskip("playwright")
    import subprocess

    from test_end_to_end import _prepare_one_recording

    import make_video
    _prepare_one_recording()
    ca.demo()
    monkeypatch.setattr(config, "RENDERER", "html")
    monkeypatch.setattr(config, "CARTOON_PRESENTER", "company:demo-anna")
    out, info = make_video.make("how to join two tables", None, 1, "beginner", style="presenter", characters="cartoon")
    frames = out / "frames_check"
    frames.mkdir()
    subprocess.run([config.FFMPEG, "-loglevel", "error", "-i", str(out / "lesson_video.mp4"), "-vf", "fps=6",
                    str(frames / "f%03d.png")], check=True)
    from PIL import Image
    shots = sorted(frames.glob("f*.png"))[6:40]
    m = ca.load("demo-anna")
    W, H = m["size"]
    vw, vh = Image.open(shots[0]).size
    k = min(440 / H, 296 / W) * vw / 1280
    x0, y0 = 1128 * vw / 1280 - W * k / 2, 724 * vh / 720 - H * k
    mx = m["mouth"][0] + m["mouth"][2] / 2
    lips = m.get("lips") or m["mouth"][1] + m["mouth"][3] * 0.45
    dark = [sum(Image.open(f).convert("RGB").getpixel((round(x0 + mx * W * k), round(y0 + (lips + 0.008) * H * k))))
            for f in shots]
    assert max(dark) - min(dark) > 150, dark                                # the mouth opens and closes
