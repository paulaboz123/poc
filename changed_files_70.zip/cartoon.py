"""
cartoon.py - original cartoon characters for the presenter and dialogue styles (CHARACTERS=cartoon):
a bear and a fox in office clothes, drawn as a puppet with joints so the runtime can move them:

  - the mouth opens and closes with the loudness of their own voice (mouth_envelope, per frame)
  - the eyes blink now and then, the pupils look at the screen
  - the brows lift and the head nods on stressed words
  - the arm closest to the screen points at what appears on the slide; the other arm moves a
    little while talking; the body breathes and sways

All shapes are drawn here (no image model, no outside artwork): the same character looks the
same in every scene, and nothing random can appear.

Drawn facing right (towards a screen on the right); facing="left" mirrors them.
Coordinates: feet at (0, 0), 500 units tall, y up is negative.
"""
from __future__ import annotations

import numpy as np

KINDS = {
    "bear": {"fur": "#a8714f", "fur2": "#875638", "snout": "#efd2b4", "inner": "#e9b9a0", "ears": "round"},
    "fox": {"fur": "#e8803a", "fur2": "#c4622a", "snout": "#fff4e8", "inner": "#fbd3b8", "ears": "pointy"},
}
INK = "#2b2433"


def presenter_kind() -> str:
    """The cartoon presenter (CARTOON_PRESENTER): bear or fox."""
    import config
    kind = getattr(config, "CARTOON_PRESENTER", "bear")
    return kind if kind in KINDS else "bear"


def _ears(k: dict) -> str:
    if k["ears"] == "round":
        return "".join(f'<circle cx="{x}" cy="-448" r="27" fill="{k["fur2"]}"/><circle cx="{x}" cy="-448" r="14" '
                       f'fill="{k["inner"]}"/>' for x in (-60, 60))
    return "".join(f'<path d="M{x - 30 * s},-428 L{x + 6 * s},-512 L{x + 34 * s},-440 Z" fill="{k["fur"]}" '
                   f'stroke="{k["fur2"]}" stroke-width="4" stroke-linejoin="round"/>'
                   f'<path d="M{x - 14 * s},-438 L{x + 6 * s},-490 L{x + 20 * s},-446 Z" fill="{INK}" opacity=".75"/>'
                   for x, s in ((-52, 1), (52, -1)))


def _head(k: dict) -> str:
    fox = k["ears"] == "pointy"
    face = (f'<path d="M-82,-372 Q-80,-322 -30,-312 L30,-312 Q80,-322 82,-372 Q60,-338 0,-336 Q-60,-338 -82,-372 Z" '
            f'fill="{k["snout"]}"/>' if fox else "")
    snout = f'<ellipse cx="6" cy="-352" rx="40" ry="30" fill="{k["snout"]}"/>'
    eye = ('<g class="t-eye" style="transform-box:fill-box;transform-origin:50% 50%">'
           '<ellipse cx="{x}" cy="-398" rx="13" ry="16" fill="#fff"/>'
           '<circle class="t-pupil" cx="{px}" cy="-396" r="7.5" fill="' + INK + '"/>'
           '<circle cx="{hx}" cy="-400" r="2.4" fill="#fff"/></g>')
    eyes = "".join(eye.format(x=x, px=x + 4, hx=x + 6) for x in (-26, 36))
    brows = (f'<g class="t-brows"><path d="M-38,-424 Q-26,-432 -14,-425" stroke="{k["fur2"]}" stroke-width="5" fill="none" '
             f'stroke-linecap="round"/><path d="M24,-425 Q36,-432 48,-424" stroke="{k["fur2"]}" stroke-width="5" '
             f'fill="none" stroke-linecap="round"/></g>')
    mouth = (f'<g class="t-mouth" transform="translate(8,-336)">'
             f'<ellipse class="t-open" cx="0" cy="2" rx="13" ry="1.5" fill="#5b1f2a"/>'
             f'<ellipse class="t-tongue" cx="0" cy="6" rx="7" ry="0" fill="#e86a7a"/>'
             f'<path class="t-closed" d="M-13,0 Q0,9 13,0" stroke="{INK}" stroke-width="4" fill="none" stroke-linecap="round"/></g>')
    cheeks = '<circle cx="-48" cy="-358" r="11" fill="#f08a8a" opacity=".35"/><circle cx="62" cy="-358" r="11" fill="#f08a8a" opacity=".35"/>'
    return (f'<g class="t-head" style="transform-box:fill-box;transform-origin:50% 92%">{_ears(k)}'
            f'<ellipse cx="0" cy="-380" rx="86" ry="80" fill="{k["fur"]}"/>{face}{snout}'
            f'<ellipse cx="8" cy="-370" rx="14" ry="10" fill="{INK}"/>{cheeks}{eyes}{brows}{mouth}</g>')


def _arm(side: str, sleeve: str, k: dict) -> str:
    """An arm hanging from the shoulder: upper arm, forearm (own joint) and paw."""
    x = 66 if side == "front" else -66
    return (f'<g class="t-arm-{side}" style="transform-origin:{x}px -282px">'
            f'<rect x="{x - 16}" y="-292" width="32" height="96" rx="16" fill="{sleeve}"/>'
            f'<g class="t-fore-{side}" style="transform-origin:{x}px -204px">'
            f'<rect x="{x - 15}" y="-212" width="30" height="86" rx="15" fill="{sleeve}"/>'
            f'<circle cx="{x}" cy="-122" r="19" fill="{k["fur"]}"/></g></g>')


def character(kind: str, x: float, y: float, height: float, *, cls: str, jacket: str, jacket2: str,
              pants: str = "#2f3a56", facing: str = "right") -> str:
    """One cartoon character with its feet at (x, y), `height` px tall, as SVG."""
    k = KINDS[kind]
    s = height / 500
    flip = -1 if facing == "left" else 1
    legs = "".join(f'<rect x="{lx}" y="-128" width="34" height="118" rx="14" fill="{pants}"/>'
                   f'<ellipse cx="{lx + 17 + 6}" cy="-10" rx="27" ry="12" fill="{INK}"/>' for lx in (-46, 12))
    torso = (f'<path d="M-72,-292 Q-80,-200 -64,-120 L64,-120 Q80,-200 72,-292 Q40,-312 0,-310 Q-40,-312 -72,-292 Z" '
             f'fill="{jacket}"/>'
             f'<path d="M-22,-306 L0,-250 L22,-306 Z" fill="#fff"/>'
             f'<path d="M-6,-290 L6,-290 L10,-232 L0,-218 L-10,-232 Z" fill="{jacket2}"/>'
             f'<path d="M-30,-304 L0,-250 L-8,-200" stroke="{jacket2}" stroke-width="3" fill="none"/>'
             f'<path d="M30,-304 L0,-250" stroke="{jacket2}" stroke-width="3" fill="none"/>'
             f'<rect x="-64" y="-140" width="128" height="20" rx="6" fill="{jacket2}" opacity=".35"/>')
    if kind == "fox":   # a tail behind the legs
        legs = (f'<path d="M-40,-150 Q-140,-170 -150,-90 Q-120,-40 -60,-90 Z" fill="{k["fur"]}"/>'
                f'<path d="M-130,-130 Q-160,-110 -150,-90 Q-130,-70 -112,-92 Z" fill="#fff4e8"/>') + legs
    body = (f'<g class="t-sway" style="transform-box:fill-box;transform-origin:50% 100%">{legs}'
            f'<g class="t-breathe" style="transform-box:fill-box;transform-origin:50% 100%">'
            f'{_arm("back", jacket2, k)}{torso}{_head(k)}{_arm("front", jacket, k)}</g></g>')
    return (f'<g class="toon {cls}" data-kind="{kind}" transform="translate({x:.1f},{y:.1f}) scale({s * flip:.4f},{s:.4f})">'
            f'<ellipse cx="0" cy="0" rx="90" ry="14" fill="#0f1b2d" opacity=".12"/>{body}</g>')


# --- the mouth follows the voice -----------------------------------------------------------------
def mouth_envelope(samples: np.ndarray, rate: int, fps: int) -> list[float]:
    """How open the mouth is in each video frame (0-1), from the loudness of the voice: quiet
    stretches close it, syllables open it. Smoothed (fast opening, slower closing) so it reads
    as speech, not flicker."""
    a = np.asarray(samples, dtype=np.float32)
    hop = max(1, int(rate / fps))
    n = max(1, int(np.ceil(len(a) / hop)))
    rms = np.array([float(np.sqrt(np.mean(a[i * hop:(i + 1) * hop] ** 2))) if len(a[i * hop:(i + 1) * hop]) else 0.0
                    for i in range(n)])
    peak = float(np.percentile(rms, 95)) if rms.any() else 0.0
    if peak < 1e-4:
        return [0.0] * n
    level = np.clip((rms / peak - 0.12) / 0.88, 0, 1)
    out, cur = [], 0.0
    for v in level:
        cur = cur + (v - cur) * (0.75 if v > cur else 0.45)
        out.append(round(float(min(1.0, cur)), 2))
    return out


RUNTIME = r"""
// cartoon characters: mouth from the voice, blinking, looking, gestures
function toon(t){
  const T=window.TL, R=(x)=>S(Math.min(Math.max(x,0),1));
  document.querySelectorAll('.toon').forEach((g,ci)=>{
    const who=g.dataset.who||'presenter';
    const m=(T.mouth&&T.mouth[who])||[]; const f=Math.round(t*25);
    const open=f<m.length? m[f] : 0;
    let talk=0;
    for(const w of (T.talk||[])) if(w[2]===who){ talk=Math.max(talk, Math.min(R((t-w[0]+0.15)/0.25), 1-R((t-w[1])/0.3))); }
    const q=(c)=>g.querySelector(c);
    // mouth
    const o=q('.t-open'), tg=q('.t-tongue'), cl=q('.t-closed');
    if(o){ o.setAttribute('ry',(1.5+15*open).toFixed(2)); o.setAttribute('rx',(13-2.5*open).toFixed(2)); }
    if(tg){ tg.setAttribute('ry',(open>0.35?5*(open-0.35):0).toFixed(2)); tg.setAttribute('cy',(4+10*open).toFixed(2)); }
    if(cl) cl.style.opacity=(open<0.12?1:0);
    const pa=q('.t-patch'); if(pa) pa.style.opacity=Math.min(1, open/0.12).toFixed(2);   // a company avatar: its own skin over the closed mouth
    // blink: about every 3-4 s, a different rhythm per character
    const ph=ci*1.37, cyc=(t+ph)%3.6, b=cyc<0.16? 1-Math.abs(cyc-0.08)/0.08 : 0;
    g.querySelectorAll('.t-eye').forEach(e=>e.style.transform=`scaleY(${(1-0.9*b).toFixed(3)})`);
    g.querySelectorAll('.t-lid').forEach(e=>e.style.opacity=(b>0.3?1:0));   // a company avatar: eyelids of its own skin
    // brows and head follow the stress of the voice
    const br=q('.t-brows'); if(br) br.style.transform=`translateY(${(-5*open*talk).toFixed(2)}px)`;
    const nod=talk*(2.2*Math.sin(t*2.6+ph)+1.2*open) + (1-talk)*0.8*Math.sin(t*0.7+ph);
    const h=q('.t-head'); if(h) h.style.transform=`rotate(${nod.toFixed(2)}deg)`;
    // pointing at the screen when something new appears while they talk (presenter: while an element is explained)
    let point=0;
    if(who==='presenter'){ for(const w of (T.active||[])) if(w){ point=Math.max(point, Math.min(R((t-w[0]+0.2)/0.35), 1-R((t-w[1]-0.6)/0.4))); } }
    else if(who==='expert'){ for(const a of (T.appear||[])) point=Math.max(point, Math.min(R((t-a+0.1)/0.35), 1-R((t-a-2.4)/0.4))*talk); }
    const af=q('.t-arm-front'), ff=q('.t-fore-front'), ab=q('.t-arm-back'), fb=q('.t-fore-back');
    const beat=talk*Math.max(0,Math.sin(t*2.1+ph));
    if(af) af.style.transform=`rotate(${(-8-112*point-14*beat*(1-point)).toFixed(2)}deg)`;
    if(ff) ff.style.transform=`rotate(${(-22*point-38*beat*(1-point)).toFixed(2)}deg)`;
    if(ab) ab.style.transform=`rotate(${(8+10*beat).toFixed(2)}deg)`;
    if(fb) fb.style.transform=`rotate(${(30*beat).toFixed(2)}deg)`;
    const sw=q('.t-sway'); if(sw) sw.style.transform=`translate(${((0.6+talk)*1.5*Math.sin(t*0.8+ph)).toFixed(2)}px,0) rotate(${(0.6*Math.sin(t*0.6+ph)).toFixed(2)}deg)`;
    const bre=q('.t-breathe'); if(bre) bre.style.transform=`scaleY(${(1+0.006*Math.sin(t*1.9+ph)).toFixed(4)})`;
  });
}
"""
