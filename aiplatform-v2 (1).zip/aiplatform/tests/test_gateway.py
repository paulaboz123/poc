"""Model calls through the gateway: routes, keys, JSON, embeddings and the spending lock."""
from __future__ import annotations

from datetime import datetime

import pytest

import config
import llm


def test_gateway_address_from_the_email_is_accepted_as_it_is():
    assert config._gateway_base("https://bifrost.example.com/anthropic/") == "https://bifrost.example.com"
    assert config._gateway_base("https://bifrost.example.com/v1") == "https://bifrost.example.com"
    assert config._gateway_base("https://x.example.com/llm/openai/v1") == "https://x.example.com/llm"


def test_budget_settings_can_never_exceed_the_hard_limit():
    assert config.clamp_budget(500) == config.HARD_DAILY_LIMIT_USD == 100
    assert config.clamp_budget(-3) == 0
    assert config.clamp_budget(20) == 20


def test_chat_uses_openai_route(gateway):
    assert llm.chat("Say OK", max_tokens=5) == "OK"
    assert llm.gateway_route() == "openai"


def test_falls_back_to_anthropic_route_when_openai_route_is_missing(gateway):
    gateway.state["openai_route"] = False
    assert llm.chat("Say OK", max_tokens=5) == "OK"
    assert llm.gateway_route() == "anthropic"
    assert "/anthropic/v1/messages" in gateway.state["calls"]


def test_image_description_works_on_both_routes(gateway, tmp_path):
    from PIL import Image
    img = tmp_path / "slide.png"
    Image.new("RGB", (64, 36), "white").save(img)
    assert llm.describe_image(img, "Describe").startswith("TYPE:")
    gateway.state["openai_route"] = False
    llm._route = None
    assert llm.describe_image(img, "Describe").startswith("TYPE:")


def test_wrong_key_gives_a_readable_message(gateway, monkeypatch):
    monkeypatch.setattr(config, "BIFROST_API_KEY", "wrong")
    with pytest.raises(llm.LLMError, match="rejected"):
        llm.chat("Say OK")


def test_json_still_works_when_gateway_refuses_response_format(gateway):
    gateway.state["reject_response_format"] = True
    schema = {"type": "object", "properties": {"term": {"type": "string"}}, "required": ["term"]}
    assert llm.chat_json("Define VTT. Answer in JSON.", schema)["term"] == "VTT file"


def test_embeddings_switch_to_one_text_per_request(gateway):
    vectors = llm.embed(["joining tables", "merge types", "clean keys"])
    assert len(vectors) == 3 and llm._embed_one_by_one


def test_lock_per_command_stops_further_calls(gateway, monkeypatch):
    monkeypatch.setattr(config, "RUN_BUDGET_USD", 0.0001)
    llm.chat("Say OK", max_tokens=5)                  # first call is allowed and costs something
    with pytest.raises(llm.BudgetExceeded, match="per command"):
        llm.chat("Say OK", max_tokens=5)


def test_daily_lock_counts_what_was_spent_earlier_today(gateway):
    config.COST_LOG.write_text("time,step,backend,model,in_tokens,in_tokens_est,out_tokens,seconds,est_cost_usd\n"
                               f"{datetime.now():%Y-%m-%dT%H:%M:%S},storyboard,bifrost,m,1,1,1,1,25.0\n")
    with pytest.raises(llm.BudgetExceeded, match="today"):
        llm.chat("Say OK")


def test_cost_estimate_is_never_zero_and_regional_ids_cost_more():
    assert llm.price("bedrock/some-new-model", "bifrost") == (5.0, 25.0)
    eu = llm.price("bedrock/eu.anthropic.claude-sonnet-5", "bifrost")
    plain = llm.price("anthropic.claude-sonnet-5", "bifrost")
    assert eu[0] > plain[0] and llm.price("llama3.1:8b", "ollama") == (0.0, 0.0)
