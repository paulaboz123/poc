"""Storyboard repair, drawing scenes, pronunciation and the quality helpers."""
from __future__ import annotations

import json

from PIL import Image

import config
import quality
import render
import storyboard
import tts


def test_storyboard_is_repaired_instead_of_breaking_the_video():
    sb = storyboard.Storyboard.model_validate({"title": "T", "goal": "G", "scenes": [
        {"visual": "bullets", "heading": "Intro", "items": ["a"], "narration": "Hello.", "sources": ["S1"]},
        {"visual": "slide", "slide": "[p9]", "heading": "X", "narration": "Talk.", "sources": ["S2", "S8"]},
        {"visual": "steps", "heading": "One step", "items": ["x"], "narration": "Steps.", "sources": []},
        {"visual": "bullets", "heading": "Empty", "narration": "  ", "sources": []}]})
    scenes, stats = storyboard.repair(sb, {"S1": {}, "S2": {}}, {}, 1)
    assert [s["visual"] for s in scenes] == ["title", "bullets", "bullets", "bullets"]   # title added, bad slide -> bullets
    assert scenes[2]["sources"] == ["S2"]                                                # invented S8 removed
    assert any("S8" in w for w in stats["warnings"]) and any("empty narration" in w for w in stats["warnings"])


def test_schema_sent_to_the_model_has_no_default_keys():
    assert '"default"' not in json.dumps(storyboard.SCHEMA)


def test_every_scene_type_renders_at_video_size(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "SLIDE_MASK", "0.7,0.6,1,1")
    slide = tmp_path / "slide.jpg"
    Image.new("RGB", (1280, 720), "white").save(slide)
    long_text = "A very long on-screen point that keeps going " * 6
    scenes = [{"visual": "title", "heading": "Joining tables"},
              {"visual": "bullets", "heading": "Why", "items": ["One view", long_text]},
              {"visual": "bullets", "heading": "Only a heading"},
              {"visual": "steps", "heading": "How", "items": ["Pick key", "Clean key", "Join", "Check"]},
              {"visual": "steps", "heading": "Many", "items": [long_text] * 6},
              {"visual": "slide"}]
    for i, sc in enumerate(scenes):
        out = render.render_scene(sc, tmp_path / f"s{i}.png", lesson_title="T", goal="G", page=f"{i}/6",
                                  slide_image=slide, caption="From: test")
        with Image.open(out) as im:
            assert im.size == (config.VIDEO_WIDTH, config.VIDEO_HEIGHT)


def test_pronunciation_changes_speech_but_not_subtitles(project):
    config.PRONUNCIATION_FILE.write_text("term,say_as\nKPI,K P I\n# comment,x\n", encoding="utf-8")
    assert tts.clean_for_speech("The KPI and KPIs [S2]") == "The K P I and KPIs"
    assert tts.clean_text("The KPI [S2]") == "The KPI"


def test_read_aloud_and_unusual_words_checks():
    slide = "Combine two tables on a key. Key is a column both tables share."
    assert quality.read_aloud_ratio("Combine two tables on a key. Key is a column both tables share.", slide) == 1.0
    assert quality.read_aloud_ratio("We merge data using a common identifier.", slide) == 0.0
    assert quality.unusual_words("The KPI and VLOOKUP in Q3, with PowerBI. OK.", {"KPI"}) == ["PowerBI", "Q3", "VLOOKUP"]
