"""Reading the input: transcripts, the description Excel, pairing files into the manifest."""
from __future__ import annotations

import subprocess

from conftest import needs_ffmpeg

import config
import ingest
import inventory
import store

VTT = """WEBVTT

1
00:00:01.000 --> 00:00:20.000
<v Anita Rao>Today we look at joining data, which means combining two tables on a shared key.</v>

2
00:00:21.000 --> 00:00:45.000
<v Anita Rao>The key is a column both tables have, for example the customer ID.</v>

3
00:00:46.000 --> 00:01:10.000
<v Ben Ito>A left join keeps every row of the first table.</v>
"""


def test_vtt_is_parsed_with_speakers_and_grouped_into_segments(tmp_path):
    path = tmp_path / "t.vtt"
    path.write_text(VTT, encoding="utf-8")
    cues = ingest.parse_transcript(path)
    assert [c.speaker for c in cues] == ["Anita Rao", "Anita Rao", "Ben Ito"]
    segments = ingest.build_segments(cues, "vid")
    assert segments[0]["start"] == 1.0 and segments[-1]["end"] == 70.0
    assert "Anita Rao: Today" in segments[0]["text"]


def test_docx_new_teams_layout(tmp_path):
    from docx import Document
    doc = Document()
    for line in ["Weekly sync", "October 3, 2026", "Anita Rao   0:03", "Joining data combines tables.",
                 "Ben Ito   0:15", "A left join keeps all rows."]:
        doc.add_paragraph(line)
    path = tmp_path / "t.docx"
    doc.save(path)
    cues = ingest.parse_transcript(path)
    assert [(c.speaker, c.start) for c in cues] == [("Anita Rao", 3.0), ("Ben Ito", 15.0)]


def test_description_rows_are_matched_by_number_then_by_name():
    entries = {"13": inventory.Entry("13", "Introduction to joining data", "d13"),
               "14": inventory.Entry("14", "Merge types explained", "d14")}
    assert inventory.match_entry("13. Introduction to joining data.mp4", entries) == (entries["13"], "")
    assert inventory.match_entry("013_Introduction to joining data.vtt", entries)[0] is entries["13"]
    assert inventory.match_entry("Merge types explained.mp4", entries) == (entries["14"], "")
    entry, problem = inventory.match_entry("13. Something else entirely.mp4", entries)
    assert entry is entries["13"] and "ANOTHER NAME" in problem
    assert inventory.match_entry("Random.mp4", entries) == (None, "NOT IN description.xlsx")


def test_description_excel_with_title_row_and_number_types(tmp_path):
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.append(["Video catalogue"])
    ws.append(["ID", "Name ", "Description"])
    ws.append([13.0, "Introduction to joining data", "What a join is."])
    ws.append(["14", "Merge types explained", None])
    path = tmp_path / "description.xlsx"
    wb.save(path)
    entries = inventory.load_descriptions(path)
    assert set(entries) == {"13", "14"}
    assert entries["13"].description == "What a join is." and entries["14"].description == ""


@needs_ffmpeg
def test_inventory_pairs_video_transcript_and_excel(project):
    (config.INPUT_DIR / "video").mkdir()
    (config.INPUT_DIR / "transcript").mkdir()
    subprocess.run([config.FFMPEG, "-loglevel", "error", "-f", "lavfi", "-i", "color=white:s=320x180:d=70",
                    "-pix_fmt", "yuv420p", str(config.INPUT_DIR / "video" / "13. Intro to joins.mp4")], check=True)
    (config.INPUT_DIR / "transcript" / "13. Intro to joins.vtt").write_text(VTT, encoding="utf-8")
    from openpyxl import Workbook
    wb = Workbook()
    wb.active.append(["id", "name", "description"])
    wb.active.append([13, "Intro to joins", "What a join is."])
    wb.save(config.INPUT_DIR / "description.xlsx")

    assert inventory.main() == 0
    (row,) = store.read_manifest()
    assert row["catalog_id"] == "13" and row["title"] == "Intro to joins"
    assert row["transcript_file"] == "transcript/13. Intro to joins.vtt" and row["check"] == ""
    assert row["video_id"].startswith("13-intro-to-joins")
