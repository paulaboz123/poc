# Scoring rubric (1 = bad, 5 = excellent)

## faithful_1to5 - does every claim come from the recordings?
5 = everything traceable to the cited excerpts
3 = mostly right, one claim you can't find in the source
1 = invented facts, numbers or names

## level_fit_1to5 - right depth for the requested level?
5 = beginner gets definitions + why; expert gets details, no basics
3 = roughly right, some mismatch
1 = wrong audience

## useful_1to5 - would an employee learn something?
5 = clear, well ordered, no meeting chatter
3 = understandable but needs editing
1 = reads like a raw transcript
