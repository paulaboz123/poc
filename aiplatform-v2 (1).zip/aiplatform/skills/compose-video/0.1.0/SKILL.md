---
name: compose-video
description: Turns excerpts and slides from internal training recordings into the storyboard of a short narrated video lesson - what the voice says in each scene and what the screen shows.
version: 0.1.0
---

# Compose video lesson

You write the storyboard for a short narrated video lesson for employees, using only
excerpts from internal training recordings. Transcript excerpts are labelled [S1], [S2] ...
Slides from the recordings that you may show are labelled [P1], [P2] ...

A voice reads the `narration` of each scene while the screen shows its `visual`.
The voice explains; the screen shows only the key points. Never read a slide aloud word
for word, and never put whole sentences on screen.

## Rules

1. Use only facts from the excerpts and slides. Never add outside knowledge, numbers or names.
   If they don't cover part of the topic, leave that part out.
2. Narration is spoken English: short sentences, active voice, "you" for the learner, no
   filler, no meeting logistics, no speaker names ("the trainer" if needed).
3. Each scene's narration is 25-70 words. Hit the total word target within 15%.
4. Match the learner level:
   - beginner: define every term, explain why it matters, one simple example
   - intermediate: skip common definitions, focus on how and when
   - expert: skip basics, focus on details, exceptions and trade-offs
5. List in `sources` the S-labels each scene's narration is based on. Only use labels that exist.

## Visuals (one per scene)

- `title`: first scene only. `heading` = the lesson title. Narration: what the learner will get.
- `slide`: shows an original slide; put its P-label in `slide`. Use it when the slide itself
  helps (a diagram, a table, a screenshot). The narration explains the slide, it does not read it.
  Use each slide at most once.
- `bullets`: `heading` plus 2-5 `items`, each at most 8 words, no full stops.
- `steps`: a process or sequence. `heading` plus 3-5 `items` in order, each at most 6 words.
- The last scene is `bullets` with heading "Key takeaways" and 3 items.

Mix the visuals: never more than two `bullets` scenes in a row.

## Fields

- title: specific to the topic, not generic
- goal: one sentence on what the learner can do after watching
- scenes: in teaching order (basics first)
