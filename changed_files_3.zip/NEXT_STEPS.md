# Next steps to the demo (~13 Nov)

Tick [x] when done. `uv run doctor.py` reminds you how many are left.

## Week 26-30 Oct
- [x] Better content: self-review of the script, goals -> example -> question -> recap, quiz.md
- [x] Topic map of the recordings (topics.py)
- [x] Long videos (4-15 min) as a course with chapters from the whole knowledge base (course.py)
- [ ] Make one 8-min course and one 5-min summary, read the scripts, watch the videos
- [ ] Run topics.py on the 4 videos, make 2-3 videos from its requests
- [ ] Animation synced with the voice (points appear as they are spoken, transitions)  <- NEXT
- [ ] Show Clara 1-2 videos, note her feedback
- [ ] Ask the platform team: Opus / Sonnet 5 model ids, is an image model available (EU)?

- [x] Senior pass: evaluation of videos/courses, privacy checks, run settings, voice cache, parallel chapters, CI, docs/DESIGN.md
- [ ] uv run evaluate.py --draft, fill must_mention, uv run evaluate.py (the baseline numbers)

## Week 2-6 Nov
- [ ] Quiz-based score in evaluate.py (questions from the recordings, answered from the video only)
- [ ] Sonnet vs Opus: same golden set, pairwise judge in both orders
- [ ] Icons, more diagram types (cycle, timeline), background music, voice choice
- [ ] The 2 audio files: transcripts with Whisper (local)
- [ ] Same topic in NotebookLM vs our video: compare
- [ ] Cost estimate: per minute of video, per month at scale

## Week 9-13 Nov
- [ ] Simple demo window in the browser (type a request, watch the video)
- [ ] Final review of the code
- [ ] For Clara: results, costs, limitations, next phase (animated characters, plugging into the platform)
- [ ] Demo rehearsal + a backup recording of the demo
