"""Practices around the model output: privacy checks, repetition, run settings, the voice cache,
a course surviving a failed chapter, and the evaluation run."""
from __future__ import annotations

import csv

from conftest import needs_ffmpeg
from test_end_to_end import _prepare_one_recording

import config
import course
import evaluate
import llm
import make_video
import quality
import storyboard
import tts


def test_personal_data_is_caught(gateway):
    vid = _prepare_one_recording()
    sb = {"sources": {"S1": {"video_id": vid}}, "scenes": [
        {"visual": "bullets", "heading": "Contact", "items": ["Write to anita.rao@example.com"], "narration": "Ask."},
        {"visual": "bullets", "heading": "Who", "items": [], "narration": "As Rao explained, call +41 61 688 1111."},
        {"visual": "bullets", "heading": "Fine", "items": ["Version 2.0 from 2024"], "narration": "All good."}]}
    fail, issues = quality.personal_data(sb)
    assert fail == ["scene 1: contains an e-mail address", "scene 2: contains a phone number"]
    assert issues == ["scene 2: names a person from the recording (Rao)"]


def test_repeated_chapters_are_flagged():
    same = "a join combines two tables on a shared key so related data shows up together"
    sb = {"scenes": [{"section": "Chapter 1: A", "narration": same},
                     {"section": "Chapter 2: B", "narration": same + " and that is all"},
                     {"section": "Chapter 3: C", "narration": "cleaning the key first avoids rows that never match"}]}
    found = quality.repeated_chapters(sb)
    assert len(found) == 1 and found[0].startswith("Chapter 2: B repeats")


def test_outputs_record_how_they_were_made(gateway):
    _prepare_one_recording()
    out_dir, _ = make_video.make("how to join two tables", minutes=1, plan_only=True)
    st = storyboard.load(out_dir)["settings"]
    assert st["skill"] == "compose-video 0.3.0" and len(st["prompt_version"]) == 10 and st["self_review"] is True
    assert f"prompts {st['prompt_version']}" in (out_dir / "script.md").read_text(encoding="utf-8")


@needs_ffmpeg
def test_rerender_only_speaks_what_changed(gateway, fake_voice, monkeypatch):
    _prepare_one_recording()
    out_dir, _ = make_video.make("how to join two tables", minutes=1)
    spoken = []
    real = tts.synthesize
    monkeypatch.setattr(tts, "synthesize", lambda text: (spoken.append(text), real(text))[1])
    sb = storyboard.load(out_dir)
    sb["scenes"][1]["narration"] = "A new sentence for the second scene only."
    store_path = out_dir / "storyboard.json"
    store_path.write_text(__import__("json").dumps(sb), encoding="utf-8")
    make_video.make(rerender=out_dir)
    assert spoken == ["A new sentence for the second scene only."]
    assert len(list((out_dir / "audio").glob("voice_*.wav"))) == len(sb["scenes"]) - (
        len(sb["scenes"]) - len({s["narration"] + str(s.get("pause_after")) for s in sb["scenes"]}))


def test_course_survives_a_failing_chapter(gateway, monkeypatch):
    _prepare_one_recording()
    real = course.make_chapter
    tries = []

    def flaky(n, *args, **kwargs):
        tries.append(n)
        if n == 1:
            raise llm.LLMError("broken JSON")
        return real(n, *args, **kwargs)

    monkeypatch.setattr(course, "make_chapter", flaky)
    out_dir = course.plan_course("how to join data", 6)
    sb = storyboard.load(out_dir)
    assert tries.count(1) == 2                                     # tried twice, then left out
    chapters = [s for s in sb["scenes"] if str(s.get("section", "")).startswith("Chapter")]
    assert chapters[0]["section"] == "Chapter 1: Checking joins" and chapters[0]["label"] == "CHAPTER 1 OF 1"
    assert all(x.startswith("C1S") for s in chapters for x in s["sources"])
    assert "left out after errors: Join basics" in sb["stats"]["warnings"][0]


def test_spending_lock_stops_a_course(gateway, monkeypatch):
    _prepare_one_recording()
    monkeypatch.setattr(config, "RUN_BUDGET_USD", 0.0)
    try:
        course.plan_course("how to join data", 6)
        raise AssertionError("expected BudgetExceeded")
    except llm.BudgetExceeded:
        pass


def test_evaluation_drafts_runs_and_compares(gateway, monkeypatch):
    _prepare_one_recording()
    monkeypatch.setattr(evaluate, "GOLDEN", config.ROOT / "tests" / "_golden.csv")
    monkeypatch.setattr(config, "EVAL_DIR", config.DATA_DIR / "eval")
    try:
        evaluate.draft_golden_set()
        with open(evaluate.GOLDEN, encoding="utf-8-sig") as f:
            rows = list(csv.DictReader(f))
    finally:
        evaluate.GOLDEN.unlink(missing_ok=True)
    assert [r["type"] for r in rows] == ["video", "video", "video", "course", "course", "lesson", "video"]
    assert rows[-1]["expect"] == "none"
    req = {**rows[0], "must_mention": "key;banana"}
    row = evaluate.run_one(req, None, review=True)
    assert row["status"] == "ok" and row["coverage"] == 0.5 and row["faithful"] == 4 and row["cost_usd"] > 0
    assert row["passed"] == 0                                       # coverage 0.5 < 0.6
    assert evaluate.run_one({**req, "must_mention": "key"}, None, review=False)["passed"] == 1
    monkeypatch.setattr(config, "MIN_SCORE", 0.99)
    refused = evaluate.run_one({**rows[-1], "minutes": "2"}, None, review=False)
    assert refused["status"] == "no material" and refused["passed"] == 1
    text = evaluate.compare_text({"passed": 1.0, "coverage": 0.8}, {"passed": 0.5, "coverage": 0.9})
    assert "passed" in text and "↑" in text and "↓" in text
