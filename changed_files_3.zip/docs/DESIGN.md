# How it works and why

## The flow

```
request in plain words ("8 min on X for beginners")              ask.py
   │  understood as: format, topic, minutes, level, wishes
   ├─ < 4 min ─► search the knowledge base ─► storyboard ─► self-review     make_video.py
   ├─ 4-15 min ► topic map ─► outline ─► chapters (in parallel) ─► frame     course.py
   └─ text ────► search ─► written lesson                                    lesson.py
                                   │
          voice per scene (Kokoro, local) ─► new slides (Pillow) ─► mp4 + mp3 + srt + quiz
                                   │
          quality checks ─► report.html            evaluation on a golden set ─► numbers
```

The knowledge base is prepared once per recording: transcript segments, slide text (OCR,
optionally described by a vision model), a search index, and a topic map (`topics.py`).

## Decisions

| Decision | Why | Alternative not taken |
|---|---|---|
| Storyboard as plain JSON between "think" and "render" | A person can read `script.md`, fix a sentence, and re-render without another model call; tests can check it | One model call straight to video: no review, no edits |
| Long videos as chapters from an outline | One huge answer gets vague and hits the output limit; small tasks keep quality up and run in parallel (the same split as PresentAgent and Paper2Video, see below) | One storyboard for 10 minutes |
| Outline from a topic map, not from search | Search finds similar sentences; a course needs the structure of the whole knowledge base | Top-k search for the whole request |
| Self-review pass | A second look against a checklist fixes weak examples, repetition and level mismatch for ~1-4 cents | Human review of every script |
| New slides only, original slides as knowledge | The goal is teaching, not copying meetings; no presenter faces or meeting chrome in the output | Screenshots of the recording |
| Answers checked and repaired in code (`repair()`) | A video must never break on one bad field from a model | Trust the model's JSON |
| Sources on every scene | Every claim can be traced to a recording and a minute; the review model checks against them | No traceability |
| Local voice (Kokoro) and rendering | Free, private, no extra approval; the model calls are the only paid step | Cloud TTS (better voices, cost, data leaves) |
| EU Bedrock models through the gateway, spending lock in code | Client rules; a loop can't burn money | Direct keys, no limit |

## Quality and safety practices

- **Grounding:** only excerpts go into the prompt, every scene cites them, invented labels are
  removed, scenes without sources are flagged, the model review scores faithfulness against
  the cited excerpts.
- **Refusal:** a request the recordings don't cover is refused (search score, or the outline's
  coverage = none) instead of being invented; the golden set has a request that must be refused.
- **Privacy:** e-mail addresses and phone numbers fail a video; names of people who spoke in
  the recordings are flagged (`quality.py`).
- **Evaluation:** `evaluate.py` runs a fixed golden set and compares with the last run: length,
  coverage of must-mention facts, invented sources, teaching structure, privacy, model review
  (faithful, level fit, clarity), cost and time. Run it after every prompt/model change.
- **Traceability:** every storyboard records model, prompt version, code version and switches.
- **Robustness:** retries on gateway errors, one repair round for bad JSON, a failed chapter is
  retried and then left out (with a warning) instead of losing the course, writes are atomic.
- **Cost:** spending lock per day and per command, cost of every call logged (`cost_log.csv`),
  the voice of unchanged scenes is reused on re-render.
- **Tests:** offline with a stand-in gateway and voice (no key, no cost), also in CI
  (`.github/workflows/tests.yml`); code checks with ruff.

## How it compares (research, Oct 2026)

| | This PoC | NotebookLM Video Overviews | PresentAgent / Paper2Video (research) | Synthesia, Colossyan (commercial) |
|---|---|---|---|---|
| Input | Teams recordings, transcripts, slides | uploaded sources | one document / paper | scripts, documents |
| Output | narrated video with new slides, 1-15 min, chapters, quiz, audio, text | narrated slides, or animation (Cinematic, Ultra plan); 2-5 min | narrated slides; Paper2Video adds cursor and talking head | avatar presenter videos, courses |
| Edit before render | yes (script.md / storyboard.json) | no, only regenerate | no | yes, in their editor |
| Sources per claim | yes | in the notebook, not in the video | no | no |
| Runs on client infra / EU models | yes | no (Google) | open source | no (SaaS) |
| Evaluation | golden set, model review, checks | - | quiz-based (PresentQuiz), pairwise judge (PresentArena) | - |

What the research says that matters here:
- The architecture (outline → slides → narration → TTS → assembly, slides in parallel) is the
  same as PresentAgent and Paper2Video; both report near-human or better quiz results.
- **Quiz-based evaluation** (questions from the source, answered from the video only) measures
  how much knowledge the video carries; a good next metric for `evaluate.py`.
- **Pairwise judging in both orders** is the fair way to compare two models or prompts.
- LLM judges are close to human experts on content and accuracy, **weak on visuals and pacing**
  (EduPanel): keep a human spot check for how it looks.
- A **pointer or highlight synced to the speech** strongly helps viewers find what is being
  talked about (Paper2Video) - this is the animation step.
- **Short reels** (30-60 s) beat long videos on a quiz in a 62-student study; learners asked
  for engaging intros, navigation, subtitles and notes - chapters, subtitles and the quiz
  cover part of that; a "shorts" mode and a handout are cheap additions.

## Known limits

- Static slides (animation is the next step); one voice; English only.
- Topic maps and outlines depend on transcript quality (Teams auto-transcripts).
- At thousands of recordings, topic maps need a second level (map of maps) and the
  index a proper vector store - both are behind `store.py`, the only file that touches data.
