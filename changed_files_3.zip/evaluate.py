"""
evaluate.py - runs a fixed set of requests (eval/golden_set.csv) and scores the results, so
"is it good?" is a number, and "did my change make it better?" a comparison of two numbers.

Run it after every change to a prompt, a model, retrieval or a setting, and before the demo.

  uv run evaluate.py --draft            # first time: writes a golden set from your recordings
  uv run evaluate.py                    # all requests (storyboards only: fast, ~$0.02-0.10 each)
  uv run evaluate.py --limit 3          # the first 3, for a quick check
  uv run evaluate.py --model <id>       # the same set with another model, to compare
  uv run evaluate.py --no-review        # without the model review (cheaper, fewer scores)

golden_set.csv, one row per request:
  id, type        lesson (text) | video (short) | course (4+ minutes, chapters)
  topic           the request in plain words
  minutes, level
  must_mention    facts the result must contain, separated by ';' (optional; you fill these in
                  from the recordings - they are the strongest check that nothing got lost)
  expect          ok, or none for a request the recordings don't cover (the system must refuse
                  it instead of inventing content: a test for hallucination)

Scores per request (automatic):
  length_ratio      words / target (ok within 0.85-1.15)
  coverage          share of must_mention facts found
  invalid_sources   source labels the model invented (must be 0)
  unsourced_scenes  scenes that cite nothing (possible invented content)
  teaching          objectives, example, question, recap present (videos and courses)
  privacy           personal data found (must be 0)
  faithful, level_fit, clarity   1-5 from the model review against the cited excerpts
  cost_usd, seconds
The summary at the end is compared with the previous run of the same golden set, so you see
at once what got better or worse. Manual columns (faithful_you, useful_you, comments) are for
your own spot checks with eval/rubric.md.
"""
from __future__ import annotations

import argparse
import csv
import logging
import sys
import time
from datetime import datetime
from pathlib import Path

import config
import course
import lesson as lesson_mod
import llm
import make_video
import quality
import store
import storyboard

log = logging.getLogger("evaluate")

GOLDEN = config.EVAL_DIR / "golden_set.csv"
GOLDEN_FIELDS = ["id", "type", "topic", "minutes", "level", "must_mention", "expect", "notes"]
RESULT_FIELDS = ["id", "type", "topic", "minutes", "level", "expect", "status", "passed", "words",
                 "length_ratio", "coverage", "missing_facts", "invalid_sources", "unsourced_scenes",
                 "teaching", "privacy", "faithful", "level_fit", "clarity", "cost_usd", "seconds",
                 "folder", "faithful_you", "useful_you", "comments"]
SUMMARY_KEYS = ["passed", "length_ratio", "coverage", "faithful", "level_fit", "clarity", "teaching",
                "cost_usd", "seconds"]


def coverage(text: str, must_mention: str) -> tuple[float | None, list[str]]:
    """Share of the ';'-separated facts found in the text (case-insensitive)."""
    facts = [f.strip() for f in must_mention.split(";") if f.strip()]
    if not facts:
        return None, []
    missing = [f for f in facts if f.lower() not in text.lower()]
    return round(1 - len(missing) / len(facts), 2), missing


# --- One request ------------------------------------------------------------------------------
def run_lesson(req: dict, model: str | None) -> dict:
    rec = lesson_mod.make_lesson(req["topic"], int(round(float(req["minutes"]))), req["level"], model=model)
    st = rec["stats"]
    text = lesson_mod.lesson_text(lesson_mod.Lesson(**rec["lesson"]))
    cov, missing = coverage(text, req.get("must_mention", ""))
    return {"words": st["words"], "length_ratio": st["length_ratio"], "coverage": "" if cov is None else cov,
            "missing_facts": "; ".join(missing), "invalid_sources": len(st["invalid_citations"]),
            "unsourced_scenes": len(st["sections_without_sources"]), "folder": rec["path"]}


def run_video(req: dict, model: str | None, review: bool) -> dict:
    """Storyboard only (the content is what is evaluated; voice and picture don't change it)."""
    minutes = float(req["minutes"])
    if req["type"] == "course":
        out_dir = course.plan_course(req["topic"], minutes, req["level"], model=model)
    else:
        out_dir, _ = make_video.make(req["topic"], None, minutes, req["level"], model, plan_only=True)
    sb = storyboard.load(out_dir)
    st = sb["stats"]
    text = "\n".join(quality.screen_and_voice_text(s) for s in sb["scenes"])
    cov, missing = coverage(text, req.get("must_mention", ""))
    fail, issues = quality.personal_data(sb)
    teaching = st.get("teaching", {})
    row = {"words": st["words"], "length_ratio": st["length_ratio"], "coverage": "" if cov is None else cov,
           "missing_facts": "; ".join(missing),
           "invalid_sources": sum("invented source labels" in w for w in st.get("warnings", [])),
           "unsourced_scenes": sum(1 for s in sb["scenes"] if not s["sources"]
                                   and s["visual"] not in ("title", "question", "answer")
                                   and s.get("section") not in ("Introduction", "Quiz", "Summary")),
           "teaching": round(sum(bool(v) for v in teaching.values()) / max(1, len(teaching)), 2),
           "privacy": len(fail) + len(issues), "folder": str(out_dir)}
    if review:
        r = quality.check(out_dir, review=True).get("review", {})
        row.update({k: r.get(k, "") for k in ("faithful", "level_fit", "clarity")})
    return row


def passed(row: dict) -> bool:
    """A request passes when it did what was expected and broke no hard rule."""
    if row["expect"] == "none":
        return row["status"] == "no material"
    if row["status"] != "ok":
        return False
    def value(key: str):
        v = row.get(key, "")
        return None if v in ("", None) else float(v)

    ratio, cov, faithful = value("length_ratio"), value("coverage"), value("faithful")
    hard = [not value("invalid_sources"), not value("privacy"),
            ratio is None or 0.75 <= ratio <= 1.25,
            cov is None or cov >= 0.6,
            faithful is None or faithful >= 4]
    return all(hard)


def run_one(req: dict, model: str | None, review: bool) -> dict:
    row = {k: req.get(k, "") for k in ("id", "type", "topic", "minutes", "level")}
    row["expect"] = (req.get("expect") or "ok").strip().lower()
    t0, cost0 = time.perf_counter(), llm.spent_this_run()
    try:
        if row["level"] not in lesson_mod.LEVELS:
            raise ValueError(f"level must be one of {list(lesson_mod.LEVELS)}")
        if req["type"] == "lesson":
            row.update(run_lesson(req, model), status="ok")
        elif req["type"] in ("video", "course"):
            row.update(run_video(req, model, review), status="ok")
        else:
            raise ValueError(f"type must be lesson, video or course, got {req['type']!r}")
    except llm.BudgetExceeded:
        raise
    except lesson_mod.NotEnoughMaterial as e:
        row.update(status="no material", comments=str(e)[:200])
    except Exception as e:   # one broken request must not stop the evaluation
        log.error("Request %s failed: %s", row["id"], e)
        row.update(status="error", comments=str(e)[:200])
    row["seconds"] = round(time.perf_counter() - t0, 1)
    row["cost_usd"] = round(llm.spent_this_run() - cost0, 4)
    row["passed"] = int(passed(row))
    return row


# --- Summary and comparison --------------------------------------------------------------------
def summary(rows: list[dict]) -> dict:
    """Averages over the requests (empty values are skipped)."""
    out = {}
    for k in SUMMARY_KEYS:
        vals = [float(r[k]) for r in rows if str(r.get(k, "")) not in ("", "None")]
        out[k] = round(sum(vals) / len(vals), 3) if vals else None
    return out


def previous_run(current: Path) -> Path | None:
    runs = sorted(p for p in (config.EVAL_DIR / "results").glob("run_*.csv") if p != current)
    return runs[-1] if runs else None


def read_rows(path: Path) -> list[dict]:
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def compare_text(now: dict, before: dict | None) -> str:
    lines = [f"{'score':<14}{'now':>9}{'before':>9}"]
    for k in SUMMARY_KEYS:
        a, b = now.get(k), (before or {}).get(k)
        fa = "-" if a is None else f"{a:.2f}"
        fb = "-" if b is None else f"{b:.2f}"
        arrow = "" if a is None or b is None or abs(a - b) < 1e-9 else (" ↑" if a > b else " ↓")
        lines.append(f"{k:<14}{fa:>9}{fb:>9}{arrow}")
    return "\n".join(lines)


# --- Golden set draft ----------------------------------------------------------------------------
def draft_golden_set() -> Path:
    """A first golden set from the topic map: short videos on the deepest topics, a course, a
    summary, a text lesson and a request the recordings don't cover. Fill in must_mention."""
    import topics
    rows = store.available_recordings()
    if not rows:
        raise ValueError("No processed recordings yet.")
    maps = [topics.analyse_recording(r) for r in rows]
    ranked = sorted(((t, m) for m in maps for t in m["topics"]),
                    key=lambda x: {"deep": 0, "solid": 1, "brief": 2}[x[0]["depth"]])
    out, n = [], 0

    def add(type_, topic, minutes, level, expect="ok", notes=""):
        nonlocal n
        n += 1
        out.append({"id": n, "type": type_, "topic": topic, "minutes": minutes, "level": level,
                    "must_mention": "", "expect": expect, "notes": notes})

    for t, m in ranked[:4]:
        add("video", t["title"], 2, t["level"], notes=f"recording {m['ref']} {t['start']}-{t['end']}")
    if ranked:
        add("video", ranked[0][0]["title"], 2, "expert", notes="same topic, other level")
    add("course", "everything in the recordings", 8, "beginner", notes="course across all recordings")
    add("course", "a summary of all recordings for managers", 5, "intermediate", notes="summary")
    if ranked:
        add("lesson", ranked[0][0]["title"], 5, "beginner", notes="text lesson")
    add("video", "how to bake sourdough bread", 2, "beginner", expect="none",
        notes="not in the recordings: must be refused")
    GOLDEN.parent.mkdir(parents=True, exist_ok=True)
    with open(GOLDEN, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=GOLDEN_FIELDS)
        w.writeheader()
        w.writerows(out)
    return GOLDEN


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--limit", type=int)
    ap.add_argument("--model")
    ap.add_argument("--no-review", action="store_true", help="skip the model review (cheaper)")
    ap.add_argument("--draft", action="store_true", help="write a first golden set from the recordings")
    args = ap.parse_args()
    config.setup_logging()
    try:
        if args.draft:
            if GOLDEN.exists() and "<topic" not in GOLDEN.read_text(encoding="utf-8-sig"):
                log.error("%s already has your requests; delete it first to draft a new one", GOLDEN)
                return 1
            print(f"Golden set drafted: {draft_golden_set()}\nOpen it, fill in must_mention, then: uv run evaluate.py")
            return 0
        if not GOLDEN.exists():
            log.error("Missing %s. Create it with: uv run evaluate.py --draft", GOLDEN)
            return 1
        with open(GOLDEN, encoding="utf-8-sig", newline="") as f:
            requests = [r for r in csv.DictReader(f) if r.get("topic", "").strip() and "<topic" not in r["topic"]]
        for r in requests:
            r["type"] = (r.get("type") or "lesson").strip().lower()
            r["minutes"] = r.get("minutes") or "2"
            r["level"] = (r.get("level") or "beginner").strip().lower()
        requests = requests[: args.limit] if args.limit else requests
        if not requests:
            log.error("No requests in %s (run: uv run evaluate.py --draft)", GOLDEN)
            return 1

        out_dir = config.EVAL_DIR / "results"
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / f"run_{datetime.now():%Y%m%d-%H%M%S}_{store.slugify(args.model or config.CHAT_MODEL, 50)}.csv"
        results = []
        for n, req in enumerate(requests, 1):
            log.info("[%s/%s] %s: %s", n, len(requests), req["type"], req["topic"])
            results.append(run_one(req, args.model, not args.no_review))
            _write(out_path, results)   # after every request, so a crash loses nothing
    except llm.BudgetExceeded as e:
        log.error("%s", e)
        return 1
    except (RuntimeError, ValueError, OSError) as e:
        log.error("%s", e)
        return 1

    now = summary(results)
    prev = previous_run(out_path)
    before = summary(read_rows(prev)) if prev else None
    print(f"\n{sum(r['passed'] for r in results)}/{len(results)} passed  ·  "
          f"total cost ~${llm.spent_this_run():.2f}\n")
    print(compare_text(now, before))
    if prev:
        print(f"\n(before = {prev.name})")
    store.write_json(out_path.with_suffix(".json"), {"summary": now, "settings": storyboard.settings(args.model),
                                                     "rows": results})
    print(f"\nResults: {out_path}  (spot-check a few: faithful_you, useful_you, eval/rubric.md)")
    return 0


def _write(path: Path, rows: list[dict]) -> None:
    """Save the results table as CSV (opens in Excel); skipped while Excel has it open."""
    try:
        with open(path, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=RESULT_FIELDS, extrasaction="ignore")
            w.writeheader()
            w.writerows(rows)
    except PermissionError:
        log.warning("%s is open in Excel - results will be written after the next request", path.name)


if __name__ == "__main__":
    sys.exit(main())
