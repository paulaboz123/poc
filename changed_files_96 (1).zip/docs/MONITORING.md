# Monitoring and answer evaluation

Two questions, every day: **does it work** (up, fast enough, not failing, within the spending limit) and **are
the answers still right** (grounded in the material, not getting worse). Code: `monitoring.py`.

## Where to look

| Who | Where | What |
|---|---|---|
| Product owner, team | The page, tab **Prices & results**, "Quality and health" | The last 7 days: answers, what the check removed, the judge's score, votes, time per format, failures, what needs attention |
| Team | `uv run monitoring.py --days 7` (in the pod: `kubectl exec <pod> -- python monitoring.py`) | The same as Markdown tables |
| The cluster | `/metrics` on port 9100 (Prometheus), `charts/proto-learning-agent` (`monitoring.prometheusOperator`: alerts) | Counts only: no questions, no text |
| Anyone | The pod's logs (JSON lines) | Every request and failure; "Job failed" with the reason |

## What is measured

| Measure | Where it comes from | Cost |
|---|---|---|
| Requests by format and result (done, refused, not covered, error), time (median, 95%) | the job worker (`app.work`) | free |
| Claude calls, tokens (input, output, cache), estimated cost by step; today's spend vs the limit | every call (`llm.py`) | free |
| Requests waiting and running | the job line | free |
| Results given back from the library instead of made again (`lesson_studio_library_reused_total`; `"reused"` on each request line) | `ask.run` (`library.py`, docs/COSTS.md) | free |
| **Every answer**: answered / not in the material / refused / from the cache; sentences the check kept, corrected or removed; numbers not in the sources; a second search needed; the best rerank score | what `answer.py` already checks for each answer | free |
| **A sample of answers** (`EVAL_SAMPLE`, the pod: 1 in 10) graded claim by claim against the excerpts by `JUDGE_MODEL` | `qa_eval.grounding`, the same judge as the offline evaluation | 1 Claude call per graded answer, under the spending lock; the real cost is the "judge grounding" step in `uv run usage.py --steps` |
| Votes 👍 / 👎 | the chat | free |

Everything is also written to `data/output/monitor.jsonl` (one line per request, answer and graded answer).

## Answer evaluation: four layers

| Layer | When | How | Fails when |
|---|---|---|---|
| 1. Checks on every answer | every answer, before it is shown | sources, quotes, numbers in code; sentence by sentence by a model (`VERIFY_ANSWERS`) | an unsupported sentence is removed, never shown |
| 2. Judge on a sample | 1 answer in 10 (`EVAL_SAMPLE`) | claim by claim against the excerpts | the week's score below 0.9 (alert, page) |
| 3. 👎 become test questions | weekly | `uv run monitoring.py --export-down` writes them to `data/eval/from_feedback.csv`; add the expected answer, then they are part of the test set | - |
| 4. Test plan with a gate | before every release, and every Monday (`evalCronJob.enabled` in the chart) | `uv run qa_eval.py --set <plan> --gate`: the test plan + the 👎 questions | a hallucination, faithfulness below the line, or fewer questions passed than the last run: the release stops (`kubectl rollout undo`) |

Layers 1-2 watch real questions; 3-4 make sure that what once went wrong is checked every time after.
Best `JUDGE_MODEL` = Opus while Sonnet writes: a model grades its own text too kindly (the page says when the
judge is the writer).

## Needs attention (thresholds)

The same values in the page (`monitoring.ATTENTION`) and in the alerts (the chart's `templates/monitoring.yaml`). Starting
values, to be tuned after the first weeks.

| What | Threshold | First step |
|---|---|---|
| Failed requests | over 10% | the logs: "Job failed" and the reason |
| Sentences removed by the check | over 15% | `qa_eval.py --gate` on the plan: did the search or the writer get worse? |
| The judge's score (sample) | under 0.9 | open the graded answers (`monitor.jsonl`, type `judged`), then the plan |
| 👎 | over 20% of votes | `monitoring.py --export-down`, read the comments |
| Today's spend | over 80% of the limit | `usage.py --steps`: which step costs |
| The app does not answer | 10 minutes | `kubectl get pods`, `kubectl logs` |
| The weekly test plan run | its gate failed | `kubectl logs job/<name>` |

## Settings

| Setting | Default | The pod |
|---|---|---|
| `EVAL_SAMPLE` | 0 (none) | 0.1 |
| `JUDGE_MODEL` | empty = `REVIEW_MODEL`, else `CHAT_MODEL` | Opus (in `.env`) |
| `METRICS_PORT` | 0 (off) | 9100 (not on the page's address) |

Without Prometheus in the cluster: the page, the report and the JSON logs are enough. CloudWatch Logs Insights,
failures per hour:

```
filter message = "Job failed" | stats count() by bin(1h)
```
