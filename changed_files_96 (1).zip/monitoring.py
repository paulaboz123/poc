"""Monitoring, and answers evaluated while the app is in use (docs/MONITORING.md).

- Metrics for Prometheus on METRICS_PORT (/metrics): requests, time, errors, Claude calls, tokens and cost, the
  spending lock, the requests waiting, and the answers' quality signals. Counts only: no questions, no text.
- Every request and every answer in data/output/monitor.jsonl: an answer with its quality signals (the checks in
  code, the sentence-by-sentence check, the search). A sample of the answers (EVAL_SAMPLE) is also graded claim by
  claim by the judge model, as qa_eval.py does it.
- The report for the last days (in the page, tab Prices & results, and `uv run monitoring.py --days 7`), with what
  needs attention; the 👎 answers exported as test questions (--export-down), checked with qa_eval.py before every
  release.
"""
from __future__ import annotations

import argparse
import csv
import json
import logging
import random
import statistics
import threading
import time
from collections.abc import Callable
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import config

log = logging.getLogger("monitoring")

# --- thresholds for "needs attention" (the alerts in charts/proto-learning-agent/templates/monitoring.yaml use the same): starting values
ATTENTION = {"error_share": 0.10,        # requests that failed
             "removed_share": 0.15,      # answer sentences the check removed (the writer or the search got worse)
             "faithfulness": 0.90,       # the judge's score on the sampled answers
             "down_share": 0.20,         # 👎 of all votes
             "spend_share": 0.80}        # of the daily spending limit

# name: (type, help). Counters end in _total; histograms in _seconds.
METRICS: dict[str, tuple[str, str]] = {
    "lesson_studio_requests_total": ("counter", "Requests finished, by format and status"),
    "lesson_studio_request_seconds": ("histogram", "Time to make a request, by format"),
    "lesson_studio_llm_calls_total": ("counter", "Claude calls, by step and model"),
    "lesson_studio_llm_tokens_total": ("counter", "Claude tokens, by kind (input, output, cache_read, cache_write)"),
    "lesson_studio_llm_cost_usd_total": ("counter", "Estimated Claude cost in USD, by step"),
    "lesson_studio_llm_call_seconds": ("histogram", "Time of one Claude call, by step"),
    "lesson_studio_answers_total": ("counter", "Answers, by outcome (answered, not_in_material, refused, cached)"),
    "lesson_studio_answer_sentences_total": ("counter", "Answer sentences after the check: supported, corrected, removed"),
    "lesson_studio_answer_searched_again_total": ("counter", "Answers that needed a second search"),
    "lesson_studio_answers_judged_total": ("counter", "Sampled answers graded by the judge model"),
    "lesson_studio_answer_faithfulness_points_total": ("counter", "Sum of the judge's faithfulness scores (0-1 each; "
                                                                  "divided by the judged answers: the mean)"),
    "lesson_studio_feedback_total": ("counter", "Votes on results, by format and vote (up, down)"),
    "lesson_studio_library_reused_total": ("counter", "Results given back from the library instead of made again, "
                                                      "by format"),
}
BUCKETS = (0.5, 1, 2, 5, 10, 30, 60, 120, 300, 600, 1200)

_lock = threading.Lock()
_counters: dict[tuple[str, tuple[tuple[str, str], ...]], float] = {}
_histograms: dict[tuple[str, tuple[tuple[str, str], ...]], list[float]] = {}   # bucket counts, then sum, count
GAUGES: dict[str, tuple[str, Callable[[], float]]] = {}   # name: (help, read at each scrape); app.py adds its own


def _key(name: str, labels: dict[str, str]) -> tuple[str, tuple[tuple[str, str], ...]]:
    return name, tuple(sorted((k, str(v)) for k, v in labels.items()))


def inc(name: str, value: float = 1.0, **labels: str) -> None:
    """Add `value` to a counter."""
    with _lock:
        k = _key(name, labels)
        _counters[k] = _counters.get(k, 0.0) + value


def observe(name: str, value: float, **labels: str) -> None:
    """Count one measurement (seconds) in a histogram."""
    with _lock:
        h = _histograms.setdefault(_key(name, labels), [0.0] * (len(BUCKETS) + 2))
        for i, b in enumerate(BUCKETS):
            if value <= b:
                h[i] += 1
        h[-2] += value
        h[-1] += 1


def reset() -> None:
    """Forget every count (tests)."""
    with _lock:
        _counters.clear()
        _histograms.clear()


def _escape(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")


def _labels(pairs: tuple[tuple[str, str], ...], le: str = "") -> str:
    """{a="1",b="2"} (with le="..." for a histogram bucket), or nothing when there are no labels."""
    parts = [f'{k}="{_escape(v)}"' for k, v in pairs] + ([f'le="{le}"'] if le else [])
    return "{" + ",".join(parts) + "}" if parts else ""


def render() -> str:
    """Every metric in the Prometheus text format (what /metrics answers)."""
    lines: list[str] = []
    with _lock:
        counters, histograms = dict(_counters), {k: list(v) for k, v in _histograms.items()}
    for name, (kind, help_) in METRICS.items():
        lines += [f"# HELP {name} {help_}", f"# TYPE {name} {kind}"]
        if kind == "counter":
            lines += [f"{name}{_labels(p)} {v:g}" for (n, p), v in sorted(counters.items()) if n == name]
            continue
        for (n, p), h in sorted(histograms.items()):
            if n == name:
                lines += [f"{name}_bucket{_labels(p, f'{b:g}')} {h[i]:g}" for i, b in enumerate(BUCKETS)]
                lines += [f"{name}_bucket{_labels(p, '+Inf')} {h[-1]:g}",
                          f"{name}_sum{_labels(p)} {h[-2]:g}", f"{name}_count{_labels(p)} {h[-1]:g}"]
    for name, (help_, read) in {**_builtin_gauges(), **GAUGES}.items():
        try:
            value = float(read())
        except Exception:   # noqa: BLE001 - one unreadable value must not hide the others
            continue
        lines += [f"# HELP {name} {help_}", f"# TYPE {name} gauge", f"{name} {value:g}"]
    lines += ["# HELP lesson_studio_info The running version", "# TYPE lesson_studio_info gauge",
              f'lesson_studio_info{{version="{config.APP_VERSION}"}} 1']
    return "\n".join(lines) + "\n"


def _builtin_gauges() -> dict[str, tuple[str, Callable[[], float]]]:
    import llm
    return {"lesson_studio_spent_today_usd": ("Estimated spend today (the spending lock's count)", llm.spent_today),
            "lesson_studio_daily_limit_usd": ("The daily spending limit", lambda: config.DAILY_BUDGET_USD)}


# --- what happened: called by app.py, llm.py and chats.py ---------------------------------------------------------
def log_file() -> Path:
    """One JSON line per finished request, per answer and per judged answer (data/output/monitor.jsonl)."""
    return config.OUTPUT_DIR / "monitor.jsonl"


def _write(line: dict) -> None:
    try:
        config.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        with _lock, open(log_file(), "a", encoding="utf-8") as f:
            f.write(json.dumps({"time": datetime.now().isoformat(timespec="seconds"), **line}, ensure_ascii=False) + "\n")
    except OSError as e:   # monitoring must never stop a request
        log.warning("Could not write %s: %s", log_file(), e)


def llm_call(step: str, model: str, tokens_in: int, tokens_out: int, cache_read: int, cache_write: int,
             cost: float, seconds: float) -> None:
    """One Claude call (from llm.py, with its cost row)."""
    inc("lesson_studio_llm_calls_total", step=step, model=model)
    for kind, n in (("input", tokens_in), ("output", tokens_out), ("cache_read", cache_read), ("cache_write", cache_write)):
        if n:
            inc("lesson_studio_llm_tokens_total", n, kind=kind)
    inc("lesson_studio_llm_cost_usd_total", cost, step=step)
    observe("lesson_studio_llm_call_seconds", seconds, step=step)


def request_finished(job: dict, result: dict | None, error: BaseException | None = None) -> None:
    """A request from the page is done (app.work): counted, written, and an answer checked (answer_seen)."""
    fmt = (result or {}).get("format") or (job.get("overrides") or {}).get("format") or job.get("kind") or "unknown"
    status = job.get("status", "unknown")
    reason = "" if status != "error" else type(error).__name__ if error else "unknown"
    seconds = float(job.get("finished", time.time()) - job.get("started", time.time()))
    inc("lesson_studio_requests_total", format=fmt, status=status)
    observe("lesson_studio_request_seconds", seconds, format=fmt)
    log.info("Request %s (%s): %s in %.0f s%s", job.get("id", ""), fmt, status, seconds, f", {reason}" if reason else "")
    _write({"type": "request", "job": job.get("id", ""), "format": fmt, "status": status, "reason": reason,
            "seconds": round(seconds, 1), "cost_usd": round(float((result or {}).get("cost_usd") or 0), 5),
            "reused": bool((result or {}).get("reused"))})
    record = (result or {}).get("answer")
    if fmt == "answer" and isinstance(record, dict):
        answer_seen(record, job.get("id", ""))


def signals(record: dict) -> dict:
    """An answer's quality signals, from what answer.py already checked (no extra cost)."""
    checks = record.get("checks") or {}
    v = checks.get("verified") or {}
    outcome = ("cached" if record.get("from_cache") else "refused" if record.get("refused")
               else "not_in_material" if record.get("not_in_material") else "answered")
    reranks = [c["rerank"] for c in record.get("candidates", []) if isinstance(c.get("rerank"), (int, float))]
    return {"outcome": outcome, "sentences": len(record.get("sentences", [])),
            "checked": bool(v.get("checked")), "supported": int(v.get("supported") or 0),
            "corrected": int(v.get("corrected") or 0), "removed": len(v.get("removed") or []),
            "numbers_not_in_sources": len(checks.get("numbers_not_in_sources") or []),
            "invalid_labels": len(checks.get("invalid_labels") or []),
            "searched_again": bool(record.get("retried")), "sources": len(record.get("excerpts") or {}),
            "best_rerank": max(reranks) if reranks else None, "cost_usd": record.get("cost_usd", 0),
            "seconds": record.get("seconds", 0)}


def answer_seen(record: dict, job_id: str = "") -> threading.Thread | None:
    """Count and write an answer's signals; grade one in EVAL_SAMPLE with the judge (in its own thread, so the
    next request does not wait). Returns that thread, or None when this answer is not graded."""
    s = signals(record)
    inc("lesson_studio_answers_total", outcome=s["outcome"])
    for verdict in ("supported", "corrected", "removed"):
        if s[verdict]:
            inc("lesson_studio_answer_sentences_total", s[verdict], verdict=verdict)
    if s["searched_again"]:
        inc("lesson_studio_answer_searched_again_total")
    folder = Path(record.get("folder") or "").name
    _write({"type": "answer", "job": job_id, "folder": folder, "question": str(record.get("question", ""))[:300], **s})
    if s["outcome"] != "answered" or not record.get("sentences") or random.random() >= config.EVAL_SAMPLE:
        return None
    t = threading.Thread(target=judge, args=(record, folder), name="judge", daemon=True)
    t.start()
    return t


def judge(record: dict, folder: str = "") -> dict | None:
    """Grade one answer claim by claim against its excerpts (qa_eval.grounding, the judge model): the same score
    as the offline evaluation, on real questions. Costs one call; stopped by the spending lock like any other."""
    import llm
    import qa_eval
    model = qa_eval.judge_model()
    try:
        g = qa_eval.grounding(record, model)
    except (llm.LLMError, llm.BudgetExceeded) as e:
        log.warning("The sampled answer was not graded: %s", e)
        return None
    if g.get("faithfulness") is None:
        return None
    inc("lesson_studio_answers_judged_total")
    inc("lesson_studio_answer_faithfulness_points_total", g["faithfulness"])
    line = {"type": "judged", "folder": folder, "model": model, "self_judged": qa_eval.judges_itself(model),
            "faithfulness": g["faithfulness"], "hallucination_rate": g["hallucination_rate"],
            "unsupported": g["unsupported"][:5]}
    _write(line)
    if g["unsupported"]:
        log.warning("Judge: unsupported claims in %s: %s", folder, "; ".join(g["unsupported"][:3]))
    return line


def feedback(rating: str, fmt: str) -> None:
    """A 👍 or 👎 on a result (chats.add_feedback)."""
    inc("lesson_studio_feedback_total", format=fmt or "unknown", vote=rating)


# --- /metrics on its own port: the cluster's Prometheus reads it; it is not on the page's address ------------------
class _MetricsHandler(BaseHTTPRequestHandler):
    def do_GET(self) -> None:
        """/metrics: the metrics; anything else: 404."""
        if self.path.split("?")[0] != "/metrics":
            self.send_error(404)
            return
        body = render().encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; version=0.0.4; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt: str, *args: object) -> None:
        """Quiet: Prometheus asks every 30 s."""


def serve(port: int, host: str = "0.0.0.0") -> ThreadingHTTPServer:
    """Start /metrics on `port` in a background thread."""
    server = ThreadingHTTPServer((host, port), _MetricsHandler)
    server.daemon_threads = True
    threading.Thread(target=server.serve_forever, name="metrics", daemon=True).start()
    log.info("Metrics on http://%s:%s/metrics", host, server.server_address[1])
    return server


# --- the report: the page and the command line ---------------------------------------------------------------------
def _lines(days: int) -> list[dict]:
    if not log_file().exists():
        return []
    since = (datetime.now() - timedelta(days=days)).isoformat(timespec="seconds")
    out = []
    with open(log_file(), encoding="utf-8") as f:
        for raw in f:
            try:
                line = json.loads(raw)
            except ValueError:
                continue
            if line.get("time", "") >= since:
                out.append(line)
    return out


def _votes(days: int) -> list[dict]:
    import chats
    path = chats.feedback_file()
    if not path.exists():
        return []
    since = (datetime.now() - timedelta(days=days)).isoformat(timespec="seconds")
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [r for r in csv.DictReader(f) if (r.get("time") or "") >= since]
    newest: dict[str, dict] = {}
    for r in rows:   # the newest vote on a result counts
        newest[r.get("result_folder") or r.get("request", "")] = r
    return list(newest.values())


def _pct(values: list[float], q: float) -> float | None:
    if not values:
        return None
    values = sorted(values)
    return round(values[min(len(values) - 1, int(q * len(values)))], 1)


def _share(part: float, whole: float) -> float | None:
    return round(part / whole, 3) if whole else None


def report(days: int = 7) -> dict:
    """The last `days`: requests (count, errors, time), answers (quality signals, the judge's score), votes,
    spend, and what needs attention."""
    import llm
    lines = _lines(days)
    requests = [x for x in lines if x.get("type") == "request"]
    answers = [x for x in lines if x.get("type") == "answer"]
    judged = [x for x in lines if x.get("type") == "judged"]
    votes = _votes(days)
    by_format = []
    for fmt in sorted({r["format"] for r in requests}):
        rs = [r for r in requests if r["format"] == fmt]
        secs = [r["seconds"] for r in rs if r["status"] == "done"]
        by_format.append({"format": fmt, "count": len(rs), "errors": sum(r["status"] == "error" for r in rs),
                          "median_s": _pct(secs, 0.5), "p95_s": _pct(secs, 0.95),
                          "cost_usd": round(sum(r.get("cost_usd", 0) for r in rs), 3)})
    sentences = sum(a["supported"] + a["corrected"] + a["removed"] for a in answers if a["checked"])
    out = {
        "days": days,
        "requests": len(requests),
        "errors": sum(r["status"] == "error" for r in requests),
        "by_format": by_format,
        "answers": len(answers),
        "answered": sum(a["outcome"] == "answered" for a in answers),
        "not_in_material": sum(a["outcome"] == "not_in_material" for a in answers),
        "refused": sum(a["outcome"] == "refused" for a in answers),
        "from_cache": sum(a["outcome"] == "cached" for a in answers),
        "removed_share": _share(sum(a["removed"] for a in answers if a["checked"]), sentences),
        "corrected_share": _share(sum(a["corrected"] for a in answers if a["checked"]), sentences),
        "searched_again": sum(bool(a["searched_again"]) for a in answers),
        "judged": len(judged),
        "faithfulness": round(statistics.mean(j["faithfulness"] for j in judged), 3) if judged else None,
        "self_judged": any(j.get("self_judged") for j in judged),
        "votes_up": sum(v.get("rating") == "up" for v in votes),
        "votes_down": sum(v.get("rating") == "down" for v in votes),
        "spent_today_usd": round(llm.spent_today(), 3),
        "daily_limit_usd": config.DAILY_BUDGET_USD,
        "sample": config.EVAL_SAMPLE,
    }
    out["attention"] = attention(out)
    return out


def attention(r: dict) -> list[str]:
    """What in the report is over its threshold (ATTENTION), in words."""
    a = ATTENTION
    notes = []
    if r["requests"] and r["errors"] / r["requests"] > a["error_share"]:
        notes.append(f"{r['errors']} of {r['requests']} requests failed: see the logs (Job failed)")
    if (r["removed_share"] or 0) > a["removed_share"]:
        notes.append(f"the check removed {r['removed_share']:.0%} of answer sentences: run qa_eval.py on the test plan")
    if r["faithfulness"] is not None and r["faithfulness"] < a["faithfulness"]:
        notes.append(f"the judge's score on sampled answers is {r['faithfulness']:.2f} (below {a['faithfulness']})")
    votes = r["votes_up"] + r["votes_down"]
    if votes and r["votes_down"] / votes > a["down_share"]:
        notes.append(f"{r['votes_down']} of {votes} votes are 👎: export them (monitoring.py --export-down) and check")
    if r["daily_limit_usd"] and r["spent_today_usd"] / r["daily_limit_usd"] > a["spend_share"]:
        notes.append(f"today's spend ${r['spent_today_usd']} is near the ${r['daily_limit_usd']} limit")
    return notes


def export_down(path: Path, days: int = 30) -> int:
    """The 👎 answers as test questions (the CSV format of qa_eval.py --set), to be checked and given the expected
    answer by a person, then added to the test set. Returns how many."""
    rows = [v for v in _votes(days) if v.get("rating") == "down" and v.get("format") == "answer"]
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8-sig", newline="") as f:   # -sig: Excel opens it
        w = csv.DictWriter(f, fieldnames=["id", "type", "question", "expected_answer", "key_facts", "comment",
                                          "result_folder"])
        w.writeheader()
        for i, v in enumerate(rows, 1):
            w.writerow({"id": f"fb{i:02d}", "type": "specific", "question": v.get("request", ""),
                        "expected_answer": "", "key_facts": "", "comment": v.get("comment", ""),
                        "result_folder": v.get("result_folder", "")})
    return len(rows)


def markdown(r: dict) -> str:
    """The report as Markdown tables (the command line)."""
    def f(v: object, pct: bool = False) -> str:
        return "-" if v is None else f"{v:.0%}" if pct else str(v)
    md = [f"# Lesson Studio, the last {r['days']} days", "",
          f"Requests {r['requests']}, failed {r['errors']}. Spent today ${r['spent_today_usd']} of ${r['daily_limit_usd']}.",
          "", "| Format | Requests | Failed | Median time (s) | 95% within (s) | Cost (USD) |", "|---|---|---|---|---|---|"]
    md += [f"| {x['format']} | {x['count']} | {x['errors']} | {f(x['median_s'])} | {f(x['p95_s'])} | {x['cost_usd']} |"
           for x in r["by_format"]]
    md += ["", "| Answers | |", "|---|---|", f"| Answered | {r['answered']} of {r['answers']} |",
           f"| Not in the material | {r['not_in_material']} |", f"| Refused (unsafe) | {r['refused']} |",
           f"| From the cache | {r['from_cache']} |", f"| Sentences removed by the check | {f(r['removed_share'], True)} |",
           f"| Sentences corrected by the check | {f(r['corrected_share'], True)} |",
           f"| Searched again | {r['searched_again']} |",
           f"| Judged (sample {r['sample']:.0%}) | {r['judged']}, faithfulness {f(r['faithfulness'])}"
           + (" (the judge is the writer: less strict)" if r["self_judged"] else "") + " |",
           f"| Votes | 👍 {r['votes_up']} · 👎 {r['votes_down']} |", ""]
    md += ["**Needs attention:**", *[f"- {n}" for n in r["attention"]]] if r["attention"] else ["Nothing over its threshold."]
    return "\n".join(md)


def main() -> int:
    """Command line: the report, or the 👎 answers as test questions. Returns the exit code."""
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--days", type=int, default=7)
    ap.add_argument("--export-down", nargs="?", const=str(config.DATA_DIR / "eval" / "from_feedback.csv"),
                    metavar="CSV", help="write the 👎 answers as test questions (default data/eval/from_feedback.csv)")
    args = ap.parse_args()
    config.setup_logging()
    if args.export_down:
        n = export_down(Path(args.export_down), max(args.days, 30))
        print(f"{n} 👎 answers written to {args.export_down}: add the expected answers, then run "
              f"uv run qa_eval.py --set {args.export_down}")
        return 0
    print(markdown(report(args.days)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
