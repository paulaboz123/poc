"""Running in a container or a Kubernetes pod (docs/DEPLOY.md): the health checks answer without a sign-in and
show no data, a stop (SIGTERM) lets the request being made finish and refuses new ones, the logs can be JSON,
and the image and the manifests agree with the app (port, health paths, the user, a read-only code folder)."""
from __future__ import annotations

import json
import logging
import re
import shutil
import subprocess
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

import pytest
from test_smoke_and_app import _server, get

import app
import chats
import config

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture
def stopping():
    """Whatever a test does with the stop flag, the next test starts with a running app."""
    yield app.STOPPING
    app.STOPPING.clear()


def test_health_checks_answer_without_sign_in_and_show_no_data(project, monkeypatch, stopping):
    monkeypatch.setattr(config, "APP_PASSWORD", "a-long-test-password")
    monkeypatch.setattr(config, "APP_VERSION", "abc1234")
    server, base = _server()
    try:
        code, _, body = get(base + "/healthz", {"Host": "10.0.0.7:8765"})          # the kubelet, by the pod's IP
        assert code == 200 and json.loads(body) == {"status": "ok", "version": "abc1234"}
        code, _, body = get(base + "/readyz", {"Host": "10.0.0.7:8765"})
        assert code == 200 and json.loads(body)["ready"] is True
        assert get(base + "/api/state", {"Host": "10.0.0.7:8765"})[0] == 401          # everything else: signed in
        stopping.set()
        code, _, body = get(base + "/readyz")
        assert code == 503 and json.loads(body)["checks"] == {"not_stopping": False, "data_writable": True}
        assert get(base + "/healthz")[0] == 200                                       # stopping is not "dead"
        log = config.OUTPUT_DIR / "app_access.log"
        assert not log.exists() or "/healthz" not in log.read_text(encoding="utf-8")  # no line every few seconds
    finally:
        server.shutdown()


def test_a_full_or_read_only_data_volume_is_not_ready(project, monkeypatch, tmp_path):
    blocked = tmp_path / "not-a-folder"
    blocked.write_text("a file where the data folder should be", encoding="utf-8")
    monkeypatch.setattr(config, "DATA_DIR", blocked)
    assert app.readiness() == (False, {"not_stopping": True, "data_writable": False})


def test_a_stop_lets_the_request_being_made_finish_and_refuses_new_ones(project, monkeypatch, stopping):
    monkeypatch.setattr(config, "APP_PASSWORD", "")
    server, base = _server()
    job = {"id": "j1", "status": "running"}
    monkeypatch.setitem(app.JOBS, "j1", job)
    stopper = threading.Thread(target=app.stop_when_idle, args=(server, 5))
    try:
        stopper.start()
        time.sleep(0.3)
        req = urllib.request.Request(base + "/api/jobs", data=b'{"request": "a document on joins"}',
                                     headers={"Content-Type": "application/json"})
        with pytest.raises(urllib.error.HTTPError) as refused:
            urllib.request.urlopen(req, timeout=10)
        assert refused.value.code == 503 and b"restarting" in refused.value.read()
        assert stopper.is_alive()                                  # still waiting for the running request
        job["status"] = "done"
        stopper.join(timeout=5)
        assert not stopper.is_alive()                              # finished, then the server stopped
    finally:
        server.shutdown()


def test_a_stop_does_not_wait_for_ever(project, stopping):
    stopped = []
    app.JOBS["stuck"] = {"id": "stuck", "status": "running"}
    try:
        t0 = time.monotonic()
        app.stop_when_idle(type("S", (), {"shutdown": lambda self: stopped.append(1)})(), wait_s=0.6)
        assert stopped == [1] and time.monotonic() - t0 < 3
    finally:
        app.JOBS.pop("stuck", None)


def test_json_logs_are_one_object_a_line():
    record = logging.LogRecord("answer", logging.WARNING, __file__, 1, "Answered in %s s", (1.5,), None)
    line = config.JsonLogFormatter().format(record)
    data = json.loads(line)
    assert "\n" not in line and data["level"] == "WARNING" and data["logger"] == "answer"
    assert data["message"] == "Answered in 1.5 s" and data["time"].endswith("+00:00")


CHART = ROOT / "charts" / "proto-learning-agent"


def test_the_image_and_the_chart_agree_with_the_app():
    yaml = pytest.importorskip("yaml")   # PyYAML: `uv add --dev pyyaml` if it is missing
    docker = (ROOT / "Dockerfile").read_text(encoding="utf-8")
    values = yaml.safe_load((CHART / "values.yaml").read_text(encoding="utf-8"))
    deploy = (CHART / "templates" / "deployment.yaml").read_text(encoding="utf-8")
    helpers = (CHART / "templates" / "_helpers.tpl").read_text(encoding="utf-8")
    port, metrics = values["app"]["port"], values["app"]["metricsPort"]
    assert values["app"]["replicaCount"] == 1 and values["app"]["service"]["port"] == 80
    assert f"APP_PORT={port}" in docker and port == 8765 and metrics != port and f"EXPOSE {port} {metrics}" in docker
    assert set(re.findall(r"httpGet: {path: (/\w+)", deploy)) <= set(app.PROBES)   # probe paths the app answers
    assert "livenessProbe:" in deploy and "httpGet: {path: /healthz" in deploy and "path: /readyz" in deploy
    assert "replicas: 1" in deploy and "type: Recreate" in deploy                # one pod: one job line, one volume
    assert "terminationGracePeriodSeconds: {{ add .Values.app.shutdownWaitS 30 }}" in deploy   # stops before killed
    assert set(re.findall(r"mountPath: (/[\w/]+)", deploy)) == {"/app/data", "/tmp", "/dev/shm"}   # the only writes
    assert "runAsNonRoot: true" in helpers and "runAsUser: 1000" in helpers and "readOnlyRootFilesystem: true" in helpers
    assert "USER 1000:1000" in docker and 'ENTRYPOINT ["tini", "--"]' in docker and "uv sync --locked" in docker
    assert "--mount=type=cache" not in docker                                   # kaniko builds it as well
    assert values["app"]["image"]["tag"] == "" and values["persistence"]["keep"] is True
    assert values["bifrost"]["apiKey"]["secretStore"] == "aws-secrets-manager"          # the key never in git
    service = (CHART / "templates" / "service.yaml").read_text(encoding="utf-8")
    assert "targetPort: http" in service and "metrics" not in service           # /metrics not on the page's address
    dev = yaml.safe_load((CHART / "values-dev-eks.yaml").read_text(encoding="utf-8"))
    assert dev["httpRoute"]["enabled"] and dev["oauth2-proxy"]["enabled"]           # company login (SSO)
    assert dev["auth"]["proxyHeader"] == "X-Forwarded-Email"
    assert set(dev["app"]["image"]) == {"repository", "tag"}                     # what the pipeline writes
    assert (CHART / "templates" / "externalsecret.yaml").exists() and (CHART / "templates" / "httproute.yaml").exists()


def test_the_pipeline_builds_the_commit_and_writes_its_tag_for_argo_cd():
    yaml = pytest.importorskip("yaml")
    ci = yaml.safe_load((ROOT / ".gitlab-ci.yml").read_text(encoding="utf-8"))
    assert ci["stages"] == ["check", "build", "deploy"]
    build = " ".join(ci["build-image"]["script"])
    assert '--destination "$IMAGE:$TAG"' in build and 'TAG="main-$CI_COMMIT_SHORT_SHA-$CI_PIPELINE_ID"' in build
    assert "HTTPS_PROXY=$HTTPS_PROXY" in build and ci["build-image"]["artifacts"]["reports"]["dotenv"] == "build.env"
    for job in ("build-image", "update-dev-image-tag"):                          # no job before ECR is provisioned
        assert ci[job]["rules"] == [{"if": "$CI_COMMIT_BRANCH == $CI_DEFAULT_BRANCH && $AWS_ECR_BACKEND"}]
    bump = ci["update-dev-image-tag"]
    script = " ".join(bump["script"])
    assert ci["variables"]["CHART"] == "charts/proto-learning-agent" and (ROOT / ci["variables"]["CHART"]).is_dir()
    assert (ROOT / ci["variables"]["VALUES_FILE"]).is_file() and bump["needs"] == ["build-image"]
    assert 'tag: \\"$TAG\\"' in script and "helm template" in script
    assert 'git push --force origin "$BUMP_BRANCH"' in script and "[skip ci]" in script
    assert ci["code-checks"]["rules"][0] == {"if": "$CI_COMMIT_BRANCH == $BUMP_BRANCH", "when": "never"}
    assert "ruff check" in " ".join(ci["code-checks"]["script"]) and "mypy" in " ".join(ci["code-checks"]["script"])


def test_the_tag_bump_changes_only_the_image_lines(tmp_path):
    """The pipeline's sed, run on the dev values: only app.image changes."""
    yaml = pytest.importorskip("yaml")
    ci = yaml.safe_load((ROOT / ".gitlab-ci.yml").read_text(encoding="utf-8"))
    sed = ci["update-dev-image-tag"]["script"][0]
    values = tmp_path / "values.yaml"
    shutil.copy(CHART / "values-dev-eks.yaml", values)
    if shutil.which("sed") is None or subprocess.run(["sed", "--version"], capture_output=True).returncode:
        pytest.skip("GNU sed is not installed (the pipeline has it)")
    env = {"IMAGE": "registry.example/pll", "TAG": "main-abc1234-77", "VALUES_FILE": str(values),
           "PATH": "/usr/bin:/bin"}
    subprocess.run(["sh", "-c", sed], env=env, check=True)
    before = yaml.safe_load((CHART / "values-dev-eks.yaml").read_text(encoding="utf-8"))
    after = yaml.safe_load(values.read_text(encoding="utf-8"))
    assert after["app"]["image"] == {"repository": "registry.example/pll", "tag": "main-abc1234-77"}
    after["app"]["image"] = before["app"]["image"]
    assert after == before


@pytest.mark.skipif(shutil.which("helm") is None, reason="helm is not installed (the pipeline has it)")
def test_the_chart_renders_with_helm(tmp_path):
    sets = ["--set", "app.image.repository=registry.example/pll", "--set", "app.image.tag=abc1234",
            "--set", "bifrost.baseUrl=https://bifrost.example", "--set", "bifrost.model=m",
            "--set", "bifrost.apiKey.awsSecretName=learning/bifrost", "--set", "auth.proxyHeader=X-Forwarded-Email"]
    out = subprocess.run(["helm", "template", "proto-learning-agent", str(CHART), *sets],
                         capture_output=True, text=True, check=True)
    import yaml
    kinds = sorted(d["kind"] for d in yaml.safe_load_all(out.stdout) if d)
    assert kinds == ["Deployment", "ExternalSecret", "PersistentVolumeClaim", "Service"]
    stopped = subprocess.run(["helm", "template", "x", str(CHART), "-f", str(CHART / "values-dev-eks.yaml"),
                              "--set", "app.image.repository=r", "--set", "app.image.tag=abc"],
                             capture_output=True, text=True)
    assert stopped.returncode and "bifrost.baseUrl is required" in stopped.stderr


def test_behind_the_company_login_the_user_comes_from_its_header(project, monkeypatch):
    """oauth2-proxy in front (AUTH_PROXY_HEADER): no header = refused; each person's chats follow their login."""
    monkeypatch.setattr(config, "APP_PASSWORD", "")
    monkeypatch.setattr(config, "AUTH_PROXY_HEADER", "X-Forwarded-Email")
    server, base = _server()
    try:
        assert get(base + "/api/state", {"Host": "proto-learning-agent.example.com"})[0] == 401   # no login
        ana = {"Host": "proto-learning-agent.example.com", "X-Forwarded-Email": "Ana@Example.com"}
        code, _, _ = get(base + "/api/state", ana)
        assert code == 200
        chats.add_request("", app_owner(ana), "A video on joins", {}, "j1")
        assert [c["title"] for c in json.loads(get(base + "/api/chats", ana)[2])["chats"]] == ["A video on joins"]
        bob = {**ana, "X-Forwarded-Email": "bob@example.com"}
        assert json.loads(get(base + "/api/chats", bob)[2])["chats"] == []           # someone else's are not shown
        assert get(base + "/healthz")[0] == 200                                      # the probes need no login
    finally:
        server.shutdown()


def app_owner(headers: dict) -> str:
    """The owner id the app gives a signed-in e-mail (the same on every device)."""
    import hashlib
    return hashlib.sha256(headers["X-Forwarded-Email"].strip().lower().encode()).hexdigest()[:24]


def test_listening_for_everyone_needs_a_password_or_the_company_login(monkeypatch):
    monkeypatch.setattr(config, "APP_PASSWORD", "")
    monkeypatch.setattr(config, "AUTH_PROXY_HEADER", "")
    with pytest.raises(SystemExit):
        app.serve(0, open_browser=False, host="0.0.0.0")
    monkeypatch.setattr(config, "AUTH_PROXY_HEADER", "X-Forwarded-Email")
    server = app.serve(0, open_browser=False, host="0.0.0.0")
    server.server_close()
