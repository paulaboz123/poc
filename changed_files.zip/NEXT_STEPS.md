# Next steps to the demo (~13 Nov)

Tick [x] when done. `uv run doctor.py` reminds you how many are left.

## Week 26-30 Oct
- [x] Better content: self-review of the script, goals -> example -> question -> recap, quiz.md
- [x] Topic map of the recordings (topics.py)
- [ ] Run topics.py on the 4 videos, make 2-3 videos from its requests
- [ ] Animation synced with the voice (points appear as they are spoken, transitions)  <- NEXT
- [ ] Show Clara 1-2 videos, note her feedback
- [ ] Ask the platform team: Opus / Sonnet 5 model ids, is an image model available (EU)?

## Week 2-6 Nov
- [ ] Icons, more diagram types (cycle, timeline), background music, voice choice
- [ ] The 2 audio files: transcripts with Whisper (local)
- [ ] Same topic in NotebookLM vs our video: compare
- [ ] Quality check on 5-10 videos; Sonnet vs Opus on one video
- [ ] Cost estimate: per minute of video, per month at scale

## Week 9-13 Nov
- [ ] Simple demo window in the browser (type a request, watch the video)
- [ ] Final review of the code
- [ ] For Clara: results, costs, limitations, next phase (animated characters, plugging into the platform)
- [ ] Demo rehearsal + a backup recording of the demo
