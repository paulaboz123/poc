"""
topics.py - what is in the recordings, without watching them: a topic map of every processed
recording, plus ready-to-use requests for videos on each topic.

  uv run topics.py                 # all recordings (results are cached: a re-run costs nothing)
  uv run topics.py --refresh       # analyse again (e.g. after changing the model)
  uv run topics.py --recording 13  # just one recording

How it works:
 1. For each recording, the chat model reads the whole transcript (with timestamps, the slide
    text and the description from description.xlsx) and lists the topics it covers: where in
    the recording, how deeply (brief / solid / deep), for which level, and a suggested request
    for a video on it.
 2. With two or more recordings, one more call looks across all of them: topics that several
    recordings cover (good for one combined video) and a suggested learning path (a series).
Cost: roughly 1-3 cents per 10 minutes of recording with Sonnet, once (results are cached in
data/processed/<recording>/topics.json).

Output (data/output/topics/):
  topics.md            read this: summary and topic table per recording, then cross-recording
                       topics and the learning path, each with a request you can copy
  topic_requests.csv   the same requests in the batch.py format (run=no: set yes for the ones
                       you want, then: uv run batch.py --file data/output/topics/topic_requests.csv)
  topics.json          everything as data
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import logging
import sys
from datetime import datetime

import config
import llm
import store

log = logging.getLogger("topics")

MAX_WORDS = 16000   # ~100 minutes of speech; longer transcripts are thinned evenly

RECORDING_SCHEMA = {
    "type": "object",
    "properties": {
        "summary": {"type": "string", "description": "2-3 sentences: what the recording is about and for whom"},
        "topics": {"type": "array", "items": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Topic name, 3-8 words, specific"},
                "covers": {"type": "string", "description": "1-2 sentences: what exactly is said about it"},
                "start": {"type": "string", "description": "mm:ss (or h:mm:ss) where it starts"},
                "end": {"type": "string", "description": "mm:ss (or h:mm:ss) where it ends"},
                "depth": {"type": "string", "enum": ["brief", "solid", "deep"],
                          "description": "brief = mentioned in passing; solid = explained; deep = explained "
                                         "with details, examples or a demo"},
                "level": {"type": "string", "enum": ["beginner", "intermediate", "expert"]},
                "minutes": {"type": "number", "description": "Video length the material supports: 1-5"},
                "visual_idea": {"type": "string", "description": "How a video could show it, e.g. 'steps of the "
                                                                "process', 'comparison of A and B', 'table of options'"},
                "request": {"type": "string", "description": "A request in plain words for a video on this topic"},
            },
            "required": ["title", "covers", "start", "end", "depth", "level", "minutes", "visual_idea", "request"],
        }},
    },
    "required": ["summary", "topics"],
}
RECORDING_SYSTEM = """You map the topics of an internal training recording, so that a person who
has not watched it knows what is in it and can order short video lessons on its parts.
Rules:
- Use only what the transcript says. List topics in the order they appear; 4-12 topics for an
  hour, fewer for a short recording. Skip meeting logistics, small talk and Q&A that adds nothing.
- One topic = one teachable idea, specific ("Left join vs inner join", not "Joins").
- start/end: the timestamps from the transcript where the topic is discussed.
- depth: be honest; a topic only mentioned is 'brief' (too thin for its own video).
- minutes: 1-2 for brief or simple topics, 3-5 only when the material is rich.
- request: what a person would type to get the video, in English, e.g.
  "Make a 3-minute video for beginners on <topic> from recording <id>, with a <visual idea>."
  Use the recording id given. Write everything in English."""

CROSS_SCHEMA = {
    "type": "object",
    "properties": {
        "shared_topics": {"type": "array", "items": {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "covers": {"type": "string", "description": "What the recordings together say about it"},
                "recordings": {"type": "array", "items": {"type": "string"}, "description": "recording ids"},
                "minutes": {"type": "number"},
                "level": {"type": "string", "enum": ["beginner", "intermediate", "expert"]},
                "request": {"type": "string"},
            },
            "required": ["title", "covers", "recordings", "minutes", "level", "request"],
        }},
        "learning_path": {"type": "array", "items": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Episode title"},
                "why_here": {"type": "string", "description": "Why this episode comes at this point, one sentence"},
                "recordings": {"type": "array", "items": {"type": "string"}},
                "minutes": {"type": "number"},
                "level": {"type": "string", "enum": ["beginner", "intermediate", "expert"]},
                "request": {"type": "string"},
            },
            "required": ["title", "why_here", "recordings", "minutes", "level", "request"],
        }},
    },
    "required": ["shared_topics", "learning_path"],
}
CROSS_SYSTEM = """You plan short video lessons across several internal training recordings, from
their topic maps. Return:
- shared_topics: topics that two or more recordings cover (overlap or complement each other),
  each good for one combined video. Only real overlaps; an empty list is fine.
- learning_path: a series of 4-8 short episodes that takes a beginner from the basics to the
  advanced topics, in a sensible order, using the topics that are covered at least 'solid'.
For each, `request` is what a person would type, in English, e.g. "Make a 3-minute video for
beginners on <topic> from recordings <id>, <id>, with a <visual idea>." Use the recording ids
given."""


# --- Material ------------------------------------------------------------------------------
def recording_ref(row: dict) -> str:
    """The id people use for a recording: the Excel id if there is one, else the video_id."""
    return row.get("catalog_id") or row["video_id"]


def transcript_text(video_id: str) -> str:
    """The whole transcript as '[mm:ss] text' lines, with the slide text in brackets; thinned
    evenly when longer than MAX_WORDS."""
    segments = store.all_segments()
    segs = [s for s in segments.values() if s["video_id"] == video_id]
    segs.sort(key=lambda s: s["start"])
    lines = []
    for s in segs:
        line = f"[{store.fmt_ts(s['start'])}] {s['text']}"
        if s.get("slide_text"):
            line += f"\n  (on the slide: {' / '.join(x.strip() for x in s['slide_text'].splitlines() if x.strip())[:300]})"
        lines.append(line)
    words = sum(len(x.split()) for x in lines)
    if words > MAX_WORDS:   # keep every n-th segment, so the whole recording is still covered
        keep = max(1, round(words / MAX_WORDS + 0.5))
        lines = lines[::keep]
        log.info("%s: transcript thinned to every %s. segment (%s words)", video_id, keep, words)
    return "\n".join(lines)


def _key(text: str, model: str) -> str:
    """Cache key: the same transcript and model give the same analysis."""
    return hashlib.sha1(f"{model}\n{text}".encode()).hexdigest()[:16]


# --- Analysis -------------------------------------------------------------------------------
def analyse_recording(row: dict, *, model: str | None = None, refresh: bool = False) -> dict:
    """Topic map of one recording (cached in data/processed/<id>/topics.json)."""
    vid = row["video_id"]
    text = transcript_text(vid)
    key = _key(text, model or config.CHAT_MODEL)
    cache = store.video_dir(vid) / "topics.json"
    cached = store.read_json(cache)
    if cached and cached.get("key") == key and not refresh:
        log.info("%s: topics from cache", row["title"])
        return cached
    meta = store.load_meta(vid)
    head = (f"Recording id: {recording_ref(row)}\nTitle: {row['title']}\n"
            f"Length: {store.fmt_ts(meta.get('duration_s') or 0)}\n"
            + (f"Description: {row['description']}\n" if row.get("description") else ""))
    log.info("Analysing %s ...", row["title"])
    data = llm.chat_json(f"{head}\nTRANSCRIPT\n{text}", RECORDING_SCHEMA, system=RECORDING_SYSTEM,
                         step="topics", model=model, max_tokens=4000, temperature=0.2)
    topics = []
    for t in data.get("topics", []):
        if not isinstance(t, dict) or not t.get("title"):
            continue
        t["minutes"] = max(1.0, min(5.0, float(t.get("minutes") or 2)))
        t["depth"] = t.get("depth") if t.get("depth") in ("brief", "solid", "deep") else "solid"
        t["level"] = t.get("level") if t.get("level") in ("beginner", "intermediate", "expert") else "beginner"
        topics.append(t)
    result = {"key": key, "video_id": vid, "ref": recording_ref(row), "title": row["title"],
              "summary": data.get("summary", ""), "topics": topics,
              "analysed": datetime.now().isoformat(timespec="seconds")}
    store.write_json(cache, result)
    return result


def analyse_across(maps: list[dict], *, model: str | None = None) -> dict:
    """Shared topics and a learning path across recordings (one call on the topic maps)."""
    blocks = []
    for m in maps:
        lines = [f"- {t['title']} ({t['depth']}, {t['level']}): {t['covers']}" for t in m["topics"]]
        blocks.append(f"Recording id {m['ref']}: {m['title']}\n{m['summary']}\n" + "\n".join(lines))
    data = llm.chat_json("\n\n".join(blocks), CROSS_SCHEMA, system=CROSS_SYSTEM, step="topics_across",
                         model=model, max_tokens=3000, temperature=0.2)
    known = {m["ref"] for m in maps}
    for part in ("shared_topics", "learning_path"):
        items = [x for x in data.get(part, []) if isinstance(x, dict) and x.get("title")]
        for x in items:
            x["recordings"] = [r for r in x.get("recordings", []) if str(r) in known]
            x["minutes"] = max(1.0, min(5.0, float(x.get("minutes") or 2)))
            if x.get("level") not in ("beginner", "intermediate", "expert"):
                x["level"] = "beginner"
        data[part] = items
    return data


# --- Output ---------------------------------------------------------------------------------
def _cmd(request: str) -> str:
    """The ask.py command for a request (double quotes inside are made single)."""
    return f'uv run ask.py "{request.replace(chr(34), chr(39))}"'


def to_markdown(maps: list[dict], across: dict | None) -> str:
    """topics.md: per recording a summary and a topic table, then the requests to copy."""
    out = ["# Topics in the recordings", "",
           f"*{len(maps)} recording(s), {sum(len(m['topics']) for m in maps)} topics · "
           f"{datetime.now():%Y-%m-%d %H:%M}*", "",
           "Depth: **deep** = explained with details or examples, **solid** = explained, "
           "*brief* = only mentioned (too thin for its own video).", ""]
    for m in maps:
        out += [f"## {m['ref']} · {m['title']}", "", m["summary"], "",
                "| # | Topic | Where | Depth | Level | Video |", "|---|---|---|---|---|---|"]
        for n, t in enumerate(m["topics"], 1):
            depth = f"*{t['depth']}*" if t["depth"] == "brief" else f"**{t['depth']}**"
            out.append(f"| {n} | {t['title']} | {t['start']}-{t['end']} | {depth} | {t['level']} | "
                       f"{t['minutes']:g} min |")
        out += ["", "**What each topic covers, and the request for a video:**", ""]
        for n, t in enumerate(m["topics"], 1):
            out += [f"{n}. **{t['title']}**: {t['covers']}" + (" *(brief: better as part of a bigger video)*"
                                                              if t["depth"] == "brief" else ""),
                    f"   Visual idea: {t['visual_idea']}", "", "   ```", f"   {_cmd(t['request'])}", "   ```", ""]
    if across:
        if across.get("shared_topics"):
            out += ["## Topics across recordings", "", "Covered by several recordings: good for one combined video.", ""]
            for t in across["shared_topics"]:
                out += [f"- **{t['title']}** (recordings {', '.join(t['recordings'])}): {t['covers']}", "",
                        "  ```", f"  {_cmd(t['request'])}", "  ```", ""]
        if across.get("learning_path"):
            out += ["## Suggested series (learning path)", ""]
            for n, t in enumerate(across["learning_path"], 1):
                out += [f"{n}. **{t['title']}** ({t['minutes']:g} min, {t['level']}): {t['why_here']}", "",
                        "   ```", f"   {_cmd(t['request'])}", "   ```", ""]
    out += ["---", "", "Tip: add `--plan-only` to read the script first; to make many at once, tick rows in "
            "`topic_requests.csv` and run `uv run batch.py --file data/output/topics/topic_requests.csv`.", ""]
    return "\n".join(out)


def to_requests_csv(maps: list[dict], across: dict | None) -> str:
    """The requests in the batch.py format; run=no, so nothing is made until you tick rows."""
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["id", "type", "topic", "recording", "minutes", "level", "model", "run", "wishes", "depth", "from"])
    n = 0
    for m in maps:
        for t in m["topics"]:
            n += 1
            w.writerow([n, "video", t["title"], m["ref"], f"{t['minutes']:g}", t["level"], "", "no",
                        t["visual_idea"], t["depth"], f"recording {m['ref']}"])
    for part, label in (("shared_topics", "across recordings"), ("learning_path", "series")):
        for i, t in enumerate((across or {}).get(part, []), 1):
            n += 1
            w.writerow([n, "video", t["title"], ",".join(t["recordings"]), f"{t['minutes']:g}", t["level"], "",
                        "no", "", "", f"{label} {i}" if part == "learning_path" else label])
    return buf.getvalue()


def run(recording: str | None = None, *, model: str | None = None, refresh: bool = False) -> dict:
    """Analyse the recordings and write topics.md, topic_requests.csv and topics.json."""
    rows = store.available_recordings()
    if recording:
        wanted = set(store.resolve_recordings(recording))
        rows = [r for r in rows if r["video_id"] in wanted]
    if not rows:
        raise ValueError("No processed recordings yet: set include=yes in data/manifest.csv and run pipeline.py.")
    maps = [analyse_recording(r, model=model, refresh=refresh) for r in rows]
    across = analyse_across(maps, model=model) if len(maps) >= 2 else None
    out_dir = config.OUTPUT_DIR / "topics"
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "topics.md").write_text(to_markdown(maps, across), encoding="utf-8")
    (out_dir / "topic_requests.csv").write_text(to_requests_csv(maps, across), encoding="utf-8-sig")
    store.write_json(out_dir / "topics.json", {"recordings": maps, "across": across})
    return {"folder": out_dir, "recordings": len(maps), "topics": sum(len(m["topics"]) for m in maps),
            "shared": len((across or {}).get("shared_topics", [])),
            "series": len((across or {}).get("learning_path", []))}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--recording", help="only this recording (id, or a word from the title)")
    ap.add_argument("--refresh", action="store_true", help="analyse again instead of using the cache")
    ap.add_argument("--model", help="override CHAT_MODEL from .env")
    args = ap.parse_args()
    config.setup_logging()
    try:
        r = run(args.recording, model=args.model, refresh=args.refresh)
    except (RuntimeError, ValueError, OSError) as e:
        log.error("%s", e)
        return 1
    print(f"\n{r['recordings']} recording(s), {r['topics']} topics"
          + (f", {r['shared']} shared, a series of {r['series']}" if r["series"] else ""))
    print(f"Read:   {r['folder'] / 'topics.md'}")
    print(f"Batch:  {r['folder'] / 'topic_requests.csv'}  (set run=yes on the rows you want)")
    print(f"Estimated model cost: ${llm.spent_this_run():.3f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
