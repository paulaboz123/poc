# Documentation

| Document | Content |
|---|---|
| [ARCHITECTURE.md](ARCHITECTURE.md) | Components, request flow, knowledge base, deployment, security |
| [DESIGN.md](DESIGN.md) | Design decisions and quality controls |
| [RAG_QUALITY.md](RAG_QUALITY.md) | Retrieval and answer grounding, quality measurement |
| [DEPLOY.md](DEPLOY.md) | CI/CD, Helm chart, configuration, operations |
| [MONITORING.md](MONITORING.md) | Metrics, answer evaluation in use, alerts |
| [COSTS.md](COSTS.md) | What is paid, how it is measured, cost controls, monthly estimate |
| [TESTING.md](TESTING.md) | Test layers and commands |
| [CODE_STYLE.md](CODE_STYLE.md) | Code rules and checks |
| [EXPERIMENTS.md](EXPERIMENTS.md) | Optional renderers and voices (`experiments/`) |
| [ROADMAP.md](ROADMAP.md) | Open items |
