# Roadmap

Open items, grouped by area. Not implemented today.

## Platform

- [ ] Roche-wide access beyond dev: production environment and hostname
- [ ] Gateway body size limit for company avatar uploads (up to 12 MB), if avatars are used in the cloud
- [ ] Knowledge base upload and indexing from the page or a pipeline job (today: prepared locally, copied to the pod)

## Scale

- [ ] External job queue (SQS or Redis) and worker pods, for parallel jobs
- [ ] Results in S3 and chats in a database, for more than one pod and zero-downtime releases
- [ ] Vector store (OpenSearch or pgvector, keeping hybrid BM25 + vector search) beyond tens of thousands of excerpts
- [ ] Course outline from the ~20 most relevant topic maps instead of all of them
- [ ] Second level of topic maps (map of maps) for thousands of recordings

## Quality

- [ ] Videos and written lessons corrected claim by claim before rendering (today: checked after, verdict FAIL)
- [ ] Cross-encoder reranker (e.g. Cohere Rerank 3.5 on Bedrock) compared with Claude reranking
- [ ] Multilingual embeddings for Polish questions (today: translated to English first)
- [ ] Quiz-based evaluation of videos (questions answered from the video only)
- [ ] Per-user access filters at search time

## Cost

- [ ] Smaller model for reranking and context sentences, adopted only if `qa_eval.py --gate` passes
- [ ] Bedrock batch inference for offline steps (search contexts, slide descriptions, evaluations)
- [ ] Per-app cost attribution (application inference profile, cost allocation tags)

## Product

- [ ] Short-form videos (30–60 s) and printable handouts
- [ ] More than one narrator voice per video; languages other than English
