# Design decisions

The flow and the components: `docs/ARCHITECTURE.md`.

## Decisions

| Decision | Reason | Alternative not taken |
|---|---|---|
| Storyboard as plain JSON between writing and rendering | Readable and editable (`script.md`), re-rendered without a model call, testable | One model call straight to video |
| Long videos as chapters from an outline | Smaller tasks keep quality, avoid the output limit and run in parallel | One storyboard for 15 minutes |
| Outline from a topic map, not from search | A course needs the structure of the whole material | Top-k search for the whole request |
| Self-review against code findings | Fixes weak examples, repetition and level mismatch; returns only its fixes | Human review of every script |
| New slides only; original slides used as knowledge | Teaching, not copying meetings; no faces or meeting UI in the output | Screenshots of recordings |
| Model output validated and repaired in code | One bad field must never break a video | Trusting the model's JSON |
| Sources on every scene and sentence | Every claim is traceable to a recording, time and slide | No traceability |
| Narration cut at animation cues, each part voiced separately | Exact audio–animation sync without word timestamps | Fixed timers |
| Slides rendered from HTML/CSS/SVG by Chromium | Professional typography and diagrams, exact repeatable motion | Pillow drawings, PowerPoint automation |
| Open illustration library (CC0), recoloured to the palette | Consistent, licence-safe pictures, offline | Generated pictures per slide |
| Local voice (Kokoro) and rendering | Free, private, no extra approval | Cloud text-to-speech |
| EU Bedrock models via the Bifrost gateway, spending lock in code | Data residency and cost control | Direct keys, no limit |

## Quality controls

| Control | What it does |
|---|---|
| Grounding | Only indexed excerpts reach the prompt; scenes without sources are flagged; unsupported claims removed |
| Numbers | Every number on screen must appear in the cited excerpts; calculations recomputed in code |
| Voice vs screen | At least half of what a slide shows must be spoken about |
| Multimedia principles (Mayer) | Redundancy, signalling, coherence and personalisation checked in code and passed to the self-review |
| Layout | The browser measures cut-off text and overlaps; the slide shrinks itself, the rest is reported |
| Audio | Silence, clipping and pace per part; loudness normalised to −16 LUFS |
| Safety | Blocked and sensitive words, instruction-like material excluded, fixed picture library |
| Privacy | Speaker names masked before model calls; e-mail addresses and phone numbers fail a result |
| Refusal | Requests the material does not cover are declined, not invented |
| Traceability | Every result records model, prompt version, code version and settings (run card) |
| Robustness | Retries on gateway errors, one repair round for invalid JSON, failed chapters retried then skipped, atomic writes |
| Stop and resume | A job stops before its next paid call; a resumed video keeps its script, voice parts and finished scenes |

Every result gets a verdict: OK, CHECK (needs a human look) or FAIL.
