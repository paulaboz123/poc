# Deployment

Lesson Studio runs as one container in one pod: the web app, the Kokoro voice, the HTML slides (Chromium) and
ffmpeg. Claude is reached through the Bifrost gateway. Target: EKS dev cluster, namespace `agent-prototypes`,
deployed by Argo CD; the platform team owns Argo CD, ECR and the IAM role used by CI.

## Repository

| Path | Content |
|---|---|
| `Dockerfile` | Two stages: *build* (Python, packages from `uv.lock`, the Kokoro voice) and *run* (runtime only). User 1000, read-only code, `tini` as PID 1. Base images can be overridden (`BASE_IMAGE`, `UV_IMAGE`) |
| `.gitlab-ci.yml` | `code-checks` (ruff, mypy) on every push; on the default branch `build-image` (kaniko → ECR, tag `main-<SHA>-<pipeline>`) and `update-dev-image-tag` (writes the image to `values-dev-eks.yaml` on the `deploy-dev` branch) |
| `charts/proto-learning-agent/` | Helm chart: Deployment, Service, PVC, ExternalSecrets (Bifrost key, optional extra settings), HTTPRoute or Ingress; optional oauth2-proxy, NetworkPolicy, Prometheus rules, weekly evaluation CronJob |
| `compose.yaml` | The same container locally (`docker compose up`) |

## Delivery flow

```
push to main ─► code-checks ─► build-image ─► update-dev-image-tag ─► branch deploy-dev ─► Argo CD ─► EKS
                                  │                   │
                ECR $IMAGE:main-<SHA>-<id>   values-dev-eks.yaml: app.image.repository / tag
```

Argo CD application: repository = this project, revision = `deploy-dev`, path = `charts/proto-learning-agent`,
value files = `values.yaml`, `values-dev-eks.yaml`.

## Configuration

### CI/CD variables

| Variable | Purpose |
|---|---|
| `GITLAB_BUMP_TOKEN` | Project access token (Maintainer, `write_repository`), masked and protected; used to push `deploy-dev` |
| `AWS_ACCOUNT_ID_DEV` | AWS account of the dev ECR registry |
| `AWS_ECR_BACKEND` | ECR repository of the app (immutable tags); the build jobs appear only once it is set |
| `CODE_PROXY` | HTTP(S) proxy, set on the runner group |

`.kaniko_base` holds the ECR login with the GitLab ID token (shared template). Job images (`PYTHON_IMAGE`,
`KANIKO_IMAGE`, `HELM_IMAGE`) and `AWS_REGION` are set in `.gitlab-ci.yml`.

### `values-dev-eks.yaml`

| Key | Value |
|---|---|
| `bifrost.baseUrl` | Bifrost gateway URL |
| `bifrost.model` | EU Bedrock model id (`CHAT_MODEL`) |
| `bifrost.apiKey.awsSecretName` / `awsSecretProperty` | AWS Secrets Manager secret holding the Bifrost key |
| `extraSecret.awsSecretName` | AWS Secrets Manager secret holding `APP_PASSWORD` (page sign-in without SSO) |
| `httpRoute.parentRefs` / `hostnames` | Gateway and host name |
| `auth.proxyHeader` | With oauth2-proxy in front: the e-mail header (e.g. `X-Forwarded-Email`); then `APP_PASSWORD` is optional |

The chart refuses to render without a model gateway, a model, an image tag, or any sign-in method.

## Pod design

| Choice | Reason |
|---|---|
| 1 replica, `strategy: Recreate` | One in-memory job queue; data is files on a ReadWriteOnce volume |
| PVC at `/app/data` (20 Gi) | Knowledge base, results, chats and cost log survive restarts |
| Secrets from AWS Secrets Manager via External Secrets | No secret in the image, git or GitLab |
| `/healthz` (liveness), `/readyz` (readiness), startup probe | Liveness never depends on the gateway; readiness is false while stopping or when the volume is not writable |
| Graceful stop on SIGTERM | New requests are refused; a running job may finish (`SHUTDOWN_WAIT_S`, 300 s; grace period 330 s) |
| Non-root, read-only root FS, no capabilities, seccomp `RuntimeDefault`, no service account token | Kubernetes "restricted" baseline; writes only to `/app/data`, `/tmp`, `/dev/shm` |
| `LOG_FORMAT=json` | One JSON object per line on stdout |
| Unique image tags `main-<SHA>-<pipeline id>` | ECR tags are immutable; reruns never collide; every release traceable to a commit |
| Requests 2 CPU / 1 Gi, limit 4 Gi | Measured: a 1-minute video peaks at ~900 MiB and uses all available CPU |

## Knowledge base (first deployment)

The material is prepared locally with `pipeline.py`. The index is rebuilt in the pod, because the pod uses the
gateway's embeddings (`EMBED_BACKEND=bifrost`).

```powershell
tar -czf kb.tgz -C data --exclude=./input --exclude=./output --exclude=./index .
$POD = (kubectl -n agent-prototypes get pod -l app.kubernetes.io/name=proto-learning-agent -o name).Replace("pod/", "")
kubectl -n agent-prototypes cp kb.tgz "${POD}:/tmp/kb.tgz"
kubectl -n agent-prototypes exec $POD -- tar -xzf /tmp/kb.tgz -C /app/data --no-same-owner --no-overwrite-dir
kubectl -n agent-prototypes exec $POD -- python index.py build
kubectl -n agent-prototypes exec $POD -- python doctor.py
```

## Operations

| Task | How |
|---|---|
| Release | Push to `main`; Argo CD syncs `deploy-dev`. About a minute of downtime (Recreate) |
| Rollback | Revert the last commit on `deploy-dev`, or roll back in Argo CD |
| Settings | `config.env` in `values.yaml`; secrets in AWS Secrets Manager |
| Health | `kubectl -n agent-prototypes get pods`; `/healthz`, `/readyz` |
| Logs | `kubectl -n agent-prototypes logs deployment/proto-learning-agent` |
| Backup | Volume snapshot of `proto-learning-agent-data`; `helm uninstall` keeps the volume |
| Costs | `docs/COSTS.md` |

## Scaling

One pod by design for now; the path to several pods is in `docs/ROADMAP.md`.
