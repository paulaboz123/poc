# Code style

Plain, readable Python following the [Google Python Style Guide](https://google.github.io/styleguide/pyguide.html),
checked by tools: `ruff.toml` (lint) and `mypy.ini` (types).

## Checks

```
uv run --with ruff ruff check .     # style, likely bugs, complexity, docstrings, annotations
uv run --with mypy mypy             # types
uv run pytest                       # tests (docs/TESTING.md)
```

CI (`code-checks`) runs ruff and mypy on every push.

## Rules

| Rule | Checked by |
|---|---|
| Docstring on every module, class and public function (Google convention) | ruff `D1` |
| All arguments and return values annotated (`Any` for untyped third-party objects) | ruff `ANN`, mypy |
| At most 15 branches per function; longer ones are split | ruff `C901` |
| `except Exception` only where one failure must not stop the rest, with `# noqa: BLE001 - <reason>` | ruff `BLE` |
| No unused arguments; simple returns and conditions | ruff `ARG`, `RET`, `SIM` |
| No mutable defaults, closures over loop variables, or `raise` without `from` in `except` | ruff `B` |
| Sorted imports, Python 3.11 syntax | ruff `I`, `UP` |
| Optional values checked before use | mypy |
| Settings in `config.py` (from `.env` or environment), secrets never in code | review |
| `logging`, not `print`, outside command-line output | review |
| A behaviour change comes with a test | review |

Line length: 120. Experiment modules (`experiments/`, renderer comparison) have looser lint rules and are not
type-checked.
