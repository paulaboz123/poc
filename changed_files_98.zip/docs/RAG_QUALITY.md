# Answer quality

How answers stay grounded in the material, and how quality is measured.

## Pipeline

```
question ─► follow-up rewritten into a full question
         ─► hybrid search: meaning (embeddings) + words (BM25), each with the excerpt's context, fused (RRF, k=60)
         ─► Claude scores ~30 candidates 0-3 and keeps those that answer; none → query rewritten, searched again
         ─► context: kept excerpts + their topic section
         ─► answer: excerpts first, question last; per sentence: quote → sources → sentence
         ─► checks in code: real sources, quotes found verbatim, numbers present in the sources
         ─► claim check by a model: unsupported sentences removed, partly supported corrected
         ─► answer with [n] citations: recording · time · slide, and the quote
```

## Techniques

| Technique | Where |
|---|---|
| Hybrid search with reciprocal rank fusion | `retrieval.py` |
| Contextual retrieval (context sentence per excerpt) | `contextual.py` |
| LLM reranking of candidates | `retrieval.py` |
| Query decomposition (≤3 parts) and glossary term expansion | `retrieval.py`, `glossary.py` |
| Small-to-big context (topic section of each excerpt) | `retrieval.py` |
| Corrective retrieval (rewrite and search again) | `RETRY_SEARCH` |
| Quote-first answers with per-sentence citations | `answer.py` |
| Claim-level verification before the answer is shown | `VERIFY_ANSWERS` |
| Abstention: "not in the material", off-topic gate | `answer.py`, `ask.py` |

## Settings

| Setting | Default | Cost |
|---|---|---|
| `CONTEXTUAL` | yes | Once per index (`uv run contextual.py` shows the price, `--yes` writes) |
| `CONTEXT_MODEL` | `RERANK_MODEL`, else `CHAT_MODEL` | — |
| `RETRY_SEARCH` | yes | Only when nothing fits: 1 small call + 1 rerank |
| `VERIFY_ANSWERS` | yes | 1 call per answer |
| `VERIFY_MODEL` | `JUDGE_MODEL`, else `CHAT_MODEL` | A model other than the writer is stricter |
| `CHAT_HISTORY_TURNS` | 3 | — |

## Measurement

| Step | Command |
|---|---|
| Run the test plan | `uv run qa_eval.py --set "<plan>.xlsx"` (the report compares with the previous run) |
| Release gate | `uv run qa_eval.py --set "<plan>.xlsx" --gate` (exit code 2 = failed) |
| Check the judge against people | `uv run calibrate.py export`, add verdicts, `uv run calibrate.py score <file>` |

Metrics: questions passed, retrieval hit rate, MRR, faithfulness, hallucination rate, false refusals,
key-fact recall, sentences removed or corrected, cost per answer.

| Target | Value |
|---|---|
| Faithfulness | ≥ 95% |
| Hallucination rate | 0 |
| False refusals | ≤ 5% |
| Out-of-scope questions declined | 100% |

Open items: `docs/ROADMAP.md`.
