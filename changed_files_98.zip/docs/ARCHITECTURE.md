# Architecture

Lesson Studio turns internal training material (recordings, transcripts, documents) into learning content on
request: an answer with sources, a document, a slide deck, a narrated video, a two-character video or audio.
Everything is generated only from the indexed material; Claude is the only paid component.

Details: `docs/DESIGN.md` (decisions, quality), `docs/DEPLOY.md` (delivery), `docs/RAG_QUALITY.md` (retrieval),
`docs/COSTS.md` (costs), `docs/MONITORING.md` (monitoring).

## System context

```mermaid
flowchart LR
    U[User<br/>browser] -->|https| GW[Cluster gateway<br/>HTTPRoute]
    GW --> OP[oauth2-proxy<br/>Microsoft sign-in]
    OP -->|X-Forwarded-Email| APP

    subgraph POD[Pod: proto-learning-agent - EKS dev, namespace agent-prototypes]
        APP[Web app<br/>app.py] --> CORE[Lesson engine<br/>retrieval, writing, rendering, checks]
        CORE --> TTS[Kokoro voice<br/>local]
        CORE --> BR[Chromium<br/>HTML slides]
        CORE --> FF[ffmpeg]
    end

    CORE -->|chat, embeddings| BF[Bifrost gateway]
    BF --> BED[Amazon Bedrock EU<br/>Claude, Titan embeddings]
    CORE --- PVC[(Volume /app/data<br/>knowledge base, index,<br/>results, chats, cost log)]
    SM[AWS Secrets Manager] -.->|External Secrets| POD
```

| Component | Technology | Role |
|---|---|---|
| Sign-in | oauth2-proxy, Microsoft Entra ID | Company login in front of the app; passes the user's e-mail |
| Web app | Python standard library HTTP server (`app.py`, `app_page.html`) | Chat page, job queue, results, costs, health and metrics endpoints |
| Language model | Claude on Amazon Bedrock (EU), via the Bifrost gateway (`llm.py`) | Understanding requests, choosing excerpts, writing answers and storyboards, reviews |
| Embeddings | Titan Text Embeddings v2 via Bifrost (pod); `nomic-embed-text` via Ollama (local) | Meaning search |
| Voice | Kokoro (ONNX, CPU, local) | Narration; no data leaves the pod |
| Slides | HTML/CSS/SVG rendered by Chromium (Playwright) | Slides and animation frames |
| Video | ffmpeg | mp4, mp3, subtitles |
| Storage | Persistent volume (files) | Knowledge base, search index, results, chats, cost log |
| Secrets | AWS Secrets Manager + External Secrets | Bifrost key, sign-in secrets |

## Request flow

```mermaid
flowchart TD
    R[Request in plain words] --> L{Library: same request<br/>made before?}
    L -->|yes| OUT[Result returned at no cost]
    L -->|no| UND[1 Understand<br/>format, topic, length, level<br/>off-topic stopped before any paid call]
    UND --> FIND[2 Find<br/>meaning search + BM25 word search, fused<br/>Claude keeps the excerpts that answer]
    FIND --> WRITE[3 Write<br/>answer / document / storyboard<br/>from the excerpts only, sources per scene]
    WRITE --> REV[Self-review with findings from code checks]
    REV --> MAKE[4 Make<br/>slides + voice + ffmpeg<br/>or document / deck / audio]
    MAKE --> CHECK[5 Check<br/>numbers vs sources, claims, safety,<br/>personal data, layout, sound]
    CHECK --> CARD[6 Verdict OK / CHECK / FAIL<br/>run card: sources, models, cost, time]
```

| Output | Path through the code |
|---|---|
| Answer | `answer.py`: retrieval → answer → sentence-by-sentence claim check |
| Document | `lesson.py`, `document.py` |
| Slide deck | `deck.py` |
| Video up to 4 min | `make_video.py`: storyboard (`storyboard.py`) → self-review → `slides_html.py` + `tts.py` → ffmpeg |
| Video 4–15 min (course) | `course.py`: topic map → outline → chapters in parallel → quick checks → assembly |
| Two-character video | `dialogue.py`, `cartoon.py` |

Jobs run one at a time from an in-memory queue; each browser sees only its own requests. A running job can be
stopped and resumed (finished scenes are kept).

## Knowledge base and retrieval

```mermaid
flowchart LR
    IN[data/input<br/>recordings, transcripts,<br/>Word, PowerPoint, PDF, Excel, quizzes] --> PIPE[pipeline.py<br/>inventory, transcripts, slide OCR,<br/>slide descriptions, document reading]
    PIPE --> CH[Excerpts<br/>sections split where the content changes]
    CH --> CTX[contextual.py<br/>1-2 sentences of context per excerpt]
    CTX --> IDX[index.py<br/>vectors.npy, ids.json, info.json]
    CH --> TOP[topics.py<br/>topic map per recording]
```

| Step | How |
|---|---|
| Ingestion | Once per source, locally (`pipeline.py`); filters system files, duplicates, other languages, low-text files |
| Chunking | Recordings split where the content changes (20 s – 3 min); documents ~180 words with their location |
| Contextual retrieval | Each excerpt gets a short context sentence before indexing |
| Index | Files on the volume (NumPy vectors + ids + metadata); rebuilt in the pod with the pod's embedding model |
| Search | Hybrid: cosine similarity + BM25, fused; ~30 candidates reranked by Claude to 8–10 excerpts |
| Courses | Outline from the topic map (structure of the whole material), chapters from search |

## Deployment

```mermaid
flowchart LR
    DEV[Push to main] --> CC[code-checks<br/>ruff, mypy]
    DEV --> LC[lint-chart<br/>helm template]
    CC --> B[build-image<br/>kaniko → ECR<br/>tag main-SHA-pipeline]
    B --> T[update-dev-image-tag<br/>tag written to values-dev-eks.yaml<br/>on branch deploy-dev]
    T --> ARGO[Argo CD<br/>syncs deploy-dev]
    ARGO --> EKS[EKS dev<br/>namespace agent-prototypes]
```

| Item | Value |
|---|---|
| Repository layout | `Dockerfile`, `.gitlab-ci.yml`, Helm chart `charts/proto-learning-agent` (`values.yaml`, `values-dev-eks.yaml`) |
| Image | One container, built by kaniko, pushed to ECR with the GitLab ID token (OIDC); immutable unique tags |
| Release | GitOps: the pipeline writes the image tag to `deploy-dev`; Argo CD deploys it |
| Pod | 1 replica, `Recreate`, non-root, read-only root file system, probes `/healthz` and `/readyz` |
| Shared platform pieces | Cluster, gateway, Bifrost, Microsoft sign-in (same as proto-invoicing) |

## Security and compliance

| Rule | Implementation |
|---|---|
| EU models only, no OpenAI, no Chinese-origin models | Model ids checked before every call (`safety.py`) |
| No secrets in code, image or git | Secrets from AWS Secrets Manager via External Secrets; locally `.env` (git-ignored) |
| Company sign-in | oauth2-proxy with Microsoft Entra ID; the app trusts only the forwarded e-mail header |
| Grounding | Only indexed excerpts go into prompts; every scene cites its sources; unsupported claims removed |
| Personal data | Speaker names masked before model calls; e-mail addresses and phone numbers fail a result |
| Spending lock | Daily and per-run budgets in code (`DAILY_BUDGET_USD`, `RUN_BUDGET_USD`); every call logged |
| Content safety | Blocked and sensitive words, instruction-like material left out, fixed picture library |

## Data on the volume (`/app/data`)

| Path | Content |
|---|---|
| `processed/`, `index/` | Excerpts, topic maps, search index |
| `output/` | Results (video, audio, documents, run cards), chats, library of finished results |
| `cost_log.csv` | Every model call with tokens and cost |

## Costs

Only Claude (and the embeddings) are paid; voice, slides and video are produced in the pod. Prompt caching cuts
repeated input to a tenth of the price, and a request asked again is served from the library at no cost. Measured
costs per video length and the AWS estimate: `docs/COSTS.md`.

## Limits

One pod and one job at a time; files on one volume; file-based vector index. The path beyond these: `docs/ROADMAP.md`.
