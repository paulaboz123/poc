"""
aws_estimate.py - what AWS costs a month, as the AWS Pricing Calculator says: no figures of our own.

Make the estimate at https://calculator.aws (two groups, Prod and Dev: docs/COSTS.md says what to
enter), then Export > CSV (or JSON) and save the file in data/aws/. The share link of the estimate can go in
data/aws/link.txt. Lesson Studio (tab Prices & results) shows each group's services and monthly total from
that file, and nothing about AWS while there is none.

  uv run aws_estimate.py          # what was read from data/aws
"""
from __future__ import annotations

import csv
import io
import json
import logging
import re
import sys
from pathlib import Path

import config

log = logging.getLogger("aws_estimate")


def folder() -> Path:
    """Where the AWS Pricing Calculator's export goes (data/aws)."""
    return config.DATA_DIR / "aws"


def _num(v: object) -> float:
    try:
        return float(re.sub(r"[^\d.\-]", "", str(v)) or 0)
    except ValueError:
        return 0.0


def _group(path: str) -> str:
    """'My Estimate > Prod > App' -> 'Prod' (the group under the estimate); no group -> 'Estimate'."""
    parts = [p.strip() for p in re.split(r"\s*>\s*", path or "") if p.strip()]
    return parts[1] if len(parts) > 1 else (parts[0] if parts else "Estimate")


def from_csv(text: str) -> list[dict]:
    """The calculator's CSV export: a summary block, then a table with Group hierarchy, Region, Description,
    Service, Upfront, Monthly, ... Configuration summary. Only that table is read."""
    rows = list(csv.reader(io.StringIO(text)))
    head = next((i for i, r in enumerate(rows) if {"Service", "Monthly"} <= {c.strip() for c in r}), None)
    if head is None:
        return []
    cols = {c.strip(): i for i, c in enumerate(rows[head])}

    def get(r: list[str], name: str) -> str:
        i = cols.get(name)
        return r[i].strip() if i is not None and i < len(r) else ""
    out = []
    for r in rows[head + 1:]:
        if not r or not get(r, "Service"):
            continue
        out.append({"group": _group(get(r, "Group hierarchy")), "service": get(r, "Service"),
                    "description": get(r, "Description"), "region": get(r, "Region"),
                    "monthly": _num(get(r, "Monthly")), "upfront": _num(get(r, "Upfront")),
                    "config": get(r, "Configuration summary")})
    return out


def from_json(data: object) -> list[dict]:
    """The calculator's JSON export: every entry with a service name and a monthly cost, wherever it is nested;
    the group is the name of the group it sits in."""
    out = []

    def walk(node: object, group: str) -> None:
        if isinstance(node, dict):
            name = node.get("Service Name") or node.get("serviceName") or node.get("Service")
            cost = node.get("Service Cost") or node.get("serviceCost") or node.get("Cost") or {}
            monthly = cost.get("monthly") if isinstance(cost, dict) else node.get("Monthly")
            if isinstance(name, str) and monthly is not None:
                out.append({"group": group, "service": name, "description": node.get("Description", "") or "",
                            "region": node.get("Region", "") or "", "monthly": _num(monthly),
                            "upfront": _num(cost.get("upfront", 0) if isinstance(cost, dict) else 0),
                            "config": node.get("Properties") and json.dumps(node["Properties"])[:300] or ""})
                return
            for k, v in node.items():
                if k in ("Groups", "groups") and isinstance(v, dict):
                    for gname, g in v.items():
                        walk(g, (g.get("Name") or gname) if isinstance(g, dict) else gname)
                else:
                    walk(v, group)
        elif isinstance(node, list):
            for v in node:
                walk(v, group)
    walk(data, "Estimate")
    return out


def newest() -> Path | None:
    """The newest exported estimate (CSV or JSON), or None."""
    files = [p for p in folder().glob("*") if p.suffix.lower() in (".csv", ".json")] if folder().is_dir() else []
    return max(files, key=lambda p: p.stat().st_mtime) if files else None


def summary() -> dict:
    """{file, link, groups: [{name, monthly, services: [...]}], monthly} from the newest export; {} without one."""
    f = newest()
    if f is None:
        return {}
    try:
        text = f.read_text(encoding="utf-8-sig", errors="replace")
        rows = from_json(json.loads(text)) if f.suffix.lower() == ".json" else from_csv(text)
    except Exception as e:   # noqa: BLE001 - a file the page cannot read: say so instead of guessing
        log.warning("%s could not be read: %s", f.name, e)
        return {"file": f.name, "error": f"{f.name} could not be read ({e})", "groups": [], "monthly": 0.0}
    order = {"prod": 0, "production": 0, "dev": 1, "development": 1}
    groups: dict[str, dict] = {}
    for r in rows:
        g = groups.setdefault(r["group"], {"name": r["group"], "services": [], "monthly": 0.0})
        g["services"].append(r)
        g["monthly"] = round(g["monthly"] + r["monthly"], 2)
    link_file = folder() / "link.txt"
    link = link_file.read_text(encoding="utf-8").strip().split()[0] if link_file.exists() and link_file.read_text().strip() else ""
    return {"file": f.name, "link": link if link.startswith("https://") else "",
            "groups": sorted(groups.values(), key=lambda g: (order.get(g["name"].lower(), 2), g["name"])),
            "monthly": round(sum(r["monthly"] for r in rows), 2),
            "error": "" if rows else f"{f.name}: no services found (export the estimate as CSV from calculator.aws)"}


def main() -> int:
    """Command line: print what was read from the calculator's export. Returns the exit code."""
    config.setup_logging()
    s = summary()
    if not s:
        print(f"No AWS estimate yet: export it from calculator.aws (CSV) into {folder()}")
        return 0
    print(f"{s['file']}{' - ' + s['link'] if s['link'] else ''}")
    for g in s["groups"]:
        print(f"\n{g['name']}: ${g['monthly']:,.2f} a month")
        for r in g["services"]:
            print(f"  ${r['monthly']:>9,.2f}  {r['service']}{' - ' + r['description'] if r['description'] else ''}")
    print(f"\nTotal: ${s['monthly']:,.2f} a month" + (f"\n{s['error']}" if s.get("error") else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
