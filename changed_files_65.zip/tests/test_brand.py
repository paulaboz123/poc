"""brand.py: the company's logo, colours and PowerPoint template in the slides, presentations and videos."""
from __future__ import annotations

import re
import subprocess
import zipfile

import pytest
from conftest import needs_ffmpeg

import brand
import config
import slides_html


def _logo(path, colour=(11, 65, 205)):
    from PIL import Image, ImageDraw
    im = Image.new("RGBA", (300, 100), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((0, 10, 290, 90), 20, fill=colour + (255,))
    d.ellipse((20, 25, 70, 75), fill=(255, 125, 41, 255))
    im.save(path)
    return path


def _template(path, accent1="0B41CD", accent2="FF7D29"):
    """A PowerPoint template with its own theme colours and one example slide (which must not end up in ours)."""
    pptx = pytest.importorskip("pptx")
    prs = pptx.Presentation()
    s = prs.slides.add_slide(prs.slide_layouts[1])
    s.shapes.title.text = "EXAMPLE SLIDE OF THE TEMPLATE"
    tmp = path.with_suffix(".tmp.pptx")
    prs.save(tmp)
    with zipfile.ZipFile(tmp) as zin, zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if re.fullmatch(r"ppt/theme/theme\d+\.xml", item.filename):
                text = data.decode("utf-8")
                text = re.sub(r'(<a:accent1>\s*<a:srgbClr val=")[0-9A-Fa-f]{6}', rf"\g<1>{accent1}", text)
                text = re.sub(r'(<a:accent2>\s*<a:srgbClr val=")[0-9A-Fa-f]{6}', rf"\g<1>{accent2}", text)
                data = text.encode("utf-8")
            zout.writestr(item, data)
    tmp.unlink()
    return path


def _reset():
    brand.info.cache_clear()
    slides_html.css.cache_clear()


def test_no_brand_changes_nothing(project):
    assert not brand.on() and brand.css() == "" and brand.logo_html() == ""
    assert brand.accents("#111111", "#222222") == ("#111111", "#222222")


def test_colours_from_the_template_and_the_logo_on_every_slide(project):
    d = config.BRAND_DIR
    d.mkdir(parents=True)
    _logo(d / "logo.png")
    _template(d / "Company template.pptx")
    _reset()
    i = brand.info()
    assert i["on"] and i["logo"].name == "logo.png" and i["accent"] == "#0b41cd" and i["accent2"] == "#ff7d29"
    assert i["colour_source"] == "template"
    html, _ = slides_html.scene_html({"visual": "bullets", "heading": "Hello", "items": ["one", "two"]},
                                     lesson_title="T", goal="", page="1 / 2")
    assert 'class="brandlogo"' in html and "has-logo" in html and ".brandlogo{" in html


def test_brand_json_wins_and_logo_colours_without_template(project):
    d = config.BRAND_DIR
    d.mkdir(parents=True)
    _logo(d / "logo.png")
    _reset()
    assert brand.info()["accent"] and brand.info()["colour_source"] == "logo"   # the logo's blue
    (d / "brand.json").write_text('{"accent": "#123456", "accent2": "#abcdef", "logo_corner": "bottom-left"}')
    _reset()
    i = brand.info()
    assert (i["accent"], i["accent2"], i["corner"]) == ("#123456", "#abcdef", "bottom-left")


def test_presentation_made_in_the_template(project):
    pptx = pytest.importorskip("pptx")
    d = config.BRAND_DIR
    d.mkdir(parents=True)
    _template(d / "template.pptx")
    _reset()
    sb = {"title": "Joining data", "goal": "Join two tables", "scenes": [
        {"visual": "title", "heading": "Joining data"},
        {"visual": "bullets", "heading": "Before you join", "elements": [{"title": "Trim the keys", "detail": "no spaces"}]},
        {"visual": "comparison", "heading": "Inner vs left", "columns": [{"heading": "Inner", "items": ["matches only"]},
                                                                         {"heading": "Left", "items": ["every row"]}]}]}
    out = brand.write_pptx(sb, ["hello", "trim", "compare"], project / "slides.pptx")
    prs = pptx.Presentation(str(out))
    texts = [" ".join(sh.text_frame.text for sh in s.shapes if sh.has_text_frame) for s in prs.slides]
    assert len(prs.slides) == 3 and "EXAMPLE SLIDE" not in " ".join(texts)
    assert "Trim the keys" in texts[1] and "no spaces" in texts[1] and "every row" in texts[2]
    assert prs.slides[1].notes_slide.notes_text_frame.text == "trim"


@needs_ffmpeg
def test_logo_put_on_a_finished_video(project):
    d = config.BRAND_DIR
    d.mkdir(parents=True)
    _logo(d / "logo.png", colour=(255, 0, 0))
    _reset()
    config.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    video = config.OUTPUT_DIR / "v.mp4"
    subprocess.run([config.FFMPEG, "-loglevel", "error", "-y", "-f", "lavfi", "-i", "color=c=white:s=640x360:d=1",
                    "-f", "lavfi", "-i", "sine=d=1", "-shortest", "-c:v", "libx264", "-pix_fmt", "yuv420p", str(video)],
                   check=True)
    assert brand.stamp(video)
    frame = config.OUTPUT_DIR / "f.png"
    subprocess.run([config.FFMPEG, "-loglevel", "error", "-y", "-i", str(video), "-frames:v", "1", str(frame)], check=True)
    from PIL import Image
    im = Image.open(frame).convert("RGB")
    r, g, b = im.getpixel((640 - 13 - 10, 13 + 6))   # inside the logo, top right
    assert r > 180 and g < 90 and b < 90
    assert im.getpixel((20, 300)) == (255, 255, 255) or sum(im.getpixel((20, 300))) > 740   # the rest untouched
