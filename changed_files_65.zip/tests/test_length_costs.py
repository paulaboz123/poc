"""length_costs.py: videos of several lengths, measured, and the progression and limits worked out."""
from __future__ import annotations

from conftest import needs_ffmpeg
from test_end_to_end import _prepare_one_recording

import config
import length_costs


@needs_ffmpeg
def test_two_lengths_measured_with_progression_and_limits(gateway, fake_voice, monkeypatch):
    _prepare_one_recording()
    monkeypatch.setattr(length_costs, "RENDERER", "pillow")   # fast; the html renderer has its own tests
    voice_before = config.TTS_VOICE
    data = length_costs.run("how to join two tables", [1, 4])
    assert set(data["runs"]) == {"1", "4"} and not data.get("errors")
    assert config.RENDERER == "pillow" and config.TTS_VOICE == voice_before   # settings put back
    rows = data["runs"]
    assert rows["1"]["claude_usd"] > 0 and rows["4"]["length_s"] > rows["1"]["length_s"]
    rep = length_costs.report()
    assert [r["minutes"] for r in rep["rows"]] == [1, 4]
    assert all(r["total_usd"] >= r["claude_usd"] for r in rep["rows"])
    assert rep["progression"][-1]["minutes"] == 60 and rep["progression"][-1]["usd"] >= rep["progression"][0]["usd"]
    assert any("Spending lock" in x["limit"] for x in rep["limits"])
    md = length_costs.write(rep)
    assert "Progression" in md.read_text(encoding="utf-8")
    # made before: not made again
    calls = len(gateway.state["calls"])
    length_costs.run("how to join two tables", [1])
    assert len(gateway.state["calls"]) == calls


def test_fit_is_a_line():
    rows = [{"real_min": 3, "total_usd": 0.2}, {"real_min": 5, "total_usd": 0.3}, {"real_min": 10, "total_usd": 0.55}]
    a, b = length_costs.fit(rows, "total_usd")
    assert abs(b - 0.05) < 0.001 and abs(a - 0.05) < 0.01
