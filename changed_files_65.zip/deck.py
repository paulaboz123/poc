"""
deck.py - a simple presentation (no voice, no motion): the same designer slides as the videos,
each in its final state, with what the narrator would say as speaker notes.

Writes into the output folder:
  slides.pdf        all slides, one per page (to present, print or send)
  slides.pptx       the same slides with speaker notes (only when python-pptx is installed:
                    uv add python-pptx); the slides are pictures, the notes are editable text.
                    With the company template in data/brand (brand.py): made in the template, the
                    headings and points editable, and the pictures in slides_pictures.pptx
  scenes/scene_NN.png   each slide as a picture
  notes.md          the speaker notes, slide by slide
  script.md / storyboard.json   as for a video (edit and re-run with --rerender)

Usage:
  uv run deck.py "the scrum roles" --minutes 4 --level beginner --style clean
  uv run deck.py --rerender output/<folder>       (after editing storyboard.json)
"""
from __future__ import annotations

import argparse
import logging
import sys
import time
from pathlib import Path

import config
import lesson
import llm
import make_video
import store
import storyboard

log = logging.getLogger("deck")


def slide_pictures(out_dir: Path, sb: dict) -> tuple[list[Path], str]:
    """scenes/scene_NN.png for every scene, everything shown, and the renderer used: designer
    slides with a browser ("html"), else the simple slides ("pillow")."""
    scenes = sb["scenes"]
    folder = out_dir / "scenes"
    folder.mkdir(parents=True, exist_ok=True)
    for stale in folder.glob("scene_*"):
        stale.unlink(missing_ok=True)
    out = [folder / f"scene_{i + 1:02d}.png" for i in range(len(scenes))]
    style = sb.get("style", "clean")
    try:
        import slides_html
        if config.RENDERER != "html":
            raise RuntimeError(f"RENDERER={config.RENDERER}")
        browser = slides_html.Browser()
    except (ImportError, RuntimeError) as e:
        log.info("simple slides (%s)", e)
        import render
        for i, sc in enumerate(scenes):
            slide = Path(sc["slide_image"]) if sc.get("slide_image") else None
            render.render_scene(sc, out[i], lesson_title=sb["title"], goal=sb.get("goal", ""),
                                page=f"{i + 1} / {len(scenes)}", slide_image=slide, caption=sc.get("caption", ""))
        return out, "pillow"
    issues: dict[str, list[str]] = {}
    try:
        for i, sc in enumerate(scenes):
            slide = Path(sc["slide_image"]) if sc.get("slide_image") else None
            page_html, n = slides_html.scene_html(sc, lesson_title=sb["title"], goal=sb.get("goal", ""),
                                                  page=f"{i + 1} / {len(scenes)}", slide_image=slide,
                                                  caption=sc.get("caption", ""), style=style)
            tl = slides_html.timeline({**sc, "animation": "none"}, [], [], n)
            browser.still(page_html, tl, 30.0, out[i])
            found = browser.page.evaluate("typeof layoutIssues==='function' ? layoutIssues() : []")
            if found:
                issues[str(i + 1)] = found
                log.warning("slide %s layout: %s", i + 1, "; ".join(found[:3]))
            out[i].with_suffix(".html").unlink(missing_ok=True)
    finally:
        browser.close()
    store.write_json(out_dir / "layout.json", issues)
    return out, "html"


def notes(sb: dict) -> list[str]:
    """What to say on each slide (the narration of the scene)."""
    return [(sc.get("narration") or "").strip() for sc in sb["scenes"]]


def write_pdf(pngs: list[Path], out: Path) -> Path:
    from PIL import Image
    pages = [Image.open(p).convert("RGB") for p in pngs]
    pages[0].save(out, save_all=True, append_images=pages[1:], resolution=150)
    for p in pages:
        p.close()
    return out


def write_pptx(pngs: list[Path], speaker_notes: list[str], out: Path) -> Path | None:
    """A 16:9 PowerPoint file: one full-size picture per slide plus speaker notes, or None
    when python-pptx is not installed."""
    try:
        from pptx import Presentation
        from pptx.util import Emu
    except ImportError:
        log.info("slides.pptx skipped: uv add python-pptx")
        return None
    prs = Presentation()
    prs.slide_width, prs.slide_height = Emu(12192000), Emu(6858000)
    blank = prs.slide_layouts[6]
    for png, text in zip(pngs, speaker_notes, strict=True):
        s = prs.slides.add_slide(blank)
        s.shapes.add_picture(str(png), 0, 0, width=prs.slide_width, height=prs.slide_height)
        if text:
            s.notes_slide.notes_text_frame.text = text
    prs.save(out)
    return out


def produce(out_dir: Path) -> dict:
    sb = storyboard.load(out_dir)
    t0 = time.perf_counter()
    pngs, renderer = slide_pictures(out_dir, sb)
    said = notes(sb)
    (out_dir / "notes.md").write_text(
        f"# {sb['title']} - speaker notes\n\n" + "\n\n".join(
            f"## Slide {i}: {sc.get('heading', '')}\n\n{t}" for i, (sc, t) in enumerate(zip(sb["scenes"], said, strict=True), 1)),
        encoding="utf-8")
    pdf = write_pdf(pngs, out_dir / "slides.pdf")
    import brand  # with the company template (data/brand): slides.pptx in it, editable; the pictures beside it
    branded = brand.write_pptx(sb, said, out_dir / "slides.pptx")
    pictures_pptx = write_pptx(pngs, said, out_dir / ("slides_pictures.pptx" if branded else "slides.pptx"))
    pptx = branded or pictures_pptx
    return {"slides": len(pngs), "pdf": str(pdf), "pptx": str(pptx) if pptx else "", "renderer": renderer,
            "template": brand.template().name if branded else "",
            "notes": str(out_dir / "notes.md"), "render_s": round(time.perf_counter() - t0, 1)}


def make(topic: str | None = None, recording: str | None = None, minutes: float = 3, level: str = "beginner",
         model: str | None = None, rerender: Path | None = None, wishes: str = "",
         style: str | None = None) -> tuple[Path, dict]:
    """Storyboard (as for a video) -> slides. Returns (folder, info)."""
    t_start = time.perf_counter()
    out_dir = rerender if rerender else make_video.plan(topic, recording, minutes, level, model, wishes,
                                                        style or "clean")
    if not rerender:   # a presentation, not a video: name the folder so
        new = out_dir.with_name(out_dir.name.replace("-video-", "-slides-"))
        if new != out_dir and not new.exists():
            out_dir = out_dir.rename(new)
    mark = llm.meter_mark()
    sb = storyboard.load(out_dir)
    info = {"title": sb["title"], "request": sb.get("request", {}), "model": sb.get("model", ""),
            "model_cost_usd_est": sb.get("plan_cost_usd_est", 0.0), "format": "slides", **produce(out_dir)}
    info["total_s"] = round(time.perf_counter() - t_start, 1)
    store.write_json(out_dir / "info.json", info)
    import runcard
    runcard.write(out_dir, kind="slides", title=sb["title"], request=sb.get("request", {}),
                  sources=sb.get("sources", {}), calls=sb.get("plan_calls", []) + llm.calls_since(mark),
                  timings={"slides_s": info["render_s"], "total_s": info["total_s"]}, style=sb.get("style", ""),
                  renderer=info["renderer"], settings=sb.get("settings"))
    return out_dir, info


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("topic", nargs="?")
    ap.add_argument("--recording", help="ids or titles of recordings to present (comma-separated)")
    ap.add_argument("--minutes", type=float, default=3, help="how long the talk would be")
    ap.add_argument("--level", choices=list(lesson.LEVELS), default="beginner")
    ap.add_argument("--style", choices=["clean", "illustrated", "presenter"], default="clean")
    ap.add_argument("--model")
    ap.add_argument("--rerender", type=Path, help="redraw an existing folder (no model calls)")
    args = ap.parse_args()
    config.setup_logging()
    if not (args.topic or args.recording or args.rerender):
        ap.error("give a topic, --recording or --rerender")
    try:
        out_dir, info = make(args.topic, args.recording, args.minutes, args.level, args.model, args.rerender,
                             style=args.style)
    except lesson.NotEnoughMaterial as e:
        log.error("%s", e)
        return 2
    except (RuntimeError, ValueError, OSError) as e:
        log.error("%s", e)
        return 1
    print(f"Slides: {info['pdf']}" + (f"\nPowerPoint: {info['pptx']}" if info["pptx"] else ""))
    print(f"Speaker notes: {info['notes']}\nEstimated model cost: ${llm.spent_this_run():.3f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
