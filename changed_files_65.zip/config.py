"""
config.py - one place for every path and setting.

Every other script does `import config` and reads from here. Settings come from .env, so
you change things in one place. Start from a template:
  .env.local.example    everything on this laptop (Ollama), no key needed
  .env.bifrost.example  Claude + Titan on Bedrock via the Bifrost gateway (needs URL + key)
"""
from __future__ import annotations

import logging
import os
import shutil
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / ".env")


def _get(name: str, default: str = "") -> str:
    """Read a setting from .env (or the environment), falling back to a default."""
    value = os.getenv(name, "").strip()
    return value or default


def _find_tesseract() -> str:
    """TESSERACT from .env, else whatever is on PATH, else the default Windows folder."""
    configured = _get("TESSERACT")
    if configured:
        return configured
    on_path = shutil.which("tesseract")
    if on_path:
        return on_path
    # usual Windows install folders: for all users, 32-bit, or only for this user (winget/no admin)
    local = os.getenv("LOCALAPPDATA", "")
    for folder in (r"C:\Program Files\Tesseract-OCR", r"C:\Program Files (x86)\Tesseract-OCR",
                   local and os.path.join(local, "Programs", "Tesseract-OCR"),
                   local and os.path.join(local, "Tesseract-OCR")):
        if folder and Path(folder, "tesseract.exe").exists():
            return str(Path(folder, "tesseract.exe"))
    return "tesseract"


# --- Folders ------------------------------------------------------------------
DATA_DIR = ROOT / "data"
INPUT_DIR = DATA_DIR / "input"          # original recordings + transcripts (never modified)
PROCESSED_DIR = DATA_DIR / "processed"  # one sub-folder per recording: segments, slides
INDEX_DIR = DATA_DIR / "index"          # search index (embeddings)
OUTPUT_DIR = DATA_DIR / "output"        # generated lessons and videos
MANIFEST = DATA_DIR / "manifest.csv"    # which recording goes with which transcript
GLOSSARY_FILE = DATA_DIR / "glossary.csv"   # terms, acronyms and their spellings (glossary.py)
MODELS_DIR = ROOT / "models"            # local model files (the Kokoro voice)
SKILLS_DIR = ROOT / "skills"            # prompts, in SKILL.md format
EVAL_DIR = ROOT / "eval"                # golden set + evaluation results
COST_LOG = ROOT / "cost_log.csv"        # one row per model call
# Excel with columns id | name | description, one row per recording (see inventory.py).
# Empty = the first description*.xlsx found anywhere in data/input.
DESCRIPTIONS_FILE = _get("DESCRIPTIONS_FILE")

# --- Model access -----------------------------------------------------------------
# Every model job can run on the company gateway or on this laptop:
#   bifrost = Bifrost gateway -> Amazon Bedrock (Claude). Needs URL + key below.
#   ollama  = local models via Ollama: free and offline, but slow and weaker.
# Paste the values from the platform team's e-mail as they are: the Claude Code address
# ".../anthropic" works too, the ending is removed here.
def _gateway_base(url: str) -> str:
    """'https://x/anthropic/' -> 'https://x' (also strips /openai and /v1 endings)."""
    url = url.strip().rstrip("/")
    for ending in ("/v1", "/anthropic", "/openai", "/v1"):
        url = url.removesuffix(ending).rstrip("/")
    return url


BIFROST_BASE_URL = _gateway_base(_get("BIFROST_BASE_URL", _get("ANTHROPIC_BASE_URL")))
BIFROST_API_KEY = _get("BIFROST_API_KEY", _get("ANTHROPIC_API_KEY"))
# How the key is sent: auto (both Authorization: Bearer and x-bf-vk, the default),
# authorization, x-bf-vk or x-api-key. Change only if the platform team says so.
BIFROST_AUTH_HEADER = _get("BIFROST_AUTH_HEADER", "auto").lower()
# Which gateway API to call: auto (OpenAI-style /v1, falls back to the Anthropic-style
# /anthropic route that Claude Code uses), openai, or anthropic.
GATEWAY_API = _get("GATEWAY_API", "auto").lower()
# Corporate networks sometimes inspect TLS with their own certificate. If you get
# "CERTIFICATE_VERIFY_FAILED", put the path of the company CA bundle (.pem) here.
CA_BUNDLE = _get("CA_BUNDLE")
OLLAMA_URL = _get("OLLAMA_URL", "http://localhost:11434").rstrip("/").removesuffix("/v1")

BACKENDS = ("bifrost", "ollama")
CHAT_BACKEND = _get("CHAT_BACKEND", "bifrost" if BIFROST_BASE_URL else "ollama").lower()
VISION_BACKEND = _get("VISION_BACKEND", CHAT_BACKEND).lower()
# Search runs locally by default: Claude models cannot make embeddings, and the local
# nomic-embed-text is free and good enough. Bedrock embeddings (Titan) only if enabled for you.
EMBED_BACKEND = _get("EMBED_BACKEND", "ollama").lower()

# Model names exactly as the backend expects them. For Bifrost: copy the ids from the
# platform team's e-mail (e.g. bedrock/eu.anthropic.claude-sonnet-...). No guessed defaults.
# Local defaults are from Meta (Llama) and Google (Gemma); models of Chinese origin are not
# allowed in this project, even offline.
CHAT_MODEL = _get("CHAT_MODEL", _get("ANTHROPIC_DEFAULT_SONNET_MODEL",
                  "" if CHAT_BACKEND == "bifrost" else "llama3.1:8b"))
if VISION_BACKEND == "bifrost":
    VISION_MODEL = _get("VISION_MODEL", CHAT_MODEL if CHAT_BACKEND == "bifrost" else "")
else:
    VISION_MODEL = _get("VISION_MODEL", "gemma3:4b")
EMBED_MODEL = _get("EMBED_MODEL", "bedrock/amazon.titan-embed-text-v2:0" if EMBED_BACKEND == "bifrost"
                   else "nomic-embed-text")
MODEL_ID = CHAT_MODEL   # old name, still used in a few log lines


def model_choices(default_model: str = "", default_backend: str = "") -> list[dict]:
    """Models to choose from on the Lesson Studio page. The first one is the default (CHAT_MODEL).
    Then MODEL_CHOICES=Label=id,Label=id from .env; without it the Claude ids in
    ANTHROPIC_DEFAULT_OPUS/SONNET/HAIKU_MODEL; plus LOCAL_MODEL (free, Ollama) when set."""
    model_id, backend = default_model or CHAT_MODEL, default_backend or CHAT_BACKEND
    family = next((f"Claude {n.title()}" for n in ("opus", "sonnet", "haiku") if n in model_id.lower()), model_id)
    listed = [(label.strip(), model.strip()) for label, _, model in
              (x.strip().partition("=") for x in _get("MODEL_CHOICES", "").split(",") if "=" in x)]
    if not listed:
        listed = [(label, _get(f"ANTHROPIC_DEFAULT_{name}_MODEL", "")) for name, label in
                  (("OPUS", "Claude Opus (best, ~2.5x cost)"), ("SONNET", "Claude Sonnet"), ("HAIKU", "Claude Haiku (cheapest)"))]
    local = _get("LOCAL_MODEL", "llama3.1:8b" if backend == "bifrost" and _get("OFFER_LOCAL_MODEL", "no") == "yes" else "")
    if local:
        listed.append(("Local Llama (free, slower, plainer)", local))
    out, seen = [], set()

    def add(label: str, model: str) -> None:
        if model and model not in seen:
            seen.add(model)
            is_local = ":" in model and "/" not in model and not model.startswith(("eu.", "us.", "anthropic."))
            out.append({"label": label, "id": model, "backend": "ollama" if is_local else
                        ("bifrost" if backend == "ollama" else backend)})
    add(f"{ {mid: name for name, mid in listed}.get(model_id, family)} (default)", model_id)
    if out:   # CHAT_MODEL empty (no .env yet): no default to mark
        out[0]["backend"] = backend
    for label, model in listed:
        add(label, model)
    return out

NUM_CTX = int(_get("NUM_CTX", "16384"))               # Ollama only: context window we request
MAX_OUTPUT_TOKENS = int(_get("MAX_OUTPUT_TOKENS", "6000"))
LLM_TIMEOUT_S = float(_get("LLM_TIMEOUT_S", "1800" if CHAT_BACKEND == "ollama" else "300"))
# How much transcript (in words) a lesson or video may read. Claude reads a lot quickly
# and cheaply; a small local model needs short prompts.
MAX_MATERIAL_WORDS = int(_get("MAX_MATERIAL_WORDS", "9000" if CHAT_BACKEND == "bifrost" else "3000"))
# Through the gateway a lesson on a topic reads material in proportion to its length (cost):
# MIN_MATERIAL_WORDS at least, MATERIAL_WORDS_PER_MINUTE per minute, at most MAX_MATERIAL_WORDS.
# (A lesson about one whole recording always reads the whole recording, up to MAX_MATERIAL_WORDS.)
MIN_MATERIAL_WORDS = int(_get("MIN_MATERIAL_WORDS", "3500"))
MATERIAL_WORDS_PER_MINUTE = int(_get("MATERIAL_WORDS_PER_MINUTE", "2200"))
# Prompt caching (Anthropic route of the gateway): the instructions and the material are sent
# once at full price and re-read at ~10% by the self-review and corrections. Switches itself
# off if the gateway does not accept it.
PROMPT_CACHE = _get("PROMPT_CACHE", "yes").lower() in ("yes", "true", "1")

# Search scores below this mean "the recordings don't cover this topic". The right value
# depends on the embedding model: check real scores with  uv run index.py search "..."
MIN_SCORE = float(_get("MIN_SCORE", "0.45" if "nomic" in EMBED_MODEL else "0.2"))

# --- Costs and spending lock ----------------------------------------------------------
# Estimated USD per 1M tokens (input, output), matched by a part of the model name, first
# match wins. Claude list prices; unknown versions get the higher price, so the lock errs
# on the safe side. Regional ids (eu./us. ...) get +10%. Local models cost 0.
PRICES: list[tuple[str, float, float]] = [
    ("sonnet-5", 2.0, 10.0), ("sonnet", 3.0, 15.0),
    ("haiku-5", 0.10, 0.50), ("haiku", 1.0, 5.0),
    ("opus-5-5", 4.0, 20.0), ("opus-4-1", 15.0, 75.0), ("opus-4-0", 15.0, 75.0), ("opus", 5.0, 25.0),
    ("titan-embed", 0.02, 0.0), ("cohere.embed", 0.10, 0.0),
]
REGIONAL_PREMIUM = 1.1
# Optional override for the chat model, if the platform team gives you exact prices
PRICE_IN_PER_MTOK = float(_get("PRICE_IN_PER_MTOK", "0"))
PRICE_OUT_PER_MTOK = float(_get("PRICE_OUT_PER_MTOK", "0"))

# Spending lock for gateway calls (estimated from token counts, logged in cost_log.csv):
# - DAILY_BUDGET_USD: no more calls today once this is reached (default 20)
# - RUN_BUDGET_USD:   one command stops once it has spent this much (default 5)
# - HARD_DAILY_LIMIT_USD: 100, fixed in code. .env values above it are cut down to it.
# Only this pipeline is counted here; Claude Code on the same key counts toward the
# platform's own limit as well.
HARD_DAILY_LIMIT_USD = 100.0


def clamp_budget(value: float) -> float:
    """A budget setting forced into 0..HARD_DAILY_LIMIT_USD (a typo can't remove the lock)."""
    return max(0.0, min(value, HARD_DAILY_LIMIT_USD))


DAILY_BUDGET_USD = clamp_budget(float(_get("DAILY_BUDGET_USD", "20")))
RUN_BUDGET_USD = min(clamp_budget(float(_get("RUN_BUDGET_USD", "5"))), DAILY_BUDGET_USD)
# Model for the automatic review of videos (quality.py --review); default: the chat model
REVIEW_MODEL = _get("REVIEW_MODEL", CHAT_MODEL)
# --- Answers to questions (answer.py) and their evaluation (qa_eval.py) ---
# speakers' names become "Speaker 1", "Speaker 2" ... (also inside what is said) before any text is
# searched, sent to a model or shown; the original names stay in data/processed only
MASK_SPEAKERS = _get("MASK_SPEAKERS", "yes").lower() != "no"
# how transcripts are cut: content (where the subject, screen or speaker changes; best) | time (~1 minute)
CHUNKING = _get("CHUNKING", "content").lower()
CHUNK_MIN_S = float(_get("CHUNK_MIN_S", "20"))     # a piece is at least this long (enough meaning to search)
CHUNK_MAX_S = float(_get("CHUNK_MAX_S", "180"))    # and at most this long (precise enough to cite)
# answers get the whole topic section of a found piece as context, if the section is at most this long
SECTION_MAX_WORDS = int(_get("SECTION_MAX_WORDS", "1200"))
# how much of a slide (its text + the description of what it shows) the writer and the judge see; a dense
# slide or a described diagram cut short loses facts (and the judge then calls them invented)
SLIDE_TEXT_CHARS = int(_get("SLIDE_TEXT_CHARS", "2000"))
SECTIONS_CONTEXT = _get("SECTIONS_CONTEXT", "yes").lower() != "no"   # no = only the piece and its neighbours
# how excerpts are found: meaning | hybrid (meaning + words) | hybrid+rerank (the model then picks; best)
RETRIEVAL = _get("RETRIEVAL", "hybrid+rerank").lower()
# the model that scores candidate excerpts (a fast, cheap one is enough, e.g. Claude Haiku); empty = CHAT_MODEL
RERANK_MODEL = _get("RERANK_MODEL", "")
# the model that grades answers in qa_eval.py; best a different (stronger) one than the writer, so
# the writer doesn't grade itself; empty = REVIEW_MODEL
JUDGE_MODEL = _get("JUDGE_MODEL", "")
# weights of sources when ranking, by kind or by text in the title: "document=1.3,Scrum Guide=1.5"
SOURCE_PRIORITY = _get("SOURCE_PRIORITY", "")
# answers in own words: if more than this share of an answer is copied word for word, it is rewritten
COPY_LIMIT = float(_get("COPY_LIMIT", "0.3"))

# --- External tools -----------------------------------------------------------------
FFMPEG = _get("FFMPEG", "ffmpeg")
FFPROBE = _get("FFPROBE", "ffprobe")
TESSERACT = _find_tesseract()
OCR_LANG = _get("OCR_LANG", "eng")

VIDEO_EXT = {".mp4", ".mkv", ".mov", ".webm", ".m4v"}
AUDIO_EXT = {".m4a", ".mp3", ".wav", ".aac"}
MEDIA_EXT = VIDEO_EXT | AUDIO_EXT
TRANSCRIPT_EXT = {".vtt", ".docx"}

# --- Pipeline mode ------------------------------------------------------------------
# easy  = videos that already have a transcript (start here)
# audio = + audio files that already have a transcript
# all   = + every recording without a transcript (transcribed locally with Whisper)
PIPELINE_MODE = _get("PIPELINE_MODE", "easy")
MODES = ("easy", "audio", "all")

# Local speech-to-text, only used in mode "all": tiny / base / small / medium
WHISPER_MODEL = _get("WHISPER_MODEL", "small")

# Part of the frame that holds the slides, as fractions "left,top,right,bottom".
# Empty = whole frame. Teams recording with people on the right: e.g. 0,0,0.78,1
# A row's own "crop" column in the manifest overrides this.
SLIDE_CROP = _get("SLIDE_CROP")
# Part of the slide (after the crop) to paint over in the video lesson, same format.
# For a presenter's camera picture on top of the slide, e.g. bottom right: 0.72,0.62,1,1
# Check it with: uv run slides.py --video <video_id> --preview
SLIDE_MASK = _get("SLIDE_MASK")

# --- Narrated video -------------------------------------------------------------------
# kokoro = natural local voice (needs: uv run tts.py --download, once)
# system = the voice built into Windows (robotic, but needs nothing extra)
# no (default) = the video shows only NEW slides designed from the content; yes = the model may
# also show original slide images (screenshots from the recording)
ORIGINAL_SLIDES = _get("ORIGINAL_SLIDES", "no").lower() in ("yes", "true", "1")
# yes (default) = after the first draft the model reviews and improves its storyboard
# (one extra call, ~1-4 cents with Sonnet); no = first draft only (cheaper, faster)
SELF_REVIEW = _get("SELF_REVIEW", "yes").lower() in ("yes", "true", "1")
# languages of the material to use (recordings and documents); others are left out.
# en,de would also use German material (lessons stay in English; search across languages is weaker)
KNOWLEDGE_LANGS = [x.strip().lower() for x in _get("KNOWLEDGE_LANGS", "en").split(",") if x.strip()]
# model calls made at the same time for the chapters of a course (1 = one after another)
PARALLEL_CALLS = max(1, int(_get("PARALLEL_CALLS", "3")))
# yes = elements of a slide appear / are highlighted when the voice gets to them, with soft fades;
# no = still slides (faster to render)
ANIMATION = _get("ANIMATION", "yes").lower() in ("yes", "true", "1")
# html = designer slides drawn by a browser engine (needs: uv add playwright; uses the installed
# Edge or Chrome if Playwright's own Chromium is not downloaded); pillow = simple built-in drawings
RENDERER = _get("RENDERER", "html").lower()   # html | pillow | remotion | remotion-ai (Claude writes the scenes) | remotion-pro
# (also manim | revideo | motion-canvas | hyperframes: free engines drawing the slides, our narration added)
#            | manim | revideo | motion-canvas (free animation engines, the narration added to their slides)
# remotion-pro: who presents in the presenter and dialogue styles:
#   robot (3D) | cat (3D) | person-3d (a woman and a man in suits) | person-2d (illustrated, fastest)
#   | company (the company's own avatar: a picture in data/avatars made to talk, company_avatar.py) | none
PRO_PRESENTER = _get("PRO_PRESENTER", "robot").lower()
# person-3d presenting alone: woman | man
PRO_PERSON = _get("PRO_PERSON", "woman").lower()
# the look of person-2d: micah (colourful) | avataaars (cartoon) | notionists (black-and-white line art, with hands);
# for PRO_PRESENTER=company: the avatar's name (its picture data/avatars/<name>.png)
PRO_AVATAR = _get("PRO_AVATAR", "micah").lower()
# the company's avatars (company_avatar.py): a picture each, <name>.png, and its marks <name>.json. Kept on
# this computer only (data/ is never committed or sent anywhere)
AVATARS_DIR = Path(_get("AVATARS_DIR", str(ROOT / "data" / "avatars")))
# the look of every video tool: main (each tool's own) | second (the same video drawn another way: other colours,
# another background and motion; for RENDERER=remotion the editorial look). The comparison makes both
VIDEO_LOOK = _get("VIDEO_LOOK", "main").lower()
# the look of RENDERER=remotion: classic (light cards) | editorial (warm paper, ink and coral: a drawn
# flow of nodes, counters, ledgers, a ring chart)
REMOTION_LOOK = _get("REMOTION_LOOK", "classic").lower()
# how many frames Remotion draws at once; 0 = half the processor cores. More = faster, needs more memory
REMOTION_CONCURRENCY = int(_get("REMOTION_CONCURRENCY", "0"))
# frames per second of Remotion videos: 30 = smoothest motion, 25 = ~17% faster to render
REMOTION_FPS = int(_get("REMOTION_FPS", "30"))
# how the browser draws 3D for remotion-pro: empty = its own choice (fast), or angle | egl | swiftshader | swangle
REMOTION_GL = _get("REMOTION_GL", "").lower()
THEME_ACCENT = _get("THEME_ACCENT", "#0b6e79")       # main colour of the slides
THEME_ACCENT_2 = _get("THEME_ACCENT_2", "#f2a541")   # second colour: numbers, highlights
# the company's brand (brand.py): put its logo, PowerPoint template (.pptx/.potx), font files and/or brand.json
# in this folder: the slides, presentations and videos take its colours, font and logo. auto = used when the
# folder has something in it; off = never. THEME_ACCENT in .env wins over the brand's colours
BRAND_DIR = Path(_get("BRAND_DIR", str(ROOT / "data" / "brand")))
BRAND = _get("BRAND", "auto").lower()
# presentation style when the request doesn't say: clean (simple and concrete), illustrated
# (with illustrations of people, offices, screens), presenter (a character presents the slides)
STYLE = _get("STYLE", "illustrated").lower()
# dialogue style: the voices of the two people (Kokoro voices; see uv run tts.py --voices)
HOST_VOICE = _get("HOST_VOICE", "af_heart")       # asks the questions
EXPERT_VOICE = _get("EXPERT_VOICE", "am_michael")  # explains
# presenter and dialogue styles: cartoon = a bear and a fox that talk (mouth moves with the voice),
# people = the drawn people (Humaaans)
CHARACTERS = _get("CHARACTERS", "cartoon").lower()
# the cartoon presenter (presenter style): bear | fox
CARTOON_PRESENTER = _get("CARTOON_PRESENTER", "bear").lower()
# yes = motion by GSAP (bundled in assets/gsap): word-by-word titles, overshoot, drawn lines; no = built-in motion
GSAP = _get("GSAP", "yes").lower() in ("yes", "true", "1")
# presenter style: a new picture of the presenter every N frames (1 = 25 per second, smooth; 2 = faster to render)
PRESENTER_STEP = max(1, int(_get("PRESENTER_STEP", "1")))
# AI pictures through the gateway (images.py); empty = built-in drawings (illustrations.py)
IMAGE_MODEL = _get("IMAGE_MODEL", "")
IMAGE_SIZE = _get("IMAGE_SIZE", "1024x1024")
IMAGE_PRICE_USD = float(_get("IMAGE_PRICE_USD", "0.04"))
TTS_ENGINE = _get("TTS_ENGINE", "kokoro").lower()
# silent slides (deck_video.py): no voice; each part of a scene is shown this long per word of its narration
SILENT_SECONDS_PER_WORD = float(_get("SILENT_SECONDS_PER_WORD", "0.22"))
# how to run Manim (deck_video.py --engines manim); empty = the project's Python if it has manim, else `manim`
MANIM_CMD = _get("MANIM_CMD", "")
# Lesson Studio (app.py): a password for the page when it is shared (empty = no password: this
# computer only)
APP_PASSWORD = _get("APP_PASSWORD", "")
# prices shown in Lesson Studio (Prices, Comparison) include this small safety margin in percent: close to
# the real cost, a little on the high side rather than the low
COST_MARGIN_PCT = max(0.0, float(_get("COST_MARGIN_PCT", "10")))
# How to say special terms (acronyms, product names): two columns term,say_as
PRONUNCIATION_FILE = ROOT / "pronunciation.csv"
TTS_VOICE = _get("TTS_VOICE", "af_heart")       # Kokoro voices: af_heart, af_sarah, am_michael, bf_emma ...
TTS_SPEED = float(_get("TTS_SPEED", "1.0"))
# Cloud voices (for comparison, benchmark.py). ElevenLabs: key from elevenlabs.io (free trial works,
# ~10 min of speech a month). Voice ids empty = picked from your account's voices automatically.
ELEVENLABS_API_KEY = _get("ELEVENLABS_API_KEY", "")
ELEVENLABS_BASE_URL = _get("ELEVENLABS_BASE_URL", "https://api.elevenlabs.io").rstrip("/")
ELEVENLABS_MODEL = _get("ELEVENLABS_MODEL", "eleven_multilingual_v2")
# voices: a name of a default ElevenLabs voice (lily, george, matilda ...; uv run tts.py --voices
# --engine elevenlabs) or a voice id; empty = lily (narrator), matilda (host), george (expert)
ELEVENLABS_VOICE = _get("ELEVENLABS_VOICE", "")
ELEVENLABS_HOST_VOICE = _get("ELEVENLABS_HOST_VOICE", "")
ELEVENLABS_EXPERT_VOICE = _get("ELEVENLABS_EXPERT_VOICE", "")
# How the voice sounds. stability: 0 = lively and varied .. 1 = steady (one lesson is spoken in many
# short parts, so a little steadier than ElevenLabs' 0.5 keeps them alike); similarity: how close to
# the original voice; style: extra expression (0 = none, steadier); seed: the same take every time
# (0 = random)
ELEVENLABS_STABILITY = float(_get("ELEVENLABS_STABILITY", "0.6"))
ELEVENLABS_SIMILARITY = float(_get("ELEVENLABS_SIMILARITY", "0.8"))
ELEVENLABS_STYLE = float(_get("ELEVENLABS_STYLE", "0.0"))
ELEVENLABS_SEED = int(_get("ELEVENLABS_SEED", "4242"))
# yes = every part is spoken knowing what comes before and after (request stitching): one flowing
# narration instead of separate sentences. no = each part on its own (the old way, to compare)
ELEVENLABS_CONTEXT = _get("ELEVENLABS_CONTEXT", "yes").lower() in ("yes", "true", "1")
# audio quality from ElevenLabs: mp3_44100_128 (every plan; as in their web app), mp3_44100_192 (Creator
# and up), pcm_44100 (Pro and up), pcm_24000 (smaller, duller)
ELEVENLABS_FORMAT = _get("ELEVENLABS_FORMAT", "mp3_44100_128").lower()
ELEVENLABS_USD_PER_1K_CHARS = float(_get("ELEVENLABS_USD_PER_1K_CHARS", "0.165"))   # Pro plan: $99 for 600,000 characters
ELEVENLABS_MONTHLY_CHARS = int(float(_get("ELEVENLABS_MONTHLY_CHARS", "10000")))   # plan limit (free: 10,000), usage.py
# price of the plan used for video by API (eleven_video.py: credits used x price per credit). Pro: $99 for 600,000
ELEVENLABS_PLAN_USD = float(_get("ELEVENLABS_PLAN_USD", "99"))
ELEVENLABS_PLAN_CREDITS = int(float(_get("ELEVENLABS_PLAN_CREDITS", "600000")))
VIDEO_WIDTH = int(_get("VIDEO_WIDTH", "1920"))  # 1920x1080 full HD (sharp text); 1280 renders faster
VIDEO_HEIGHT = VIDEO_WIDTH * 9 // 16
# frames per second of our videos (designer slides, cartoon and realistic presenters): 30 = smoother motion,
# 25 = about 20% faster to make
VIDEO_FPS = max(10, min(60, int(_get("VIDEO_FPS", "30"))))


def setup_logging(verbose: bool = False) -> None:
    """Same log format in every script: time, level, module, message."""
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )
    logging.getLogger("httpx").setLevel(logging.WARNING)  # hide one log line per HTTP request


# the company's colours (brand.py) instead of the default ones, unless THEME_ACCENT is set in .env
if BRAND != "off" and not (_get("THEME_ACCENT") or _get("THEME_ACCENT_2")):
    try:
        import brand as _brand
        THEME_ACCENT, THEME_ACCENT_2 = _brand.accents(THEME_ACCENT, THEME_ACCENT_2)
    except Exception:  # noqa: BLE001 - the brand is optional: the default colours stay
        pass
