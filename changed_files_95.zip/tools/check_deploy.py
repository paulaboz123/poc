"""
tools/check_deploy.py - check the deployment files before asking for the infrastructure: the CI pipeline, the
Helm chart and the dev values. Finds placeholders left in, values copied from another app, keys this chart does
not read, helper names that do not exist and names that do not match the release.

  uv run tools/check_deploy.py                          release name = the repository folder's name
  uv run tools/check_deploy.py --release proto-learning-agent

Exit code 0: no problems (warnings are printed but do not fail).
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
CHART = ROOT / "charts" / "proto-learning-lessons"
DEV = CHART / "values-dev-eks.yaml"
CI = ROOT / ".gitlab-ci.yml"

PLACEHOLDER = re.compile(r"<[^<>\n]*>|\bXXX\b|CHANGE-ME|\bTODO\b", re.I)
FOREIGN = re.compile(r"proto-invoic|frontend|backend", re.I)
HEADER = "X-Forwarded-Email"


class Report:
    def __init__(self) -> None:
        self.problems: list[str] = []
        self.warnings: list[str] = []

    def problem(self, where: str, text: str) -> None:
        self.problems.append(f"{where}: {text}")

    def warn(self, where: str, text: str) -> None:
        self.warnings.append(f"{where}: {text}")


def _load(path: Path, r: Report) -> dict:
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        r.problem(path.name, "file not found")
        return {}
    except yaml.YAMLError as e:
        r.problem(path.name, f"not valid YAML ({str(e).splitlines()[0]})")
        return {}
    return data if isinstance(data, dict) else {}


def _scan_text(path: Path, r: Report, foreign: re.Pattern = FOREIGN, placeholders: bool = True) -> None:
    """Placeholders and another app's names left in a file (comments ignored)."""
    for n, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        code = line.split(" #", 1)[0] if not line.lstrip().startswith("#") else ""
        if "{{" in code:
            continue
        if placeholders and PLACEHOLDER.search(code):
            r.problem(f"{path.name}:{n}", f"placeholder left in: {code.strip()}")
        m = foreign.search(code)
        if m:
            r.problem(f"{path.name}:{n}", f"'{m.group(0)}' looks copied from the other app: {code.strip()}")


def check_values(r: Report, release: str) -> None:
    base, dev = _load(CHART / "values.yaml", r), _load(DEV, r)
    if not dev:
        return
    _scan_text(DEV, r)
    for key in dev:
        if key not in base:
            r.problem(DEV.name, f"top-level key '{key}' is not read by this chart (keys: {', '.join(base)})")
    bif = dev.get("bifrost") or {}
    for key in ("baseUrl", "model"):
        if not bif.get(key):
            r.problem(DEV.name, f"bifrost.{key} is empty")
    if not (bif.get("apiKey") or {}).get("awsSecretName"):
        r.problem(DEV.name, "bifrost.apiKey.awsSecretName is empty")
    image = (dev.get("app") or {}).get("image") or {}
    if image.get("repository") or image.get("tag"):
        r.warn(DEV.name, "app.image is filled in: the pipeline writes it; keep it empty on main")
    for section in ("httpRoute", "auth", "bifrost", "app"):
        known = set(base.get(section) or {})
        for key in dev.get(section) or {}:
            if key not in known:
                r.problem(DEV.name, f"{section}.{key} is not read by this chart (keys: {', '.join(sorted(known))})")
    check_route(r, dev.get("httpRoute") or {}, release)
    oauth = dev.get("oauth2-proxy") or {}
    header = (dev.get("auth") or {}).get("proxyHeader", "")
    if oauth.get("enabled"):
        if header != HEADER:
            r.problem(DEV.name, f"auth.proxyHeader must be {HEADER} with oauth2-proxy (is '{header}')")
        check_oauth(r, oauth, release)
    elif not header and not (dev.get("extraSecret") or {}).get("awsSecretName"):
        r.problem(DEV.name, "no sign-in: enable oauth2-proxy or give APP_PASSWORD through extraSecret")


def check_route(r: Report, route: dict, release: str) -> None:
    if route.get("enabled"):
        if "gateway" in route:
            r.problem(DEV.name, "httpRoute.gateway is not read by this chart: rename it to parentRefs")
        refs = route.get("parentRefs")
        if not isinstance(refs, list) or not refs or not all(isinstance(x, dict) and x.get("name") for x in refs):
            r.problem(DEV.name, "httpRoute.parentRefs must be a list of {name, namespace, ...}")
        hosts = route.get("hostnames")
        if not isinstance(hosts, list) or not hosts:
            r.problem(DEV.name, "httpRoute.hostnames must be a list with the app's host")
        elif not any(release in h for h in hosts):
            r.warn(DEV.name, f"no hostname contains '{release}': {hosts}")


def check_oauth(r: Report, oauth: dict, release: str) -> None:
    text = yaml.safe_dump(oauth)
    secret = (oauth.get("config") or {}).get("existingSecret")
    if secret and secret != f"{release}-oauth2-proxy":
        r.warn(DEV.name, f"oauth2-proxy.config.existingSecret is '{secret}'; the chart's secret will be "
                         f"'{release}-oauth2-proxy' if it is named after the release")
    ups = re.findall(r"upstreams?[\"']?\s*[:=]\s*\[?\s*[\"']?(https?://[^\s\"',\]]+)", text)
    if not ups:
        r.warn(DEV.name, "no upstream found in oauth2-proxy (where the login sends people after sign-in)")
    for u in ups:
        if not re.match(rf"https?://{re.escape(release)}(:80)?(/|$)", u):
            r.problem(DEV.name, f"oauth2-proxy upstream '{u}' must be http://{release}:80 (this app's service)")
    for url in re.findall(r"https://[^\s\"',]+/oauth2/callback", text):
        if release not in url:
            r.problem(DEV.name, f"redirect URL '{url}' is not this app's host")
    deps = (_load(CHART / "Chart.yaml", r).get("dependencies")) or []
    if not any(isinstance(d, dict) and d.get("name") == "oauth2-proxy" for d in deps):
        r.problem("Chart.yaml", "oauth2-proxy is enabled but not in dependencies: copy the dependency block")


def check_templates(r: Report) -> None:
    folder = CHART / "templates"
    defined: set[str] = set()
    for f in folder.glob("*.tpl"):
        defined |= set(re.findall(r'define\s+"([^"]+)"', f.read_text(encoding="utf-8")))
    for f in sorted(folder.glob("*.yaml")):
        text = f.read_text(encoding="utf-8")
        for n, line in enumerate(text.splitlines(), 1):
            for name in re.findall(r'(?:include|template)\s+"([^"]+)"', line):
                if name not in defined:
                    r.problem(f"templates/{f.name}:{n}", f'helper "{name}" does not exist (use one of: '
                                                         f'{", ".join(sorted(defined))})')
        _scan_text(f, r, foreign=re.compile(r"proto-invoic", re.I), placeholders=False)


def check_ci(r: Report) -> None:
    ci = _load(CI, r)
    if not ci:
        return
    _scan_text(CI, r)
    var = ci.get("variables") or {}
    if str(var.get("CHART", "")).rstrip("/") != "charts/proto-learning-lessons":
        r.problem(CI.name, "variables.CHART must be charts/proto-learning-lessons")
    if str(var.get("VALUES_FILE", "")) != "charts/proto-learning-lessons/values-dev-eks.yaml":
        r.problem(CI.name, "variables.VALUES_FILE must be charts/proto-learning-lessons/values-dev-eks.yaml")
    defaults = {"PYTHON_IMAGE": "python:3.12-slim", "KANIKO_IMAGE": "gcr.io/kaniko-project/executor:v1.23.2-debug",
                "HELM_IMAGE": "alpine/helm:3.16.3"}
    for k, v in defaults.items():
        if var.get(k) == v:
            r.warn(CI.name, f"{k} is still the public default; use the team's image if runners cannot pull it")
    check_jobs(r, ci)
    for job in ("build-image", "update-dev-image-tag"):
        rules = str((ci.get(job) or {}).get("rules", ""))
        if job in ci and "AWS_ECR" not in rules:
            r.problem(CI.name, f"{job}: rules must wait for the ECR variable (&& $AWS_ECR_APP)")
    if "lint-chart" not in ci:
        r.warn(CI.name, "no lint-chart job: the chart is only checked once ECR exists")


def check_jobs(r: Report, ci: dict) -> None:
    build = ci.get("build-image") or {}
    if not build:
        r.problem(CI.name, "job build-image is missing")
    else:
        script = " ".join(build.get("script") or [])
        if not (build.get("id_tokens") or build.get("before_script")):
            r.problem(CI.name, "build-image has no ECR login (id_tokens / before_script from the team's kaniko "
                               "template)")
        for part in ('--destination "$IMAGE:$TAG"', "build.env"):
            if part not in script + yaml.safe_dump(build):
                r.problem(CI.name, f"build-image: '{part}' missing")
    bump = ci.get("update-dev-image-tag") or {}
    if not bump:
        r.problem(CI.name, "job update-dev-image-tag is missing")
    else:
        script = " ".join(bump.get("script") or [])
        if "helm dependency" not in script:
            r.problem(CI.name, "update-dev-image-tag: add `helm dependency build \"$CHART\"` before helm template")
        if "$TAG" not in script or "GITLAB_BUMP_TOKEN" not in script:
            r.problem(CI.name, "update-dev-image-tag is an older version (needs $TAG and GITLAB_BUMP_TOKEN)")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--release", default=ROOT.name, help="the release / Argo CD app name (default: the folder)")
    args = ap.parse_args(argv)
    r = Report()
    check_values(r, args.release)
    check_templates(r)
    check_ci(r)
    print(f"Release name: {args.release}\n")
    for p in r.problems:
        print(f"PROBLEM  {p}")
    for w in r.warnings:
        print(f"warning  {w}")
    if not r.problems:
        print("OK: no problems found" + (" (see the warnings)" if r.warnings else ""))
    return 1 if r.problems else 0


if __name__ == "__main__":
    sys.exit(main())
